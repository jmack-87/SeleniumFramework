package common_resources.enumerations;

public enum RandomOptions {

	RANDOMIZED,
	DEFAULT,
	;


}
