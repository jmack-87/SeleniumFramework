package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class RobNoTMXLogin {

	public static By Locator_Button_No = 					By.cssSelector("button#cancel");
	public static By Locator_Button_Submit = 				By.cssSelector("input#btnSubmit");
	public static By Locator_Button_Yes = 					By.cssSelector("button#accept");
//	public static By Locator_Image_LoadingDots = 			By.xpath(""); // no locator yet discovered
	public static By Locator_Link_Enroll = 					By.xpath("//a[contains(text(),'Enroll')]");
	public static By Locator_Link_ForgotYourPassword = 		By.xpath("//a[contains(@href,'forgotPwd')]");
	public static By Locator_Link_ForgotYourUserId = 		By.xpath("//a[contains(@href,'forgotUserID')]");
	public static By Locator_Link_ResendOTP = 				By.xpath("//span[contains(text(),'Resend now')]");
	public static By Locator_Link_UseDateOfBirth = 			By.xpath("//a[contains(text(),'Click to use your Date of Birth')]");
	public static By Locator_Link_UseSSN = 					By.cssSelector("input#inputSSN");
	public static By Locator_SubTitle_ResetYourPassword = 	By.xpath("//span[contains(text(),'Reset your Password')]");
	public static By Locator_SubTitle_RetreiveYourUserId = 	By.xpath("");
	public static By Locator_Text_CancelTranscation = 		By.xpath("//p[contains(text(),'Are you sure you wish to cancel the transaction')]");
	public static By Locator_Text_EnterOTP = 				By.xpath("/p[contains(text(),'charge for text messages sent')]");
	public static By Locator_Text_EnterUserIdBelow = 		By.xpath("//p[contains(text(),'Enter your Online Banking User ID below')]");
	public static By Locator_TextField_CardNumber = 		By.cssSelector("input#inputAccountCard");
	public static By Locator_TextField_DOB = 				By.cssSelector("input#inputDOB");
	public static By Locator_TextField_OTP = 				By.cssSelector("input#inputOTP");
	public static By Locator_TextField_SSN = 				By.cssSelector("input#inputSSN");
	public static By Locator_TextField_UserId = 			By.cssSelector("input#inputUserID");
	public static String Text_Url = 						"https://liferay2.sov.pre.corp/us/web/wcsanusa/personal/rolb-login";


//	Input_CardNumber("572622006315494016"),
//	Input_DOB("10/7/1997"),
//	Input_SSN("8659"),
//	Input_UserId("Sysadmax10"),
//	Locator_Button_No("RobNoTMXLogin.Locator.Button.No"),
//	Locator_Button_Submit("RobNoTMXLogin.Locator.Button.Submit"),
//	Locator_Button_Yes("RobNoTMXLogin.Locator.Button.Yes"),
//	Locator_Image_LoadingDots("RobNoTMXLogin.Locator.Image.LoadingDots"),
//	Locator_Link_Enroll("RobNoTMXLogin.Locator.Link.Enroll"),
//	Locator_Link_ForgotYourPassword("RobNoTMXLogin.Locator.Link.ForgotYourPassword"),
//	Locator_Link_ForgotYourUserId("RobNoTMXLogin.Locator.Link.ForgotYourUserId"),
//	Locator_Link_ResendOTP("RobNoTMXLogin.Locator.Link.ResendOTP"),
//	Locator_Link_UseDateOfBirth("RobNoTMXLogin.Locator.Link.UseDateOfBirth"),
//	Locator_Link_UseSSN("RobNoTMXLoginRobNoTMXLogin.Locator.Link.UseSSN"),
//	Locator_SubTitle_ResetYourPassword("RobNoTMXLogin.Locator.SubTitle.ResetYourPassword"),
//	Locator_SubTitle_RetrieveYourUserId("RobNoTMXLogin.Locator.SubTitle.RetrieveYourUserId"),
//	Locator_Text_CancelTranscation("RobNoTMXLogin.Locator.Text.CancelTranscation"),
//	Locator_Text_EnterOTP("RobNoTMXLogin.Locator.Text.EnterOTP"),
//	Locator_Text_EnterUserIdBelow("RobNoTMXLogin.Locator.Text.EnterUserIdBelow"),
//	Locator_TextField_CardNumber("RobNoTMXLogin.Locator.TextField.CardNumber"),
//	Locator_TextField_DOB("RobNoTMXLogin.Locator.TextField.DOB"),
//	Locator_TextField_OTP("RobNoTMXLogin.Locator.TextField.OTP"),
//	Locator_TextField_SSN("RobNoTMXLogin.Locator.TextField.SSN"),
//	Locator_TextField_UserId("RobNoTMXLogin.Locator.TextField.UserId"),
//	Text_URL("RobNoTMXLogin.Text.URL"),


//	RobNoTMXLogin.Locator.Button.No=button#cancel@@@css
//	RobNoTMXLogin.Locator.Button.Submit=input#btnSubmit@@@css
//	RobNoTMXLogin.Locator.Button.Yes=button#accept@@@css
//	RobNoTMXLogin.Locator.Link.Enroll=//a[contains(text(),'Enroll')]@@@xpath
//	RobNoTMXLogin.Locator.Link.ForgotYourPassword=//a[contains(@href,'forgotPwd')]@@@xpath
//	RobNoTMXLogin.Locator.Link.ForgotYourUserId=//a[contains(@href,'forgotUserID')]@@@xpath
//	RobNoTMXLogin.Locator.Link.ResendOTP=//span[contains(text(),'Resend now')]@@@xpath
//	RobNoTMXLogin.Locator.Link.UseDateOfBirth=//a[contains(text(),'Click to use your Date of Birth')]@@@xpath
//	RobNoTMXLogin.Locator.Link.UseSSN=//a[contains(text(),'Click to use your SSN')]@@@xpath
//	RobNoTMXLogin.Locator.SubTitle.ResetYourPassword=//span[contains(text(),'Reset your Password')]@@@xpath
//	RobNoTMXLogin.Locator.SubTitle.RetrieveYourUserId=//span[contains(string(),"Retrieve your User ID")]@@@xpath
//	RobNoTMXLogin.Locator.Text.CancelTranscation=//p[contains(text(),'Are you sure you wish to cancel the transaction')]@@@xpath
//	RobNoTMXLogin.Locator.Text.EnterOTP=//p[contains(text(),'charge for text messages sent')]@@@xpath
//	RobNoTMXLogin.Locator.Text.EnterUserIdBelow=//p[contains(text(),'Enter your Online Banking User ID below')]@@@xpath
//	RobNoTMXLogin.Locator.TextField.CardNumber=input#inputAccountCard@@@css
//	RobNoTMXLogin.Locator.TextField.DOB=input#inputDOB@@@css
//	RobNoTMXLogin.Locator.TextField.OTP=input#inputOTP@@@css
//	RobNoTMXLogin.Locator.TextField.SSN=input#inputSSN@@@css
//	RobNoTMXLogin.Locator.TextField.UserId=input#inputUserID@@@css
//	RobNoTMXLogin.Text.URL=https://liferay2.sov.pre.corp/us/web/wcsanusa/personal/rolb-login


}
