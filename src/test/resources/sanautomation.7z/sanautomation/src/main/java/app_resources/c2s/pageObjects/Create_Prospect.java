package app_resources.c2s.pageObjects;

import org.openqa.selenium.By;

public class Create_Prospect {
	
    public static By Locator_CreateProspect_Button =				By.xpath("//div[@class='customerSearch-notselected'][@id='prospectTab']");
	public static By Locator_AddProspect_Button =					By.xpath("//div[@id='customer-search-results']/div[1]/div/div[@ng-click='addProspect()']/span");
	public static By Locator_ConsumerType_Dropdown =				By.xpath("//select[@class='ng-pristine ng-valid ng-valid-required'][@ng-model='selectedCustomerType'][@ng-change='toggleCustomerType()']");
	public static int Text_ConsumerType_Index = 					1;
	public static int Text_ConsumerType_Value = 					1;
	public static By Locator_DocumentType_Dropdown = 				By.xpath("//select[@class='ng-pristine ng-valid'][@ng-model='selectedDocumentType']");
	public static int Text_DocumentType_Index = 					0;				
	public static By Locator_DocumentNumber_TextField = 			By.xpath("//input[@name='docNum'][@class='ng-pristine ng-valid-pattern ng-valid ng-valid-required ng-valid-duplicate-prospect ng-valid-duplicate-customer'][@ng-model='prospect.docNum']");
	public static By Locator_BusinessName_TextField = 				By.xpath("//input[@name='businessName'][@class='ng-pristine ng-invalid ng-invalid-required']");
	public static By Locator_IndustryType_TextField = 				By.xpath("//input[@name='industry'][@class='ng-pristine ng-valid']");
	public static By Locator_ContactNumber_TextField = 				By.xpath("//input[@name='contactData'][@id='prospectHomePhone']");
	public static By Locator_AddressType_Dropdown = 				By.xpath("//select[@class='ng-pristine ng-valid'][@ng-model='prospect.address.format'][@ng-change='resetAddress()']");
	public static By Locator_AddressTypeAfterSelected_Dropdown = 	By.xpath("//select[@class='ng-valid ng-dirty'][@ng-model='prospect.address.format'][@ng-change='resetAddress()']");
	public static int Text_AddressType_Index = 						1;
	public static int Text_AddressType_Value = 						0;
	public static By Locator_StreetNo_TextField = 					By.xpath("//input[@name='number']");
	public static By Locator_StreetName_TextField = 				By.xpath("//input[@name='street']");
	public static By Locator_CityName_TextField = 					By.xpath("//input[@name='city']");
	public static By Locator_State_Dropdown = 						By.xpath("//select[@name='state'][@ng-model='prospect.address.state'][@class='ng-pristine ng-invalid ng-invalid-required']");
	public static int Text_State_Index = 							6;
	public static By Locator_StateAfterSelected_Dropdown = 			By.xpath("//select[@name='state'][@ng-model='prospect.address.state'][@class='ng-dirty ng-valid ng-valid-required']");
	public static By Locator_Zipcode_TextField = 					By.xpath("//input[@name='zipCode']");
	public static By Locator_AdditionalInfo_Button = 				By.xpath("//button[contains(text(),'Add Additional Information')][@type='submit']");
	public static By Locator_Email_TextField = 						By.xpath("//input[@class='ng-pristine ng-valid-email ng-valid ng-valid-required'][@name='editEmailcontactData'][@type='email'][@ng-model='prospect.contact.email']");
	public static By Locator_SaveExit_Button = 						By.xpath("//div[@id='submitProspect']/button[2]");
	public static By Locator_FirstName_TextField = 					By.xpath("//input[@name='firstName'][@class='ng-pristine ng-invalid ng-invalid-required']");
	public static By Locator_LastName_TextField = 					By.xpath("//input[@name='lastName'][@class='ng-pristine ng-invalid ng-invalid-required']");
	public static By Locator_BirthDate_TextField = 					By.xpath("//input[@name='txtBirthDateProspect'][@id='txtBirthDateProspect']");
	public static By Locator_EmploymentStatusClean_DropDown = 		By.xpath("//select[@class='ng-pristine ng-valid'][@ng-model='prospect.empStatus']");
	public static By Locator_EmploymentStatusDirty_DropDown = 		By.xpath("//select[@class='ng-valid ng-dirty'][@ng-model='prospect.empStatus']");
	public static int Text_EmploymentStatus_Index = 				1;
	public static By Locator_Occupation_TextField = 				By.xpath("//input[@name='occupation'][@class='ng-pristine ng-valid ng-valid-required']");
	public static String Text_OccupationText_Value = 				"FISHERMAN";
	public static By Locator_DropDownOption_OccupationListFirst = 	By.xpath("//ul[@class='dropdown-menu ng-isolate-scope'][@select='select(activeIdx)']/li/a");
	public static By Locator_Button_SaveAndExitConsumer = 			By.xpath("//div[@id='submitProspect']/button[3]");
	public static By Locator_RadioButton_ProspectNotInPerson = 		By.xpath("//div[@class='authQuestion authenHang'][@ng-show='isCustomerInPersonShow']/div[3]/img");
	public static By Locator_Text_FNumber = 						By.xpath("//div[@class='profileInlineDiv'][@id='customerNumber']/p");

}
