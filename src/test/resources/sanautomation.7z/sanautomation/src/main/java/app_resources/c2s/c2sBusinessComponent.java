package app_resources.c2s;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import app_resources.c2s.pageObjects.Create_Prospect;
import app_resources.c2s.pageObjects.KYCPage;
import app_resources.c2s.pageObjects.LoginPage;
import app_resources.c2s.pageObjects.ONEDashboard;
import app_resources.c2s.pageObjects.PersonalDataPage;
import app_resources.c2s.pageObjects.PrintingAndSummary;
import app_resources.c2s.pageObjects.ProductSelection;
import app_resources.c2s.pageObjects.QualificationPage;
import app_resources.c2s.pageObjects.SearchPage;
import common_resources.utility;

/*
    *Author: Nayan Bhavsar
    *Description: All Subscribe related functions
    *date:
*/

public class c2sBusinessComponent extends utility {

    public void fnC2SLogin(String struserid, String strpassword)
    {
    	
    	this.sendText(LoginPage.Locator_Textfield_UserId, struserid);
    	
    	this.sendText(LoginPage.Locator_Textfield_Password, strpassword);
    	
    	this.clickElement(LoginPage.Locator_Button_Submit);
    	
    }
    
    /**
	 * This method will open the ONE side bar and search for a customer by name
	 */
	public void searchRetailCustomer(String firstName, String lastName) {
		
		this.waitForPageLoaded();
		
		// Open Side Bar
		this.clickElement(SearchPage.Locator_Img_SearchLink, 120);
		
		// Set dropdown to search name
		this.setDropdownByIndex(SearchPage.Locator_DropDown_SearchName, SearchPage.Text_Name_Index);
		
		// Set dropdown to search consumers
		this.setDropdownByIndex(SearchPage.Locator_DropDown_SearchBusiness, SearchPage.Text_BusinessDropDown_ConsumerIndex);
		
		// set dropdown for seach to return only equal values
		this.setDropdownByIndex(SearchPage.Locator_DropDown_SearchInclusive, SearchPage.Text_Equals_Index);
		
		// Enter First name
		this.clickElement(SearchPage.Locator_TextField_ConsumerFirstName);
		this.sendText(SearchPage.Locator_TextField_ConsumerFirstName, firstName);
		
		// Enter Last name
		this.clickElement(SearchPage.Locator_TextField_ConsumerLastName);
		this.sendText(SearchPage.Locator_TextField_ConsumerLastName, lastName);
		
		// Click Submit
		this.clickElement(SearchPage.Locator_Button_Submit);
		
	}
	
	/**
	 * This method will open the ONE side bar and search for a customer by name for an existing consumer
	 */
	public void searchExistingRetailCustomer(String firstName, String lastName, String fNumber) {

		this.waitForPageLoaded();
		
		// Open Side Bar
		this.clickElement(SearchPage.Locator_Img_SearchLink);
		
		// Set dropdown to search name
		this.setDropdownByIndex(SearchPage.Locator_DropDown_SearchName,SearchPage.Text_Name_Index);
		
		// Set dropdown to search consumers
		this.setDropdownByIndex(SearchPage.Locator_DropDown_SearchBusiness, SearchPage.Text_BusinessDropDown_ConsumerIndex);
		
		// set dropdown for seach to return only equal values
		this.setDropdownByIndex(SearchPage.Locator_DropDown_SearchInclusive,SearchPage.Text_Equals_Index);
		
		// Enter First name
		this.clickElement(SearchPage.Locator_TextField_ConsumerFirstName);
		this.sendText(SearchPage.Locator_TextField_ConsumerFirstName, firstName);
		
		// Enter Last name
		this.clickElement(SearchPage.Locator_TextField_ConsumerLastName);
		this.sendText(SearchPage.Locator_TextField_ConsumerLastName, lastName);
		
		// Click Submit
		this.clickElement(SearchPage.Locator_Button_Submit);
		
		// Select resulting consumer by F-Number
		this.clickElement(By.cssSelector(SearchPage.CompoundLocator_Text_SearchEntryByFNumber.replace("~~~", fNumber)));
		
		
	}
	
	/**
	 * Randomize the input data to make user unique
	 */
	public void randomizeInputDataConsumer(HashMap<String, String> testData) {
		
		// Take Seed First name from Runtime data and add 5 Random Characters to the end
		testData.put("searchFirstName", testData.get("searchFirstName") + fnRandomString(5));
		
		// Take Seed First name from Runtime data and add 5 Random Characters to the end
		testData.put("searchLastName", testData.get("searchLastName") + fnRandomString(5));
		
		// Generate a Random SSN starting with "387" to ensure no errors with SSN
		while(testData.get("documentNumber").length() != 9) {
			testData.put("documentNumber", "387" + fnRandomNumber(6));
		}
		
		// Generate a Random Phone Number
		while(testData.get("contactNumber").length() != 10) {
			testData.put("contactNumber", "1" + fnRandomNumber(9));
		}
	}
	
	/*
	 * Method: getRandomDate
	 * param: input date String in mm/dd/yyyy format
	 * result: date string in mmm/dd/yyyy format
	 */
	public static String getALegalBirthDate()  {
	
		String format;
		String month = "" + LocalDate.now().getMonthValue();
		String day = "" + LocalDate.now().minusDays(24).getDayOfMonth();
		String year = "" + LocalDate.now().minusYears(20).getYear();
		
		format = "" + month + "/" + day + "/" + year;
		
		return format;
		
	}
	
	/**
	 * This method navigates from the search side-bar to the create prospect form
	 */
	public void addProspect() {
		
		this.waitForPageLoaded(10);
		
		// Once seaching is complete, select prospect and click add prospect button
		this.clickElement(Create_Prospect.Locator_CreateProspect_Button);
		this.clickElement(Create_Prospect.Locator_AddProspect_Button);
	}
	
	/**
	 * This method inputs date into the Prospects form for Consumers, then continues the process.
	 */
	public void enterProspectInformationConsumer(HashMap<String, String> testData) {
			
		this.waitForPageLoaded(10);
		
		// Enter SSN 
		this.sendText(Create_Prospect.Locator_DocumentNumber_TextField, testData.get("documentNumber"));
		
		// Enter name
		this.sendText(Create_Prospect.Locator_FirstName_TextField, testData.get("searchFirstName"));
		this.sendText(Create_Prospect.Locator_LastName_TextField, testData.get("searchLastName"));
		
		// Enter Birthdate
		this.sendText(Create_Prospect.Locator_BirthDate_TextField, getALegalBirthDate());
		
		// Select employed from Dropdown
		this.setDropdownByIndex(Create_Prospect.Locator_EmploymentStatusClean_DropDown, Create_Prospect.Text_EmploymentStatus_Index, Create_Prospect.Locator_EmploymentStatusDirty_DropDown);
		
		System.out.println("Done with dropdown");
		
		// Enter Occupation
		this.sendText(Create_Prospect.Locator_Occupation_TextField, testData.get("occupation"));
		
		this.clickElement(Create_Prospect.Locator_DropDownOption_OccupationListFirst);
		
		// Enter Phone number
		this.sendText(Create_Prospect.Locator_ContactNumber_TextField, testData.get("contactNumber"));
		
		// Select Address type from Dropdown
		this.setDropdownByIndex(Create_Prospect.Locator_AddressType_Dropdown, Create_Prospect.Text_AddressType_Index, Create_Prospect.Locator_AddressTypeAfterSelected_Dropdown);
		
		// Enter address
		this.sendText(Create_Prospect.Locator_StreetNo_TextField, testData.get("streetNum"));
		this.sendText(Create_Prospect.Locator_StreetName_TextField, testData.get("streetName"));
		this.sendText(Create_Prospect.Locator_CityName_TextField, testData.get("city"));
		this.setDropdownByVisibleText(Create_Prospect.Locator_State_Dropdown, testData.get("State"), Create_Prospect.Locator_StateAfterSelected_Dropdown);
		this.sendText(Create_Prospect.Locator_Zipcode_TextField, testData.get("zipCode"));
		
		// Click Save and Exit
		this.clickElement(Create_Prospect.Locator_Button_SaveAndExitConsumer);

	}
		
	/**
	 * This method grabs the F-Number of the new prospect and outputs it as a log entry
	 */
	public String getFNumberFromLandingPage() {
		WebElement we;
		String fNumber;
		
		this.waitForPageLoaded();
		
		// Confirm F-Number is on screen
		we = this.confirmElementExistence(Create_Prospect.Locator_Text_FNumber, 120);
		
		// Get the Text of the Element to pickup assigned F-Number
		fNumber = we.getText();
		
		return fNumber;
		
	}
	
	/**
	 * This method navigates from the Consumer page to open accounts
	 */
	public void goToOpenAccounts() {
		WebElement we;
		
		this.waitForPageLoaded();
		
		// Open the Add accounts Menu
		we = this.confirmElementExistence(PersonalDataPage.Locator_Image_AddAccounts, 120);
		this.clickElementWhenInteractable(we, 30);
		
		// Select Open account
		this.clickElement(PersonalDataPage.Locator_DropDownOption_OpenAccount);
		
		// Select Deposit accounts
		this.clickElement(PersonalDataPage.Locator_DropDownOption_DepositAccounts);
		this.waitForPageLoaded();
		
	}
	
	/**
	 * This method navigates from the Consumer page to open accounts for an Existing Customer
	 */
	public void returnToOpenAccounts() {
		WebElement we;
		
		this.waitForPageLoaded();
		
		// Open the Add accounts Menu
		we = this.confirmElementExistence(PersonalDataPage.Locator_Image_CustomerActionsAccount);
		this.clickElementWhenInteractable(we, 30);
		
		// Select Open account
		this.clickElement(PersonalDataPage.Locator_DropDownOption_OpenAccount);
		
		// Select Deposit accounts
		this.clickElement(PersonalDataPage.Locator_DropDownOption_DepositAccounts);
		this.waitForPageLoaded();
		
	}
	
	/**
	 * This method searches for an existing customer
	 */
	public void searchExistingCustomer(String docNum) {
		
		// Confirn that the SSN Search box is present
		this.confirmElementExistence(PersonalDataPage.Locator_TextField_SSNSearchBox, 120);
		
		// Enter SSN into the Text Field
		this.sendText(PersonalDataPage.Locator_TextField_SSNSearchBox, docNum);
		
		// Click the Existing Customer Check button
		this.clickElement(PersonalDataPage.Locator_Button_ExistingCustomerCheck);
		
		// Click on the results with correct name
		this.clickElement(PersonalDataPage.Locator_Text_NameInList);
		this.waitForPageLoaded();
		
		// Check that the Personal Data Header is displayed before moving forward
		this.confirmElementExistence(PersonalDataPage.Locator_Text_PersonalDataHeader, 120);
		
	}
	
	/**
	 * This method completes the personal data form
	 */
	public void completePersonalDataForm(String emailID, String employer, String state, String documentNumber) {
		WebElement we;
		
		this.clickElementWhenInteractable(confirmElementExistence(PersonalDataPage.Locator_TextField_PersonalDataEmail), 30);
		
		// Fill in Email address
		this.sendText(PersonalDataPage.Locator_TextField_PersonalDataEmail, 
				emailID);
		
		//click validate address
		this.clickElement(PersonalDataPage.Locator_Button_ValidateAddress);
		this.confirmElementExistence(PersonalDataPage.Locator_Text_NewAddressesTitle);
		
		// Click to continue without validation. Moved down to avoid timing issues
		we = this.confirmElementExistence(PersonalDataPage.Locator_Button_ContinueWithoutValidatingButton);
		this.clickElementWhenInteractable(we, 60);
		
		// Select Additional Personal Information
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_CountryOfBirthClean, 
				PersonalDataPage.Text_Index_AddtionalPersonalInfoIndex, 
				PersonalDataPage.Locator_DropDown_CountryOfBirthDirty);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_CountryOfResidence, 
				PersonalDataPage.Text_Index_AddtionalPersonalInfoIndex,
				PersonalDataPage.Locator_DropDown_CountryOfResidence);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_Citizenship, 
				PersonalDataPage.Text_Index_AddtionalPersonalInfoIndex,
				PersonalDataPage.Locator_DropDown_Citizenship);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_ResidentTaxStatusClean, 
				PersonalDataPage.Text_Index_AddtionalPersonalInfoIndex,
				PersonalDataPage.Locator_DropDown_ResidentTaxStatusDirty);
		
		// Enter employer information
		this.sendText(PersonalDataPage.Locator_TextField_EmployerNameField, 
				employer);
		
		// Enter Primary ID information
		this.clickElement(PersonalDataPage.Locator_Tab_PrimaryOtherID);
		this.confirmElementExistence(PersonalDataPage.Locator_DropDown_PrimaryOtherIDType, 120);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryOtherIDType, 
				PersonalDataPage.Text_Index_AmishIDType);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_IssueCountry, 
				PersonalDataPage.Text_Index_PrimaryID_IssueCountryIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_IssueDateMonth, 
				PersonalDataPage.Text_Index_PrimaryIDIssueDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_IssueDateDay, 
				PersonalDataPage.Text_Index_PrimaryIDIssueDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_IssueDateYear, 
				PersonalDataPage.Text_Index_PrimaryIDIssueDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_ExpireDateMonth, 
				PersonalDataPage.Text_Index_PrimaryIDExpireDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_ExpireDateDay, 
				PersonalDataPage.Text_Index_PrimaryIDExpireDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_ExpireDateYear, 
				PersonalDataPage.Text_Index_PrimaryIDExpireDateIndex);
		this.setDropdownByVisibleText(PersonalDataPage.Locator_DropDown_PrimaryID_StateIssued, 
				state);
		
		//Enter Secondary ID information
		this.clickElement(PersonalDataPage.Locator_Tab_SecondaryMedicalID);
		we = this.confirmElementExistence(PersonalDataPage.Locator_TextField_SecondaryIDNumber);
		this.clickElementWhenInteractable(we, 60);
		this.sendText(PersonalDataPage.Locator_TextField_SecondaryIDNumber, 
				documentNumber);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_SecondaryIssueCountry,
				PersonalDataPage.Text_Index_SecondaryIssueCountryIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_SecondaryID_IssueDateMonth, 
				PersonalDataPage.Text_Index_SecondaryIDIssueDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_SecondaryID_IssueDateDay, 
				PersonalDataPage.Text_Index_SecondaryIDIssueDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_SecondaryID_IssueDateYear, 
				PersonalDataPage.Text_Index_SecondaryIDIssueDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_Secondary_ExpireDateMonth, 
				PersonalDataPage.Text_Index_SecondaryIDExpireDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_Secondary_ExpireDateDay, 
				PersonalDataPage.Text_Index_SecondaryIDExpireDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_Secondary_ExpireDateYear, 
				PersonalDataPage.Text_Index_SecondaryIDExpireDateIndex);
		this.setDropdownByVisibleText(PersonalDataPage.Locator_DropDown_Secondary_StateIssued, 
				state);
		
		// Click Qualification Button
		this.clickElement(PersonalDataPage.Locator_Button_GoToQualification);
		this.waitForPageCompletelyLoaded(180);
		
		
	}
	
	/**
	 * This method Completes the Primary and Secondary ID's for an Existing Customer
	 */
	public void completeIDCaptures(String state, String documentNumber) {
		WebElement we;
		
		// Enter Primary ID information
		this.clickElement(PersonalDataPage.Locator_Tab_PrimaryOtherID);
		this.waitForPageLoaded(60);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryOtherIDType, 
				PersonalDataPage.Text_Index_AmishIDType);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_IssueCountry, 
				PersonalDataPage.Text_Index_PrimaryID_IssueCountryIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_IssueDateMonth, 
				PersonalDataPage.Text_Index_PrimaryIDIssueDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_IssueDateDay, 
				PersonalDataPage.Text_Index_PrimaryIDIssueDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_IssueDateYear, 
				PersonalDataPage.Text_Index_PrimaryIDIssueDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_ExpireDateMonth, 
				PersonalDataPage.Text_Index_PrimaryIDExpireDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_ExpireDateDay, 
				PersonalDataPage.Text_Index_PrimaryIDExpireDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_PrimaryID_ExpireDateYear, 
				PersonalDataPage.Text_Index_PrimaryIDExpireDateIndex);
		this.setDropdownByVisibleText(PersonalDataPage.Locator_DropDown_PrimaryID_StateIssued, 
				state);
				
		//Enter Secondary ID information
		this.clickElement(PersonalDataPage.Locator_Tab_SecondaryMedicalID);
		we = this.confirmElementExistence(PersonalDataPage.Locator_TextField_SecondaryIDNumber);
		this.clickElementWhenInteractable(we, 30);
		this.sendText(PersonalDataPage.Locator_TextField_SecondaryIDNumber, 
				documentNumber);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_SecondaryIssueCountry,
				PersonalDataPage.Text_Index_SecondaryIssueCountryIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_SecondaryID_IssueDateMonth, 
				PersonalDataPage.Text_Index_SecondaryIDIssueDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_SecondaryID_IssueDateDay, 
				PersonalDataPage.Text_Index_SecondaryIDIssueDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_SecondaryID_IssueDateYear, 
				PersonalDataPage.Text_Index_SecondaryIDIssueDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_Secondary_ExpireDateMonth, 
				PersonalDataPage.Text_Index_SecondaryIDExpireDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_Secondary_ExpireDateDay, 
				PersonalDataPage.Text_Index_SecondaryIDExpireDateIndex);
		this.setDropdownByIndex(PersonalDataPage.Locator_DropDown_Secondary_ExpireDateYear, 
				PersonalDataPage.Text_Index_SecondaryIDExpireDateIndex);
		this.setDropdownByVisibleText(PersonalDataPage.Locator_DropDown_Secondary_StateIssued, 
				state);
				
		// Got to Product Selection
		this.clickElement(QualificationPage.Locator_Button_GoToProducts, 60);
		
	}
	
	/**
	 * This method passes the qualification of a customer or prospect regardless of system results
	 * 
	 * @param fNumber (String)
	 * @param documentNumber (String)
	 * @param contactNumber (String) 
	 * @param employer (String)
	 * @param occupation (String)
	 * 
	 */
	public void passQualificationForm(String fNumber, String documentNumber, String contactNumber, String employer, String occupation) {
		WebElement we;
		
		// Validate F-Number is displayed Correctly
		we = this.confirmElementExistence(QualificationPage.Locator_Text_CustomerNumber);
		ss.assertTrue(we.getText().contains(fNumber));
		
		// Validate SSN is displayed Correctly
		we = this.confirmElementExistence(QualificationPage.Locator_Text_DocumentNumber);
		ss.assertTrue(we.getText().replace("-", "").contains(documentNumber));
		
		// Validate Phone Number is displayed Correctly
		we = this.confirmElementExistence(QualificationPage.Locator_Text_HomePhone);
		ss.assertTrue(we.getText().replace("-", "").contains(contactNumber));
		
		// Validate Employer is displayed Correctly
		we = this.confirmElementExistence(QualificationPage.Locator_Text_Employer);
		ss.assertTrue(we.getText().equalsIgnoreCase(employer));
		
		// Validate Occupation is displayed Correctly
		we = this.confirmElementExistence(QualificationPage.Locator_Text_Occupation);
		ss.assertTrue(we.getText().equalsIgnoreCase(occupation));
		
		// Once Validation is complete move to product selection
		we = this.confirmElementExistence(QualificationPage.Locator_Button_GoToProducts);
		this.clickElementWhenInteractable(we, 30);

		
	}
	
		/**
		 * This method selects the Basic checking product
		 */
		public void chooseBasicChecking() {
			WebElement we;
			int i = 0;
			String randomAccount;
			
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Checking Slider
			this.clickElement(ProductSelection.Locator_Checkbox_CheckingSlider);
			
			// Select Basic Checking
			we = this.confirmElementExistence(ProductSelection.Locator_Checkbox_BasicCheckingBox, 90);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation, 90);
			this.clickElementWhenInteractable(we, 90);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeChecking);
			this.clickElementWhenInteractable(we, 30);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Attempt to find a suitable Checking Account Number and continue
			while(this.waitForElementToBecomeNull(ProductSelection.Locator_Button_ContinueToNextStep, 30) instanceof WebElement && i < 30) {
				randomAccount = "" + this.fnRandomNumber(10);
				this.sendText(ProductSelection.Locator_TextField_AccountNumber, randomAccount);
				this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
				i++;
				this.waitForPageCompletelyLoaded(120);
			}
			
			// Fail Test if one is not found in a reasonable amounts of attempts
			if(i == 30) {
				ss.fail("Tried 30 times to find an account number but was unsuccessful.");
			}
			
		}
		
		/**
		 * This method selects the Premier Plus checking product
		 */
		public void choosePremierPlusChecking() {
			WebElement we;
			int i = 0;
			String randomAccount;

			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Checking Slider
			this.clickElement(ProductSelection.Locator_Checkbox_CheckingSlider);
			
			// Select Premier Plus Checking
			this.confirmElementExistence(ProductSelection.Locator_Checkbox_PremierPlusCheckingBox);
			this.clickElement(ProductSelection.Locator_Checkbox_PremierPlusCheckingBox);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeChecking);
			this.clickElementWhenInteractable(we, 30);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Attempt to find a suitable Checking Account Number and continue
			while(this.waitForElementToBecomeNull(ProductSelection.Locator_Button_ContinueToNextStep, 30) instanceof WebElement && i < 30) {
				randomAccount = "" + this.fnRandomNumber(10);
				this.sendText(ProductSelection.Locator_TextField_AccountNumber, randomAccount);
				this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
				i++;
				this.waitForPageLoaded();
			}
			
			if(i == 30) {
				ss.fail("Tried 30 times to find an account number but was unsuccessful.");
			}
			
		}
		
		/**
		 * This method selects the Basic checking and savings product
		 */
		public void chooseBasicCheckingAndSavings() {
			WebElement we;
			int i = 0;
			String randomAccount;
			
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Checking and Savings Slider
			this.clickElement(ProductSelection.Locator_Checkbox_CheckingAndSavingsSlider);
			
			// Select Basic Checking and Savings
			this.confirmElementExistence(ProductSelection.Locator_Checkbox_BasicCheckingBox);
			this.clickElement(ProductSelection.Locator_Checkbox_BasicCheckingBox);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeChecking);
			this.clickElementWhenInteractable(we, 30);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Attempt to find a suitable Checking Account Number and continue
			while(this.waitForElementToBecomeNull(ProductSelection.Locator_Button_ContinueToNextStep, 30) instanceof WebElement && i < 30) {
				randomAccount = "" + this.fnRandomNumber(10);
				this.sendText(ProductSelection.Locator_TextField_AccountNumber, randomAccount);
				this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
				i++;
				this.waitForPageLoaded();
			}
			
			if(i == 30) {
				ss.fail("Tried 30 times to find an account number but was unsuccessful.");
			}
			
		}
		
		/**
		 * This method selects the Premier Plus checking and savings product
		 */
		public void choosePremierPlusCheckingAndSavings() {
			WebElement we;
			int i = 0;
			String randomAccount;
				
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Checking and Savings Slider
			this.clickElement(ProductSelection.Locator_Checkbox_CheckingAndSavingsSlider);
			
			// Select Premier Plus Checking and Savings
			this.confirmElementExistence(ProductSelection.Locator_Checkbox_PremierPlusCheckingBox);
			this.clickElement(ProductSelection.Locator_Checkbox_PremierPlusCheckingBox);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeChecking);
			this.clickElementWhenInteractable(we, 30);
			this.clickElement(ProductSelection.Locator_Button_OverDraftProtectionSomeSavingsWithChecking);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Attempt to find a suitable Checking Account Number and continue
			while(this.waitForElementToBecomeNull(ProductSelection.Locator_Button_ContinueToNextStep, 30) instanceof WebElement && i < 30) {
				randomAccount = "" + this.fnRandomNumber(10);
				this.sendText(ProductSelection.Locator_TextField_AccountNumber, randomAccount);
				this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
				i++;
				this.waitForPageLoaded();
			}
			
			if(i == 30) {
				ss.fail("Tried 30 times to find an account number but was unsuccessful.");
			}
				
		}

		/**
		 * This method selects the Select checking and savings product
		 */
		public void chooseSelectCheckingAndSavings() {
			WebElement we;
			int i = 0;
			String randomAccount;
			
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Checking and Savings Slider
			this.clickElement(ProductSelection.Locator_Checkbox_CheckingAndSavingsSlider);
			
			// Choose Select Checking and Savings
			this.confirmElementExistence(ProductSelection.Locator_Checkbox_SelectCheckingBox);
			this.clickElement(ProductSelection.Locator_Checkbox_SelectCheckingBox);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeChecking);
			this.clickElementWhenInteractable(we, 30);
			this.clickElement(ProductSelection.Locator_Button_OverDraftProtectionSomeSavingsWithChecking);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Attempt to find a suitable Checking Account Number and continue
			while(this.waitForElementToBecomeNull(ProductSelection.Locator_Button_ContinueToNextStep, 30) instanceof WebElement && i < 30) {
				randomAccount = "" + this.fnRandomNumber(10);
				this.sendText(ProductSelection.Locator_TextField_AccountNumber, randomAccount);
				this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
				i++;
				this.waitForPageLoaded();
			}
			
			if(i == 30) {
				ss.fail("Tried 30 times to find an account number but was unsuccessful.");
			}
			
		}
		
		/**
		 * This method selects the Simply Right checking and savings product
		 */
		public void chooseSimplyRightCheckingAndSavings() {
			WebElement we;
			int i = 0;
			String randomAccount;
			
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Checking and Savings Slider
			this.clickElement(ProductSelection.Locator_Checkbox_CheckingAndSavingsSlider);
			
			// Select Simply Right Checking and Savings
			this.confirmElementExistence(ProductSelection.Locator_Checkbox_SimplyRightCheckingBox);
			this.clickElement(ProductSelection.Locator_Checkbox_SimplyRightCheckingBox);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeChecking);
			this.clickElementWhenInteractable(we, 30);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Attempt to find a suitable Checking Account Number and continue
			while(this.waitForElementToBecomeNull(ProductSelection.Locator_Button_ContinueToNextStep, 30) instanceof WebElement && i < 30) {
				randomAccount = "" + this.fnRandomNumber(10);
				this.sendText(ProductSelection.Locator_TextField_AccountNumber, randomAccount);
				this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
				i++;
				this.waitForPageLoaded();
			}
			
			if(i == 30) {
				ss.fail("Tried 30 times to find an account number but was unsuccessful.");
			}
			
		}
		
		/**
		 * This method selects the Student Value checking and savings product
		 */
		public void chooseStudentValueCheckingAndSavings() {
			WebElement we;
			int i = 0;
			String randomAccount;
			
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Checking and Savings Slider
			this.clickElement(ProductSelection.Locator_Checkbox_CheckingAndSavingsSlider);
			
			// Select Student Value Checking and Savings
			this.confirmElementExistence(ProductSelection.Locator_Checkbox_StudentValueCheckingBox);
			this.clickElement(ProductSelection.Locator_Checkbox_StudentValueCheckingBox);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeChecking);
			this.clickElementWhenInteractable(we, 30);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Attempt to find a suitable Checking Account Number and continue
			while(this.waitForElementToBecomeNull(ProductSelection.Locator_Button_ContinueToNextStep, 30) instanceof WebElement && i < 30) {
				randomAccount = "" + this.fnRandomNumber(10);
				this.sendText(ProductSelection.Locator_TextField_AccountNumber, randomAccount);
				this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
				i++;
				this.waitForPageLoaded();
			}
			
			if(i == 30) {
				ss.fail("Tried 30 times to find an account number but was unsuccessful.");
			}
			
		}
		
		/**
		 * This method selects the Team Member checking and savings product
		 */
		public void chooseTeamMemberCheckingAndSavings() {
			WebElement we;
			int i = 0;
			String randomAccount;
			
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Checking and Savings Slider
			this.clickElement(ProductSelection.Locator_Checkbox_CheckingAndSavingsSlider);
			
			// Select Team Member Checking and Savings
			this.confirmElementExistence(ProductSelection.Locator_Checkbox_TeamMemberCheckingBox);
			this.clickElement(ProductSelection.Locator_Checkbox_TeamMemberCheckingBox);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeChecking);
			this.clickElementWhenInteractable(we, 30);
			this.clickElement(ProductSelection.Locator_Button_OverDraftProtectionSomeSavingsWithChecking);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Attempt to find a suitable Checking Account Number and continue
			while(this.waitForElementToBecomeNull(ProductSelection.Locator_Button_ContinueToNextStep, 30) instanceof WebElement && i < 30) {
				randomAccount = "" + this.fnRandomNumber(10);
				this.sendText(ProductSelection.Locator_TextField_AccountNumber, randomAccount);
				this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
				i++;
				this.waitForPageLoaded();
			}
			
			if(i == 30) {
				ss.fail("Tried 30 times to find an account number but was unsuccessful.");
			}
			
		}
		
		/**
		 * This method selects the Select checking product
		 */
		public void chooseSelectChecking() {
			WebElement we;
			int i = 0;
			String randomAccount;
			
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Checking Slider
			this.clickElement(ProductSelection.Locator_Checkbox_CheckingSlider);
			
			// Choose Select Checking
			this.confirmElementExistence(ProductSelection.Locator_Checkbox_SelectCheckingBox);
			this.clickElement(ProductSelection.Locator_Checkbox_SelectCheckingBox);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeChecking);
			this.clickElementWhenInteractable(we, 30);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Attempt to find a suitable Checking Account Number and continue
			while(this.waitForElementToBecomeNull(ProductSelection.Locator_Button_ContinueToNextStep, 30) instanceof WebElement && i < 30) {
				randomAccount = "" + this.fnRandomNumber(10);
				this.sendText(ProductSelection.Locator_TextField_AccountNumber, randomAccount);
				this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
				i++;
				this.waitForPageLoaded();
			}
			
			if(i == 30) {
				ss.fail("Tried 30 times to find an account number but was unsuccessful.");
			}
			
		}
		
		/**
		 * This method selects the Simply Right checking product
		 */
		public void chooseSimplyRightChecking() {
			WebElement we;
			int i = 0;
			String randomAccount;
			
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Checking Slider
			this.clickElement(ProductSelection.Locator_Checkbox_CheckingSlider);
			
			// Select Simply Right Checking
			this.confirmElementExistence(ProductSelection.Locator_Checkbox_SimplyRightCheckingBox);
			this.clickElement(ProductSelection.Locator_Checkbox_SimplyRightCheckingBox);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeChecking);
			this.clickElementWhenInteractable(we, 30);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Attempt to find a suitable Checking Account Number and continue
			while(this.waitForElementToBecomeNull(ProductSelection.Locator_Button_ContinueToNextStep, 30) instanceof WebElement && i < 30) {
				randomAccount = "" + this.fnRandomNumber(10);
				this.sendText(ProductSelection.Locator_TextField_AccountNumber, randomAccount);
				this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
				i++;
				this.waitForPageLoaded();
			}
			
			if(i == 30) {
				ss.fail("Tried 30 times to find an account number but was unsuccessful.");
			}
			
		}
		
		/**
		 * This method selects the Student Value checking product
		 */
		public void chooseStudentValueChecking() {
			WebElement we;
			int i = 0;
			String randomAccount;
			
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Checking Slider
			this.clickElement(ProductSelection.Locator_Checkbox_CheckingSlider);
			
			// Select Student Value Checking
			this.confirmElementExistence(ProductSelection.Locator_Checkbox_StudentValueCheckingBox);
			this.clickElement(ProductSelection.Locator_Checkbox_StudentValueCheckingBox);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeChecking);
			this.clickElementWhenInteractable(we, 30);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Attempt to find a suitable Checking Account Number and continue
			while(this.waitForElementToBecomeNull(ProductSelection.Locator_Button_ContinueToNextStep, 30) instanceof WebElement && i < 30) {
				randomAccount = "" + this.fnRandomNumber(10);
				this.sendText(ProductSelection.Locator_TextField_AccountNumber, randomAccount);
				this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
				i++;
				this.waitForPageLoaded();
			}
			
			if(i == 30) {
				ss.fail("Tried 30 times to find an account number but was unsuccessful.");
			}
			
		}
		
		/**
		 * This method selects the Team Member checking product
		 */
		public void chooseTeamMemberChecking() {
			WebElement we;
			int i = 0;
			String randomAccount;
			
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Checking Slider
			this.clickElement(ProductSelection.Locator_Checkbox_CheckingSlider);
			
			// Select Team Member Checking
			this.confirmElementExistence(ProductSelection.Locator_Checkbox_TeamMemberCheckingBox);
			this.clickElement(ProductSelection.Locator_Checkbox_TeamMemberCheckingBox);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeChecking);
			this.clickElementWhenInteractable(we, 30);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Attempt to find a suitable Checking Account Number and continue
			while(this.waitForElementToBecomeNull(ProductSelection.Locator_Button_ContinueToNextStep, 30) instanceof WebElement && i < 30) {
				randomAccount = "" + this.fnRandomNumber(10);
				this.sendText(ProductSelection.Locator_TextField_AccountNumber, randomAccount);
				this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
				i++;
				this.waitForPageLoaded();
			}
			
			if(i == 30) {
				ss.fail("Tried 30 times to find an account number but was unsuccessful.");
			}
			
		}
		
		/**
		 * This method selects the Santander Money Market savings product
		 */
		public void chooseSantanderMoneyMarketSavings() {
			WebElement we;
			
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Savings Slider
			this.clickElement(ProductSelection.Locator_Checkbox_SavingsSlider);
			
			// Select Santander Money Market Savings
			this.confirmElementExistence(ProductSelection.Locator_Checkbox_SantanderMoneyMarketSavingsBox);
			this.clickElement(ProductSelection.Locator_Checkbox_SantanderMoneyMarketSavingsBox);
			this.waitForPageLoaded();
			
			// Select that the account was created Offsite
			we = this.confirmElementExistence(ProductSelection.Locator_RadioButton_OffSiteAccountConfirmation);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Select Some OverDraft Protection
			we = this.confirmElementExistence(ProductSelection.Locator_Button_OverDraftProtectionSomeSavingsWithoutChecking);
			this.clickElementWhenInteractable(we, 30);
			
			// Reject offer for Online Banking
			this.clickElement(ProductSelection.Locator_Button_RejectOnlineBanking);
			
			// Continue to KYC
			this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
			
		}
		
		/**
		 * This method selects the Santander savings product
		 */
		public void chooseSantanderSavings() {
			WebElement we;
			
			// Check the box for No Promo Code
			this.clickElement(ProductSelection.Locator_Checkbox_NoPromoCode);
			
			// Click that Savings Slider
			this.clickElement(ProductSelection.Locator_Checkbox_SavingsSlider);
			
			// Select Santander Savings
			we  = this.confirmElementExistence(ProductSelection.Locator_Checkbox_SantanderSavingsBox);
			this.clickElementWhenInteractable(we, 60);
			this.waitForPageLoaded();
			
			// Reject offer for Online Banking
			we = this.confirmElementExistence(ProductSelection.Locator_Button_RejectOnlineBanking);
			this.clickElementWhenInteractable(we, 60);
			
			// Continue to KYC
			this.clickElement(ProductSelection.Locator_Button_ContinueToNextStep);
			
		}
	
		/**
		 * This method Completes the KYC for Only Checking Accounts
		 */
		public void completeKYCForChecking() {
			WebElement we;
			
			// Select Family Status as No
			this.clickElement(KYCPage.Locator_RadioButton_FamilyStatusNo);
			
			// Select Is Officer as No
			this.clickElement(KYCPage.Locator_RadioButton_IsOfficerQuestionNo);
			
			// Select Purpose of Client Relationship from the Dropdown
			this.setDropdownByIndex(KYCPage.Locator_DropDown_PurposeOfClientRelationship, 
					KYCPage.Text_Index_PurposeOfClientRelationshipIndex,
					KYCPage.Locator_DropDown_PurposeOfClientRelationship);
			
			// Select Checking as products requested
			this.clickElement(KYCPage.Locator_Checkbox_CheckingAccount);
			
			// Select the lowest amount for the Expected Monthly Dropdowns
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyDeposit, 
					KYCPage.Text_Index_TransactionAmountsIndex,
					KYCPage.Locator_DropDown_ExpectedMonthlyDeposit);
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyWithdrawal, 
					KYCPage.Text_Index_TransactionAmountsIndex,
					KYCPage.Locator_DropDown_ExpectedMonthlyWithdrawal);
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyDebitTrans, 
					KYCPage.Text_Index_TransactionAmountsIndex,
					KYCPage.Locator_DropDown_ExpectedMonthlyDebitTrans);
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyCreditTrans, 
					KYCPage.Text_Index_TransactionAmountsIndex,
					KYCPage.Locator_DropDown_ExpectedMonthlyCreditTrans);
			
			// Select Expecting International transactions as No
			this.clickElement(KYCPage.Locator_RadioButton_ExpectInternationalTransNo);
			
			// Select Consumer checking as 
			this.clickElement(KYCPage.Locator_Checkbox_ConsumerChecking);
			
			// Click Continue to Printing and deal with the pop-up
			this.clickElement(KYCPage.Locator_Button_ContinueToPrinting);
			we = this.confirmElementExistence(KYCPage.Locator_Button_PopUpVerify);
			this.clickElementWhenInteractable(we, 30);
			
		}
		
		/**
		 * This method Completes the KYC for Checking and Savings Accounts
		 */
		public void completeKYCForCheckingAndSavings() {
			WebElement we;
			
			// Select Family Status as No
			this.clickElement(KYCPage.Locator_RadioButton_FamilyStatusNo);
			
			// Select Is Officer as No
			this.clickElement(KYCPage.Locator_RadioButton_IsOfficerQuestionNo);
			
			// Select Purpose of Client Relationship from the Dropdown
			this.setDropdownByIndex(KYCPage.Locator_DropDown_PurposeOfClientRelationship, 
					KYCPage.Text_Index_PurposeOfClientRelationshipIndex);
			
			// Select Checking and Savings as products requested
			this.clickElement(KYCPage.Locator_Checkbox_CheckingAccount);
			this.clickElement(KYCPage.Locator_Checkbox_SavingsAccount);
			
			// Select the lowest amount for the Expected Monthly Dropdowns
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyDeposit, 
					KYCPage.Text_Index_TransactionAmountsIndex);
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyWithdrawal, 
					KYCPage.Text_Index_TransactionAmountsIndex);
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyDebitTrans, 
					KYCPage.Text_Index_TransactionAmountsIndex);
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyCreditTrans, 
					KYCPage.Text_Index_TransactionAmountsIndex);
			
			// Select Expecting International transactions as No
			this.clickElement(KYCPage.Locator_RadioButton_ExpectInternationalTransNo);
			
			// Select Consumer checking and savings as 
			this.clickElement(KYCPage.Locator_Checkbox_ConsumerChecking);
			this.clickElement(KYCPage.Locator_Checkbox_ConsumerSavings);
			
			// Click Continue to Printing and deal with the pop-up
			this.clickElement(KYCPage.Locator_Button_ContinueToPrinting);
			we = this.confirmElementExistence(KYCPage.Locator_Button_PopUpVerify);
			this.clickElementWhenInteractable(we, 30);
			
		}
		
		/**
		 * This method Completes the KYC for Only Savings Accounts
		 */
		public void completeKYCForSavings() {
			WebElement we;
			
			// Select Family Status as No
			this.clickElement(KYCPage.Locator_RadioButton_FamilyStatusNo);
			
			// Select Is Officer as No
			this.clickElement(KYCPage.Locator_RadioButton_IsOfficerQuestionNo);
			
			// Select Purpose of Client Relationship from the Dropdown
			this.setDropdownByIndex(KYCPage.Locator_DropDown_PurposeOfClientRelationship, KYCPage.Text_Index_PurposeOfClientRelationshipIndex);
			
			// Select Savings as products requested
			this.clickElement(KYCPage.Locator_Checkbox_SavingsAccount);
			
			// Select the lowest amount for the Expected Monthly Dropdowns
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyDeposit, KYCPage.Text_Index_TransactionAmountsIndex);
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyWithdrawal, KYCPage.Text_Index_TransactionAmountsIndex);
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyDebitTrans, KYCPage.Text_Index_TransactionAmountsIndex);
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyCreditTrans, KYCPage.Text_Index_TransactionAmountsIndex);
			
			// Select Expecting International transactions as No
			this.clickElement(KYCPage.Locator_RadioButton_ExpectInternationalTransNo);
			
			// Select Consumer savings as 
			this.clickElement(KYCPage.Locator_Checkbox_ConsumerSavings);
			
			// Click Continue to Printing and deal with the pop-up
			this.clickElement(KYCPage.Locator_Button_ContinueToPrinting);
			we = this.confirmElementExistence(KYCPage.Locator_Button_PopUpVerify);
			this.clickElementWhenInteractable(we, 30);
			
		}
		
		/**
		 * This method Completes the KYC for Checking and Savings Accounts to create an existing customer 
		 */
		public void completeKYCForCheckingAndSavingsExistingCustomer() {
			WebElement we;
			
			// Select Family Status as No
			this.clickElement(KYCPage.Locator_RadioButton_FamilyStatusNo);
			
			// Select Is Officer as No
			this.clickElement(KYCPage.Locator_RadioButton_IsOfficerQuestionNo);
			
			// Select Purpose of Client Relationship from the Dropdown
			this.setDropdownByIndex(KYCPage.Locator_DropDown_PurposeOfClientRelationship, KYCPage.Text_Index_PurposeOfClientRelationshipIndex);
			
			// Select Checking and Savings as products requested
			this.clickElement(KYCPage.Locator_Checkbox_CheckingAccount);
			this.clickElement(KYCPage.Locator_Checkbox_SavingsAccount);
			
			// Select the lowest amount for the Expected Monthly Dropdowns
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyDeposit, KYCPage.Text_Index_TransactionAmountsIndex);
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyWithdrawal, KYCPage.Text_Index_TransactionAmountsIndex);
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyDebitTrans, KYCPage.Text_Index_TransactionAmountsIndex);
			this.setDropdownByIndex(KYCPage.Locator_DropDown_ExpectedMonthlyCreditTrans, KYCPage.Text_Index_TransactionAmountsIndex);
			
			// Select Expecting International transactions as No
			this.clickElement(KYCPage.Locator_RadioButton_ExpectInternationalTransNo);
			
			// Select Consumer checking and savings as 
			this.clickElement(KYCPage.Locator_Checkbox_ConsumerChecking);
			this.clickElement(KYCPage.Locator_Checkbox_ConsumerSavings);
			
			// Click Continue to Printing and deal with the pop-up
			this.clickElement(KYCPage.Locator_Button_ContinueToPrinting);
			we = this.confirmElementExistence(KYCPage.Locator_Button_PopUpVerify);
			this.clickElementWhenInteractable(we, 30);
			
			// Wait for page to load and confirm that Print all Documents button is displayed before moving on
			this.waitForPageLoaded();
			this.confirmElementExistence(PrintingAndSummary.Locator_Button_PrintAllDocuments);
		}
	
		/**
		 * This method clicks the option to print all documents needed to complete the account opening process
		 */
		public void printAllRequiredDocs(String firstName, String lastName, String downloadPDFPath) {
			WebElement we;
			int i = 0;
			
			// Click Print All Documents when Interactable
			we = this.confirmElementExistence(PrintingAndSummary.Locator_Button_PrintAllDocuments, 120);
			this.clickElementWhenInteractable(we, 120);
			
			// Try to move on from printing
			while(this.waitForElementToBecomeNull(PrintingAndSummary.Locator_Button_ContinueToSummary, 60) instanceof WebElement && i < 10) {
				this.clickElement(PrintingAndSummary.Locator_Button_ContinueToSummary);
				i++;
				this.waitForPageLoaded();
			}
			
			// Fail test if it cannot move forward after 10 attempts
			if(i == 10) {
				ss.fail("Print all documents window was not loaded after 10 attempts to continue.");
			}
			
			// Download PDF that was generated by the print action
			this.waitForPageCompletelyLoaded(60);
			downloadPDF(firstName, lastName, downloadPDFPath);
			
		}
		
		/**
		 * This method returns to the Main ONE Dashboard where final validation will be done
		 */
		public void returnToONE() {
			WebElement we;
			
			// click on the Finish button when it is interactable
			we = this.confirmElementExistence(PrintingAndSummary.Locator_Button_FinishButton);
			this.clickElementWhenInteractable(we, 60);
			
			// Wait for the pop-up to appear and then click yes
			this.waitForPageLoaded();
			this.clickElement(PrintingAndSummary.Locator_Button_ReturnToONEYes, 60);

		}
		
		/**
		 * This method switches to the PDF window, downloads the file, and returns to the main window.
		 */
		private void downloadPDF(String firstName, String lastName, String downloadPDFPath) {
			
			// Try to switch to PDF window
			switchToDaughterWindowNoWait();
			
			// try to copy the PDF from the browser
	        try {

	            URL url = new URL(getCurrentUrl());
	            InputStream in = url.openStream();
	            Files.copy(in, Paths.get(downloadPDFPath + 
	            		firstName + "_" + lastName + 
	            		"_" + LocalDate.now() + ".pdf"));
	            in.close();

	        } catch (IOException e) {
	        	e.printStackTrace();
	        	System.out.format("An IO exception was thrown while trying to download PDF."
	        			+ " See above Stack trace. >%n");
	        	ss.fail();
	        }
	        
	        // Switch back to the main window to continue
	        this.switchToWindowByTitleNoWait(PrintingAndSummary.Text_ReturnWindowTitle);
	        

		}
	
		/**
		 * This method validates that the basic checking account was created successfully
		 */
		public void validateAccountsCreatedBasicChecking() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_SantanderBasicChecking);
			
		}
		
		/**
		 * This method validates that the basic checking and savings accounts was created successfully
		 */
		public void validateAccountsCreatedBasicCheckingAndSavings() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_SantanderBasicChecking);
			this.confirmElementExistence(ONEDashboard.Locator_SantanderSavings);
			
		}
		
		/**
		 * This method validates that the premier plus checking account was created successfully
		 */
		public void validateAccountsCreatedPremierPlusChecking() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_SantanderPremierPlusChecking);
			
		}
		
		/**
		 * This method validates that the premier plus checking and savings accounts was created successfully
		 */
		public void validateAccountsCreatedPremierPlusCheckingAndSavings() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_SantanderPremierPlusMoneyMarketSavings);
			this.confirmElementExistence(ONEDashboard.Locator_SantanderPremierPlusChecking);
			
		}
		
		/**
		 * This method validates that the Select checking and savings accounts was created successfully
		 */
		public void validateAccountsCreatedSelectCheckingAndSavings() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_SantanderSelectMoneyMarket);
			this.confirmElementExistence(ONEDashboard.Locator_SantanderSelectChecking);
		}
		
		/**
		 * This method validates that the simply right checking and savings accounts was created successfully
		 */
		public void validateAccountsCreatedSimplyRightCheckingAndSavings() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_SantanderSavings);
			this.confirmElementExistence(ONEDashboard.Locator_SimplyRightChecking);
			
		}
		
		/**
		 * This method validates that the student value checking and savings accounts was created successfully
		 */
		public void validateAccountsCreatedStudentValueCheckingAndSavings() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_SantanderSavings);
			this.confirmElementExistence(ONEDashboard.Locator_StudentValueChecking);
			
		}
		
		/**
		 * This method validates that the team member checking and savings accounts was created successfully
		 */
		public void validateAccountsCreatedTeamMemberCheckingAndSavings() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_SantanderPremierPlusMoneyMarketSavings);
			this.confirmElementExistence(ONEDashboard.Locator_TeamMemberChecking);
		}
		
		/**
		 * This method validates that the select checking account was created successfully
		 */
		public void validateAccountsCreatedSelectChecking() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_SantanderSelectChecking);

		}
		
		/**
		 * This method validates that the simply right checking account was created successfully
		 */
		public void validateAccountsCreatedSimplyRightChecking() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_SimplyRightChecking);

		}
		
		/**
		 * This method validates that the student value checking account was created successfully
		 */
		public void validateAccountsCreatedStudentValueChecking() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_StudentValueChecking);
			
		}
		
		/**
		 * This method validates that the team member checking account was created successfully
		 */
		public void validateAccountsCreatedTeamMemberChecking() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_TeamMemberChecking);
			
		}
		
		/**
		 * This method validates that the santander money market savings account was created successfully
		 */
		public void validateAccountsCreatedSantanderMoneyMarketSavings() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_SantanderPremierPlusMoneyMarketSavings);
			
		}
		
		/**
		 * This method validates that the santander savings account was created successfully
		 */
		public void validateAccountsCreatedSantanderSavings() {
			
			// Open Engagement Summary Dropdown
			this.clickElement(ONEDashboard.Locator_Image_EngagementSummaryDropDown);
			
			// Validate the proper Accounts have been created
			this.confirmElementExistence(ONEDashboard.Locator_SantanderSavings);
			
		}
		
		/**
		 * Return the current URL
		 */
		public String getCurrentUrl() {

			return wd.getCurrentUrl();
			
		}
		
		
		/**
		 * Launch regular login page url.
		 *
		 * @param url (String) target url to launch (excel data)
		 */
		public void launchPage(String url) {

			getUrl(url);
//			fnReportLog("PASSED", String.format("Launched %s", url), String.format("Could not launch %s", url), false);

			if (wd.getCurrentUrl().length() > 0) {
				fnReportLog("Passed", String.format("URL launched: %s", url), "URL launched.", false);
			} else {
				fnReportLog("Failed", String.format("URL launched: %s", url), "URL not launched.", false);
				ss.fail(String.format("Could not launch url: %s", url));
			}

		}

}