package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class RobTMXLogin {


    public static By Locator_Button_Login = 			By.cssSelector("input[type=button][value=Login]");
    public static By Locator_Select_Environment = 		By.cssSelector("select#environment");
    public static By Locator_TextField_Password = 		By.cssSelector("input[name$=pwd]");
    public static By Locator_TextField_TMXPolicy = 		By.cssSelector("input#i_tmx_policy");
    public static By Locator_TextField_UserId = 		By.cssSelector("input[name$=alias]");
    public static String Text_Environment = 			"PRE";
    public static String Text_URL = 					"file:///C:/Dev/EclipseWorkspace/automation/src/test/resources/ROB/Retail_Login_with_TMX.HTML";


//  Locator_Button_Login("RobTMXLogin.Locator.Button.Login"),
//	Locator_Select_Environment("RobTMXLogin.Locator.Select.Environment"),
//	Locator_TextField_Password("RobTMXLogin.Locator.TextField.Password"),
//	Locator_TextField_TMXPolicy("RobTMXLogin.Locator.TextField.TMXPolicy"),
//	Locator_TextField_UserId("RobTMXLogin.Locator.TextField.UserID"),
//	Text_Environment("RobTMXLogin.Text.Environment"),
//	Text_URL("RobTMXLogin.Text.URL"),


//	RobTMXLogin.Locator.Button.Login=input[type=button][value=Login]@@@css
//	RobTMXLogin.Locator.Select.Environment=select#environment@@@css
//	RobTMXLogin.Locator.TextField.Password=input[name$=pwd]@@@css
//	RobTMXLogin.Locator.TextField.TMXPolicy=input#i_tmx_policy@@@css
//	RobTMXLogin.Locator.TextField.UserID=input[name$=alias]@@@css
//	RobTMXLogin.Text.URL=file:///C:/Dev/EclipseWorkspace/automation/src/test/resources/ROB/Retail_Login_with_TMX.HTML


}
