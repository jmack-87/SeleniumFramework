package common_resources.database_tools;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.NoPermissionException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;


public class LDAPQueryHelper {

	private String uID;


	/**
	 * Retrieve last login date from LDAP respective a given f-number
	 * CAUTION: multiple IDs possible per f-number
	 *
	 * @param fNumber
	 * @return (String) last login date
	 */
	public static String getLastLoginDateTimeBy_FNumber(String fNumber) {

		try {
	        DirContext ctx = new InitialDirContext(getEnvironment());
	        NamingEnumeration<?> namingEnum = ctx.search(DatabaseReference.ldapContext, "bscodigopersona="+fNumber, getSimpleSearchControls());
	        while (namingEnum.hasMore()) {
	            SearchResult result = (SearchResult) namingEnum.next ();
	            Attributes attrs = result.getAttributes();
	            return attrs.get("BSfechaUltimoLogon").toString();

	        }
	        namingEnum.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		return null;

	}


	/**
	 * Retrieve last login date from LDAP respective a given user name (LDAP bsalias)
	 *
	 * @param userName (String) user name used during login
	 * @return (String) Last login date
	 */
	public static String getLastLoginDateTime_ByLoginUserName(String userName) {

		try {
			DirContext ctx = new InitialDirContext(getEnvironment());
	        NamingEnumeration<?> namingEnum = ctx.search(DatabaseReference.ldapContext, LDAPQuery.LDAP_KEY_USERNAME+"="+userName, getSimpleSearchControls());
	        while (namingEnum.hasMore()) {
	            SearchResult result = (SearchResult) namingEnum.next ();
	            Attributes attrs = result.getAttributes();
	            return attrs.get(LDAPQuery.LDAP_KEY_LASTLOGON).toString();

	        }
	        namingEnum.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		return null;

	}


	/**
	 * Retrieve "common name" from LDAP given an f-number
	 * CAUTION: multiple IDs possible per f-number
	 *
	 * @param fNumber (String) customer f-number
	 * @return (String) customer common name
	 */
	public static String getCustomerName_ByFNumber(String fNumber) {

		try {
			DirContext ctx = new InitialDirContext(getEnvironment());
	        NamingEnumeration<?> namingEnum = ctx.search(DatabaseReference.ldapContext, LDAPQuery.LDAP_KEY_FJNUMBER+"="+fNumber, getSimpleSearchControls());
	        while (namingEnum.hasMore()) {
	            SearchResult result = (SearchResult) namingEnum.next ();
	            Attributes attrs = result.getAttributes();
	            return attrs.get(LDAPQuery.LDAP_KEY_CUSTOMERNAME).toString();

	        }
	        namingEnum.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		return null;

	}


	/**
	 * Retrieve "common name" given a login name
	 *
	 * @param userName (String) user name used during login
	 * @return (String) customer common name
	 */
	public String getCustomerName_ByLoginName(String userName) {

		try {
			DirContext ctx = new InitialDirContext(getEnvironment());
	        NamingEnumeration<?> namingEnum = ctx.search(DatabaseReference.ldapContext, LDAPQuery.LDAP_KEY_USERNAME+"="+userName, getSimpleSearchControls());
	        while (namingEnum.hasMore()) {
	            SearchResult result = (SearchResult) namingEnum.next ();
	            Attributes attrs = result.getAttributes();
	            return attrs.get(LDAPQuery.LDAP_KEY_CUSTOMERNAME).toString();

	        }
	        namingEnum.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		return null;

	}


	/**
	 * Retrieve the value of a target attribute, given a corresponding known attribute:value pair
	 *
	 * @param target (String) attribute name to retrieve
	 * @param queryPoint (String) uniquely identifying attribute
	 * @param queryValue (String) value of 'filter' attribute
	 *
	 * @return (String) target attribute value
	 */
	public String getAttribute_ByAttribute_AndValue(String target, String queryPoint, String queryValue) {

		String filter = queryPoint+"="+queryValue;

		try {
			DirContext ctx = new InitialDirContext(getEnvironment());

	        NamingEnumeration<SearchResult> namingEnum = ctx.search(DatabaseReference.ldapContext, filter, getSimpleSearchControls());
	        while (namingEnum.hasMore()) {
	            SearchResult result = namingEnum.next();
	            Attributes attrs = result.getAttributes();
	            return (String) attrs.get(target).get();

	        }
	        namingEnum.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		return null;

	}


	/**
	 * Tidiness method: define SearchControls in a uniform way (allows for response filtering (Attributes) etc.)
	 *
	 * @return (SearchControls) LDAP search conditions
	 */
	private static SearchControls getSimpleSearchControls() {

	    SearchControls searchControls = new SearchControls();
	    searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
	    searchControls.setTimeLimit(30000);
	    return searchControls;

	}


	/**
	 * Tidiness method: Set initial LDAP connect conditions
	 *
	 * @return (Hashtable<String, String>) LDAP connection environment
	 */
	private static Hashtable<String, String> getEnvironment() {

		Hashtable<String, String> env = new Hashtable<String, String>(11);
		env.clear();
		env.put(Context.INITIAL_CONTEXT_FACTORY, DatabaseReference.ldapFactory);
		env.put(Context.PROVIDER_URL, DatabaseReference.ldapURL);
		env.put(Context.SECURITY_CREDENTIALS, DatabaseReference.ldapPass);
	    return env;

	}


	/**
	 * Set the mobile [OTP] phone number of target LDAP entry
	 *
	 * @param newPhoneNumber (String) phone number to replace current entry ex. +15175551234
	 * @param ldapFilter (String) uniquely identifying combination of one or more attribute=value pairs
	 * 		ex. bscodigopersona=123456789
	 * 		ex. (&(bsalias=MyLoginName)(sn=Lastname))
	 */
	public void setPhoneNumber(String newPhoneNumber, String ldapFilter) {

		try {
			DirContext ctx = new InitialDirContext(getEnvironment());

	        NamingEnumeration<SearchResult> namingEnum = ctx.search(DatabaseReference.ldapContext, ldapFilter, getSimpleSearchControls());
	        while (namingEnum.hasMore()) {
	            SearchResult result = (SearchResult) namingEnum.next ();
	            Attributes attrs = result.getAttributes();
	            uID = (String) attrs.get(LDAPQuery.LDAP_KEY_ID).get();
	        }
	        namingEnum.close();

	        ModificationItem[] mod = new ModificationItem[1];
	        Attribute attribute = new BasicAttribute("mobile", newPhoneNumber);
            mod[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, attribute);
            ctx.modifyAttributes(LDAPQuery.LDAP_KEY_ID+"="+uID+","+DatabaseReference.ldapContext, mod);

            /* used for console logging
    	   namingEnum = ctx.search(DatabaseReference.ldapContext, ldapFilter, getSimpleSearchControls());
	        while (namingEnum.hasMore()) {
	            SearchResult result = (SearchResult) namingEnum.next ();
	            Attributes attrs = result.getAttributes();
	        }
	        */
	        namingEnum.close();
		} catch (NoPermissionException npe) {
			System.out.println(npe.getMessage());
		} catch (NamingException ne) {
			System.out.println(ne.getMessage());
		}

	}


}
