package common_resources.database_tools;

public class LDAPQuery {

	// LDAP KEYS
	public static String LDAP_KEY_LASTLOGON = 		"BSfechaUltimoLogon";		// ex. YYYYMMDDHHmmss
	public static String LDAP_KEY_PRIORLOGON = 		"BSfechaPenultimoLogon";	// ex. YYYYMMDDHHmmss
	public static String LDAP_KEY_USERNAME = 		"BSalias";					// ex. logonUserName
	public static String LDAP_KEY_FIRSTNAME = 		"givenName";				// ex. FIRST
	public static String LDAP_KEY_LASTNAME = 		"sn";						// ex. LAST
	public static String LDAP_KEY_CUSTOMERNAME = 	"cn";						// ex. FIRST LAST
	public static String LDAP_KEY_FJNUMBER = 		"BScodigoPersona";			// ex. 612345678
	public static String LDAP_KEY_MOBILENUMBER = 	"mobile";					// ex. +15551112222
	public static String LDAP_KEY_ID = 				"uid";						// ex. FLAST
	public static String LDAP_KEY_TYPE =			"BStipoPersona"; 			// ex. F


}
