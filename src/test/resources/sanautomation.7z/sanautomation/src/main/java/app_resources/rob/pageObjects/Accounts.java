package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class Accounts {


	public static By Locator_CreditAccounts_UltimateCashBack =								By.xpath("//a[contains(text(),'ULTIMATE CASH BACK')]");
	public static By Locator_LeftNav_Button_AccountDetailsAndActivityTab =					By.cssSelector("a[id='Account Details & Activity']");
	public static By Locator_LeftNav_Button_AccountDetailsAndActivityTab_Active =			By.cssSelector("li.active a[id='Account Details & Activity']");
	public static By Locator_LeftNav_Button_AccountServicesTab =							By.cssSelector("a[id='Account Services']");
	public static By Locator_LeftNav_Button_AccountServicesTab_Active =						By.cssSelector("li.active a[id='Account Services']");
	public static By Locator_LeftNav_Button_AlertsTab =										By.cssSelector("a#Alerts");
	public static By Locator_LeftNav_Button_AlertsTab_Active =								By.cssSelector("li.active a#Alerts");
	public static By Locator_LeftNav_Button_ATMAndDebitCardServicesTab =					By.cssSelector("a[id='ATM & Debit Card Services']");
	public static By Locator_LeftNav_Button_ATMAndDebitCardServicesTab_Active =				By.cssSelector("li.active a[id='ATM & Debit Card Services']");
	public static By Locator_LeftNav_Button_OverviewTab =									By.cssSelector("a#Overview");
	public static By Locator_LeftNav_Button_OverviewTab_Active =							By.cssSelector("li.active a#Overview");
	public static By Locator_LeftNav_Button_StatementsAndDocumentsTab =						By.cssSelector("a[id='Statements & Documents']");
	public static By Locator_LeftNav_Button_StatementsAndDocumentsTab_Active =				By.cssSelector("li.active a[id='Statements & Documents']");
	public static By Locator_LeftNav_TextContainer_Title =									By.cssSelector("h2.accounts");
//	public static By Locator_Link_CheckingEditedAfterChange =								By.cssSelector(""); //missing from properties
//	public static By Locator_Link_CheckingEditedBeforeChange =								By.cssSelector(""); //missing from properties
//	public static By Locator_Link_SavingsEditedAfterChange =								By.cssSelector(""); //missing from properties
//	public static By Locator_Link_SavingsEditedBeforeChange =								By.cssSelector(""); //missing from properties
	public static By Locator_Overview_Container_Content =									By.cssSelector("div.contenido");
	public static By Locator_Overview_Container_Header =									By.cssSelector("div.cabecera");
	public static By Locator_Overview_Container_Paginator =									By.cssSelector("div.NavPaginador");
	public static By Locator_Overview_Container_TableBody =									By.cssSelector("tbody");
	public static By Locator_Overview_Link_Header_ShowHide =								By.cssSelector("div.cabecera a[title^='Show']");
	public static By Locator_Overview_Link_HelpWithThisPage =								By.cssSelector("a[title^=Help]");
	public static By Locator_Overview_Link_Print =											By.cssSelector("a#imprimir");
	public static By Locator_Overview_TextContainer_Header_Title =							By.cssSelector("div.cabecera span.title");
	public static By Locator_Overview_TextContainer_Paginator_Numbers =						By.cssSelector("div.NavPaginador div.numeros");
	public static By Locator_Overview_TextContainer_Title =									By.cssSelector("span.titulo");
	public static By MultiLocator_Overview_TextContainer_CheckingTableColumns =				By.cssSelector("div[id='main.cntTabla'] div.contenido thead th span");
	public static By MultiLocator_Overview_TextContainer_CheckSaveMoneyMarketAccounts =		By.cssSelector("div[id='main.tblTabla'] td[id$='.0']");
	public static By MultiLocator_Overview_TextContainer_CheckSaveMoneyMarketNicknames =	By.cssSelector("div[id='main.tblTabla'] td[id$='.0'] span");
	public static By MultiLocator_Overview_TextContainer_CreditCardAccounts =				By.cssSelector("div[id='main.tblCreditCards'] td[id$='.0']");
	public static By MultiLocator_Overview_TextContainer_CreditCardNicknames =				By.cssSelector("div[id='main.tblCreditCards'] td[id$='.0'] span");
	public static By MultiLocator_Overview_TextContainer_CreditCardsTableColumns =			By.cssSelector("div[id='main.cntCreditCards'] div.contenido thead th span");
	public static By MultiLocator_Overview_TextContainer_TableColumns =						By.cssSelector("div.contenido thead th span");
	public static String MultiText_Overview_CheckingTableColumns =							"Accounts,Available Balance,Current Balance,Actions";
	public static String MultiText_Overview_CreditCardsTableColumns =						"Credit Cards,Available Credit,Current Balance,Actions";
	public static String Text_LeftNav_Title =												"accounts";
	public static String Text_Overview_Header_Title =										"checking";
	public static String Text_Overview_Paginator_Numbers =									"1";
	public static String Text_Overview_Title =												"overview";


//	Locator_CreditAccounts_UltimateCashBack("Accounts.Locator.CreditAccounts.UltimateCashBack"),
//	Locator_LeftNav_Button_AccountDetailsAndActivityTab("Accounts.Locator.LeftNav.Button.AccountDetailsAndActivity"),
//	Locator_LeftNav_Button_AccountDetailsAndActivityTab_Active("Accounts.Locator.LeftNav.Button.AccountDetailsAndActivity.Active"),
//	Locator_LeftNav_Button_AccountServicesTab("Accounts.Locator.LeftNav.Button.AccountServices"),
//	Locator_LeftNav_Button_AccountServicesTab_Active("Accounts.Locator.LeftNav.Button.AccountServices.Active"),
//	Locator_LeftNav_Button_AlertsTab("Accounts.Locator.LeftNav.Button.Alerts"),
//	Locator_LeftNav_Button_AlertsTab_Active("Accounts.Locator.LeftNav.Button.Alerts.Active"),
//	Locator_LeftNav_Button_ATMAndDebitCardServicesTab("Accounts.Locator.LeftNav.Button.ATMAndDebitCardServices"),
//	Locator_LeftNav_Button_ATMAndDebitCardServicesTab_Active("Accounts.Locator.LeftNav.Button.ATMAndDebitCardServices.Active"),
//	Locator_LeftNav_Button_OverviewTab("Accounts.Locator.LeftNav.Button.Overview"),
//	Locator_LeftNav_Button_OverviewTab_Active("Accounts.Locator.LeftNav.Button.Overview.Active"),
//	Locator_LeftNav_Button_StatementsAndDocumentsTab("Accounts.Locator.LeftNav.Button.StatementsAndDocuments"),
//	Locator_LeftNav_Button_StatementsAndDocumentsTab_Active("Accounts.Locator.LeftNav.Button.StatementsAndDocuments.Active"),
//	Locator_LeftNav_TextContainer_Title("Accounts.LeftNave.Locator.TextContainer.Title"),
//	Locator_Link_CheckingEditedAfterChange("Accounts.Locator.Link.CheckingEditedAfterChange"),
//	Locator_Link_CheckingEditedBeforeChange("Accounts.Locator.Link.CheckingEditedBeforeChange"),
//	Locator_Link_SavingsEditedAfterChange("Accounts.Locator.Link.SavingsEditedAfterChange"),
//	Locator_Link_SavingsEditedBeforeChange("Accounts.Locator.Link.SavingsEditedBeforeChange"),
//	Locator_Overview_Container_Content("Accounts.Locator.Overview.Container.Content"),
//	Locator_Overview_Container_Header("Accounts.Locator.Overview.Container.Header"),
//	Locator_Overview_Container_Paginator("Accounts.Locator.Overview.Container.Paginator"),
//	Locator_Overview_Container_TableBody("Accounts.Locator.Overview.Container.TableBody"),
//	Locator_Overview_Link_Header_ShowHide("Accounts.Locator.Overview.Link.Header.ShowHide"),
//	Locator_Overview_Link_HelpWithThisPage("Accounts.Locator.Overview.Link.HelpWithThisPage"),
//	Locator_Overview_Link_Print("Accounts.Locator.Overview.Link.Print"),
//	Locator_Overview_TextContainer_Header_Title("Accounts.Locator.Overview.TextContainer.Header.Title"),
//	Locator_Overview_TextContainer_Paginator_Numbers("Accounts.Locator.Overview.TextContainer.Paginator.Numbers"),
//	Locator_Overview_TextContainer_Title("Accounts.Locator.Overview.TextContainer.Title"),
//	MultiLocator_Overview_TextContainer_CheckingTableColumns("Accounts.MultiLocator.Overview.TextContainer.CheckingTableColumns"),
//	MultiLocator_Overview_TextContainer_CheckSaveMoneyMarketAccounts("Accounts.MultiLocator.Overview.TextContainer.CheckSaveMoneyMarketAccounts"),
//	MultiLocator_Overview_TextContainer_CheckSaveMoneyMarketNicknames("Accounts.MultiLocator.Overview.TextContainer.CheckSaveMoneyMarketNicknames"),
//	MultiLocator_Overview_TextContainer_CreditCardAccounts("Accounts.MultiLocator.Overview.TextContainer.CreditCardAccounts"),
//	MultiLocator_Overview_TextContainer_CreditCardNicknames("Accounts.MultiLocator.Overview.TextContainer.CreditCardNicknames"),
//	MultiLocator_Overview_TextContainer_CreditCardsTableColumns("Accounts.MultiLocator.Overview.TextContainer.CreditCardsTableColumns"),
//	MultiText_Overview_CheckingTableColumns("Accounts.MultiText.Overview.CheckingTableColumns"),
//	MultiText_Overview_CreditCardsTableColumns("Accounts.MultiText.Overview.CreditCardsTableColumns"),
//	Text_LeftNav_Title("Accounts.Text.LeftNav.Title"),
//	Text_Overview_Header_Title("Accounts.Text.Overview.Header.Title"),
//	Text_Overview_Paginator_Numbers("Accounts.Text.Overview.Paginator.Numbers"),
//	Text_Overview_Title("Accounts.Text.Overview.Title"),


//  Accounts.Locator.CreditAccounts.UltimateCashBack=//a[contains(text(),'ULTIMATE CASH BACK')]@@@xpath
//	Accounts.Locator.LeftNav.Button.AccountDetailsAndActivity.Active=li.active a#Account\\ Details\\ \\&\\ Activity@@@css
//	Accounts.Locator.LeftNav.Button.AccountDetailsAndActivity=a#Account\\ Details\\ \\&\\ Activity@@@css
//	Accounts.Locator.LeftNav.Button.AccountServices.Active=li.active a#Account\\ Services@@@css
//	Accounts.Locator.LeftNav.Button.AccountServices=a#Account\\ Services@@@css
//	Accounts.Locator.LeftNav.Button.Alerts.Active=li.active a#Alerts@@@css
//	Accounts.Locator.LeftNav.Button.Alerts=a#Alerts@@@css
//	Accounts.Locator.LeftNav.Button.ATMAndDebitCardServices.Active=li.active a#ATM\\ \\&\\ Debit\\ Card\\ Services@@@css
//	Accounts.Locator.LeftNav.Button.ATMAndDebitCardServices.Active=li.active a#ATM\\ \\&\\ Debit\\ Card\\ Services@@@css
//	Accounts.Locator.LeftNav.Button.ATMAndDebitCardServices=a#ATM\\ \\&\\ Debit\\ Card\\ Services@@@css
//	Accounts.Locator.LeftNav.Button.ATMAndDebitCardServices=a#ATM\\ \\&\\ Debit\\ Card\\ Services@@@css
//	Accounts.Locator.LeftNav.Button.Overview.Active=li.active a#Overview@@@css
//	Accounts.Locator.LeftNav.Button.Overview=a#Overview@@@css
//	Accounts.Locator.LeftNav.Button.StatementsAndDocuments.Active=li.active a#Statements\\ \\&\\ Documents@@@css
//	Accounts.Locator.LeftNav.Button.StatementsAndDocuments=a#Statements\\ \\&\\ Documents@@@css
//	Accounts.Locator.Overview.Container.Content=div.contenido@@@css
//	Accounts.Locator.Overview.Container.Header=div.cabecera@@@css
//	Accounts.Locator.Overview.Container.Paginator=div.NavPaginador@@@css
//	Accounts.Locator.Overview.Container.TableBody=tbody@@@css
//	Accounts.Locator.Overview.Link.Header.ShowHide=div.cabecera a[title^='Show']@@@css
//	Accounts.Locator.Overview.Link.HelpWithThisPage=a[title^=Help]@@@css
//	Accounts.Locator.Overview.Link.Print=a#imprimir@@@css
//	Accounts.Locator.Overview.TextContainer.Header.Title=div.cabecera span.title@@@css
//	Accounts.Locator.Overview.TextContainer.Paginator.Numbers=div.NavPaginador div.numeros@@@css
//	Accounts.Locator.Overview.TextContainer.Title=span.titulo@@@css
//	Accounts.Locator.TextContainer.Title=h2.accounts@@@css
//	Accounts.MultiLocator.Overview.TextContainer.CheckingTableColumns=div#main\\.cntTabla div.contenido thead th span@@@css
//	Accounts.MultiLocator.Overview.TextContainer.CheckSaveMoneyMarketAccounts=div#main\\.tblTabla td[id$='.0']@@@css
//	Accounts.MultiLocator.Overview.TextContainer.CheckSaveMoneyMarketNicknames=div#main\\.tblTabla td[id$='.0'] span@@@css
//	Accounts.MultiLocator.Overview.TextContainer.CreditCardAccounts=div#main\\.tblCreditCards td[id$='.0']@@@css
//	Accounts.MultiLocator.Overview.TextContainer.CreditCardNicknames=div#main\\.tblCreditCards td[id$='.0'] span@@@css
//	Accounts.MultiLocator.Overview.TextContainer.CreditCardsTableColumns=div#main\\.cntCreditCards div.contenido thead th span@@@css
//	Accounts.MultiLocator.Overview.TextContainer.TableColumns=div.contenido thead th span@@@css
//	Accounts.MultiText.Overview.CheckingTableColumns=Accounts,Available Balance,Current Balance,Actions
//	Accounts.MultiText.Overview.CreditCardsTableColumns=Credit Cards,Available Credit,Current Balance,Actions
//	Accounts.Text.LeftNav.Title=accounts
//	Accounts.Text.Overview.Header.Title=checking
//	Accounts.Text.Overview.Paginator.Numbers=1
//	Accounts.Text.Overview.Title=overview


}
