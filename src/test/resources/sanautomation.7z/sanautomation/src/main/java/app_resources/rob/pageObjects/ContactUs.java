package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class ContactUs {


	public static By Locator_BranchOffice_Link_FindABranch =						By.cssSelector("a#main_txtCntbracnh2_enlace_1");
	public static By Locator_Email_Link_SendAnEmail =								By.cssSelector("a#main_txtEmail2_enlace_1");
	public static By Locator_Help_Link_QA1 =										By.xpath("(//div[contains(@id, 'Help_CONTENT')]//a[contains(@id, '_2')])[1]");
	public static By Locator_Help_Title_Help =										By.cssSelector("div#main_cabSimple_1_CabSimple");
	public static By Locator_HelpQA_TextContainer_RateThisAnswer =					By.cssSelector("div#rate h3");
	public static By Locator_Mail_Text_GeneralInquiries =							By.xpath("//p[contains(text(),'Please include your')]");
	public static By Locator_Phone_Text_BankingRepNumber =							By.xpath("//p[contains(text(),'Contact our Personal')]");
	public static By Locator_SecurityAdvice_Link_LaunchSecurityCenter =				By.cssSelector("a#main_txtEnlaceSec_enlace_1");
	public static String Locator_HelpQA_WindowTitle_FAQWindowTitle =				"Santander e-Banking FAQs";
	public static String Text_HelpQA_WindowTitle_FAQWindowTitle =					"Santander e-Banking FAQs";


//	Locator_BranchOffice_Link_FindABranch("ContactUs.Locator.BranchOffice.Link.FindABranch"),
//	Locator_Email_Link_SendAnEmail("ContactUs.Locator.Email.Link.SendAnEmail"),
//	Locator_Help_Link_QA1("ContactUs.Locator.Link.HelpQA1"),
//	Locator_Help_Title_Help("ContactUs.Locator.Text.HelpTitle"),
//	Locator_HelpQA_TextContainer_RateThisAnswer("ContactUs.Locator.Help.TextContainer.RateThisAnswer"),
//	Locator_HelpQA_WindowTitle_FAQWindowTitle("ContactUs.Locator.Help.Text.FAQWindowTitle"),
//	Locator_Mail_Text_GeneralInquiries("ContactUs.Locator.Mail.Text.GeneralInquiries"),
//	Locator_Phone_Text_BankingRepNumber("ContactUs.Locator.Phone.Text.BankingRepNumber"),
//	Locator_SecurityAdvice_Link_LaunchSecurityCenter("ContactUs.Locator.SecurityAdvice.Link.LaunchSecurityCenter"),


//	ContactUs.Locator.BranchOffice.Link.FindABranch=a#main_txtCntbracnh2_enlace_1@@@css
//	ContactUs.Locator.Email.Link.SendAnEmail=a#main_txtEmail2_enlace_1@@@css
//	ContactUs.Locator.Help.Text.FAQWindowTitle=Santander e-Banking FAQs
//	ContactUs.Locator.Help.TextContainer.RateThisAnswer=div#rate h3@@@css
//	ContactUs.Locator.Link.HelpQA1=a#main_txtEnlace10_enlace_2@@@css
//	ContactUs.Locator.Mail.Text.GeneralInquiries=//p[contains(text(),'Please include your')]@@@xpath
//	ContactUs.Locator.Phone.Text.BankingRepNumber=//p[contains(text(),'Contact our Personal')]@@@xpath
//	ContactUs.Locator.SecurityAdvice.Link.LaunchSecurityCenter=a#main_txtEnlaceSec_enlace_1@@@css
//	ContactUs.Locator.Text.HelpTitle=div#main_cabSimple_1_CabSimple@@@css


}
