package common_resources.database_tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author x923749
 *
 */
public class DB2QueryHelper {


	/**
	 * Return contract number (formatted) per given XPAN (credit card number)
	 *
	 * @param number (String) XPAN number
	 * @return (String) contract number
	 */
	public String contractNumber_from_xpan(String number) {

		Connection connection = null;
		List<String> results = new ArrayList<String>();

        try {
            Class.forName(DatabaseReference.jdbcClassName);
            connection = DriverManager.getConnection(DatabaseReference.url, DatabaseReference.user, DatabaseReference.password);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;

        } finally {

            if (null != connection) {
                try {
                	Statement stmnt = connection.createStatement();

                	ResultSet rs = stmnt.executeQuery(String.format(DB2Query.Query_ContractNumber_from_Xpan, number));

                	if (rs.next()) {
                		results.add(rs.getString("PREFIX"));
                		results.add(rs.getString("INFIX"));
                		String temp = String.format("%d", rs.getLong("SUFFIX"));
                		results.add(temp.substring(0,3));
                		results.add(temp.substring(3));
                	}

                	rs.close();
                	stmnt.close();
                    connection.close();

                    return String.join(" ", results);

                } catch (SQLException e) {
                    e.printStackTrace();
                    return null;

                }
            }

        }

        return null;

	}


}
