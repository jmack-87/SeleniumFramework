package common_resources;


import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

import com.paulhammant.ngwebdriver.NgWebDriver;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import AlmReporting.AlmReport;
import AlmReporting.storeReportLog;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.HttpCommandExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import javax.imageio.ImageIO;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;
import java.util.function.Function;

/****************************************************************************************
 * Please list all the functions you are adding down here:
 * public void discard()
 * public String fnGetScriptName()
 * public String dateConv()
 * public void fnReportLog(String result, String expected, String actual, Boolean snapshot)
 * public void fnReportLog(String result, String expected, String actual, Boolean snapshot, String excMsg)
 * public void initBeforeEachTest(@Optional String envname, @Optional String appname)
 * public void afterEachTest()
 * public static void hard_wait(int amt)
 * public void initialize_Setup(String appscriptmame, String curenv, String curapp, boolean postToALM)
 * public void initialize_TestDataSheet(String appFilename)
 * public void fnInvokeBrowser(String browserType, String appURL)
 * public void fnInvokeBrowser(String browserType)
 * protected void fnInvokeExsistingBrowser(WebDriver rd)
 * public  void saveCurrentBrowserSession(WebDriver driver)
 * public void fnWebDriverDebugMode(String browserType)
 * public void fnCloseBrowser()
 * public void fnDefineQuery(String strQuery)
 * public String fnCurRowValue(String strColname)
 * public String fnGetText(By byProperty)
 * public void fnCustomWait(String oExpectedCond, By byProperty)
 * public void fnClickObject(By byProperty)
 * public void fnEnterText(By byProperty, String str)
 * public boolean fnObjectExist(By byProperty, int waitTimeInSeconds)
 * public boolean fnValidateObjectExist(By byProperty, int waitTime, String ObjectDiscription)
 * public String fnGetObjectProperty(String objProp, By byProperty)
 * public int getElementIndex(WebElement element)
 * public String fnRandomString(int length)
 * public long fnRandomNumber(int length)
 * public int fnRandomNumberInRange(int max, int min)
 * public Date fnDateAddorMinus(Date date, int numOfDays)
 * public String fnFormatDate(Date date,String DatePattern)
 * public boolean fnIsNumeric(String str)
 * public String fnGetComputerName()
 * public ArrayList getDataColumnNames()
 * public HashMap<String, String> getTestData()
 * public void fnSelect(By byProperty, String sValue)
 * public void fnSelectByIndex(By byProperty, int ind)
 * protected void closeChromeDriver()
 * protected void closeChromeBrowser()
 * public Boolean fnSwitchWindow(String wMain, String pTitle)
 * public void fnSwitchBacktoMain(String wMain)
 * public void fnWriteDataToExcel(String sheetName, String testCaseID, String colName, String value)
 * public void fnSelectByVisibleText(By byProperty, String sValue)
 * public int fnTableGetRowwithCellText(By byTableProperty, String cellText)
 * public String fnTableGetCellData(By byTableProperty, int rowNum, int colNum)
 * public WebElement fnTableChildItem(By byTableProperty, int rowNum, int colNum, String htmTag, int ind)
 * public String fnFormatCurrentDate()
 ****************************************************************************************/

public class utility {

	private static int stepNumber = 0;

	public static String testDataFilePath;
	public final static String ProjectPath = "C:\\Dev";
	public final static String LibraryPath = ProjectPath + "\\Library";
	public final static String ReportPath = ProjectPath + "\\ReportLog";
	public final String Timestamp = dateConv();
	public static String scenarioPath;
	public static String snapshotPath;
	public final static String testDataFolderPath = System.getProperty("user.dir") + "\\src\\main\\resources\\TestData";
	public final static String BrowserPath = System.getProperty("user.dir") + "\\src\\main\\resources\\browserDrivers";

	private String SessionTempDirectory = System.getProperty("java.io.tempdir") + "\\";
	private String SessionTempFileName = "UserSessionID1.properties";
	private String SessionTempFullPath = SessionTempDirectory + SessionTempFileName;

	public ExtentReports extent;
	public ExtentTest tests;

	public RemoteWebDriver wd;
	public WebDriverWait wdwait;
	public EventFiringWebDriver ed;
	public NgWebDriver ngWebDriver;

	private FluentWait<RemoteWebDriver> fWait;
	private WebElement we;
	private List<WebElement> weArray = new ArrayList<WebElement>();
	private int standardWait = 30;
	private JavascriptExecutor jse;

	public static sanlistener sanl = new sanlistener();

	private static Connection connection;
	private static Recordset recordset;
	private static String xlQuery;
	public static String curBrowser = "";
	public static String appScriptName = "";
	public static String curEnv = "";
	public static String curApp = "";
	public static String curTestSet = "";
	public static boolean postToALM = true;
	public static boolean closeBrowserAfterTest = true;

	public static AlmReport almObj = new AlmReport();

	public static String workingDir = System.getProperty("user.dir");
	public final static String HTMLPath = workingDir + "\\target\\ExtentReports\\ExecutionReport.html";
	public final static String VBSPath = workingDir + "\\src\\main\\resources\\SendEmail.vbs";
	public final static String ConfigPath = workingDir + "\\src\\main\\resources\\extent-config.xml";

	public static ExtentReports htmlextent;
	public static ExtentTest htmltests;
	public static boolean isSuiteRun = true;
	public static List<String> testList = new ArrayList<>();

	public static ScreenShot ss;


	/**
	 * Before suite initialization
	 *
	 * @author
	 */
	@BeforeSuite
	public void Initialization() {

		setJVMEncoding();
		Init_HTMLExtent();
		deleteRunHistory();

	}


	/**
	 * Set the encoding to UTF-8
	 *
	 * @author
	 */
	public static void setJVMEncoding() {

		String defaultCharacterEncoding = System.getProperty("file.encoding");

		if (!defaultCharacterEncoding.equalsIgnoreCase("UTF-8")) {
			System.setProperty("file.encoding", "UTF-8");
		}

		if (System.getProperty("file.encoding").equalsIgnoreCase("UTF-8")) {
			System.out.println("Encoding - set to UTF-8");
		}

	}


	/**
	 * Delete Run History Folders older than n days
	 *
	 * @author
	 */
	public static void deleteRunHistory() {

		int daysBack = 15;
		String dirWay = ReportPath;
		Boolean blnDelete = false;
		File directory = new File(dirWay);

		if (directory.exists()) {

			File[] listFiles = directory.listFiles();
			long purgeTime = System.currentTimeMillis() - ((long) daysBack * 24 * 60 * 60 * 1000);

			for (File listFile : listFiles) {
				blnDelete = false;

				if (listFile.isDirectory()) {
					File parentdir = new File(listFile.getAbsolutePath());
					File[] childFiles = parentdir.listFiles();

					for (File childFile : childFiles) {

						if (childFile.isFile()) {

							if (childFile.lastModified() < purgeTime) {
								blnDelete = true;
								break;
							}

						}

					}

					try {
						if (blnDelete) {
							FileUtils.deleteDirectory(listFile);
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}

	}


	/**
	 * Initialize extent html report
	 *
	 * @author
	 */
	public void Init_HTMLExtent() {

		if (null == htmlextent) {
			// Set HTML reporting file location
			htmlextent = new ExtentReports(HTMLPath, true);
			htmlextent.loadConfig(new File(ConfigPath));
			// htmltests = htmlextent.startTest("Test Suite", "Test Execution Report");
		}

	}


	/**
	 * Initialize test environment/platform data
	 *
	 * @param envname (String) test environment (i.e. PreProduction, Production, etc)
	 * @param appname (String) application under test (i.e. ROB, MOB)
	 * @param testsetname (String) name of test
	 * @param testbrowser (String) browser on which the test cases should run
	 * @author
	 */
	@BeforeMethod
	@Parameters({"envname", "appname", "testsetname", "testbrowser"})
	public void initBeforeEachTest(
			@Optional String envname,
			@Optional String appname,
			@Optional String testsetname,
			@Optional String testbrowser) {

		utility.curEnv = envname == null ?  utility.curEnv : envname;
		utility.curApp = appname == null ?  utility.curApp : appname;
		utility.curTestSet = testsetname == null ? utility.curTestSet : testsetname;
		utility.curBrowser = testbrowser == null ? utility.curBrowser : testbrowser;

		System.out.format("Params:%n\tEnvironment: %s%n\tApplication: %s%n\tTestSet: %s%n\tBrowser: %s%n",
				envname,
				appname,
				testsetname,
				testbrowser);

		String scriptName = this.getClass().getSimpleName();

		if (envname == null) {

			if (curEnv.isEmpty() && curApp.isEmpty() && curTestSet.isEmpty()) {

				isSuiteRun = false;
				EnvironmentDialogBox envDb = new EnvironmentDialogBox();

				if (envDb.isEnvironmentSettings()) {

					initialize_Setup(scriptName, envDb.getEnvrionment(), envDb.getApplication(), envDb.getTestset(), envDb.isPostToALM());

					curBrowser = envDb.getBrowser();
					closeBrowserAfterTest = envDb.closeBrowserAfterTest();
				}

			} else {
				initialize_Setup(scriptName, curEnv, curApp, curTestSet, postToALM);
			}

		} else {
			initialize_Setup(scriptName, envname, appname, testsetname, true);
			curBrowser = testbrowser;
			curTestSet = testsetname;
			curEnv = envname;
			curApp = appname;
		}

	}


	/*
	 * Author: Nayan Bhavsar Description: Initialize the Setup
	 *
	 */
	/**
	 *
	 *
	 * @param appscriptmame
	 * @param curenv
	 * @param curapp
	 * @param postToALM
	 */
	public void initialize_Setup(String appscriptmame, String curenv, String curapp, boolean postToALM) {

		utility.curEnv = curenv;
		utility.curApp = curapp;
		utility.appScriptName = appscriptmame;
		utility.postToALM = postToALM;

		scenarioPath = ReportPath + "\\" + appScriptName + "_" + Timestamp;
		snapshotPath = scenarioPath + "\\Snapshots";

		File dir = new File(snapshotPath);
		Boolean dircreated = false;

		if (!dir.exists()) {
			dircreated = dir.mkdirs();
			if (!dircreated) {
				scenarioPath = "C:\\";
				snapshotPath = "C:\\";
			}
		}

		String fPath = scenarioPath + "\\" + appScriptName + "_" + Timestamp + ".html";
		extent = new ExtentReports(fPath, true);
		tests = extent.startTest(appScriptName, "Test Execution Report");

		// htmltests = htmlextent.startTest(appScriptName, "Test Execution Report");

	}


	/*
	 * Author: Nayan Bhavsar Description: Initialize the Setup
	 *
	 */
	/**
	 *
	 * @param appscriptmame
	 * @param curenv
	 * @param curapp
	 * @param curtestset
	 * @param postToALM
	 */
	public void initialize_Setup(String appscriptmame, String curenv, String curapp, String curtestset,	boolean postToALM) {

		utility.curEnv = curenv;
		utility.curApp = curapp;

		if (null == curtestset) // gets a null when no parameter is present
			utility.curTestSet = "";
		else
			utility.curTestSet = curtestset;

		utility.appScriptName = appscriptmame;
		utility.postToALM = postToALM;

		scenarioPath = ReportPath + "\\" + appScriptName + "_" + Timestamp;
		snapshotPath = scenarioPath + "\\Snapshots";

		File dir = new File(snapshotPath);
		Boolean dircreated = false;

		if (!dir.exists()) {
			dircreated = dir.mkdirs();
			if (!dircreated) {
				scenarioPath = "C:\\";
				snapshotPath = "C:\\";
			}
		}

		String fPath = scenarioPath + "\\" + appScriptName + "_" + Timestamp + ".html";

		extent = new ExtentReports(fPath, true);

		tests = extent.startTest(appScriptName, "Test Execution Report");
		// htmlextent = new ExtentReports(HTMLPath, true);
		htmltests = htmlextent.startTest(appScriptName, "Suite Execution Report");

	}


	/*
	 * Author: Nayan Bhavsar Description: Initialize after each test date:
	 */
	/**
	 *
	 */
	@AfterMethod
	public void afterEachTest() {

		String testName = this.getClass().getSimpleName();
		String testStatus = getFinalStatus();

		if (testStatus.equalsIgnoreCase("Passed")) {
			testList.add(testName + ":Passed");
			System.out.println(testName + ":Passed");

		} else if (testStatus.equalsIgnoreCase("Failed")) {
			testList.add(testName + ":Failed");
			System.out.println(testName + ":Failed");

		} else if (testStatus.equalsIgnoreCase("Not Completed")) {
			testList.add(testName + ":Not completed");
			System.out.println(testName + ":Not completed");
		}

		if (postToALM) {
			try {
				if (!utility.curTestSet.isEmpty())
					almObj.postReportToAlm(utility.curEnv, utility.curTestSet, utility.appScriptName);
				else
					almObj.postReportToAlm(utility.curEnv, utility.curApp, utility.appScriptName);
			} catch (Exception e) {
				fnReportLog("Failed", "Exception occurred at ", e.getMessage(), true, e.getLocalizedMessage());
			}
		}
		if ((null != ed || null != wd) && closeBrowserAfterTest == true) {
			fnCloseBrowser();
		}
		discard();

	}


	/*
	 * Author: Nayan Bhavsar Description: Discard the Report object
	 *
	 */
	/**
	 *
	 */
	public void discard() {
		almObj.ListReportLog.clear();
		extent.endTest(tests);
		extent.flush();
		extent.close();

		htmlextent.endTest(htmltests);

	}


	/**
	 *
	 * @return
	 */
	public String getFinalStatus() {

		ArrayList<String> allStatus = new ArrayList<>();

		String endStatus;

		for (storeReportLog i : almObj.ListReportLog) {
			allStatus.add(i.getStatus());
		}

		if (allStatus.contains("Not Completed")) {
			endStatus = "Not Completed";
		} else if (allStatus.contains("Failed")) {
			endStatus = "Failed";
		} else {
			endStatus = "Passed";
		}

		return endStatus;
	}


	/*
	 * Author: Nayan Bhavsar Description: Discard HtmlExtent after suite
	 *
	 */
	/**
	 *
	 */
	@AfterSuite
	public void End_HTMLExtent() {

		// htmlextent.endTest(htmltests);
		htmlextent.flush();
		htmlextent.close();
		if (isSuiteRun) {
			System.out.println("Sending an Email");
			sendMail();
		} else
			System.out.println("Email is not Required");

	}


	/**
	 *
	 */
	public void sendMail() {

		StringBuilder strlist = new StringBuilder();
		for (String s : testList) {
			strlist.append(s);
			strlist.append(";");
		}
		String file = "wscript " + VBSPath + " " + HTMLPath + " " + curApp + " " + curEnv + " " + strlist.toString();
		try {
			// JOptionPane.showMessageDialog(null, "Sending Email");
			// setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
			Process p = Runtime.getRuntime().exec(file);
			// p.waitFor();//Wait for .vbs file to finish executing
		} catch (Exception e) {
			// JOptionPane.showMessageDialog(null, "Failed to install selected printers.
			// Exception thrown: " + e);
			e.printStackTrace();
		}

	}


	/*
	 * Author: Nayan Bhavsar Description: Get the current script name
	 *
	 */
	/**
	 *
	 * @return
	 */
	public String fnGetScriptName() {

		return this.getClass().getSimpleName();

	}


	/*
	 * Author: Nayan Bhavsar Description: Date Conversion
	 *
	 */
	/**
	 *
	 * @return
	 */
	public String dateConv() {

		DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
		Date date = new Date();
		return (dateFormat.format(date).replaceAll(":", ""));

	}


	/*
	 * Author: Nayan Bhavsar Description: Report the Result to the HTML report and
	 * add to the ALM Report list object
	 *
	 */
	/**
	 * Log a result to reporter
	 *
	 * @param result (String) pass/fail/skip condition to pass to report
	 * @param expected (String) description of expected observation
	 * @param actual (String) description of actual observation
	 * @param snapshot (boolean) take snapshot flag
	 */
	public void fnReportLog(String result, String expected, String actual, Boolean snapshot) {

		String snappath = null;

		expected = expected.substring(0, Math.min(expected.length(), 250)).replace('&', ' ').replace('-', ' ');
		if (null == actual) {
			actual = "Exception returned no detail.";
		}
		actual = actual.substring(0, Math.min(actual.length(), 250)).replace('&', ' ').replace('-', ' ');

		System.out.format("Log Record #%d:%n\tSnapshot:\t%b%n\tExpected:\t%s%n\tActual:\t\t%s%n", stepNumber++, snapshot, expected, actual);

		if (snapshot) {
			File scrFile = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
			snappath = snapshotPath + "\\" + dateConv() + "snap.png";
			try {
				FileUtils.copyFile(scrFile, new File(snappath));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		if (result.equalsIgnoreCase("Passed") || result.equalsIgnoreCase("Pass")) {
			if (snapshot) {
				// tests.log(LogStatus.INFO, expected, actual);
				tests.log(LogStatus.PASS, expected, actual + tests.addScreenCapture(snappath));
			} else {
				tests.log(LogStatus.PASS, expected, actual);
			}
			htmltests.log(LogStatus.PASS, expected, actual);
		}

		if (result.equalsIgnoreCase("Failed") || result.equalsIgnoreCase("Fail")) {
			if (snapshot) {
				// tests.log(LogStatus.INFO, expected, actual);
				tests.log(LogStatus.FAIL, expected, actual + tests.addScreenCapture(snappath));
			} else {
				tests.log(LogStatus.FAIL, expected, actual);
			}
			htmltests.log(LogStatus.FAIL, expected, actual);
		}

		almObj.ListReportLog.add(new storeReportLog(expected, actual, result));

	}


	/**
	 * Log a result to reporter
	 *
	 * @param result (String) pass/fail/skip condition to pass to report
	 * @param expected (String) description of expected observation
	 * @param actual (String) description of actual observation
	 * @param snapshot (boolean) take snapshot flag
	 * @param excMsg (String) - not used -
	 *
	 * @deprecated excMsg not used
	 */
	public void fnReportLog(String result, String expected, String actual, Boolean snapshot, String excMsg) {

		String snappath = null;

		expected = expected.substring(0, Math.min(expected.length(), 250)).replace('&', ' ').replace('-', ' ');
		if (actual != null) {
			actual = actual.substring(0, Math.min(actual.length(), 250)).replace('&', ' ').replace('-', ' ');
		}
		if (excMsg != null) {
			excMsg = excMsg.replace('&', ' ').replace('-', ' ');
		}
		if (snapshot) {
			File scrFile = ed.getScreenshotAs(OutputType.FILE);
			snappath = snapshotPath + "\\" + dateConv() + "snap.png";
			try {
				FileUtils.copyFile(scrFile, new File(snappath));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		if (result.equalsIgnoreCase("Passed") || result.equalsIgnoreCase("Pass")) {
			if (snapshot) {
				// tests.log(LogStatus.INFO, expected, actual);
				tests.log(LogStatus.PASS, expected, actual + tests.addScreenCapture(snappath));
			} else {
				tests.log(LogStatus.PASS, expected, actual);
			}
			htmltests.log(LogStatus.PASS, expected, actual);
		}

		if (result.equalsIgnoreCase("Failed") || result.equalsIgnoreCase("Fail")) {
			if (snapshot) {
				// tests.log(LogStatus.INFO, expected, actual);
				tests.log(LogStatus.FAIL, expected, actual + tests.addScreenCapture(snappath));
			} else {
				tests.log(LogStatus.FAIL, expected, actual);
			}
			htmltests.log(LogStatus.FAIL, expected, actual);
		}

		almObj.ListReportLog.add(new storeReportLog(expected, excMsg, result));

	}


	/*
	 * @BeforeMethod
	 *
	 * @Parameters({"envname","appname"}) public void initBeforeEachTest(@Optional
	 * String envname, @Optional String appname){ String scriptName =
	 * this.getClass().getSimpleName(); if (envname == null){ if (curEnv.isEmpty()
	 * && curApp.isEmpty() ) { EnvironmentDialogBox envDb = new
	 * EnvironmentDialogBox(); if (envDb.isEnvironmentSettings()) {
	 * initialize_Setup(scriptName, envDb.getEnvrionment(), envDb.getApplication(),
	 * envDb.isPostToALM()); this.closeBrowserAfterTest =
	 * envDb.closeBrowserAfterTest(); } }else{ initialize_Setup(scriptName, curEnv,
	 * curApp, postToALM); } }else{ initialize_Setup(scriptName, envname, appname,
	 * true); } }
	 */

	/*
	 * Author: Nayan Bhavsar Description: Initialize Datasheet path
	 *
	 */
	/**
	 *
	 * @param appFilename
	 */
	public void initialize_TestDataSheet(String appFilename) {

		testDataFilePath = testDataFolderPath + "\\" + curEnv + "\\" + curApp + "\\" + appFilename;

	}


	// ***********************************************************
	// ***********************************************************
	// *******Please all the common functions below***************
	// ***********************************************************
	// ***********************************************************


	/*
	 * Author: Nayan Bhavsar Description: Hard Wait
	 *
	 */
	/**
	 * Pause execution for desired
	 *
	 * @param amt (int) time to wait in seconds
	 */
	public static void hard_wait(int amt) {

//		long a = System.currentTimeMillis();
//		long b = System.currentTimeMillis();
//		while ((b - a) <= amt) {
//			b = System.currentTimeMillis();
//		}

		try {
			Thread.sleep((long) amt*1000);
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		}

	}


	/**
	 * Open browser
	 *
	 * @param browserType
	 * @param appURL
	 *
	 * @author Nayan Bhavsar
	 */
	public void fnInvokeBrowser(String browserType, String appURL) {

		if (curBrowser == null || curBrowser.isEmpty()) {
			curBrowser = browserType;
		} else {
			browserType = curBrowser;
		}

		if (browserType.equalsIgnoreCase("desktopfirefox")) {

			FirefoxOptions options = new FirefoxOptions();
			Path path = Paths.get("C:\\Dev\\FF\\chrome.exe");
			options.setBinary(path);

			FirefoxProfile ffProf = new FirefoxProfile();
			ffProf.setPreference("network.proxy.type", 2);
			ffProf.setPreference("network.proxy.autoconfig_url", "http://wpad.svrn.sovereignbank.com/wpad.dat");
			ffProf.setAcceptUntrustedCertificates(true);
			ffProf.setAssumeUntrustedCertificateIssuer(false);
			options.setProfile(ffProf);

			System.setProperty("webdriver.gecko.driver", BrowserPath + "\\geckodriver.exe");
			System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE, "target\\fflog.txt");
			wd = new FirefoxDriver(options);

		} else if (browserType.equalsIgnoreCase("desktopchrome")) {
			System.setProperty("webdriver.chrome.driver", BrowserPath + "\\chromedriver.exe");
			wd = new ChromeDriver();

		} else if (browserType.equalsIgnoreCase("desktopiexplore")) {
			System.setProperty("webdriver.ie.driver", BrowserPath + "\\IEDriverServer_32.exe");
			wd = new InternetExplorerDriver();
		}

		wd.manage().window().maximize();
		ed = new EventFiringWebDriver(wd);
		ed.register(sanl);
		wdwait = new WebDriverWait(ed, 60);
//		wd.get(appURL);
//		saveCurrentBrowserSession(wd);
//
//		if (wd.getCurrentUrl().length() > 0) {
//			fnReportLog("Passed", browserType + " Browser should be launched",
//					"The URL: " + appURL + " launched successfully", false);
//		} else {
//			fnReportLog("Failed", browserType + " Browser should be launched",
//					"The URL: " + appURL + " didnot launched successfully", true);
//		}

		ss = new ScreenShot(wd);
		jse = (JavascriptExecutor) wd;
		fWait = new FluentWait<RemoteWebDriver>(wd)
				.withTimeout(Duration.ofSeconds(standardWait))
				.ignoring(NoSuchElementException.class);

		fnReportLog("Passed", browserType + " Browser should be launched", browserType + " launched successfully", false);

	}


	/**
	 *
	 * @param browserType
	 */
	public void fnInvokeBrowser(String browserType) {

		if (!curBrowser.isEmpty())
			browserType = curBrowser;
		if (browserType.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", BrowserPath + "\\geckodriver.exe");
			wd = new FirefoxDriver();

		} else if (browserType.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", BrowserPath + "\\chromedriver.exe");
			wd = new ChromeDriver();

		} else if (browserType.equalsIgnoreCase("ie")) {
			System.setProperty("webdriver.ie.driver", BrowserPath + "\\IEDriverServer.exe");
			wd = new InternetExplorerDriver();
		}

		ed = new EventFiringWebDriver(wd);
		ed.register(sanl);
		wdwait = new WebDriverWait(ed, 60);
		saveCurrentBrowserSession(wd);

		ss = new ScreenShot(wd);
		jse = (JavascriptExecutor) wd;
		fWait = new FluentWait<RemoteWebDriver>(wd)
				.withTimeout(Duration.ofSeconds(standardWait))
				.ignoring(NoSuchElementException.class);

		fnReportLog("Passed", browserType + " Browser should be launched", browserType + " launched successfully", false);

	}


	/**
	 *
	 * @param rd
	 */
	protected void fnInvokeExsistingBrowser(RemoteWebDriver rd) {

		ed = new EventFiringWebDriver(rd);
		ed.register(sanl);
		wdwait = new WebDriverWait(ed, 60);

		ss = new ScreenShot(rd);
		jse = (JavascriptExecutor) rd;

	}


	/**
	 *
	 * @param driver
	 */
	public void saveCurrentBrowserSession(WebDriver driver) {

		String session_id = ((RemoteWebDriver) driver).getSessionId().toString();
		HttpCommandExecutor executor = (HttpCommandExecutor) ((RemoteWebDriver) driver).getCommandExecutor();
		URL url = executor.getAddressOfRemoteServer();

		BufferedWriter br;

		try {
			new File(SessionTempFullPath).createNewFile();

			br = new BufferedWriter(new FileWriter(new File(SessionTempFullPath)));

			br.write("url=" + url);
			br.newLine();
			br.write("session_id=" + session_id);

			br.flush();
			br.close();

		} catch (Exception e) {
			new Throwable("Unable to save Session information");
		}

	}


	/*
	 * *****public void fnWebDriverDebugMode(String browserType) { boolean
	 * blnCreateNewBrowserSession = false; WebDriver rw = null; if (new
	 * File(SessionTempFullPath).exists()) { Properties pr = new Properties();
	 *
	 * try { pr.load(new FileInputStream(new File(SessionTempFullPath))); URL url =
	 * new URL(pr.get("url").toString()); String session_id =
	 * pr.get("session_id").toString(); WebDriverDebugMode WDebug = new
	 * WebDriverDebugMode(); rw = WDebug.createDriverFromSession(session_id,url);
	 * try { rw.getTitle(); }catch(UnreachableBrowserException ur){
	 * blnCreateNewBrowserSession = true; }
	 *
	 *
	 * } catch (IOException e) { blnCreateNewBrowserSession = true; } }else{
	 * blnCreateNewBrowserSession = true; }
	 *
	 * if(blnCreateNewBrowserSession){ fnInvokeBrowser(browserType); }else{
	 * fnInvokeExsistingBrowser(rw); }
	 *
	 * }
	 */


	/*
	 * Author: Nayan Bhavsar Description: Close the Browser
	 *
	 */
	/**
	 *
	 */
	public void fnCloseBrowser() {

		// ed.close();
//		for (String handle : ed.getWindowHandles()) {
//			ed.switchTo().window(handle);
//			ed.close();
//
//		}
		System.out.println("Quitting browser.");
		wd.quit();

		/*
		 * if(ed.toString().contains("null"))
		 * fnReportLog("Passed","Browser should be closed",
		 * "Browser closed successfully", false); else
		 * fnReportLog("Failed","Browser should be closed", "Browser didnot get closed",
		 * true);
		 */

		ed.unregister(sanl);

	}


	/*
	 * Author: Nayan Bhavsar Description: Define the Query to retrieve the
	 *
	 */
	/**
	 *
	 * @param strQuery
	 */
	public void fnDefineQuery(String strQuery) {

		xlQuery = strQuery;

	}


	/*
	 * Author: Nayan Bhavsar Description: Retrieve the Column value
	 *
	 */
	/**
	 *
	 * @param strColname
	 * @return
	 */
	public String fnCurRowValue(String strColname) {

		String strVal = null;
		Fillo fillo = new Fillo();

		try {
			connection = fillo.getConnection(testDataFilePath);
			recordset = connection.executeQuery(xlQuery);

			while (recordset.next()) {
				strVal = recordset.getField(strColname);
			}
			fnReportLog("Passed", "Retrive Test Data",
					"Column: " + strColname + " value: " + strVal + " retrieved  successfully", false);
		} catch (FilloException e) {
			e.printStackTrace();
			fnReportLog("Failed", "Retrive Test Data",
					"Exception while Retriving Column: " + strColname + " at " + e.getLocalizedMessage(), true);
		}

		recordset.close();
		connection.close();

		recordset = null;
		connection = null;

		return strVal;

	}


	/*
	 * Author: Nayan Bhavsar Description: Retrive the Element Text
	 *
	 */
	/**
	 *
	 * @param byProperty
	 * @return
	 */
	public String fnGetText(By byProperty) {

		String oText = ed.findElement(byProperty).getText();
		return oText;

	}


	/*
	 * Author: Nayan Bhavsar Description: Custom wait
	 *
	 */
	/**
	 *
	 * @param oExpectedCond
	 * @param byProperty
	 */
	public void fnCustomWait(String oExpectedCond, By byProperty) {

		if (oExpectedCond.equalsIgnoreCase("Clickable")) {
			wdwait.until(ExpectedConditions.elementToBeClickable(byProperty));
		} else if (oExpectedCond.equalsIgnoreCase("Visible")) {
			wdwait.until(ExpectedConditions.visibilityOfElementLocated(byProperty));
		} else if (oExpectedCond.equalsIgnoreCase("InVisible")) {
			wdwait.until(ExpectedConditions.invisibilityOfElementLocated(byProperty));
		}

	}


	/*
	 * Author: Nayan Bhavsar Description: Click a object
	 *
	 */
	/**
	 *
	 * @param byProperty
	 */
	public void fnClickObject(By byProperty) {

		if (fnObjectExist(byProperty, 20)) {
			ed.findElement(byProperty).click();
			fnReportLog("Passed", "Clicking object:" + byProperty.toString(), "Object has been clicked", false);
		} else {
			fnReportLog("Failed", "Clicking object:" + byProperty.toString(), "Object has not been clicked", true);
		}

	}


	/*
	 * Author: Nayan Bhavsar Description: Click a object
	 *
	 */
	public void fnClickObject(By byProperty, String sLogMsg) {

		if (fnObjectExist(byProperty, 20)) {
			ed.findElement(byProperty).click();
			fnReportLog("Passed", sLogMsg, sLogMsg, false);
			fnReportLog("Passed", "Clicking object:" + byProperty.toString(), "Object has been clicked", false);
		} else {
			fnReportLog("Failed", sLogMsg, "", true);
			fnReportLog("Failed", "Clicking object:" + byProperty.toString(), "Object has not been clicked", true);
		}

	}


	/*
	 * Author: Nayan Bhavsar Description: Enter text
	 *
	 */
	/**
	 *
	 * @param byProperty
	 * @param str
	 */
	public void fnEnterText(By byProperty, String str) {

		if (fnObjectExist(byProperty, 20)) {
			ed.findElement(byProperty).sendKeys(str);
			fnReportLog("Passed", "Entering text to object:" + byProperty.toString(), str + " Text has been entered",
					false);
		} else {
			fnReportLog("Failed", "Entering text to object:" + byProperty.toString(),
					str + " Text has not been entered", true);
		}

	}


	/*
	 * Author: Nayan Bhavsar Description: Clear text
	 *
	 */
	/**
	 *
	 * @param byProperty
	 */
	public void fnClearText(By byProperty) {

		if (fnObjectExist(byProperty, 20)) {
			ed.findElement(byProperty).clear();
			fnReportLog("Passed", "Clearing existing text to object:" + byProperty.toString(), "Text has been cleared",
					false);
		} else {
			fnReportLog("Failed", "Clearing existing text to object:" + byProperty.toString(),
					"Text has not been cleared", true);
		}

	}


	/*
	 * Author: Nayan Bhavsar Description: Enter text
	 *
	 */
	/**
	 *
	 * @param byProperty
	 * @param str
	 * @param sLogMsg
	 */
	public void fnEnterText(By byProperty, String str, String sLogMsg) {

		if (fnObjectExist(byProperty, 20)) {
			ed.findElement(byProperty).sendKeys(str);
			fnReportLog("Passed", sLogMsg, sLogMsg + ": " + str, false);
			fnReportLog("Passed", "Entering text to object:" + byProperty.toString(), "Text has been entered", false);
		} else {
			fnReportLog("Failed", "Entering text to object:" + byProperty.toString(), "Text has not been entered",
					true);
		}

	}


	/*
	 * Author: Nayan Bhavsar Description: Check if a single instance of a web object
	 * exist. wait time in seconds
	 *
	 */
	/**
	 *
	 * @param byProperty
	 * @param waitTimeInSeconds
	 * @return
	 */
	public boolean fnObjectExist(By byProperty, int waitTimeInSeconds) {

		WebDriverWait wait = new WebDriverWait(ed, waitTimeInSeconds);
		try {
			wait.until(ExpectedConditions.numberOfElementsToBe(byProperty, 1));
			return true;
		} catch (TimeoutException T) {
			return false;
		}

	}


	/*
	 * Author: Nayan Bhavsar Description: Verify if a object exists
	 *
	 */
	/**
	 *
	 * @param byProperty
	 * @param waitTime
	 * @param ObjectDiscription
	 * @return
	 */
	public boolean fnValidateObjectExist(By byProperty, int waitTime, String ObjectDiscription) {

		boolean blnObjecExist = fnObjectExist(byProperty, waitTime);

		if (blnObjecExist) {
			fnReportLog("Passed", "Verify if object [" + ObjectDiscription + "] exist using identification property: "
					+ byProperty.toString(), "object [" + ObjectDiscription + "] exist", true);
			return true;
		} else {
			fnReportLog("Failed", "Verify if object [" + ObjectDiscription + "] exist using identification property: "
					+ byProperty.toString(), "object [" + ObjectDiscription + "] does not exist", false);
			return false;
		}
	}


	/*
	 * Author: Nayan Bhavsar Description: Retrieve Object Property
	 *
	 */
	/**
	 *
	 * @param objProp
	 * @param byProperty
	 * @return
	 */
	public String fnGetObjectProperty(String objProp, By byProperty) {

		String oProp = ed.findElement(byProperty).getAttribute(objProp);
		return oProp;

	}


	/*
	 * Author: Nayan Bhavsar Description: Retrieve Object index
	 *
	 */
	/**
	 *
	 * @param element
	 * @return
	 */
	public int getElementIndex(WebElement element) {

		WebElement parent = element.findElement(By.xpath("src/main"));
		List<WebElement> siblings = parent.findElements(By.xpath("./" + element.getTagName()));
		int i = 0;
		for (WebElement sibling : siblings) {
			if (element.equals(sibling)) {
				return i;
			} else {
				i++;
			}
		}
		throw new NotFoundException(); // Should never happen

	}


	/*
	 * Author: Nayan Bhavsar Description: Generate a random alphabet string based on
	 * the imput length
	 *
	 */
	/**
	 *
	 * @param length
	 * @return
	 */
	public String fnRandomString(int length) {

		char[] alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
		String randomString = "";

		for (int i = 1; i <= length; i++) {
			Random rand = new Random();
			int randomIndex = rand.nextInt(alphabets.length);
			randomString += alphabets[randomIndex];
		}

		return randomString;

	}


	/*
	 * Author: Nayan Bhavsar Description: Generate a random number based on the
	 * input length
	 *
	 */
	/**
	 *
	 * @param length
	 * @return
	 */
	public long fnRandomNumber(int length) {

		Random rand = new Random();
		String randomNumber = "";

		for (int i = 1; i <= length; i++) {
			int randomIndex = rand.nextInt(10);
			randomNumber += String.valueOf(randomIndex);
		}

		return Long.valueOf(randomNumber);

	}


	/*
	 * Author: Nayan Bhavsar Description: Generate a random number between two
	 * numbers
	 *
	 */
	/**
	 *
	 * @param max
	 * @param min
	 * @return
	 */
	public int fnRandomNumberInRange(int max, int min) {

		Random rand = new Random();
		return rand.nextInt((max - min) + 1) + min;

	}


	/*
	 * Author: Nayan Bhavsar Description: Add or minus days from an input date
	 *
	 */
	/**
	 *
	 * @param date
	 * @param numOfDays
	 * @return
	 */
	public Date fnDateAddorMinus(Date date, int numOfDays) {

		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.DATE, numOfDays);
		return c.getTime();

	}


	/*
	 * Author: Nayan Bhavsar Description: format date
	 *
	 */
	/**
	 *
	 * @param date
	 * @param DatePattern
	 * @return
	 */
	public String fnFormatDate(Date date, String DatePattern) {

		/*
		 * Pattern Example dd-MM-yy 31-01-12 dd-MM-yyyy 31-01-2012 MM-dd-yyyy 01-31-2012
		 * yyyy-MM-dd 2012-01-31 hh:mm:ss a 10:01:59 AM/PM yyyy-MM-dd hh:mm:ss a
		 * 2012-01-31 10:01:59 AM/PM yyyy-MM-dd HH:mm:ss 2012-01-31 23:59:59 yyyy-MM-dd
		 * HH:mm:ss.SSS 2012-01-31 23:59:59.999 yyyy-MM-dd HH:mm:ss.SSSZ 2012-01-31
		 * 23:59:59.999+0100 EEEEE MMMMM yyyy HH:mm:ss.SSSZ Saturday November 2012
		 * 10:45:42.720+0100 ..and many more format. search Google for java example
		 * SimpleDateFormat.
		 */

		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(DatePattern);
		return DATE_FORMAT.format(date);

	}


	/*
	 * Author: Nayan Bhavsar Description: format date
	 *
	 */
	/**
	 *
	 * @param date
	 * @param DatePattern
	 * @param dtTimeZone
	 * @return
	 */
	public String fnFormatDate(Date date, String DatePattern, String dtTimeZone) {

		/*
		 * Pattern Example dd-MM-yy 31-01-12 dd-MM-yyyy 31-01-2012 MM-dd-yyyy 01-31-2012
		 * yyyy-MM-dd 2012-01-31 hh:mm:ss a 10:01:59 AM/PM yyyy-MM-dd hh:mm:ss a
		 * 2012-01-31 10:01:59 AM/PM yyyy-MM-dd HH:mm:ss 2012-01-31 23:59:59 yyyy-MM-dd
		 * HH:mm:ss.SSS 2012-01-31 23:59:59.999 yyyy-MM-dd HH:mm:ss.SSSZ 2012-01-31
		 * 23:59:59.999+0100 EEEEE MMMMM yyyy HH:mm:ss.SSSZ Saturday November 2012
		 * 10:45:42.720+0100 ..and many more format. search Google for java example
		 * SimpleDateFormat.
		 */

		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(DatePattern);
		if (dtTimeZone.equalsIgnoreCase("EST"))
			DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		else if (dtTimeZone.equalsIgnoreCase("CST"))
			DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
		else if (dtTimeZone.equalsIgnoreCase("MST"))
			DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("America/Phoenix"));
		else if (dtTimeZone.equalsIgnoreCase("PST"))
			DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));
		else
			DATE_FORMAT.setTimeZone(TimeZone.getDefault());

		return DATE_FORMAT.format(date);

	}


	/*
	 * Author: Nayan Bhavsar Description: Check if a string is Numeric
	 *
	 */
	/**
	 *
	 * @param str
	 * @return
	 */
	public boolean fnIsNumeric(String str) {

		NumberFormat formatter = NumberFormat.getInstance();
		ParsePosition pos = new ParsePosition(0);
		formatter.parse(str, pos);
		return str.length() == pos.getIndex();

	}


	/*
	 * Author: Nayan Bhavsar Description: Get the current user's computer name
	 *
	 */
	/**
	 *
	 * @return
	 */
	public String fnGetComputerName() {
		String hostname = "";
		try {
			InetAddress addr;
			addr = InetAddress.getLocalHost();
			hostname = addr.getHostName();
		} catch (UnknownHostException ex) {
			ex.printStackTrace();
		}

		return hostname;

	}


	/*
	 * Author: Nayan Bhavsar Description: Retrieve the Column names for the
	 * specified test data record
	 *
	 */
	/**
	 *
	 * @return
	 */
	public ArrayList getDataColumnNames() {

		ArrayList<String> sColumnNames = null;
		Fillo fillo = new Fillo();

		try {
			connection = fillo.getConnection(testDataFilePath);
			recordset = connection.executeQuery(xlQuery);

			while (recordset.next()) {
				sColumnNames = recordset.getFieldNames();
			}
			fnReportLog("Passed", "Retrieve Test Data Column Names", "Column Names retrieved  successfully", false);
		} catch (FilloException e) {
			e.printStackTrace();
			fnReportLog("Failed", "Retrieve Test Data Column Names",
					"Exception while Retrieving Column Names at " + e.getLocalizedMessage(), true);
		}

		recordset.close();
		connection.close();

		recordset = null;
		connection = null;

		return sColumnNames;

	}


	/*
	 * Author: Nayan Bhavsar Description: Retrieve the Column values for the
	 * specified test data record
	 *
	 */
	/**
	 *
	 * @return
	 */
	public HashMap<String, String> getTestData() {

		HashMap<String, String> sTestData = new HashMap<String, String>();
		Fillo fillo = new Fillo();

		try {
			ArrayList<String> listColNames = getDataColumnNames();
			connection = fillo.getConnection(testDataFilePath);
			recordset = connection.executeQuery(xlQuery);

			while (recordset.next()) {
				for (String listColName : listColNames) {
					sTestData.put(listColName, recordset.getField(listColName));
				}

//                listColNames.forEach(name -> {
//                    try {
//                        recordset.getField(name);
//                    }
//                    catch (FilloException e) {
//                        e.printStackTrace();
//                        fnReportLog("Failed","Retrieve Test Data", "Exception while Retrieving test data " + e.getLocalizedMessage(), true);
//                    }
//                });
			}
			fnReportLog("Passed", "Retrieve Test Data", "Retrieved test data successfully", false);
		} catch (FilloException e) {
			e.printStackTrace();
			fnReportLog("Failed", "Retrieve Test Data",
					"Exception while Retrieving test data " + e.getLocalizedMessage(), true);
		}

		recordset.close();
		connection.close();

		recordset = null;
		connection = null;

		return sTestData;

	}


	/*
	 * Author: Nayan Bhavsar Description: Select from a list
	 *
	 */
	/**
	 *
	 * @param byProperty
	 * @param sValue
	 */
	public void fnSelect(By byProperty, String sValue) {

		if (fnObjectExist(byProperty, 20)) {
			Select objSelect = new Select(ed.findElement(byProperty));
			objSelect.selectByValue(sValue);
			fnReportLog("Passed", "Selecting text to object:" + byProperty.toString(),
					sValue + " Text has been selected", false);
		} else {
			fnReportLog("Failed", "Selecting text to object:" + byProperty.toString(),
					sValue + " Text has not been selected", true);
		}

	}


	/*
	 * Author: Nayan Bhavsar Description: Select from a list by Index
	 *
	 */
	/**
	 *
	 * @param byProperty
	 * @param ind
	 */
	public void fnSelectByIndex(By byProperty, int ind) {

		if (fnObjectExist(byProperty, 20)) {
			Select objSelect = new Select(ed.findElement(byProperty));
			objSelect.selectByIndex(ind);
			fnReportLog("Passed", "Selecting text to object:" + byProperty.toString(), ind + " index has been selected",
					false);
		} else {
			fnReportLog("Failed", "Selecting text to object:" + byProperty.toString(),
					ind + " index has not been selected", true);
		}

	}


	/**
	 *
	 * @throws IOException
	 * @throws InterruptedException
	 */
	protected void closeChromeDriver() throws IOException, InterruptedException {

		System.out.println("Closing chrome driver ...");
		Process process = Runtime.getRuntime().exec("taskkill /F /IM ChromeDriver.exe");
		hard_wait(3000);
		process.destroy();

	}


	/**
	 *
	 * @throws IOException
	 * @throws InterruptedException
	 */
	protected void closeChromeBrowser() throws IOException, InterruptedException {

		System.out.println("Closing chrome browser processes ...");
		Process process = Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
		hard_wait(3000);
		process.destroy();

	}


	/*
	 * Author: Nayan Bhavsar Description: Report the Result to the HTML report and
	 * add to the ALM Report list object
	 *
	 */
	/**
	 *
	 * @param result
	 * @param expected
	 * @param actual
	 * @param snapshot
	 * @param bFullLengthScreenshot
	 * @throws AWTException
	 */
	public void fnReportLog(String result, String expected, String actual, Boolean snapshot, boolean bFullLengthScreenshot) throws AWTException {

		String snappath = null;

		if (snapshot && bFullLengthScreenshot) {
//            File scrFile = ((TakesScreenshot)wd).getScreenshotAs(OutputType.FILE);
			BufferedImage currentScreen = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			snappath = snapshotPath + "\\" + dateConv() + "snap.png";
			try {
//                FileUtils.copyFile(scrFile, new File(snappath));
				ImageIO.write(currentScreen, "png", new File(snappath));
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (snapshot) {
			fnReportLog(result, expected, actual, snapshot);
		}
		if (result.equalsIgnoreCase("Passed")) {
			if (snapshot) {
				// tests.log(LogStatus.INFO, expected, actual);
				tests.log(LogStatus.PASS, expected, actual + tests.addScreenCapture(snappath));
			} else {
				tests.log(LogStatus.PASS, expected, actual);
			}
		}

		if (result.equalsIgnoreCase("Failed")) {
			if (snapshot) {
				// tests.log(LogStatus.INFO, expected, actual);
				tests.log(LogStatus.FAIL, expected, actual + tests.addScreenCapture(snappath));
			} else {
				tests.log(LogStatus.FAIL, expected, actual);
			}
		}

		almObj.ListReportLog.add(new storeReportLog(expected, actual, result));

	}


	// Invoke chrome browser with desired options
	// @author Nayan
	/**
	 *
	 * @param browserType
	 * @throws InterruptedException
	 */
	protected void fnInvokeChromeBrowserWithOptions(String browserType) throws InterruptedException {

		ChromeOptions options = new ChromeOptions();
		String sProfilePath = System.getProperty("user.home") + "\\AppData\\Local\\Google\\Chrome\\User Data";
		options.addArguments("user-data-dir=" + sProfilePath);
		options.addArguments("disable-popup-blocking");
		options.setCapability("platform", "ANY");
		System.setProperty("webdriver.chrome.driver", BrowserPath + "\\chromedriver.exe");
		wd = new ChromeDriver(options);
		Thread.sleep(10000);
		wd.manage().window().maximize();
		ed = new EventFiringWebDriver(wd);
		ed.register(sanl);
		wdwait = new WebDriverWait(ed, 10);
		ngWebDriver = new NgWebDriver(ed);
		saveCurrentBrowserSession(wd);

	}


	/*
	 * Author: Nayan Bhavsar Description: Switch to new opened Tab
	 *
	 */
	/**
	 *
	 * @param wMain
	 * @param pTitle
	 * @return
	 */
	public Boolean fnSwitchWindow(String wMain, String pTitle) {

		Boolean blnWinSwitch = false;
		Set<String> sAllWindows = ed.getWindowHandles();
		for (String sCurBrowser : sAllWindows) {
			if (!wMain.equalsIgnoreCase(sCurBrowser)) {
				String curTitle = ed.switchTo().window(sCurBrowser).getTitle();
				if (curTitle.contains(pTitle)) {
					hard_wait(2000);
					blnWinSwitch = true;
					break;
				} else
					ed.switchTo().window(wMain);

			}
		}
		return blnWinSwitch;

	}


	/*
	 * Author: Nayan Bhavsar Description: Switch to Main Window
	 *
	 */
	/**
	 *
	 * @param wMain
	 */
	public void fnSwitchBacktoMain(String wMain) {

		ed.switchTo().window(wMain);
		hard_wait(2000);

	}


	/*
	 * Author: Nayan Bhavsar Description: check if file is opened
	 *
	 */
	/**
	 *
	 * @param filename
	 * @return
	 */
	public boolean isFileOpened(String filename) {

		boolean res = false;
		FileWriter fw = null;
		/*
		 * File file = new File(filename);
		 *
		 * FileChannel channel = new RandomAccessFile(file, "rw").getChannel(); // Get
		 * an exclusive lock on the whole file FileLock lock = channel.lock();
		 *
		 * try { //The file is not already opened lock = channel.tryLock(); }
		 */

		try {
			fw = new FileWriter(filename);
		} catch (IOException e) {
			// File is open by someone else
			res = true;
		} finally {
			// lock.release();
			try {
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return res;

	}


	/*
	 * Function Name : fnWriteDataToExcel() Input : Description : Update the excel
	 * file with some datavalue. Input : Sheet Name, Test Case ID, Column name,
	 * Value to be updated Author : Nayan Bhavsar Date :
	 */
	/**
	 *
	 * @param filePath
	 * @param sheetName
	 * @param testCaseID
	 * @param colName
	 * @param value
	 */
	public void fnWriteDataToExcel(String filePath, String sheetName, String testCaseID, String colName, String value) {

		Fillo fillo = new Fillo();

		try {

			connection = fillo.getConnection(filePath);
			String strQuery = "Update " + sheetName + " Set " + colName + " ='" + value + "' where TestCaseNo = '"
					+ testCaseID + "'";
			connection.executeUpdate(strQuery);

		} catch (FilloException e) {
			e.printStackTrace();
			fnReportLog("Failed", "Update Test Data", "Exception while updating test data " + e.getLocalizedMessage(),
					true);
		} finally {
			connection.close();
		}

	}


	/*
	 * Function Name : fnSelectByVisibleText Input : Description : Select a value
	 * from dropdown based upon visible text Author : Nayan Bhavsar Date :
	 */
	/**
	 *
	 * @param byProperty
	 * @param sValue
	 */
	public void fnSelectByVisibleText(By byProperty, String sValue) {

		if ((ed.findElement(byProperty).isDisplayed())) {
			Select objSelect = new Select(ed.findElement(byProperty));
			objSelect.selectByVisibleText(sValue);
			fnReportLog("Passed", "Selecting text to object:" + byProperty.toString(),
					"Text has been selected " + sValue, false);
		} else {
			fnReportLog("Failed", "Selecting text to object:" + byProperty.toString(),
					"Text has not been selected " + sValue, true);
		}

	}


	/*
	 * Function Name : fnTableGetRowwithCellText Input : Description : Returns the
	 * rownumber for given text Author : Nayan Bhavsar Date :
	 */
	/**
	 *
	 * @param byTableProperty
	 * @param cellText
	 * @return
	 */
	public int fnTableGetRowwithCellText(By byTableProperty, String cellText) {

		int rowNum = 0;
		if (fnObjectExist(byTableProperty, 2)) {
			fnReportLog("Passed", "Table should exist", "Table exists ", false);

			WebElement tblUsers = ed.findElement(byTableProperty);
			List<WebElement> tblRows = tblUsers.findElements(By.xpath("tbody/tr")); // [text()='"+cellText+"']"));
			for (int i = 0; i < tblRows.size(); i++) {
				String strRowVal = tblRows.get(i).getText();
				if (strRowVal.toLowerCase().contains(cellText.toLowerCase())) {
					rowNum = i + 1;
					break;
				}
			}
		} else
			fnReportLog("Failed", "Table should exist", "Table does not exist", true);
		return rowNum;

	}


	/*
	 * Function Name : fnTableGetCellData Input : Description : Returns the celldata
	 * for given text Author : Nayan Bhavsar Date :
	 */
	/**
	 *
	 * @param byTableProperty
	 * @param rowNum
	 * @param colNum
	 * @return
	 */
	public String fnTableGetCellData(By byTableProperty, int rowNum, int colNum) {

		String txtCellVal = "";
		if (fnObjectExist(byTableProperty, 2)) {
			fnReportLog("Passed", "Table should exist", "Table exists ", false);

			WebElement tblUsers = ed.findElement(byTableProperty);
			List<WebElement> tblRows = tblUsers.findElements(By.xpath("tbody/tr"));
			List<WebElement> tblCells = tblRows.get(rowNum - 1).findElements(By.xpath("td"));
			txtCellVal = tblCells.get(colNum - 1).getText();

		} else
			fnReportLog("Failed", "Table should exist", "Table does not exist", true);
		return txtCellVal;

	}


	/*
	 * Function Name : fnTableChildItem Input : Description : Returns the object for
	 * given cell Author : Nayan Bhavsar Date :
	 */
	/**
	 *
	 * @param byTableProperty
	 * @param rowNum
	 * @param colNum
	 * @param xpathExpression
	 * @param ind
	 * @return
	 */
	public WebElement fnTableChildItem(By byTableProperty, int rowNum, int colNum, String xpathExpression, int ind) {

		WebElement objCell = null;
		if (fnObjectExist(byTableProperty, 2)) {
			fnReportLog("Passed", "Table should exist", "Table exists ", false);

			WebElement tblUsers = ed.findElement(byTableProperty);
			List<WebElement> tblRows = tblUsers.findElements(By.xpath("tbody/tr"));
			List<WebElement> tblCells = tblRows.get(rowNum - 1).findElements(By.xpath("td"));
			List<WebElement> objCells = tblCells.get(colNum - 1).findElements(By.xpath(xpathExpression));
			if (objCells.size() > 0) {
				fnReportLog("Passed", "Object should found", "Object found", false);
				objCell = objCells.get(ind);
			} else
				fnReportLog("Failed", "Object should found", "Object didnot get found", true);
		} else
			fnReportLog("Failed", "Table should exist", "Table does not exist", true);
		return objCell;

	}


	/*
	 * Function Name : fnFormatCurrentDate Input : Description : Format current date
	 * to desired format Author : Nayan Bhavsar
	 *
	 */
	/**
	 *
	 * @param format
	 * @return
	 * @throws InterruptedException
	 */
	public String fnFormatCurrentDate(String format) throws InterruptedException {

		/*
		 * // Create object of SimpleDateFormat class and decide the format DateFormat
		 * dateFormat = new SimpleDateFormat(format); //Get current date Date() Date
		 * date = new Date(); // Now format the date String dateFormatted =
		 * dateFormat.format(date); //Return formatted date return dateFormatted;
		 */

		/*
		 * Date currentTime = new Date(); SimpleDateFormat sdf = new
		 * SimpleDateFormat(format);
		 * sdf.setTimeZone(TimeZone.getTimeZone("US/Pacific")); String dateFormatted =
		 * sdf.format(currentTime); return dateFormatted;
		 */

		Calendar calender = Calendar.getInstance();
		calender.setTime(new Date());
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		sdf.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		String dateFormatted = sdf.format(calender.getTime());

		return dateFormatted;

	}



































	/**
	 * Attempt to locate element within default time constraint
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (WebElement)
	 */
	private WebElement waitForElement(By by) {

		we = null;

		double initTime = System.currentTimeMillis();
		try {
			we = fWait
					.withTimeout(Duration.ofSeconds((long) standardWait))
					.until(new Function<RemoteWebDriver, WebElement>() {
				public WebElement apply(RemoteWebDriver drv) {
					return drv.findElement(by);
				}
			});
			return we;
		} catch (TimeoutException to) {
			return null;
		} finally {
			System.out.format("Waited %.2f seconds for element%n", (System.currentTimeMillis() - initTime)/1000);
		}

	}


	/**
	 * Attempt to locate element within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum wait time in seconds
	 *
	 * @return (WebElement)
	 */
	private WebElement waitForElement(By by, int maxWait) {

		we = null;

		double initTime = System.currentTimeMillis();
		try {
			we = fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.until(new Function<RemoteWebDriver, WebElement>() {
				public WebElement apply(RemoteWebDriver drv) {
					return drv.findElement(by);
				}
			});
			return we;
		} catch (TimeoutException to) {
			return null;
		} finally {
			System.out.format("Waited %.2f seconds for element%n", (System.currentTimeMillis() - initTime)/1000);
		}

	}


	/**
	 * Attempt to locate element within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (WebElement|null)
	 */
	private WebElement waitForElement(By by, int maxWait, int pollingRate) {

		we = null;
		try {
			we = fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.pollingEvery(Duration.ofMillis((long) pollingRate))
					.until(new Function<RemoteWebDriver, WebElement>() {
				public WebElement apply(RemoteWebDriver drv) {
					return drv.findElement(by);
				}
			});
			return we;
		} catch (TimeoutException to) {
			return null;
		}

	}


	/**
	 *  Attempt to locate element within default time constraint.
	 *
	 * @param w (WebElement) parent element containing target element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (WebElement|null)
	 */
	private WebElement waitForElement(WebElement w, By by) {

		we = null;

		try {
			we = fWait
					.withTimeout(Duration.ofSeconds((long) standardWait))
					.until(new Function<RemoteWebDriver, WebElement>() {
				public WebElement apply(RemoteWebDriver drv) {
					return w.findElement(by);
				}
			});
			return we;
		} catch (TimeoutException to) {
			return null;
		}

	}


	/**
	 *  Attempt to locate element within maxWait time constraint.
	 *
	 * @param w (WebElement) parent element containing target element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (WebElement|null)
	 */
	private WebElement waitForElement(WebElement w, By by, int maxWait) {

		we = null;

		try {
			we = fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.until(new Function<RemoteWebDriver, WebElement>() {
				public WebElement apply(RemoteWebDriver drv) {
					return w.findElement(by);
				}
			});
			return we;
		} catch (TimeoutException to) {
			return null;
		}

	}


	/**
	 *  Attempt to locate element within maxWait time constraint.
	 *
	 * @param w (WebElement) parent element containing target element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (WebElement|null)
	 */
	private WebElement waitForElement(WebElement w, By by, int maxWait, int pollingRate) {

		we = null;

		try {
			we = fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.pollingEvery(Duration.ofMillis((long) pollingRate))
					.until(new Function<RemoteWebDriver, WebElement>() {
				public WebElement apply(RemoteWebDriver drv) {
					return w.findElement(by);
				}
			});
			return we;
		} catch (TimeoutException to) {
			return null;
		}
	}


	/**
	 * Attempt to locate one or more element(s) within default time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (List[WebElement]|null)
	 */
	private List<WebElement> waitForElements(By by) {

		weArray.clear();

		try {
			weArray = fWait
					.withTimeout(Duration.ofSeconds((long) standardWait))
					.until(new Function<RemoteWebDriver, List<WebElement>>() {
				public List<WebElement> apply(RemoteWebDriver drv) {
					return drv.findElements(by);
				}
			});
			return weArray;
		} catch (TimeoutException to) {
			return null;
		}

	}


	/**
	 * Attempt to locate one or more element(s) within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (List[WebElement]|null)
	 */
	private List<WebElement> waitForElements(By by, int maxWait) {

		weArray.clear();

		try {
			weArray = fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.until(new Function<RemoteWebDriver, List<WebElement>>() {
				public List<WebElement> apply(RemoteWebDriver drv) {
					return drv.findElements(by);
				}
			});
			return weArray;
		} catch (TimeoutException to) {
			return null;
		}

	}


	/**
	 * Attempt to locate one or more element(s) within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (List[WebElement]|null)
	 */
	private List<WebElement> waitForElements(By by, int maxWait, int pollingRate) {

		weArray.clear();

		try {
			weArray = fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.pollingEvery(Duration.ofMillis((long) pollingRate))
					.until(new Function<RemoteWebDriver, List<WebElement>>() {
				public List<WebElement> apply(RemoteWebDriver drv) {
					return drv.findElements(by);
				}
			});
			return weArray;
		} catch (TimeoutException to) {
			return null;
		}

	}


	/**
	 * Attempt to locate one or more element(s) within default time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (List[WebElement]|null)
	 */
	private List<WebElement> waitForElements(WebElement w, By by) {

		weArray.clear();

		try {
			weArray = fWait
					.withTimeout(Duration.ofSeconds((long) standardWait))
					.until(new Function<RemoteWebDriver, List<WebElement>>() {
				public List<WebElement> apply(RemoteWebDriver drv) {
					return w.findElements(by);
				}
			});
			return weArray;
		} catch (TimeoutException to) {
			return null;
		}

	}


	/**
	 * Attempt to locate one or more element(s) within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (List[WebElement]|null)
	 */
	private List<WebElement> waitForElements(WebElement w, By by, int maxWait) {

		weArray.clear();

		try {
			weArray = fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.until(new Function<RemoteWebDriver, List<WebElement>>() {
				public List<WebElement> apply(RemoteWebDriver drv) {
					return w.findElements(by);
				}
			});
			return weArray;
		} catch (TimeoutException to) {
			return null;
		}



	}


	/**
	 * Attempt to locate one or more element(s) within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait(int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (List[WebElement]|null)
	 */
	private List<WebElement> waitForElements(WebElement w, By by, int maxWait, int pollingRate) {

		weArray.clear();

		try {
			weArray = fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.pollingEvery(Duration.ofMillis((long) pollingRate))
					.until(new Function<RemoteWebDriver, List<WebElement>>() {
				public List<WebElement> apply(RemoteWebDriver drv) {
					return w.findElements(by);
				}
			});
			return weArray;
		} catch (TimeoutException to) {
			return null;
		}

	}


	/**
	 * Attempt to NOT locate element within default time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (null|WebElement)
	 */
	private WebElement waitForElementNotFound(By by) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) standardWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					we = null;
					return !((we = drv.findElement(by)) instanceof WebElement);
				}
			});
			return we;
		} catch (TimeoutException to) {
			if (null == we) {
				return null;
			} else {
				return we;
			}
		}

	}


	/**
	 * Attempt to NOT locate element within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (null|WebElement)
	 */
	private WebElement waitForElementNotFound(By by, int maxWait) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					we = null;
					return !((we = drv.findElement(by)) instanceof WebElement);
				}
			});
			return we;
		} catch (TimeoutException to) {
			if (null == we) {
				return null;
			} else {
				return we;
			}
		}

	}


	/**
	 * Attempt to NOT locate element within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (null|WebElement)
	 */
	private WebElement waitForElementNotFound(By by, int maxWait, int pollingRate) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.pollingEvery(Duration.ofMillis((long) pollingRate))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					we = null;
					return !((we = drv.findElement(by)) instanceof WebElement);
				}
			});
			return we;
		} catch (TimeoutException to) {
			if (null == we) {
				return null;
			} else {
				return we;
			}
		}

	}


	/**
	 * Attempt to NOT locate element within default time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (null|WebElement)
	 */
	private WebElement waitForElementNotFound(WebElement w, By by) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) standardWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					we = null;
					return !((we = w.findElement(by)) instanceof WebElement);
				}
			});
			return we;
		} catch (TimeoutException to) {
			if (null == we) {
				return null;
			} else {
				return we;
			}
		}

	}


	/**
	 * Attempt to NOT locate element within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (null|WebElement)
	 */
	private WebElement waitForElementNotFound(WebElement w, By by, int maxWait) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					we = null;
					return !((we = w.findElement(by)) instanceof WebElement);
				}
			});
			return we;
		} catch (TimeoutException to) {
			if (null == we) {
				return null;
			} else {
				return we;
			}
		}
	}


	/**
	 * Attempt to NOT locate element within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (null|WebElement)
	 */
	private WebElement waitForElementNotFound(WebElement w, By by, int maxWait, int pollingRate) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.pollingEvery(Duration.ofMillis((long) pollingRate))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					we = null;
					return !((we = w.findElement(by)) instanceof WebElement);
				}
			});
			return we;
		} catch (TimeoutException to) {
			if (null == we) {
				return null;
			} else {
				return we;
			}
		}

	}


	/**
	 * Attempt to NOT locate one or more element(s) within default time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (null|List[WebElement])
	 */
	private List<WebElement> waitForElementsNotFound(By by) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) standardWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					weArray.clear();
					return ((weArray = drv.findElements(by)).size() == 0);
				}
			});
			return weArray;
		} catch (TimeoutException to) {
			if (weArray.size() == 0) {
				return null;
			} else {
				return weArray;
			}
		}

	}


	/**
	 * Attempt to NOT locate one or more element(s) within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (null|List[WebElement])
	 */
	private List<WebElement> waitForElementsNotFound(By by, int maxWait) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					weArray.clear();
					return ((weArray = drv.findElements(by)).size() == 0);
				}
			});
			return weArray;
		} catch (TimeoutException to) {
			if (weArray.size() == 0) {
				return null;
			} else {
				return weArray;
			}
		}

	}


	/**
	 * Attempt to NOT locate one or more element(s) within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (null|List[WebElement])
	 */
	private List<WebElement> waitForElementsNotFound(By by, int maxWait, int pollingRate) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.pollingEvery(Duration.ofMillis((long) pollingRate))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					weArray.clear();
					return ((weArray = drv.findElements(by)).size() == 0);
				}
			});
			return weArray;
		} catch (TimeoutException to) {
			if (weArray.size() == 0) {
				return null;
			} else {
				return weArray;
			}
		}

	}


	/**
	 * Attempt to NOT locate one or more element(s) within default time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (null|List[WebElement])
	 */
	private List<WebElement> waitForElementsNotFound(WebElement w, By by) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) standardWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					weArray.clear();
					return ((weArray = w.findElements(by)).size() == 0);
				}
			});
			return weArray;
		} catch (TimeoutException to) {
			if (weArray.size() == 0) {
				return null;
			} else {
				return weArray;
			}
		}

	}


	/**
	 * Attempt to NOT locate one or more element(s) within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (null|List[WebElement])
	 */
	private List<WebElement> waitForElementsNotFound(WebElement w, By by, int maxWait) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					weArray.clear();
					return ((weArray = w.findElements(by)).size() == 0);
				}
			});
			return weArray;
		} catch (TimeoutException to) {
			if (weArray.size() == 0) {
				return null;
			} else {
				return weArray;
			}
		}

	}


	/**
	 * Attempt to NOT locate one or more element(s) within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (null|List[WebElement])
	 */
	private List<WebElement> waitForElementsNotFound(WebElement w, By by, int maxWait, int pollingRate) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.pollingEvery(Duration.ofMillis(pollingRate))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					weArray.clear();
					return ((weArray = w.findElements(by)).size() == 0);
				}
			});
			return weArray;
		} catch (TimeoutException to) {
			if (weArray.size() == 0) {
				return null;
			} else {
				return weArray;
			}
		}

	}


	/**
	 * Asserts element can be found within default time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmElementExistence(By by) {

		ss.assertTrue((we = waitForElement(by)) instanceof WebElement, "Element could not be located.");
		return we;

	}


	/**
	 * Asserts element can be found within default time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmElementExistence(By by, int maxWait) {

		ss.assertTrue((we = waitForElement(by, maxWait)) instanceof WebElement, "Element could not be located.");
		return we;

	}


	/**
	 * Asserts element can be found within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmElementExistence(By by, int maxWait, int pollingRate) {

		ss.assertTrue((we = waitForElement(by, maxWait, pollingRate)) instanceof WebElement, "Element could not be located.");
		return we;

	}

	/**
	 * Asserts element can be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param customError (String) custom TestNG onFail description
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmElementExistence(By by, String customError) {

		ss.assertTrue((we = waitForElement(by)) instanceof WebElement, customError);
		return we;

	}


	/**
	 * Asserts element can be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param customError (String) custom TestNG onFail description
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmElementExistence(By by, int maxWait, String customError) {

		ss.assertTrue((we = waitForElement(by, maxWait)) instanceof WebElement, customError);
		return we;

	}


	/**
	 * Asserts element can be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 * @param customError (String) custom TestNG onFail description
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmElementExistence(By by, int maxWait, int pollingRate, String customError) {

		ss.assertTrue((we = waitForElement(by, maxWait, pollingRate)) instanceof WebElement, customError);
		return we;

	}


	/**
	 * Asserts element can be found within default time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmElementExistence(WebElement w, By by) {

		ss.assertTrue((we = waitForElement(w, by)) instanceof WebElement, "Element could not be located.");
		return we;

	}


	/**
	 * Asserts element can be found within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmElementExistence(WebElement w, By by, int maxWait) {

		ss.assertTrue((we = waitForElement(w, by, maxWait)) instanceof WebElement, "Element could not be located.");
		return we;

	}


	/**
	 * Asserts element can be found within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmElementExistence(WebElement w, By by, int maxWait, int pollingRate) {

		ss.assertTrue((we = waitForElement(w, by, maxWait, pollingRate)) instanceof WebElement, "Element could not be located.");
		return we;

	}


	/**
	 * Asserts element can be found within default time constraint.
	 * Includes custom error message.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param customError (String) custom TestNG onFail description
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmElementExistence(WebElement w, By by, String customError) {

		ss.assertTrue((we = waitForElement(w, by)) instanceof WebElement, customError);
		return we;

	}


	/**
	 * Asserts element can be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param customError (String) custom TestNG onFail description
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmElementExistence(WebElement w, By by, int maxWait, String customError) {

		ss.assertTrue((we = waitForElement(w, by, maxWait)) instanceof WebElement, customError);
		return we;

	}


	/**
	 * Asserts element can be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 * @param customError (String) custom TestNG onFail description
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmElementExistence(WebElement w, By by, int maxWait, int pollingRate, String customError) {

		ss.assertTrue((we = waitForElement(w, by, maxWait, pollingRate)) instanceof WebElement, customError);
		return we;

	}


	/**
	 * Attempts to discover WebElement within default time constraint.
	 * If found, returns WebElement. If not found, returns null.
	 *
	 * By itself, this is less useful than a standard
	 * {@link #confirmElementExistence(By) confirmElementExistence} as there
	 * is no validation on the return.
	 * However, used as sentinel, it provides a safe (T/F) switch for
	 * conditional branching.
	 * <br>
	 * Example:
	 * <pre>if (confirmElementExistenceOrNone(by) instanceof WebElement) {...</pre>
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (WebElement|null)
	 */
	public WebElement confirmElementExistenceOrNone(By by) {

		return we = waitForElement(by);

	}


	/**
	 * Attempts to discover WebElement within maxWait time constraint.
	 * If found, returns WebElement. If not found, returns null.
	 *
	 * By itself, this is less useful than a standard
	 * {@link #confirmElementExistence(By) confirmElementExistence} as there
	 * is no validation on the return.
	 * However, used as sentinel, it provides a safe (T/F) switch for
	 * conditional branching.
	 * <br>
	 * Example:
	 * <pre>if (confirmElementExistenceOrNone(by) instanceof WebElement) {...</pre>
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (WebElement|null)
	 */
	public WebElement confirmElementExistenceOrNone(By by, int maxWait) {

		return we = waitForElement(by, maxWait);

	}


	/**
	 * Attempts to discover WebElement within maxWait time constraint.
	 * If found, returns WebElement. If not found, returns null.
	 *
	 * By itself, this is less useful than a standard
	 * {@link #confirmElementExistence(By) confirmElementExistence} as there
	 * is no validation on the return.
	 * However, used as sentinel, it provides a safe (T/F) switch for
	 * conditional branching.
	 * <br>
	 * Example:
	 * <pre>if (confirmElementExistenceOrNone(by) instanceof WebElement) {...</pre>
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (WebElement|null)
	 */
	public WebElement confirmElementExistenceOrNone(By by, int maxWait, int pollingRate) {

		return we = waitForElement(by, maxWait, pollingRate);

	}


	/**
	 * Attempts to discover WebElement within default time constraint.
	 * If found, returns WebElement. If not found, returns null.
	 *
	 * By itself, this is less useful than a standard
	 * {@link #confirmElementExistence(By) confirmElementExistence} as there
	 * is no validation on the return.
	 * However, used as sentinel, it provides a safe (T/F) switch for
	 * conditional branching.
	 * <br>
	 * Example:
	 * <pre>if (confirmElementExistenceOrNone(by) instanceof WebElement) {...</pre>
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (WebElement|null)
	 */
	public WebElement confirmElementExistenceOrNone(WebElement w, By by) {

		return we = waitForElement(w, by);

	}


	/**
	 * Attempts to discover WebElement within maxWait time constraint.
	 * If found, returns WebElement. If not found, returns null.
	 *
	 * By itself, this is less useful than a standard
	 * {@link #confirmElementExistence(By) confirmElementExistence} as there
	 * is no validation on the return.
	 * However, used as sentinel, it provides a safe (T/F) switch for
	 * conditional branching.
	 * <br>
	 * Example:
	 * <pre>if (confirmElementExistenceOrNone(by) instanceof WebElement) {...</pre>
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (WebElement|null)
	 */
	public WebElement confirmElementExistenceOrNone(WebElement w, By by, int maxWait) {

		return we = waitForElement(w, by, maxWait);

	}


	/**
	 * Attempts to discover WebElement within maxWait time constraint.
	 * If found, returns WebElement. If not found, returns null.
	 *
	 * By itself, this is less useful than a standard
	 * {@link #confirmElementExistence(By) confirmElementExistence} as there
	 * is no validation on the return.
	 * However, used as sentinel, it provides a safe (T/F) switch for
	 * conditional branching.
	 * <br>
	 * Example:
	 * <pre>if (confirmElementExistenceOrNone(by) instanceof WebElement) {...</pre>
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (WebElement|null)
	 */
	public WebElement confirmElementExistenceOrNone(WebElement w, By by, int maxWait, int pollingRate) {

		return we = waitForElement(w, by, maxWait, pollingRate);

	}


	/**
	 * Asserts one or more element(s) can be found within default time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistence(By by) {

		ss.assertTrue(null != (weArray = waitForElements(by)), "One or more elements could not be located.");
		int size = weArray.size();
		ss.assertTrue(size > 0, "One or more elements could not be located.");
		return weArray;

	}


	/**
	 * Asserts one or more element(s) can be found within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistence(By by, int maxWait) {

		ss.assertTrue(null != (weArray = waitForElements(by, maxWait)), "One or more elements could not be located.");
		int size = weArray.size();
		ss.assertTrue(size > 0, "One or more elements could not be located.");
		return weArray;

	}


	/**
	 * Asserts one or more element(s) can be found within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistence(By by, int maxWait, int pollingRate) {

		ss.assertTrue(null != (weArray = waitForElements(by, maxWait, pollingRate)), "One or more elements could not be located.");
		int size = weArray.size();
		ss.assertTrue(size > 0, "One or more elements could not be located.");
		return weArray;

	}


	/**
	 * Asserts one or more element(s) can be found within default time constraint.
	 * Includes custom error message.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param customError (String) custom TestNG onFail description
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistence(By by, String customError) {

		ss.assertTrue(null != (weArray = waitForElements(by)), customError);
		int size = weArray.size();
		ss.assertTrue(size > 0, "One or more elements could not be located.");
		return weArray;

	}


	/**
	 * Asserts one or more element(s) can be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param customError (String) custom TestNG onFail description
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistence(By by, int maxWait, String customError) {

		ss.assertTrue(null != (weArray = waitForElements(by, maxWait)), customError);
		int size = weArray.size();
		ss.assertTrue(size > 0, "One or more elements could not be located.");
		return weArray;

	}


	/**
	 * Asserts one or more element(s) can be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 * @param customError (String) custom TestNG onFail description
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistence(By by, int maxWait, int pollingRate, String customError) {

		ss.assertTrue(null != (weArray = waitForElements(by, maxWait, pollingRate)), customError);
		int size = weArray.size();
		ss.assertTrue(size > 0, "One or more elements could not be located.");
		return weArray;

	}


	/**
	 * Asserts one or more element(s) can be found within default time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistence(WebElement w, By by) {

		ss.assertTrue(null != (weArray = waitForElements(w, by)), "One or more elements could not be located.");
		int size = weArray.size();
		ss.assertTrue(size > 0, "One or more elements could not be located.");
		return weArray;

	}


	/**
	 * Asserts one or more element(s) can be found within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistence(WebElement w, By by, int maxWait) {

		ss.assertTrue(null != (weArray = waitForElements(w, by, maxWait)), "One or more elements could not be located.");
		int size = weArray.size();
		ss.assertTrue(size > 0, "One or more elements could not be located.");
		return weArray;

	}


	/**
	 * Asserts one or more element(s) can be found within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistence(WebElement w, By by, int maxWait, int pollingRate) {

		ss.assertTrue(null != (weArray = waitForElements(w, by, maxWait, pollingRate)), "One or more elements could not be located.");
		int size = weArray.size();
		ss.assertTrue(size > 0, "One or more elements could not be located.");
		return weArray;

	}


	/**
	 * Asserts one or more element(s) can be found within standard time constraint.
	 * Includes custom error message.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param customError (String) custom TestNG onFail description
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistence(WebElement w, By by, String customError) {

		ss.assertTrue(null != (weArray = waitForElements(w, by)), customError);
		int size = weArray.size();
		ss.assertTrue(size > 0, "One or more elements could not be located.");
		return weArray;

	}


	/**
	 * Asserts one or more element(s) can be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param customError (String) custom TestNG onFail description
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistence(WebElement w, By by, int maxWait, String customError) {

		ss.assertTrue(null != (weArray = waitForElements(w, by, maxWait)), customError);
		int size = weArray.size();
		ss.assertTrue(size > 0, "One or more elements could not be located.");
		return weArray;

	}


	/**
	 * Asserts one or more element(s) can be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 * @param customError (String) custom TestNG onFail description
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistence(WebElement w, By by, int maxWait, int pollingRate, String customError) {

		ss.assertTrue(null != (weArray = waitForElements(w, by, maxWait, pollingRate)), customError);
		int size = weArray.size();
		ss.assertTrue(size > 0, "One or more elements could not be located.");
		return weArray;

	}


	/**
	 * Attempts to discover one or more WebElement within maxWait time constraint.
	 * If found, populated List[WebElement]. If not found, returns empty List[WebElement].
	 *
	 * By itself, this is less useful than a standard
	 * {@link #confirmElementsExistence(By) confirmElementsExistence} as there
	 * is no validation on the return.
	 * However, used as sentinel, it provides a safe (T/F) switch for
	 * conditional branching.
	 * <br>
	 * Example:
	 * <pre>if (confirmElementsExistenceOrNone(by).size() > 0) {...</pre>
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistenceOrNone(By by) {

		if (null == (weArray = waitForElements(by))) {
			weArray = new ArrayList<WebElement>();
		}
		return weArray;

	}


	/**
	 * Attempts to discover one or more WebElement within maxWait time constraint.
	 * If found, populated List[WebElement]. If not found, returns empty List[WebElement].
	 *
	 * By itself, this is less useful than a standard
	 * {@link #confirmElementsExistence(By) confirmElementsExistence} as there
	 * is no validation on the return.
	 * However, used as sentinel, it provides a safe (T/F) switch for
	 * conditional branching.
	 * <br>
	 * Example:
	 * <pre>if (confirmElementsExistenceOrNone(by).size() > 0) {...</pre>
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistenceOrNone(By by, int maxWait) {

		if (null == (weArray = waitForElements(by, maxWait))) {
			weArray = new ArrayList<WebElement>();
		}
		return weArray;

	}


	/**
	 * Attempts to discover one or more WebElement within maxWait time constraint.
	 * If found, populated List[WebElement]. If not found, returns empty List[WebElement].
	 *
	 * By itself, this is less useful than a standard
	 * {@link #confirmElementsExistence(By) confirmElementsExistence} as there
	 * is no validation on the return.
	 * However, used as sentinel, it provides a safe (T/F) switch for
	 * conditional branching.
	 * <br>
	 * Example:
	 * <pre>if (confirmElementsExistenceOrNone(by).size() > 0) {...</pre>
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistenceOrNone(By by, int maxWait, int pollingRate) {

		if (null == (weArray = waitForElements(by, maxWait, pollingRate))) {
			weArray = new ArrayList<WebElement>();
		}
		return weArray;

	}


	/**
	 * Attempts to discover one or more WebElement within standard time constraint.
	 * If found, populated List[WebElement]. If not found, returns empty List[WebElement].
	 *
	 * By itself, this is less useful than a standard
	 * {@link #confirmElementsExistence(By) confirmElementsExistence} as there
	 * is no validation on the return.
	 * However, used as sentinel, it provides a safe (T/F) switch for
	 * conditional branching.
	 * <br>
	 * Example:
	 * <pre>if (confirmElementsExistenceOrNone(by).size() > 0) {...</pre>
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistenceOrNone(WebElement w, By by) {

		if (null == (weArray = waitForElements(w, by))) {
			weArray = new ArrayList<WebElement>();
		}
		return weArray;

	}


	/**
	 * Attempts to discover one or more WebElement within maxWait time constraint.
	 * If found, populated List[WebElement]. If not found, returns empty List[WebElement].
	 *
	 * By itself, this is less useful than a standard
	 * {@link #confirmElementsExistence(By) confirmElementsExistence} as there
	 * is no validation on the return.
	 * However, used as sentinel, it provides a safe (T/F) switch for
	 * conditional branching.
	 * <br>
	 * Example:
	 * <pre>if (confirmElementsExistenceOrNone(by).size() > 0) {...</pre>
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistenceOrNone(WebElement w, By by, int maxWait) {

		if (null == (weArray = waitForElements(w, by, maxWait))) {
			weArray = new ArrayList<WebElement>();
		}
		return weArray;

	}


	/**
	 * Attempts to discover one or more WebElement within maxWait time constraint.
	 * If found, populated List[WebElement]. If not found, returns empty List[WebElement].
	 *
	 * By itself, this is less useful than a standard
	 * {@link #confirmElementsExistence(By) confirmElementsExistence} as there
	 * is no validation on the return.
	 * However, used as sentinel, it provides a safe (T/F) switch for
	 * conditional branching.
	 * <br>
	 * Example:
	 * <pre>if (confirmElementsExistenceOrNone(by).size() > 0) {...</pre>
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 *
	 * @return (List<WebElement>)
	 */
	public List<WebElement> confirmElementsExistenceOrNone(WebElement w, By by, int maxWait, int pollingRate) {

		if (null == (weArray = waitForElements(w, by, maxWait, pollingRate))) {
			weArray = new ArrayList<WebElement>();
		}
		return weArray;

	}


	/**
	 * Asserts element cannot be found within default time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 */
	public void confirmElementNonExistence(By by) {

		ss.assertFalse(waitForElementNotFound(by) instanceof WebElement, "Persistent element located unexpectedly.");

	}


	/**
	 * Asserts element cannot be found within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 */
	public void confirmElementNonExistence(By by, int maxWait) {

		ss.assertFalse(waitForElementNotFound(by, maxWait) instanceof WebElement, "Persistent element located unexpectedly.");

	}


	/**
	 * Asserts element cannot be found within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 */
	public void confirmElementNonExistence(By by, int maxWait, int pollingRate) {

		ss.assertFalse(waitForElementNotFound(by, maxWait, pollingRate) instanceof WebElement, "Persistent element located unexpectedly.");

	}

	/**
	 * Asserts element cannot be found within default time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 */
	public void confirmElementNonExistence(WebElement w, By by) {

		ss.assertFalse(waitForElementNotFound(w, by) instanceof WebElement, "Persistent element located unexpectedly.");

	}


	/**
	 * Asserts element cannot be found within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 */
	public void confirmElementNonExistence(WebElement w, By by, int maxWait) {

		ss.assertFalse(waitForElementNotFound(w, by, maxWait) instanceof WebElement, "Persistent element located unexpectedly.");

	}


	/**
	 * Asserts element cannot be found within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 */
	public void confirmElementNonExistence(WebElement w, By by, int maxWait, int pollingRate) {

		ss.assertFalse(waitForElementNotFound(w, by, maxWait, pollingRate) instanceof WebElement, "Persistent element located unexpectedly.");

	}


	/**
	 * Asserts element cannot be found within default time constraint.
	 * Includes custom error message.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param customError (String) custom TestNG onFail description
	 */
	public void confirmElementNonExistence(By by, String customError) {

		ss.assertFalse(waitForElementNotFound(by) instanceof WebElement, customError);

	}


	/**
	 * Asserts element cannot be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param customError (String) custom TestNG onFail description
	 */
	public void confirmElementNonExistence(By by, int maxWait, String customError) {

		ss.assertFalse(waitForElementNotFound(by, maxWait) instanceof WebElement, customError);

	}


	/**
	 * Asserts element cannot be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 * @param customError (String) custom TestNG onFail description
	 */
	public void confirmElementNonExistence(By by, int maxWait, int pollingRate, String customError) {

		ss.assertFalse(waitForElementNotFound(by, maxWait, pollingRate) instanceof WebElement, customError);

	}

	/**
	 * Asserts element cannot be found within default time constraint.
	 * Includes custom error message.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param customError (String) custom TestNG onFail description
	 */
	public void confirmElementNonExistence(WebElement w, By by, String customError) {

		ss.assertFalse(waitForElementNotFound(w, by) instanceof WebElement, customError);

	}


	/**
	 * Asserts element cannot be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param customError (String) custom TestNG onFail description
	 */
	public void confirmElementNonExistence(WebElement w, By by, int maxWait, String customError) {

		ss.assertFalse(waitForElementNotFound(w, by, maxWait) instanceof WebElement, customError);

	}


	/**
	 * Asserts element cannot be found within maxWait time constraint.
	 * Includes custom error message.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 * @param customError (String) custom TestNG onFail description
	 */
	public void confirmElementNonExistence(WebElement w, By by, int maxWait, int pollingRate, String customError) {

		ss.assertFalse(waitForElementNotFound(w, by, maxWait, pollingRate) instanceof WebElement, customError);

	}


	/**
	 * Asserts one or more element(s) cannot be found within default time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 */
	public void confirmElementsNonExistence(By by) {

		ss.assertFalse(waitForElementsNotFound(by) instanceof List<?>, "Persistent element(s) located unexpectedly.");

	}


	/**
	 * Asserts one or more element(s) cannot be found within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 */
	public void confirmElementsNonExistence(By by, int maxWait) {

		ss.assertFalse(waitForElementsNotFound(by, maxWait) instanceof List<?>, "Persistent element(s) located unexpectedly.");

	}


	/**
	 * Asserts one or more element(s) cannot be found within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 */
	public void confirmElementsNonExistence(By by, int maxWait, int pollingRate) {

		ss.assertFalse(waitForElementsNotFound(by, maxWait, pollingRate) instanceof List<?>, "Persistent element(s) located unexpectedly.");

	}


	/**
	 * Asserts one or more element(s) cannot be found within default time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 */
	public void confirmElementsNonExistence(WebElement w, By by) {

		ss.assertFalse(waitForElementsNotFound(w, by) instanceof List<?>, "Persistent element(s) located unexpectedly.");

	}


	/**
	 * Asserts one or more element(s) cannot be found within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 */
	public void confirmElementsNonExistence(WebElement w, By by, int maxWait) {

		ss.assertFalse(waitForElementsNotFound(w, by, maxWait) instanceof List<?>, "Persistent element(s) located unexpectedly.");

	}


	/**
	 * Asserts one or more element(s) cannot be found within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 */
	public void confirmElementsNonExistence(WebElement w, By by, int maxWait, int pollingRate) {

		ss.assertFalse(waitForElementsNotFound(w, by, maxWait, pollingRate) instanceof List<?>, "Persistent element(s) located unexpectedly.");

	}


	/**
	 * Asserts one or more element(s) cannot be found within default time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param customError (String) custom TestNG onFail description
	 */
	public void confirmElementsNonExistence(By by, String customError) {

		ss.assertFalse(waitForElementsNotFound(by) instanceof List<?>, customError);

	}


	/**
	 * Asserts one or more element(s) cannot be found within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param customError (String) custom TestNG onFail description
	 */
	public void confirmElementsNonExistence(By by, int maxWait, String customError) {

		ss.assertFalse(waitForElementsNotFound(by, maxWait) instanceof List<?>, customError);

	}


	/**
	 * Asserts one or more element(s) cannot be found within maxWait time constraint.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 * @param customError (String) custom TestNG onFail description
	 */
	public void confirmElementsNonExistence(By by, int maxWait, int pollingRate, String customError) {

		ss.assertFalse(waitForElementsNotFound(by, maxWait, pollingRate) instanceof List<?>, customError);

	}


	/**
	 * Asserts one or more element(s) cannot be found within default time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param customError (String) custom TestNG onFail description
	 */
	public void confirmElementsNonExistence(WebElement w, By by, String customError) {

		ss.assertFalse(waitForElementsNotFound(w, by) instanceof List<?>, customError);

	}


	/**
	 * Asserts one or more element(s) cannot be found within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param customError (String) custom TestNG onFail description
	 */
	public void confirmElementsNonExistence(WebElement w, By by, int maxWait, String customError) {

		ss.assertFalse(waitForElementsNotFound(w, by, maxWait) instanceof List<?>, customError);

	}


	/**
	 * Asserts one or more element(s) cannot be found within maxWait time constraint.
	 *
	 * @param w (WebElement) reference element
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait for element
	 * @param pollingRate (int) check frequency in milliseconds
	 * @param customError (String) custom TestNG onFail description
	 */
	public void confirmElementsNonExistence(WebElement w, By by, int maxWait, int pollingRate, String customError) {

		ss.assertFalse(waitForElementsNotFound(w, by, maxWait, pollingRate) instanceof List<?>, customError);

	}


	/**
	 * Waits up to standardWait for the browser JavaScript engine to report standby.
	 *
	 */
	public void waitForPageLoaded() {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) standardWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					return ( ((JavascriptExecutor) drv).executeScript("return document.readyState").equals("complete") ||
							 ((JavascriptExecutor) drv).executeScript("return document.readyState").equals("interactive") );
				}
			});
		} catch (TimeoutException to) {
			ss.fail(String.format("Page still loading after %d seconds.", standardWait));
		}

	}


	/**
	 * Waits up to maxWait seconds for the browser JavaScript engine to report standby.
	 *
	 * @param maxWait (int) maximum time in seconds to wait
	 */
	public void waitForPageLoaded(int maxWait) {

		try {

			fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					return ( ((JavascriptExecutor) drv).executeScript("return document.readyState").equals("complete") ||
							 ((JavascriptExecutor) drv).executeScript("return document.readyState").equals("interactive") );
				}
			});
		} catch (TimeoutException to) {
			ss.fail(String.format("Page still loading after %d seconds.", maxWait));
		}

	}


	/**
	 * Waits up to standardWait seconds for the browser JavaScript engine to report completed.
	 *
	 */
	public void waitForPageCompletelyLoaded() {

		try {
			fWait
				.withTimeout(Duration.ofSeconds((long) standardWait))
				.until(new Function<RemoteWebDriver, Boolean>() {
					public Boolean apply(RemoteWebDriver drv) {
						return ( ((JavascriptExecutor) drv).executeScript("return document.readyState").equals("complete") );
					}
				});
		} catch (TimeoutException to) {
			ss.fail(String.format("Page still loading after %d seconds.", standardWait));
		}

	}


	/**
	 * Waits up to maxWait seconds for the browser JavaScript engine to report completed.
	 *
	 * @param maxWait (int) maximum time in seconds to wait
	 */
	public void waitForPageCompletelyLoaded(int maxWait) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					return ( ((JavascriptExecutor) drv).executeScript("return document.readyState").equals("complete") );
				}
			});
		} catch (TimeoutException to) {
			ss.fail(String.format("Page still loading after %d seconds.", maxWait));
		}


	}


	/**
	 * Waits for dropdown to be found. Once found, sets dropdown to target value.
	 * Once set, confirms selection.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param value (String) dropdown value option to set
	 */
	public void setDropdownByValue(By by, String value) {

		String elementValue;
		boolean valueExists = false;

		Select sel = new Select(confirmElementExistence(by));

		for (WebElement we: sel.getOptions()) {
			elementValue = we.getAttribute("value");
			ss.assertTrue(null != elementValue, "Non-standard select option detected. Cannot operate by value.");
			if (elementValue.toLowerCase().equals(value.toLowerCase())) {
				valueExists = true;
				break;
			}
		}

		if (valueExists) {
			sel.selectByValue(value);
			waitForPageCompletelyLoaded();
		} else {
			ss.assertTrue(valueExists, String.format("Value \"%s\" not present among options.", value));
		}

		ss.assertTrue((sel = new Select(confirmElementExistence(by))).getAllSelectedOptions().size() == 1, "Multiple selections unexpected.");
		elementValue = sel.getFirstSelectedOption().getAttribute("value");
		ss.assertTrue(elementValue.toLowerCase().equals(value.toLowerCase()), "Unable to confirm selection.");

	}


	/**
	 * Waits for dropdown to be found. Once found, sets dropdown to target value.
	 * Once set, confirms selection.
	 *
	 * @param w (WebElement) reference select element
	 * @param value (String) dropdown value option to set
	 */
	public void setDropdownByValue(WebElement w, String value) {

		String elementValue;
		boolean valueExists = false;

		Select sel = new Select(w);

		for (WebElement we: sel.getOptions()) {
			elementValue = we.getAttribute("value");
			ss.assertTrue(null != elementValue, "Non-standard select option detected. Cannot operate by value.");
			if (elementValue.toLowerCase().equals(value.toLowerCase())); {
				valueExists = true;
				break;
			}
		}

		if (valueExists) {
			sel.selectByValue(value);
			waitForPageCompletelyLoaded();
		} else {
			ss.assertTrue(valueExists, String.format("Value \"%s\" not present among options.", value));
		}

		ss.assertTrue((sel = new Select(w)).getAllSelectedOptions().size() == 1, "Multiple selections unexpected.");
		elementValue = sel.getFirstSelectedOption().getAttribute("value");
		ss.assertTrue(elementValue.toLowerCase().equals(value.toLowerCase()), "Unable to confirm selection.");

	}


	/**
	 * Waits for dropdown to be found. Once found, sets dropdown to target index.
	 * Once set, confirms selection.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param index (int) target option index
	 */
	public void setDropdownByIndex(By by, int index) {

		String elementValue;

		Select sel = new Select(confirmElementExistence(by));

		for (WebElement we: sel.getOptions()) {
			elementValue = we.getAttribute("value");
			ss.assertTrue(null != elementValue, "Non-standard select option detected. Cannot operate by value.");
		}

		int size = sel.getOptions().size();
		ss.assertTrue(index < size, String.format("Index \"%d\" beyond allowable bounds.", index));

		sel.selectByIndex(index);
		waitForPageCompletelyLoaded();

		ss.assertTrue((sel = new Select(confirmElementExistence(by))).getAllSelectedOptions().size() == 1, "Multiple selections unexpected.");
		elementValue = sel.getOptions().get(index).getAttribute("value");
		ss.assertTrue(sel.getFirstSelectedOption().getAttribute("value").equals(elementValue), "Unable to confirm selection.");

	}

	/**
	 * Waits for dropdown to be found. Once found, sets dropdown to target index.
	 * Once set, confirms selection.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param index (int) target option index
	 * @param afterBy (By) selenium By after selection
	 */
	public void setDropdownByIndex(By by, int index, By afterBy) {

		String elementValue;

		Select sel = new Select(confirmElementExistence(by));

		for (WebElement we: sel.getOptions()) {
			elementValue = we.getAttribute("value");
			ss.assertTrue(null != elementValue, "Non-standard select option detected. Cannot operate by value.");
		}

		int size = sel.getOptions().size();
		ss.assertTrue(index < size, String.format("Index \"%d\" beyond allowable bounds.", index));

		elementValue = sel.getOptions().get(index).getAttribute("value");

		sel.selectByIndex(index);
		waitForPageCompletelyLoaded();

		sel = new Select(confirmElementExistence(afterBy));
		ss.assertTrue(sel.getAllSelectedOptions().size() == 1, "Multiple selections unexpected.");
		ss.assertTrue(sel.getFirstSelectedOption().getAttribute("value").equals(elementValue), "Unable to confirm selection.");

	}


	/**
	 * Waits for dropdown to be found. Once found, sets dropdown to target index.
	 * Once set, confirms selection.
	 *
	 * @param w (WebElement) reference select element
	 * @param index (int) target option index
	 */
	public void setDropdownByIndex(WebElement w, int index) {

		String elementValue;

		Select sel = new Select(w);

		for (WebElement we: sel.getOptions()) {
			elementValue = we.getAttribute("value");
			ss.assertTrue(null != elementValue, "Non-standard select option detected. Cannot operate by value.");
		}

		int size = sel.getOptions().size();
		ss.assertTrue(index < size, String.format("Index \"%d\" beyond allowable bounds.", index));

		sel.selectByIndex(index);
		waitForPageCompletelyLoaded();

		ss.assertTrue((sel = new Select(w)).getAllSelectedOptions().size() == 1, "Multiple selections unexpected.");
		elementValue = sel.getOptions().get(index).getAttribute("value");
		ss.assertTrue(sel.getFirstSelectedOption().getAttribute("value").equals(elementValue), "Unable to confirm selection.");

	}


	/**
	 * Waits for dropdown to be found. Once found, sets dropdown to target value (testReference).
	 * Once set, confirms selection.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param visibleText (String) dropdown value option to set
	 */
	public void setDropdownByVisibleText(By by, String visibleText) {

		String elementValue;
		boolean valueExists = false;

		Select sel = new Select(confirmElementExistence(by));

		for (WebElement we: sel.getOptions()) {
			elementValue = we.getText();
			ss.assertTrue(null != elementValue, "Non-standard select option detected. Cannot operate by value.");
			if (elementValue.toLowerCase().equals(visibleText.toLowerCase())); {
				valueExists = true;
				break;
			}
		}

		if (valueExists) {
			sel.selectByVisibleText(visibleText);
			waitForPageCompletelyLoaded();
		} else {
			// force a descriptive fail if no match
			ss.assertTrue(valueExists, String.format("Visible text \"%s\" not present among options.", visibleText));
		}

		ss.assertTrue((sel = new Select(confirmElementExistence(by))).getAllSelectedOptions().size() == 1, "Multiple selections unexpected.");
		elementValue = sel.getFirstSelectedOption().getText();
		ss.assertTrue(elementValue.toLowerCase().equals(visibleText.toLowerCase()), "Unable to confirm selection.");

	}

	/**
	 * Waits for dropdown to be found. Once found, sets dropdown to target value (testReference).
	 * Once set, confirms selection.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param visibleText (String) dropdown value option to set
	 * @param afterBy (By) Selenium By of path after selection
	 */
	public void setDropdownByVisibleText(By by, String visibleText, By afterBy) {

		String elementValue;
		boolean valueExists = false;

		Select sel = new Select(confirmElementExistence(by));

		for (WebElement we: sel.getOptions()) {
			elementValue = we.getText();
			ss.assertTrue(null != elementValue, "Non-standard select option detected. Cannot operate by value.");
			if (elementValue.toLowerCase().equals(visibleText.toLowerCase())); {
				valueExists = true;
				break;
			}
		}


		if (valueExists) {
			sel.selectByVisibleText(visibleText);
			waitForPageCompletelyLoaded();
		} else {
			// force a descriptive fail if no match
			ss.assertTrue(valueExists, String.format("Visible text \"%s\" not present among options.", visibleText));
		}
		elementValue = sel.getFirstSelectedOption().getText();

		sel = new Select(confirmElementExistence(afterBy));
		ss.assertTrue(sel.getAllSelectedOptions().size() == 1, "Multiple selections unexpected.");
		ss.assertTrue(elementValue.toLowerCase().equals(visibleText.toLowerCase()), "Unable to confirm selection.");

	}


	/**
	 * Waits for dropdown to be found. Once found, sets dropdown to target value (testReference).
	 * Once set, confirms selection.
	 *
	 * @param w (WebElement) reference select element
	 * @param visibleText (String) dropdown value option to set
	 */
	public void setDropdownByVisibleText(WebElement w, String visibleText) {

		String elementValue;
		boolean valueExists = false;

		Select sel = new Select(w);

		for (WebElement we: sel.getOptions()) {
			elementValue = we.getText();
			ss.assertTrue(null != elementValue, "Non-standard select option detected. Cannot operate by value.");
			if (elementValue.toLowerCase().equals(visibleText.toLowerCase())); {
				valueExists = true;
				break;
			}
		}

		if (valueExists) {
			sel.selectByVisibleText(visibleText);
			waitForPageCompletelyLoaded();
		} else {
			ss.assertTrue(valueExists, String.format("Visible text \"%s\" not present among options.", visibleText));
		}

		ss.assertTrue((sel = new Select(w)).getAllSelectedOptions().size() == 1, "Multiple selections unexpected.");
		elementValue = sel.getFirstSelectedOption().getText();
		ss.assertTrue(elementValue.toLowerCase().equals(visibleText.toLowerCase()), "Unable to confirm selection.");

	}


	/**
	 * Waits for dropdown to be found. Once found, sets dropdown to target index,
	 * as determined by partial text match.
	 * Once set, confirms selection.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param partialVisibleText (String) partial text to compare against option text
	 */
	public void setDropdownByPartialVisibleText(By by, String partialVisibleText) {

		String elementValue;

		Select sel = new Select(confirmElementExistence(by));
		int index = getIndexByPartialVisibleText(sel, partialVisibleText);

		ss.assertTrue(index >= 0, String.format("Partial visible text \"%s\" not present among options.", partialVisibleText));
		sel.selectByIndex(index);
		waitForPageCompletelyLoaded();

		ss.assertTrue((sel = new Select(confirmElementExistence(by))).getAllSelectedOptions().size() == 1, "Multiple selections unexpected.");
		elementValue = sel.getFirstSelectedOption().getText();
		ss.assertTrue(elementValue.toLowerCase().contains(partialVisibleText.toLowerCase()), "Unable to confirm selection.");

	}

	/**
	 * Waits for dropdown to be found. Once found, sets dropdown to target index,
	 * as determined by partial text match.
	 * Once set, confirms selection.
	 *
	 * @param w (WebElement) reference select element
	 * @param partialVisibleText (String) partial text to compare against option text
	 */
	public void setDropdownByPartialVisibleText(WebElement w, String partialVisibleText) {

		String elementValue;

		Select sel = new Select(w);
		int index = getIndexByPartialVisibleText(sel, partialVisibleText);

		ss.assertTrue(index >= 0, String.format("Partial visible text \"%s\" not present among options.", partialVisibleText));
		sel.selectByIndex(index);
		waitForPageCompletelyLoaded();

		ss.assertTrue((sel = new Select(w)).getAllSelectedOptions().size() == 1, "Multiple selections unexpected.");
		elementValue = sel.getFirstSelectedOption().getText();
		ss.assertTrue(elementValue.toLowerCase().contains(partialVisibleText.toLowerCase()), "Unable to confirm selection.");

	}


	/**
	 * Helper method for {@link #setDropdownByPartialVisibleText(By, String)}
	 * and {@link #setDropdownByPartialVisibleText(WebElement, String)}.
	 *
	 * Compares list element text to a known string in order to determine index of
	 * matching element.
	 *
	 * @param sel (Select) target selenium select node
	 * @param textToMatch (String) text to
	 *
	 * @return (int) index of match or -1
	 */
	private int getIndexByPartialVisibleText(Select sel, String textToMatch) {

		List<WebElement> options = sel.getOptions();

		for (int i = 0; i < options.size(); i++) {
			if (null != options.get(i) && options.get(i).getText().contains(textToMatch)) {
				return i;
			}
		}
		return -1;

	}


	/**
	 * Inserts string into target element
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param input (String) text to enter into target element
	 */
	public void sendText(By by, String input) {

		we = confirmElementExistence(by);
		we.clear();
		we.sendKeys(input);

	}


	/**
	 * Inserts string into target element. assumes element needs refresh after clear
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param input (String) text to enter into target element
	 */
	public void sendText_staleSafe(By by, String input) {

		waitForPageLoaded();
		we = confirmElementExistence(by);
		we.clear();
		waitForPageLoaded();
		we = confirmElementExistence(by);
		we.sendKeys(input);

	}


	/**
	 * Inserts string into target element
	 *
	 * @param w (WebElement) reference select element
	 * @param input (String) text to enter into target element
	 */
	public void sendText(WebElement w, String input) {

		w.clear();
		w.sendKeys(input);

	}


	/**
	 * After confirming element existence, clicks element.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 */
	public void clickElement(By by) {

		System.out.format("Clicking element %s%n", by.getClass().getName().substring(by.getClass().getName().indexOf("$")+1));
		we = confirmElementExistence(by);
		we.click();
		System.out.println("Element clicked");
		waitForPageCompletelyLoaded();

	}


	/**
	 * Clicks known element.
	 *
	 * @param w (WebElement) reference select element
	 */
	public void clickElement(WebElement w) {

		System.out.format("Clicking element %s%n", w.getTagName());
		w.click();
		System.out.println("Element clicked");
		waitForPageCompletelyLoaded();

	}


	/**
	 * After confirming element existence, clicks element.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait
	 */
	public void clickElement(By by, int maxWait) {

		we = confirmElementExistence(by);
		we.click();
		waitForPageCompletelyLoaded(maxWait);

	}


	/**
	 * Clicks known element.
	 *
	 * @param w (WebElement) reference select element
	 * @param maxWait (int) maximum time in seconds to wait
	 */
	public void clickElement(WebElement w, int maxWait) {

		w.click();
		waitForPageCompletelyLoaded(maxWait);

	}


	/**
	 * Compares a given string (property key) against the text contents of
	 * a given web element
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param textToCompare (String) text to compare against WebElement text content
	 *
	 * @return (WebElement)
	 */
	public WebElement confirmTextValue(By by, String textToCompare) {

		System.out.format("Checking %s for text content: %s%n", by.getClass().getName().substring(by.getClass().getName().indexOf("$")+1), textToCompare);
		we = confirmElementExistence(by);
		String foundText = we.getText().toLowerCase();
		ss.assertTrue(foundText.contains(textToCompare.toLowerCase()), String.format("Expected to contain: %s, Found: %s%n", textToCompare, foundText));
		return we;

	}


	/**
	 * Compares a given string (property key) against the text contents of
	 * a given web element
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param textToCompare (String) text to compare against WebElement text content
	 */
	public void confirmTextValue(WebElement w, String textToCompare) {

		String foundText = w.getText().toLowerCase();
		ss.assertTrue(foundText.contains(textToCompare.toLowerCase()), String.format("Expected to contain: %s, Found: %s%n", textToCompare, foundText));

	}


	/**
	 * Compares a given string (runtimeData) against the text contents of a given web element
	 * (property key)
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param exactTextValue (String) exact text to compare against WebElement text content
	 */
	public WebElement confirmTextValueExact(By by, String exactTextToCompare) {

		we = confirmElementExistence(by);
		ss.assertTrue(we.getText().equals(exactTextToCompare), String.format("Expected: %s, Found: %s%n", exactTextToCompare, we.getText()));
		return we;

	}


	/**
	 * Compares a given string (runtimeData) against the text contents of a given web element
	 * (property key)
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param exactTextValue (String) exact text to compare against WebElement content
	 */
	public void confirmTextValueExact(WebElement w, String exactTextToCompare) {

		ss.assertTrue(w.getText().equals(exactTextToCompare), String.format("Expected: %s, Found: %s%n", exactTextToCompare, w.getText()));

	}


	/**
	 * Compares a given string against the text contents of
	 * a given web element. Expected absence.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param textToCompare (String) text to compare against WebElement text content
	 */

	public WebElement confirmNotTextValue(By by, String textToCompare) {

		we = confirmElementExistence(by);
		ss.assertTrue(!we.getText().toLowerCase().contains(textToCompare.toLowerCase()));
		return we;

	}


	/**
	 * Compares a given string against the text contents of
	 * a given web element. Expected absence.
	 *
	 * @param w (WebElement) reference select element
	 * @param exactTextToCompare (String) exact text to compare against WebElement text content
	 */

	public void confirmNotTextValue(WebElement w, String exactTextToCompare) {

		ss.assertTrue(!w.getText().toLowerCase().contains(exactTextToCompare.toLowerCase()));

	}


	/**
	 * Compares a given string against the text contents of
	 * a given web element. Expected absence.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param exactTextToCompare (String) exact text to compare against WebElement text content
	 */

	public WebElement confirmNotTextValueExact(By by, String exactTextToCompare) {

		we = confirmElementExistence(by);
		ss.assertTrue(!we.getText().toLowerCase().equals(exactTextToCompare.toLowerCase()));
		return we;

	}


	/**
	 * Compares a given string against the text contents of
	 * a given web element. Expected absence.
	 *
	 * @param w (WebElement) reference select element
	 * @param exactTextToCompare (String) exact text to compare against WebElement text content
	 */
	public void confirmNotTextValueExact(WebElement w, String exactTextToCompare) {

		ss.assertTrue(!w.getText().toLowerCase().equals(exactTextToCompare.toLowerCase()));

	}


	/**
	 * Helper method for {@link #confirmTextValues(WebElement, List)}.
	 * Compares singular string against string list contents.
	 *
	 * @param search (String) string to compare against list values
	 * @param textsToCompare (List[String]) list of strings to compare against WebElement text content
	 *
	 * @return (boolean) search string found in list?
	 */
	private boolean elementContentInList(String search, List<String> textsToCompare) {

		for (String s: textsToCompare) {
			if (s.toLowerCase().contains(search.toLowerCase())) {
				return true;
			}
		}
		return false;

	}


	/**
	 * Helper method for {@link #confirmTextValues(WebElement, List)}.
	 * Compares singular string against string list contents.
	 *
	 * @param search (String) string to compare against list values
	 * @param textsToCompare (List[String]) list of exact strings to compare against WebElement text content
	 *
	 * @return (boolean) search string found in list?
	 */
	private boolean elementContentInListExact(String search, List<String> textsToCompare) {

		for (String s: textsToCompare) {
			if (s.toLowerCase().equals(search.toLowerCase())) {
				return true;
			}
		}
		return false;

	}


	/**
	 * Compares text content of a given WebElement to a list of possible values.
	 *
	 * @param w (WebElement) reference select element
	 * @param textsToCompare (List[String]) list of strings to compare against WebElement text content
	 */
	public void confirmTextValues(WebElement w, List<String> textsToCompare) {

		ss.assertTrue(elementContentInList(w.getAttribute("innerHTML"), textsToCompare), "Could not match target text \"%s\" to available comparison options.");

	}


	/**
	 * Compares text content of a given WebElement to a list of possible values.
	 *
	 * @param w (WebElement) reference select element
	 * @param textsToCompare (List[String]) list of exact strings to compare against WebElement text content
	 */
	public void confirmTextValuesExact(WebElement w, List<String> textsToCompare) {

		ss.assertTrue(elementContentInListExact(w.getAttribute("innerHTML"), textsToCompare), "Could not match target text \"%s\" to available comparison options.");

	}


	/**
	 * Compares text content of a given WebElement to a list of possible values. Negative expectation.
	 *
	 * @param w (WebElement) reference select element
	 * @param textsToCompare (List[String]) list of strings to compare against WebElement text content
	 */
	public void confirmNotTextValues(WebElement w, List<String> textsToCompare) {

		ss.assertTrue(!elementContentInList(w.getAttribute("innerHTML"), textsToCompare), "Could not match target text \"%s\" to available comparison options.");

	}

	/**
	 * Compares text content of a given WebElement to a list of possible values. Negative expectation.
	 *
	 * @param w (WebElement) reference select element
	 * @param textsToCompare (List[String]) list of exact strings to compare against WebElement text content
	 */
	public void confirmNotTextValuesExact(WebElement w, List<String> textsToCompare) {

		ss.assertTrue(!elementContentInListExact(w.getAttribute("innerHTML"), textsToCompare), "Could not match target text \"%s\" to available comparison options.");

	}


	/**
	 * Confirm the selection state of a target dropdown menu widget
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param valueToCompare (String) comparison string
	 */
	public void confirmDropdownValue(By by, String valueToCompare) {

		Select sel = new Select(confirmElementExistence(by));
		ss.assertTrue(sel.getFirstSelectedOption().getText().toLowerCase().equals(valueToCompare.toLowerCase()));

	}


	/**
	 * Confirm the selection state of a target dropdown menu widget
	 *
	 * @param w (WebElement) reference Selenium element
	 * @param valueToCompare (String) comparison string
	 */
	public void confirmDropdownValue(WebElement w, String valueToCompare) {

		Select sel = new Select(w);
		ss.assertTrue(sel.getFirstSelectedOption().getText().toLowerCase().equals(valueToCompare.toLowerCase()));

	}


	/**
	 * Given a target window title, cycle through open windows until title matches, else return false
	 *
	 * @param targetWindowTitle (String) window title for comparison
	 */
	public void switchToWindowByTitle(String targetWindowTitle) {

		String title;
		String currentHandle = wd.getWindowHandle();
		Set<String> handles = wd.getWindowHandles();

		for (String handle: handles) {
			if(!handle.equals(currentHandle)) {
				wd.switchTo().window(handle);
				waitForPageLoaded(120);
				title = wd.getTitle();
				if (title.replace("\u2013","-").toLowerCase().equals(targetWindowTitle.toLowerCase())) {
					return;
				}
			}
		}
		ss.fail("Could not find matching window title.");

	}
	
	/**
	 * Given a target window title, cycle through open windows until title matches, else return false
	 *
	 * @param targetWindowTitle (String) window title for comparison
	 */
	public void switchToWindowByTitleNoWait(String targetWindowTitle) {

		String title;
		String currentHandle = wd.getWindowHandle();
		Set<String> handles = wd.getWindowHandles();

		for (String handle: handles) {
			if(!handle.equals(currentHandle)) {
				wd.switchTo().window(handle);
				title = wd.getTitle();
				if (title.replace("\u2013","-").toLowerCase().equals(targetWindowTitle.toLowerCase())) {
					return;
				}
			}
		}
		ss.fail("Could not find matching window title.");

	}


	/**
	 *  Given one daughter window, switch to daughter window
	 */
	public String[] switchToDaughterWindow() {

		String initialHandle = wd.getWindowHandle();
		ss.assertTrue(waitForMoreHandles(), "No additional windows/tabs discovered.");
		Set<String> handles = wd.getWindowHandles();
		String daughterHandle = null;

		ss.assertTrue(handles.size() == 2, String.format("One (1) daughter window expected. Found %d.", handles.size() - 1));

		for (String handle: handles) {
			if (!handle.equals(initialHandle)) {
				wd.switchTo().window(handle);
				waitForPageLoaded(30);
				daughterHandle = handle;
			}
		}
		return new String[] {initialHandle, daughterHandle};

	}
	
	/**
	 *  Given one daughter window, switch to daughter window
	 */
	public String[] switchToDaughterWindowNoWait() {

		String initialHandle = wd.getWindowHandle();
		ss.assertTrue(waitForMoreHandles(), "No additional windows/tabs discovered.");
		Set<String> handles = wd.getWindowHandles();
		String daughterHandle = null;

		ss.assertTrue(handles.size() == 2, String.format("One (1) daughter window expected. Found %d.", handles.size() - 1));

		for (String handle: handles) {
			if (!handle.equals(initialHandle)) {
				wd.switchTo().window(handle);
				daughterHandle = handle;
			}
		}
		return new String[] {initialHandle, daughterHandle};

	}


	/**
	 * Given a window handle, switch to it
	 *
	 * @param handle (String) target window handle
	 */
	public void switchToWindowByHandle(String handle) {

		Set<String> handles = wd.getWindowHandles();
		if (handles.contains(handle)) {
			wd.switchTo().window(handle);
			waitForPageLoaded(30);
		} else {
			ss.fail("Window handle not found.");
		}

	}
	
	/**
	 * Given a window handle, switch to it
	 *
	 * @param handle (String) target window handle
	 */
	public void switchToWindowByHandleNoWait(String handle) {

		Set<String> handles = wd.getWindowHandles();
		if (handles.contains(handle)) {
			wd.switchTo().window(handle);
		} else {
			ss.fail("Window handle not found.");
		}

	}


	/**
	 * Wait up to standardWait seconds for count of windows handles to be greater than one (1)
	 *
	 * @return (boolean) more than one window discovered
	 */
	public boolean waitForMoreHandles() {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) standardWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					return (drv.getWindowHandles().size() > 1);
				}
			});
			return true;
		} catch (TimeoutException to) {
			return false;
		}

	}


	/**
	 * Wait up to maxWait seconds for count of windows handles to be greater than one (1)
	 *
	 * @param maxWait (int) maximum time in seconds to wait
	 *
	 * @return (boolean) more than one window discovered
	 */
	public boolean waitForMoreHandles(int maxWait) {

		try {
			fWait
					.withTimeout(Duration.ofSeconds((long) maxWait))
					.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					return (drv.getWindowHandles().size() > 1);
				}
			});
			return true;
		} catch (TimeoutException to) {
			return false;
		}

	}


	/**
	 * Close current window
	 */
	public void closeWindow() {

		wd.close();

	}


	/**
	 * Check for broken image.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 */
	public boolean checkForBrokenImage(By by) {

		we = confirmElementExistence(by);
		boolean goodImage = false;

		try {
			goodImage = fWait
				.withTimeout(Duration.ofSeconds((long) standardWait))
				.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					 return (boolean) ((JavascriptExecutor) drv).executeScript("return (arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0)", we);
				}
			});
			return goodImage;
		} catch (TimeoutException to) {
			ss.assertTrue(goodImage, "Could not confirm image.");
		}
		return goodImage;

	}


	/**
	 * Check for broken image.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param maxWait (int) maximum time in seconds to wait
	 *
	 * @return (boolean)
	 */
	public boolean checkForBrokenImage(By by, int maxWait) {

		we = confirmElementExistence(by);
		boolean goodImage = false;

		try {
			goodImage = fWait
				.withTimeout(Duration.ofSeconds((long) maxWait))
				.until(new Function<RemoteWebDriver, Boolean>() {
				public Boolean apply(RemoteWebDriver drv) {
					 return (boolean) ((JavascriptExecutor) drv).executeScript("return (arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0)", we);
				}
			});
			return goodImage;
		} catch (TimeoutException to) {
			ss.assertTrue(goodImage, "Could not confirm image.");
		}
		return goodImage;

	}


	/**
	 * Populates text list from multi-element locator, compares against known text list (CSV)
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param commaSeparatedValues (String) values to be compared, separated by comma
	 */
	public void confirmMultiElementText(By by, String commaSeparatedValues) {

		List<String> foundList = new ArrayList<String>();
		List<String> expectedList = new ArrayList<String>();
		List<WebElement> weArray = new ArrayList<WebElement>();
		String[] values = null;

		weArray = confirmElementsExistence(by);
		values = commaSeparatedValues.split(",");
		expectedList = Arrays.asList(values);

		for (WebElement we: weArray) {
			foundList.add(we.getText());
		}

		ss.assertTrue(expectedList.equals(foundList), "Lists differ.");
		ss.takeScreenShot();

	}


	/**
	 * Populates text list from multi-element locator, compares against known text list (CSV)
	 * element by element.
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 * @param commaSeparatedValues (String) values to be compared, separated by comma
	 */
	public void confirmMultiElementTextByElement(By by, String commaSeparatedValues) {

		List<String> foundList = new ArrayList<String>();
		List<String> expectedList = new ArrayList<String>();
		List<WebElement> weArray = new ArrayList<WebElement>();
		String[] values = null;

		weArray = confirmElementsExistence(by);
		values = commaSeparatedValues.split(",");
		expectedList = Arrays.asList(values);

		for (WebElement we: weArray) {
			foundList.add(we.getText());
		}

		Iterator<String> found = foundList.listIterator();
		Iterator<String> expected = expectedList.listIterator();
		while (found.hasNext() && expected.hasNext()) {
			String f = found.next();
			String e = expected.next();
			ss.assertTrue(f.contains(e), String.format("Found: %s; Expected: %s", f, e));
		}
		ss.takeScreenShot();

	}


	/**
	 * Execute a boolean returning synchronous JavaScript snippet (fully defined)
	 *
	 * @param script (String) javaScript snippet
	 *
	 * @return (boolean) result of script execution as returned by JSE
	 */
	public boolean jseExecuteBoolean(String script) {

		return (boolean) this.jse.executeScript(script);

	}


	/**
	 * Execute a boolean returning synchronous JavaScript snippet (fully defined),
	 * respective some WebElement
	 *
	 * @param script (String) javaScript snippet
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (boolean) result of script execution as returned by JSE
	 */
	public boolean jseExecuteBoolean(String script, By by) {

		we = confirmElementExistence(by);
		return (boolean) this.jse.executeScript(script, we);

	}


	/**
	 * Execute a boolean returning synchronous JavaScript snippet (fully defined),
	 * respective some WebElement
	 *
	 * @param script (String) javaScript snippet
	 * @param w (WebElement) reference element
	 *
	 * @return (boolean) result of script execution as returned by JSE
	 */
	public boolean jseExecuteBoolean(String script, WebElement w) {

		return (boolean) this.jse.executeScript(script, w);

	}


	/**
	 * Execute a integer returning synchronous JavaScript snippet (fully defined)
	 *
	 * @param script (String) javaScript snippet
	 *
	 * @return (int) result of script execution as returned by JSE
	 */
	public int jseExecuteInteger(String script) {

		return (int) (long) this.jse.executeScript(script);

	}


	/**
	 * Execute a integer returning synchronous JavaScript snippet (fully defined),
	 * respective some WebElement
	 *
	 * @param script (String) javaScript snippet
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (int) result of script execution as returned by JSE
	 */
	public int jseExecuteInteger(String script, By by) {

		we = confirmElementExistence(by);
		return (int) (long) this.jse.executeScript(script, we);

	}


	/**
	 * Execute a integer returning synchronous JavaScript snippet (fully defined),
	 * respective some WebElement
	 *
	 * @param script (String) javaScript snippet
	 * @param w (WebElement) reference element
	 *
	 * @return (int) result of script execution as returned by JSE
	 */
	public int jseExecuteInteger(String script, WebElement w) {

		return (int) (long) this.jse.executeScript(script, w);

	}


	/**
	 * Execute a String returning synchronous JavaScript snippet (fully defined)
	 *
	 * @param script (String) javaScript snippet
	 *
	 * @return (String) result of script execution as returned by JSE
	 */
	public String jseExecuteString(String script) {

		return (String) this.jse.executeScript(script);

	}


	/**
	 * Execute a String returning synchronous JavaScript snippet (fully defined),
	 * respective some WebElement
	 *
	 * @param script (String) javaScript snippet
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 *
	 * @return (String) result of script execution as returned by JSE
	 */
	public String jseExecuteString(String script, By by) {


		we = confirmElementExistence(by);
		return (String) this.jse.executeScript(script, we);

	}


	/**
	 * Execute a String returning synchronous JavaScript snippet (fully defined),
	 * respective some WebElement
	 *
	 * @param script (String) javaScript snippet
	 * @param we (WebElement) reference element
	 *
	 * @return (String) result of script execution as returned by JSE
	 */
	public String jseExecuteString(String script, WebElement w) {

		return (String) this.jse.executeScript(script, w);

	}


	/**
	 * Execute a synchronous JavaScript snippet (fully defined)
	 *
	 * @param script (String) javaScript snippet
	 */
	public void jseExecuteVoid(String script) {

		this.jse.executeScript(script);

	}


	/**
	 * Execute a synchronous JavaScript snippet (fully defined),
	 * respective some WebElement
	 *
	 * @param script (String) javaScript snippet
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 */
	public void jseExecuteVoid(String script, By by) {

		we = confirmElementExistence(by);
		this.jse.executeScript(script, we);

	}


	/**
	 * Execute a synchronous JavaScript snippet (fully defined),
	 * respective some WebElement
	 *
	 * @param script (String) javaScript snippet
	 * @param w (WebElement) reference select element
	 */
	public void jseExecuteVoid(String script, WebElement w) {

		this.jse.executeScript(script, w);

	}


	/**
	 * Navigates browser to target URL
	 *
	 * @param url (String) target url to load in browser
	 */
	public void getUrl(String url) {

		wd.get(url);
		waitForPageLoaded();

	}


	/**
	 * Asserts page title equals target value
	 *
	 * @param comparisonText (String) text to compare against page title
	 */
	public void confirmTitle(String comparisonText) {

		ss.assertTrue(wd.getTitle().toLowerCase().equals(comparisonText));

	}


	/**
	 * Scroll to an element, direction independent
	 *
	 * @param by (By) selenium By (ex. By.xpath("//some/locator");)
	 */
	public WebElement smartScroll(By by) {

		we = confirmElementExistence(by);

		int currentY = 0;
		int currentX = 0;
		int afterY = 100000;
		int afterX = 100000;

		do {
			currentY = (int) (long) jse.executeScript("return window.pageYOffset;");
			currentX = (int) (long) jse.executeScript("return window.pageXOffset;");

			jse.executeScript("return arguments[0].scrollIntoView(true);", we);

			afterY = (int) (long) jse.executeScript("return window.pageYOffset;");
			afterX = (int) (long) jse.executeScript("return window.pageXOffset;");
		} while ((Math.abs(currentY - afterY) != 0) && (Math.abs(currentX - afterX) != 0));

		return we;

	}


	/**
	 * Scroll to an element, direction independent
	 *
	 * @param w (WebElement) WebElement to scroll to
	 */
	public WebElement smartScroll(WebElement w) {

		int currentY = 0;
		int currentX = 0;
		int afterY = 100000;
		int afterX = 100000;

		do {
			currentY = (int) (long) this.jse.executeScript("return window.pageYOffset;");
			currentX = (int) (long) this.jse.executeScript("return window.pageXOffset;");

			this.jse.executeScript("return arguments[0].scrollIntoView(true);", w);

			afterY = (int) (long) this.jse.executeScript("return window.pageYOffset;");
			afterX = (int) (long) this.jse.executeScript("return window.pageXOffset;");
		} while ((Math.abs(currentY - afterY) != 0) && (Math.abs(currentX - afterX) != 0));

		return w;

	}


	/**
	 * Wait For an Element to be interactable then click it.
	 * Waiting a number of seconds equal to maxWait before timing out.
	 *
	 *  @param propertyElement (WebElement) Element to be clicked that has been confirmed to exist.
	 *  @param maxWait (int) maximum length of the wait time in seconds
	 *  @return (WebElement|null)
	 */
	public void clickElementWhenInteractable(WebElement propertyElement, int maxWait) {

		try {
			FluentWait<RemoteWebDriver> wait = new FluentWait<RemoteWebDriver>(wd)
					.ignoring(ElementNotInteractableException.class)
					.withTimeout(Duration.ofSeconds((long) maxWait));
			wait.until(new Function<RemoteWebDriver, WebElement>() {
				public WebElement apply(RemoteWebDriver drv) {
					propertyElement.click();
					return propertyElement;
				}
			});
		} catch (TimeoutException to) {
			ss.fail(" <timed out: unexpected>%n");
		}

	}

	/**
	 * Wait until an Element is no longer on the page. Returns the WebElement if it is found and returns
	 * null once it is no longer found
	 *
	 * @param propertyKey (String) properties file key defining element locator
	 * @return (WebElement|null)
	 */
	public WebElement waitForElementToBecomeNull(By waitForElement, int maxWait) {

		try {
			FluentWait<RemoteWebDriver> wait = new FluentWait<RemoteWebDriver>(wd)
					.withTimeout(Duration.ofSeconds(maxWait));
			we = wait.until(new Function<RemoteWebDriver, WebElement>() {
						public WebElement apply(RemoteWebDriver drv) {
							return drv.findElement(waitForElement);
						}
			});
		} catch (TimeoutException to) {
			ss.fail(" <timed out: unexpected>%n");

		} catch (NoSuchElementException go) {
			return null;
		}

		return we;

	}



}
