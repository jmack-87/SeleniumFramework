package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class QuickTransfer {


	public static By Locator_Button_Calendar =									By.cssSelector("div.transferwrapper_01 button.calendar");
	public static By Locator_Button_Go =										By.cssSelector("div.transferwrapper_01 input.button");
	public static By Locator_Container =										By.cssSelector("fieldset.form div.transferwrapper_01");
	public static By Locator_Container_CalendarWidget =							By.cssSelector("div.calendarUI");
	public static By Locator_Container_CalendarWidget_Dates =					By.cssSelector("div.calendarUI tbody");
	public static By Locator_Image_Waiting =									By.xpath("//div[@class='transferwrapper_01']//img[contains(@style,'inline')]");
	public static By Locator_Image_Waiting_Hidden =								By.xpath("//div[@class='transferwrapper_01']//img[contains(@style,'none')]");
	public static By Locator_Select_From =										By.cssSelector("div.transferwrapper_01 select#selectFrom");
	public static By Locator_Select_To =										By.cssSelector("div.transferwrapper_01 select#selectTo");
	public static By Locator_TextContainer_Title =								By.cssSelector("div.transferwrapper_01 h3");
	public static By Locator_TextField_Amount =									By.cssSelector("div.transferwrapper_01 input#txt_amount");
	public static By Locator_TextField_Date_Day =								By.cssSelector("div.transferwrapper_01 input[id='thisDate.day']");
	public static By Locator_TextField_Date_Month =								By.cssSelector("div.transferwrapper_01 input[id='thisDate.month']");
	public static By Locator_TextField_Date_Year =								By.cssSelector("div.transferwrapper_01 input[id='thisDate.year']");
	public static String CompoundLocator_Container_CalendarWidget_TargetDate =	"//div[@class='calendarUI']//td[text()='~~~']";
	public static String Locator_Text_Title =									"quick transfer";
	public static String Script_String_getElementValueText = 					"return arguments[0].value;";


//	CompoundLocator_Container_CalendarWidget_TargetDate("QuickTransfers.CompoundLocator.Container.CalendarWidget.TargetDate"),
//	Locator_Button_Calendar("QuickTransfers.Locator.Button.Calendar"),
//	Locator_Button_Go("QuickTransfers.Locator.Button.Go"),
//	Locator_Container("QuickTransfers.Locator.Container"),
//	Locator_Container_CalendarWidget("QuickTransfers.Locator.Container.CalendarWidget"),
//	Locator_Container_CalendarWidget_Dates("QuickTransfers.Locator.Container.CalendarWidget.Dates"),
//	Locator_Image_Waiting("QuickTransfers.Locator.Image.Waiting"),
//	Locator_Image_Waiting_Hidden("QuickTransfers.Locator.Image.Waiting.Hidden"),
//	Locator_Select_From("QuickTransfers.Locator.Select.From"),
//	Locator_Select_To("QuickTransfers.Locator.Select.To"),
//	Locator_Text_Title("QuickTransfers.Locator.Text.Title"),
//	Locator_TextContainer_Title("QuickTransfers.Locator.TextContainer.Title"),
//	Locator_TextField_Amount("QuickTransfers.Locator.TextField.Amount"),
//	Locator_TextField_Date_Day("QuickTransfers.Locator.TextField.Date.Day"),
//	Locator_TextField_Date_Month("QuickTransfers.Locator.TextField.Date.Month"),
//	Locator_TextField_Date_Year("QuickTransfers.Locator.TextField.Date.Year"),


//	QuickTransfers.CompoundLocator.Container.CalendarWidget.TargetDate=//div[@class='calendarUI']//td[text()='~~~']@@@xpath
//	QuickTransfers.Locator.Button.Calendar=div.transferwrapper_01 button.calendar@@@css
//	QuickTransfers.Locator.Button.Go=div.transferwrapper_01 input.button@@@css
//	QuickTransfers.Locator.Container.CalendarWidget.Dates=div.calendarUI tbody@@@css
//	QuickTransfers.Locator.Container.CalendarWidget=div.calendarUI@@@css
//	QuickTransfers.Locator.Container=fieldset.form div.transferwrapper_01@@@css
//	QuickTransfers.Locator.Image.Waiting.Hidden=//div[@class='transferwrapper_01']//img[contains(@style,'none')]@@@xpath
//	QuickTransfers.Locator.Image.Waiting=//div[@class='transferwrapper_01']//img[contains(@style,'inline')]@@@xpath
//	QuickTransfers.Locator.Select.From=div.transferwrapper_01 select#selectFrom@@@css
//	QuickTransfers.Locator.Select.To=div.transferwrapper_01 select#selectTo@@@css
//	QuickTransfers.Locator.Text.Title=quick transfer
//	QuickTransfers.Locator.TextContainer.Title=div.transferwrapper_01 h3@@@css
//	QuickTransfers.Locator.TextField.Amount=div.transferwrapper_01 input#txt_amount@@@css
//	QuickTransfers.Locator.TextField.Date.Day=div.transferwrapper_01 input#thisDate\\.day@@@css
//	QuickTransfers.Locator.TextField.Date.Month=div.transferwrapper_01 input#thisDate\\.month@@@css
//	QuickTransfers.Locator.TextField.Date.Year=div.transferwrapper_01 input#thisDate\\.year@@@css


}
