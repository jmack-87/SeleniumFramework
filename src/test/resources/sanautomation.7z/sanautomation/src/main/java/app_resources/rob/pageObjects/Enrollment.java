package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class Enrollment {


	public static By Locator_Account_DropDown_AccountType =				By.cssSelector("select#slcAccountType");
	public static By Locator_Account_TextField_AccountNumber =			By.cssSelector("input#inputAccountNumber");
	public static By Locator_ATM_TextField_CardNumber =					By.cssSelector("input#inputCardNumber");
	public static By Locator_DropDown_AuthenticationMethod =			By.cssSelector("select#selAuthenticationMethod");
	public static By Locator_DropDown_VerificationOptions =				By.cssSelector("select#slcProductType_msgOption_0");
	public static By Locator_Link_UseDOB =								By.xpath("//span[contains(text(),'use your Date of Birth')]");
	public static By Locator_Link_UseSSN =								By.xpath("//span[contains(text(),'use your SSN')]");
	public static By Locator_Subtitle_OnlineBankingSetup =				By.xpath("//span[contains(text(),'Online Banking Setup')]");
	public static By Locator_TextField_DOB =							By.cssSelector("input#inpDatBirth");
	public static By Locator_TextField_SSN =							By.cssSelector("input#inputSSN");
	public static String Locator_AccountType_Checking =					"Checking account";
	public static String Locator_AccountType_LOCAccount =				"Line of credit account";
	public static String Locator_AccountType_Mortgage =					"Mortage";
	public static String Locator_AccountType_Savings =					"Savings account";
	public static String Locator_AccountType_TimeDepositAccount =		"Time deposit account";
	public static String Locator_Authentication_OneTimePasscode =		"One-Time Passcode";
	public static String Locator_Authentication_Questionnaire =			"Personal Questionnaire";
	public static String Locator_VerificationOption_AccountNumber =		"Account Number";
	public static String Locator_VerificationOption_ATM_Debit_Credit =	"ATM / Debit or Credit Card";


//	Locator_Account_DropDown_AccountType("Enrollment.Locator.Account.DropDown.AccountType"),
//	Locator_Account_TextField_AccountNumber("Enrollment.Locator.Account.TextField.AccountNumber"),
//	Locator_AccountType_Checking("Checking account"),
//	Locator_AccountType_LOCAccount("Line of credit account"),
//	Locator_AccountType_Mortgage("Mortage"),
//	Locator_AccountType_Savings("Savings account"),
//	Locator_AccountType_TimeDepositAccount("Time deposit account"),
//	Locator_ATM_TextField_CardNumber("Enrollment.Locator.ATM.TextField.CardNumber"),
//	Locator_Authentication_OneTimePasscode("One-Time Passcode"),
//	Locator_Authentication_Questionnaire("Personal Questionnaire"),
//	Locator_DropDown_AuthenticationMethod("Enrollment.Locator.DropDown.AuthenticationMethod"),
//	Locator_DropDown_VerificationOptions("Enrollment.Locator.DropDown.VerificationOptions"),
//	Locator_Link_UseDOB("Enrollment.Locator.Link.UseDOB"),
//	Locator_Link_UseSSN("Enrollment.Locator.Link.UseSSN"),
//	Locator_Subtitle_OnlineBankingSetup("Enrollment.Locator.Subtitle.OnlineBankingSetup"),
//	Locator_TextField_DOB("Enrollment.Locator.DropDown.DOB"),
//	Locator_TextField_SSN("Enrollment.Locator.TextField.SSN"),
//	Locator_VerificationOption_AccountNumber("Account Number"),
//	Locator_VerificationOption_ATM_Debit_Credit("ATM / Debit or Credit Card"),

//	Enrollment.Locator.Account.DropDown.AccountType=select#slcAccountType@@@css
//	Enrollment.Locator.Account.TextField.AccountNumber=input#inputAccountNumber@@@css
//	Enrollment.Locator.ATM.TextField.CardNumber=input#inputCardNumber@@@css
//	Enrollment.Locator.DropDown.AuthenticationMethod=select#selAuthenticationMethod@@@css
//	Enrollment.Locator.DropDown.VerificationOptions=select#slcProductType_msgOption_0@@@css
//	Enrollment.Locator.Link.UseDOB=//span[contains(text(),'use your Date of Birth')]@@@xpath
//	Enrollment.Locator.Link.UseSSN=//span[contains(text(),'use your SSN')]@@@xpath
//	Enrollment.Locator.Subtitle.OnlineBankingSetup=//span[contains(text(),'Online Banking Setup')]@@@xpath
//	Enrollment.Locator.TextField.DOB=input#inpDatBirth@@@css
//	Enrollment.Locator.TextField.SSN=input#inputSSN@@@css


}
