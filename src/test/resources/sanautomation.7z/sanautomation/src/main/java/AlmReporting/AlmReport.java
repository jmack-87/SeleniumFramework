package AlmReporting;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Nayan Bhavsar
 */
public class AlmReport {

    private String testCycle_ID = "";
    private String testID = "";
    private String cycleId = "";
    private String RunID = "";
    private String environmentFolderName = "";
    private String testSetInstanceName = "";
    public String testScriptName = "";
    private RestConnector con;
    public List<storeReportLog> ListReportLog = new ArrayList<storeReportLog>();

    /**
     * constructer AlmReport()
     * Description: Gets the name of the executed test script class name assigngs it to testScriptName
     * Created by Nayan Bhavsar
     */
    public AlmReport()  {
    }

    /**
     * name: postReportToAlm
     * Description: reports all report log to ALM
     * Created by Nayan Bhavsar
     */
    public void postReportToAlm(String envFolder, String TestSetName, String tScriptName){
        boolean blnSetupRunInstance;

        this.testScriptName = tScriptName;
        this.testSetInstanceName = TestSetName;
        this.environmentFolderName = envFolder;

        /*SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR, -5);
        String[] tdateTime = DATE_FORMAT.format(cal.getTime()).split(" ");
        String texec_date = tdateTime[0];
        String texec_time = tdateTime[1];*/

        //Log into ALM
        AlmAuthenticate alm = new AlmAuthenticate();
        //Get the instance of the connection to ALM
        con = alm.AlmAuthGetInstace();
        //Create the run instance
        blnSetupRunInstance = CreateRunInstance(envFolder, TestSetName);

        if (blnSetupRunInstance) {
            //Post all the report steps to ALM
            String finalStatus = postAllSteps();

            //create a xml post file to update the final status of the test script
            String str = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>" +
                    "<Entity Type='run'>" +
                    "<Fields>" +
                    "<Field Name='status'><Value>" + finalStatus + "</Value></Field>" +
                    //"<Field Name='execution-date'><Value>" + texec_date + "</Value></Field>" +
                    //"<Field Name='execution-time'><Value>" + texec_time + "</Value></Field>" +
                    "</Fields>" +
                    "<RelatedEntities/>" +
                    "</Entity>";

            Map<String, String> requestHeadersv = new HashMap<String, String>();
            String requirementsUrl = con.buildEntityCollectionUrl("run") + "/" + this.RunID;
            requestHeadersv.put("Content-Type", "application/xml");
            Response res = con.httpPut(requirementsUrl, str.getBytes(), requestHeadersv);
            if (res.getStatusCode() != 200){
                throw new RuntimeException("ALM API status did not return a 200 status for posting final run status" +
                        "ALM server return status=" + res.getStatusCode() + "\n" +
                        "ALM server message=" + res.toString());
            }
        }
        //Log out of ALM
        alm.logout();
    }

    /**
     * name: CreateRunInstance
     * Description: create the run the instance for the test script based on the envFolder and TestSetName
     * Created by Nayan Bhavsar
     */
    public boolean CreateRunInstance(String envFolder, String TestSetName){

        String requirementsUrl = con.buildEntityCollectionUrl("test-set-folder");

        StringBuilder b = new StringBuilder();
        //The query - where field name has a  value that starts with the
        // name of the requirement we posted
        b.append("query={parent-id[11]}");

        //query a collection of entities:
        Response res = null;

        res = con.httpGet(requirementsUrl, b.toString(), null);
        if (res.getStatusCode() == 200) {
            String ServerResponse = res.toString();

            ParseXMLResponse xml = new ParseXMLResponse(ServerResponse);

            ArrayList<String> folderNames = xml.getValues("name");


            if (folderNames.contains(envFolder)) {
                int Index = folderNames.indexOf(envFolder);

                String hierarchical_path = xml.getValue("hierarchical-path", Index);
                //System.out.println("subFolderId=" + hierarchical_path);
                String testSetID = getTestSet(TestSetName, hierarchical_path);
                if (!testSetID.isEmpty()) {
                    boolean testScript = getTestCase(testSetID, testScriptName);

                    if (testScript) {
                        DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
                        Date date = new Date();
                        String TestName = "Run_" + dateFormat.format(date);
                        boolean blnRunInstance =  PostRunInstaceInfo(this.testCycle_ID, this.testID, this.cycleId, TestName);
                        //blnRunInstance =  PostRunInstaceInfo(this.testCycle_ID, this.testID, this.cycleId, TestName);
                        return blnRunInstance;
                    }
                }

            } else {
                throw new RuntimeException("Test environment folder name [" + envFolder + "] was not found under parent folder 'Automation Land' \n" +
                        "ALM server return status=" + res.getStatusCode() + "\n" +
                        "ALM server message=" + res.toString());
            }

        }else{
            throw new RuntimeException("ALM API status did not return a 200 status for 'Automation Land' \n " +
                    "Check if 'Automation Land' folder exist in ALM" +
                    "ALM server return status=" + res.getStatusCode() + "\n" +
                    "ALM server message=" + res.toString());
        }

        return false;
    }


    public String getTestSet(String testSetName, String hierarchical_path) {

        String requirementsUrl = con.buildEntityCollectionUrl("test-set");

        //query a collection of entities:
        StringBuilder b = new StringBuilder();
        //The query - where field name has a  value that starts with the
        // name of the requirement we posted
        b.append("query={test-set-folder.hierarchical-path" +
                "["+ hierarchical_path + "*]}");

        Response res = con.httpGet(requirementsUrl, b.toString(), null);

        if (res.getStatusCode() == 200) {

            String ServerResponse = res.toString();

            //System.out.println(ServerResponse);

            ParseXMLResponse xml = new ParseXMLResponse(ServerResponse);

            ArrayList<String> folderNames = xml.getValues("name");


            if (folderNames.contains(testSetName)) {
                int Index = folderNames.indexOf(testSetName);

                String testSetId = xml.getValue("id", Index);
                return testSetId;

            }else{
                throw new RuntimeException("Test set instance [" + testSetName + "] was not found under environment folder [" + this.environmentFolderName + "] \n" +
                        "ALM server return status=" + res.getStatusCode() + "\n" +
                        "ALM server message=" + res.toString());
            }

        }else{
            throw new RuntimeException("ALM API status did not return a 200 status for Testset name [" + testSetName + "] \n" +
                    "ALM server return status=" + res.getStatusCode() + "\n" +
                    "ALM server message=" + res.toString());
        }
    }

    public boolean getTestCase(String testSetId, String TestScriptName)  {


        String requirementsUrl = con.buildEntityCollectionUrl("test-instance");

        //query a collection of entities:
        StringBuilder b = new StringBuilder();
        //The query - where field name has a  value that starts with the
        // name of the requirement we posted
        b.append("query={cycle-id[" + testSetId + "]}");

        Response res = con.httpGet(requirementsUrl, b.toString(), null);

        if (res.getStatusCode() == 200) {

            String ServerResponse = res.toString();

            //  System.out.println(ServerResponse);

            ParseXMLResponse xml = new ParseXMLResponse(ServerResponse);

            ArrayList<String> folderNames = xml.getValues("name");
            String formatTestScriptName = TestScriptName + " [1]";

            if (folderNames.contains(formatTestScriptName)) {
                int Index = folderNames.indexOf(formatTestScriptName);

                this.testCycle_ID = xml.getValue("id", Index);
                this.testID = xml.getValue("test-id", Index);
                this.cycleId = xml.getValue("cycle-id", Index);
                return true;
            }else{
                throw new RuntimeException("Test script [" + TestScriptName + "] was not found under environment folder [" + this.environmentFolderName + "] in Test instance [" + this.testSetInstanceName + "\n" +
                        "ALM server return status=" + res.getStatusCode() + "\n" +
                        "ALM server message=" + res.toString());
            }

        }else{
            throw new RuntimeException("ALM API status did not return a 200 status for Testscript name [" + TestScriptName + "] \n" +
                    "ALM server return status=" + res.getStatusCode() + "\n" +
                    "ALM server message=" + res.toString());
        }
    }

    private boolean PostRunInstaceInfo(String testcycl_id, String testID, String cycleId, String RunTestName) {
        //hp.qc.run.EXTERNAL-TEST
        SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String[] dateTime = DATE_FORMAT.format(new Date()).split(" ");
        /*Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR, -5);
        String[] dateTime = DATE_FORMAT.format(cal.getTime()).split(" ");*/
        String exec_date = dateTime[0];
        String exec_time = dateTime[1];

        String str = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>" +
                "<Entity Type='run'>" +
                "<Fields>" +
                "<Field Name='name'><Value>" + RunTestName + "</Value></Field>" +
                "<Field Name='test-instance'><Value>1</Value></Field>" +
                "<Field Name='testcycl-id'><Value>" + testcycl_id + "</Value></Field>" +
                "<Field Name='cycle-id'><Value>" + cycleId + "</Value></Field>" +
                "<Field Name='test-id'><Value>" + testID + "</Value></Field>" +
                "<Field Name='subtype-id'><Value>hp.qc.run.QUICKTEST_TEST</Value></Field>" +
                "<Field Name='status'><Value>Not Completed</Value></Field>" +
                "<Field Name='owner'><Value>n217114</Value></Field>" +
                "<Field Name='host'><Value>" + getHostName() + "</Value></Field>" +
                "<Field Name='execution-date'><Value>" + exec_date + "</Value></Field>" +
                "<Field Name='execution-time'><Value>" + exec_time + "</Value></Field>" +
                "</Fields>" +
                "<RelatedEntities/>" +
                "</Entity>";

        Map<String, String> requestHeadersv = new HashMap<String, String>();
        String requirementsUrl = con.buildEntityCollectionUrl("run");
        requestHeadersv.put("Content-Type", "application/xml");
        Response res = con.httpPost(requirementsUrl, str.getBytes(), requestHeadersv);
        if (res.getStatusCode() == 201) {
            String ServerResponse = res.toString();
            ParseXMLResponse xml = new ParseXMLResponse(ServerResponse);

            this.RunID = xml.getValue("id", 0);
            return true;
        }else{
            throw new RuntimeException("ALM API status did not return a 201 status for Run instance creation \n" +
                    "ALM server return status=" + res.getStatusCode() + "\n" +
                    "ALM server message=" + res.toString());
        }
    }

    private String UpdateTestInstance(String TestInstaceID, String overallStatus)  {



        String str = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>" +
                "<Entity Type='test-instance'>" +
                "<Fields>" +
                "<Field Name='status'><Value>" + overallStatus + "</Value></Field>" +
                "</Fields>" +
                "<RelatedEntities/>" +
                "</Entity>";

        Map<String, String> requestHeadersv = new HashMap<String, String>();
        String requirementsUrl = con.buildEntityCollectionUrl("test-instance") + "/" + TestInstaceID;
        requestHeadersv.put("Content-Type", "application/xml");
        Response res = con.httpPut(requirementsUrl, str.getBytes(), requestHeadersv);

        String ServerResponse = res.toString();
        System.out.println(ServerResponse);

        return ServerResponse;
    }

    private String postAllSteps()  {

        ArrayList<String> holdAllStatus = new ArrayList<>();

        String finalStatus;

        for (storeReportLog a: ListReportLog){

            holdAllStatus.add(a.getStatus());

            postSteps(a.getExpected(), a.getActual(), a.getStatus(), a.getDatestamp(), a.getTimestamp());
        }

        if (holdAllStatus.contains("Not Completed")){
            finalStatus = "Not Completed";
        }else if(holdAllStatus.contains("Failed")){
            finalStatus = "Failed";
        }else{
            finalStatus = "Passed";
        }

        return finalStatus;
    }

    private void postSteps(String expected, String actual, String status, String execution_date, String execution_time) {

        // "<Field Name='test-id'><Value>9122</Value></Field>" +
        String str = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>" +
                "<Entity Type='run-step'>" +
                "<Fields>" +
                "<Field Name='name'><Value>" + expected + "</Value></Field>" +
                "<Field Name='description'><Value>" + expected + "</Value></Field>" +
                "<Field Name='status'><Value>" + status +  "</Value></Field>" +
                "<Field Name='expected'><Value> " + expected + "</Value></Field>" +
                "<Field Name='actual'><Value>" + actual + "</Value></Field>" +
                "<Field Name='execution-date'><Value>" + execution_date + "</Value></Field>" +
                "<Field Name='execution-time'><Value>" + execution_time + "</Value></Field>" +
                "</Fields>" +
                "<RelatedEntities/>" +
                "</Entity>";

        Map<String, String> requestHeadersv = new HashMap<String, String>();
        String requirementsUrl = con.buildEntityCollectionUrl("run") + "/" + this.RunID + "/" + "run-steps";
        requestHeadersv.put("Content-Type", "application/xml");
        Response res = con.httpPost(requirementsUrl, str.getBytes(), requestHeadersv);

        if (res.getStatusCode() != 201){
            throw new RuntimeException("ALM API status did not return a 201 status for posting run steps \n" +
                    "ALM server return status=" + res.getStatusCode() + "\n" +
                    "ALM server message=" + res.toString());
        }

    }

    private String getHostName(){
        String hostname = "UNKNOWN";
        try
        {
            InetAddress addr;
            addr = InetAddress.getLocalHost();
            hostname = addr.getHostName();
        }
        catch (UnknownHostException ex)
        {
            ex.printStackTrace();
        }

        return hostname;
    }


}
