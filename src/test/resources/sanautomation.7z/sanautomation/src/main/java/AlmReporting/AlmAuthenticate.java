package AlmReporting; /**
 * Created by Nayan Bhavsar.
 */

import org.testng.Assert;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * note that this is a  rather "thin" layer over {@link RestConnector} because
 * these operations are *almost* HTML standards.
 */
public class AlmAuthenticate {

    private String HOST;
    private String PORT;
    private String DOMAIN;
    private String PROJECT;
    private String USERNAME;
    private String PASSWORD;
    private RestConnector con;
    private int responseStatus;
    private String responseMessage;
    private boolean almLoginStatus = false;

    public AlmAuthenticate()  {

        initAlMConfigProperties();

        String serverUrl = "http://" + HOST + ":" + PORT + "/qcbin";
        String domain = DOMAIN;
        String project  = PROJECT;
        String username = USERNAME;
        String password = PASSWORD;

        con = RestConnector.getInstance().init(
                new HashMap<String, String>(),
                serverUrl,
                domain,
                project);

        //if we're authenticated we'll get a null, otherwise a URL where we should login at (we're not logged in, so we'll get a URL).
        String authenticationPoint = null;

        try {

            authenticationPoint = isAuthenticated();
            //"response from isAuthenticated means we're authenticated. that can't be."
            Assert.assertTrue(authenticationPoint != null,"response from isAuthenticated means we're authenticated. that can't be.");
            //now we login to previously returned URL.
            boolean loginResponse = login(authenticationPoint, username, password);

            if(loginResponse) {
                almLoginStatus = true;
                if (con.getCookieString().contains("LWSSO_COOKIE_KEY")) {

                    //  Assert.assertTrue(loginResponse, "failed to login.");
                    //  Assert.assertTrue(con.getCookieString().contains("LWSSO_COOKIE_KEY"), "login did not cause creation of Light Weight Single Sign On(LWSSO) cookie.");


                    // Assert.assertNull(isAuthenticated(), "isAuthenticated returned not authenticated after login.");

                    //proof that we are indeed logged in
                    if (isAuthenticated() == null) {
                        Map<String, String> requestHeadersS = new HashMap<String, String>();
                        String qcsession = con.buildUrl("rest/site-session");
                        con.httpPost(qcsession, null, requestHeadersS);

                        if (!con.getCookieString().contains("XSRF-TOKEN")) {
                            throw new RuntimeException("ALM server:" + "http://" + HOST + ":" + PORT + "/qcbin/" + domain + "/" + project + "/ failed to create User site-scession. X-XSRF-TOKEN is not returned \n" +
                                    "ALM response status=" + this.responseStatus + "\n" +
                                    "ALM response message=" + this.responseMessage);
                        }

                    }else{
                        throw new RuntimeException("ALM server:" + "http://" + HOST + ":" + PORT + "/qcbin/" + domain + "/" + project + "/ isAuthenticated returned not authenticated after login."  +
                                "ALM response status=" + this.responseStatus + "\n" +
                                "ALM response message=" + this.responseMessage);
                    }

                    //  Assert.assertTrue(con.getCookieString().contains("XSRF-TOKEN"), "User site-scession was not created. X-XSRF-TOKEN is not returned");


                }else{
                    throw new RuntimeException("ALM server:" + "http://" + HOST + ":" + PORT + "/qcbin/" + domain + "/" + project + "/ failed to return LWSSO_COOKIE_KEY."  +
                            "ALM response status=" + this.responseStatus + "\n" +
                            "ALM response message=" + this.responseMessage);
                }

            }else{
                throw new RuntimeException("Fail to login with username '" +  USERNAME + "' to ALM server:" + "http://" + HOST + ":" + PORT + "/qcbin/" + domain + "/" + project + "\n" +
                        "ALM response status=" + this.responseStatus + "\n" +
                        "ALM response message=" + this.responseMessage);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    public RestConnector AlmAuthGetInstace() {
        return RestConnector.getInstance();
    }

    /**
     * @param username
     * @param password
     * @return true if authenticated at the end of this method.
     * @throws Exception
     *
     * convenience method used by other examples to do their login
     */
    public boolean login(String username, String password) throws Exception {

        String authenticationPoint = this.isAuthenticated();
        if (authenticationPoint != null) {
            return this.login(authenticationPoint, username, password);
        }
        return true;
    }


    /**
     * @param loginUrl
     *            to authenticate at
     * @param username
     * @param password
     * @return true on operation success, false otherwise
     * @throws Exception
     *
     * Logging in to our system is standard http login (basic authentication),
     * where one must store the returned cookies for further use.
     */
    public boolean login(String loginUrl, String username, String password)
            throws Exception {

        //create a string that lookes like:
        // "Basic ((username:password)<as bytes>)<64encoded>"
        byte[] credBytes = (username + ":" + password).getBytes();
        //String credEncodedString = "Basic " + Base64Encoder.encode(credBytes);
        String credEncodedString = "Basic " + new String(Base64.getEncoder().encode(credBytes));

        Map<String, String> map = new HashMap<String, String>();
        map.put("Authorization", credEncodedString);

        Response response = con.httpGet(loginUrl, null, map);

        this.responseStatus = response.getStatusCode();
        this.responseMessage = response.getResponseData().toString();

        boolean ret = response.getStatusCode() == HttpURLConnection.HTTP_OK;

        return ret;
    }



    /**
     * @return true if logout successful
     * @throws Exception
     *             close session on server and clean session cookies on client
     */
    public boolean logout() {

        //note the get operation logs us out by setting authentication cookies to:
        // LWSSO_COOKIE_KEY="" via server response header Set-Cookie
        Response response =
                con.httpGet(con.buildUrl("authentication-point/logout"),
                        null, null);

        return (response.getStatusCode() == HttpURLConnection.HTTP_OK);

    }

    /**
     * @return null if authenticated.<br>
     *         a url to authenticate against if not authenticated.
     * @throws Exception
     */
    public String isAuthenticated() throws Exception {

        String isAuthenticateUrl = con.buildUrl("rest/is-authenticated");
        String ret;

        Response response = con.httpGet(isAuthenticateUrl, null, null);
        int responseCode = response.getStatusCode();

        //if already authenticated
        if (responseCode == HttpURLConnection.HTTP_OK) {

            ret = null;
        }

        //if not authenticated - get the address where to authenticate
        // via WWW-Authenticate
        else if (responseCode == HttpURLConnection.HTTP_UNAUTHORIZED) {

            Iterable<String> authenticationHeader =
                    response.getResponseHeaders().get("WWW-Authenticate");

            String newUrl =
                    authenticationHeader.iterator().next().split("=")[1];
            newUrl = newUrl.replace("\"", "");
            newUrl += "/authenticate";
            ret = newUrl;
        }

        //Not ok, not unauthorized. An error, such as 404, or 500
        else {

            throw response.getFailure();
        }

        return ret;
    }


    public void initAlMConfigProperties(){

        Properties prop = new Properties();
        String ALMprop = "C:\\Dev\\ALMLogin\\AlmConfig.properties";

        try (InputStream input = new FileInputStream(ALMprop)) {

            // Loading the properties.
            prop.load(input);

            // Getting properties
            HOST = prop.getProperty("HOST");
            PORT = prop.getProperty("PORT");
            DOMAIN = prop.getProperty("DOMAIN");
            PROJECT = prop.getProperty("PROJECT");
            USERNAME = prop.getProperty("USERNAME");
            PASSWORD = prop.getProperty("PASSWORD");
            input.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Problem occurs when reading file !");
            e.printStackTrace();
        }
    }

    /*public void initAlMConfigProperties(){

        Properties prop = new Properties();
        InputStream input;
        try {
            ClassLoader classLoader = getClass().getClassLoader();
            input = classLoader.getResourceAsStream("C:\\Dev\\ALMLogin\\AlmConfig.properties");
            prop.load(input);

            HOST = prop.getProperty("HOST");
            PORT = prop.getProperty("PORT");
            DOMAIN = prop.getProperty("DOMAIN");
            PROJECT = prop.getProperty("PROJECT");
            USERNAME = prop.getProperty("USERNAME");
            PASSWORD = prop.getProperty("PASSWORD");
            input.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/

}


