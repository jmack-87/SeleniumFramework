package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class RobRegTMXLogin {


	public static By Locator_Header_Button_BusinessTab =	 		By.xpath("//a[contains(@title, 'Business')]");
	public static By Locator_Header_Button_BusinessTab_Active = 	By.xpath("//li[contains(@class, 'active')]//a[contains(@href, 'business')]");
	public static By Locator_Header_Button_CorporateTab = 			By.xpath("//a[contains(@title, 'Corporate')]");
	public static By Locator_Header_Button_CorporateTab_Active = 	By.xpath("//li[contains(@class, 'activa')]//a[contains(@href, 'corporate')]");
	public static By Locator_Header_Button_PersonalTab = 			By.xpath("//a[contains(@title, 'Personal')]");
	public static By Locator_Header_Button_PersonalTab_Active = 	By.xpath("//li[contains(@class, 'active')]//a[contains(@title, 'Personal')]");
	public static By Locator_Link_FindATMBranch = 					By.xpath("//a[contains(@title, 'Find an ATM/Branch')]");
	public static By Locator_Text_EnterUserIdBelow = 				By.xpath("//p[contains(text(),'Enter your Online Banking User ID below')]");
	public static By Locator_TextField_Password = 					By.xpath("//input[contains(@name, 'entrada.pwd')]");
	public static By Locator_TextField_UserId = 					By.xpath("//input[contains(@name, 'entrada.alias')]");
	public static String Text_URL = 								"https://liferay2.sov.pre.corp/us/personal/rolb-login";


//	Locator_Header_Button_BusinessTab("RobRegTMXLogin.Locator.Header.Button.BusinessTab"),
//	Locator_Header_Button_BusinessTab_Active("RobRegTMXLogin.Locator.Header.Button.BusinessTab.Active"),
//	Locator_Header_Button_CorporateTab("RobRegTMXLogin.Locator.Header.Button.CorporateTab"),
//	Locator_Header_Button_CorporateTab_Active("RobRegTMXLogin.Locator.Header.Button.CorporateTab.Active"),
//	Locator_Header_Button_PersonalTab("RobRegTMXLogin.Locator.Header.Button.PersonalTab"),
//	Locator_Header_Button_PersonalTab_Active("RobRegTMXLogin.Locator.Header.Button.PersonalTab.Active"),
//	Locator_Link_FindATMBranch("RobRegTMXLogin.Locator.Link.FindATMBranch"),
//	Locator_Text_EnterUserIdBelow("RobRegTMXLogin.Locator.Text.EnterUserIdBelow"),
//	Locator_TextField_Password("RobRegTMXLogin.Locator.TextField.Password"),
//	Locator_TextField_UserId("RobRegTMXLogin.Locator.TextField.UserId"),
//	Text_URL("RobRegTMXLogin.Text.URL"),


//	RobRegTMXLogin.Locator.Header.Button.BusinessTab.Active=//li[contains(@class,"active")]//a[contains(@href,"business")]@@@xpath
//	RobRegTMXLogin.Locator.Header.Button.BusinessTab=//a[contains(@title,"Business")]@@@xpath
//	RobRegTMXLogin.Locator.Header.Button.CorporateTab.Active=//li[contains(@class,"active")]//a[contains(@href,"corporate")]@@@xpath
//	RobRegTMXLogin.Locator.Header.Button.CorporateTab=//a[contains(@title,"Corporate")]@@@xpath
//	RobRegTMXLogin.Locator.Header.Button.PersonalTab.Active=//li[contains(@class,"activa")]//a[contains(@title,"Personal")]@@@xpath
//	RobRegTMXLogin.Locator.Header.Button.PersonalTab=//a[contains(@title,"Personal")]@@@xpath
//	RobRegTMXLogin.Locator.Link.FindATMBranch=//a[contains(@title,"Find an ATM/Branch")]@@@xpath
//	RobRegTMXLogin.Locator.Text.EnterUserIdBelow=//p[contains(text(),'Enter your Online Banking User ID below')]@@@xpath
//	RobRegTMXLogin.Locator.TextField.Password=//input[contains(@name,"entrada.pwd")]@@@xpath
//	RobRegTMXLogin.Locator.TextField.UserId=//input[contains(@name,"entrada.alias")]@@@xpath
//	RobRegTMXLogin.Text.URL=https://liferay2.sov.pre.corp/us/personal/rolb-login


}
