package common_resources;

import javax.swing.*;
import java.io.*;
import java.util.Properties;

/**
 * Author: Nayan Bhavsar
 * Class creates a dialog box for the user to input Environment and application name.
 *
 */
public class EnvironmentDialogBox {
    private boolean environmentSettings;
    private String envrionment = "";
    private String[] envList = {"","PreProduction","Certification","","","",""};
    private String application = "";
    private String[] appList = {"", "ROB","BOB","MOB","","","","","","","",""};
    private boolean postToALM = true;
    private boolean closeBrowserAfterTest = true;
    private String settingsTempDirectory  = System.getProperty("java.io.tmpdir") + "\\";
    private String settingsTempFileName =  "Selenium_Run_Settings.properties";
    private String settingsTempFullPath = settingsTempDirectory + settingsTempFileName;
    private String testset = "";
    private String[] testSetList = {"","ROB_BuildValidation","","","","","","","","","","","","","","",""};
    private String testBrowser = "";
    private String[] testBrowserList = {"","DesktopIE","DesktopChrome","DesktopFirefox","DesktopEdge","DesktopSafari","AndroidNative","AndroidChrome","iOSNative","iOSSafari"};

    public  EnvironmentDialogBox() {

        this.LoadSaveSettings();

        //JTextField envField = new JTextField(15);
        //envField.setText(envrionment);
        //JTextField appField = new JTextField(15);
        //appField.setText(application);
        JComboBox envField = new JComboBox(envList);
        envField.setSelectedIndex(0);
        JComboBox appField = new JComboBox(appList);
        appField.setSelectedIndex(0);
        JComboBox testSetField = new JComboBox(testSetList);
        testSetField.setSelectedIndex(0);
        JComboBox testBrowserField = new JComboBox(testBrowserList);
        testBrowserField.setSelectedIndex(0);

        JCheckBox jC = new JCheckBox("Post results to ALM");
        jC.setSelected(postToALM);

        JCheckBox closeBrowser = new JCheckBox("Close browser");
        closeBrowser.setSelected(closeBrowserAfterTest);

        JFrame frame = new JFrame("Environment variable config");
        frame.setAlwaysOnTop(true);
        frame.setLocationByPlatform(true);
        JPanel myPanel = new JPanel();


        myPanel.add(new JLabel("Environment"));
        myPanel.add(envField);
        myPanel.add(Box.createHorizontalStrut(30)); // a spacer
        myPanel.add(new JLabel("Application"));
        myPanel.add(appField);
        myPanel.add(Box.createHorizontalStrut(30)); // a spacer
        myPanel.add(new JLabel("TestSet"));
        myPanel.add(testSetField);
        myPanel.add(Box.createHorizontalStrut(30)); // a spacer
        myPanel.add(new JLabel("Browser"));
        myPanel.add(testBrowserField);
        myPanel.add(Box.createHorizontalStrut(30)); // a spacer
        myPanel.add(jC);
        myPanel.add(closeBrowser);

        int result = JOptionPane.showConfirmDialog(frame, myPanel,
                "Environment and application variable setup", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String envVal = (String)envField.getSelectedItem();
            String appVal = (String)appField.getSelectedItem();
            String testSetVal = (String)testSetField.getSelectedItem();
            String testBrowserVal = (String)testBrowserField.getSelectedItem();
            if (!envVal.isEmpty() &&  !appVal.isEmpty() && !testSetVal.isEmpty()) { //if (!envField.getText().isEmpty() &&  !appField.getText().isEmpty()) {
                this.environmentSettings = true;
                //this.envrionment = envField.getText();
                this.envrionment = envVal;
                //this.application = appField.getText();
                this.application = appVal;
                this.testset = testSetVal;
                this.testBrowser = testBrowserVal;
                this.postToALM = jC.isSelected();
                this.closeBrowserAfterTest = closeBrowser.isSelected();
                //saveSettings();
            }else{
                new Throwable("Environment and Application field were not set.");
            }

        }else{
            new Throwable("Fail to initialize environment name and application variables.");
        }

    }

    //Save settings
    private void saveSettings(){
        BufferedWriter br;

        try {

            new File(settingsTempFullPath).createNewFile();

            br = new BufferedWriter(new FileWriter(new File(settingsTempFullPath)));

            br.write("envrionment=" + this.envrionment);
            br.newLine();
            br.write("application=" + this.application);
            br.newLine();
            br.write("testset=" + this.testset);
            br.newLine();
            br.write("testbrowser=" + this.testBrowser);
            br.newLine();
            br.write("postToALM=" + this.postToALM);
            br.newLine();
            br.write("closeBrowserAfterTest=" + this.closeBrowserAfterTest);

            br.flush();
            br.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    //load previously saved settings
    private void LoadSaveSettings(){
        File fl = new File(settingsTempFullPath);
        if (fl.exists()){
            Properties pr = new Properties();
            try {
                InputStream in = new FileInputStream(fl);
                pr.load(in);

                this.envrionment = pr.getProperty("envrionment");
                this.application = pr.getProperty("application");
                this.testset = pr.getProperty("testset");
                this.testBrowser = pr.getProperty("testbrowser");
                this.postToALM = Boolean.valueOf(pr.getProperty("postToALM"));
                this.closeBrowserAfterTest = Boolean.valueOf(pr.getProperty("closeBrowserAfterTest"));

                in.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public String getEnvrionment() {
        return envrionment;
    }

    public String getApplication() {
        return application;
    }

    public String getTestset() {
        return testset;
    }

    public String getBrowser() {
        return testBrowser;
    }

    public boolean isPostToALM() {
        return postToALM;
    }

    public boolean closeBrowserAfterTest(){
        return this.closeBrowserAfterTest;
    }

    public boolean isEnvironmentSettings() {
        return environmentSettings;
    }
}
