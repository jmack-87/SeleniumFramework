package app_resources.c2s.pageObjects;

import org.openqa.selenium.By;

public class ProductSelection {

	public static By Locator_Checkbox_NoPromoCode = 									By.cssSelector("div#productSelectionContainer input[name^=offerCodeNotProvided]");
	public static By Locator_Checkbox_CheckingSlider = 									By.cssSelector("div#product-selection label[for^='02']");
	public static By Locator_Checkbox_CheckingAndSavingsSlider = 						By.cssSelector("div#product-selection label[for^='01']");
	public static By Locator_Checkbox_SavingsSlider = 									By.cssSelector("div#product-selection label[for^='03']");
	public static By Locator_Checkbox_BasicCheckingBox = 								By.cssSelector("div#product-list img[src*=Santander_BASIC]");
	public static By Locator_Checkbox_PremierPlusCheckingBox = 							By.cssSelector("div#product-list img[src*=Santander_PREMIER_PLUS]");
	public static By Locator_Checkbox_SelectCheckingBox = 								By.cssSelector("div#product-list img[src*=Santander_SELECT]");
	public static By Locator_Checkbox_SimplyRightCheckingBox = 							By.cssSelector("div#product-list img[src*=SIMPLY_RIGHT]");
	public static By Locator_Checkbox_StudentValueCheckingBox = 						By.cssSelector("div#product-list img[src*=STUDENT_VALUE]");
	public static By Locator_Checkbox_TeamMemberCheckingBox = 							By.cssSelector("div#product-list img[src*=TEAM_MEMBER]");
	public static By Locator_Checkbox_SantanderMoneyMarketSavingsBox = 					By.cssSelector("div#product-list img[src*=MONEY_MARKET]");
	public static By Locator_Checkbox_SantanderSavingsBox = 							By.cssSelector("div#product-list img[src*=santander_SAVINGS]");
	public static By Locator_RadioButton_OffSiteAccountConfirmation = 					By.cssSelector("div#productAdvise div.sectionLine div[ng-class*=offsiteAccountSelected][ng-click*=true]");
	public static By Locator_Image_GenerateAccountNumberImage = 						By.cssSelector("form#checkingForm img[src*='/nao/apps-general/images/productSelection/icon_reload.png']");
	public static By Locator_Button_ContinueToNextStep = 								By.cssSelector("div#productSelectionContainer button[ng-click*=continueToNextStep]");
	public static By Locator_TextField_AccountNumber = 									By.cssSelector("input#productNumber");
	public static By Locator_Button_OverDraftProtectionSomeChecking = 					By.cssSelector("form#checkingForm button[ng-class*=santanderAccountProtector][ng-click*=N]");
	public static By Locator_Button_OverDraftProtectionSomeSavingsWithChecking = 		By.cssSelector("form#savingsForm button[ng-click*=A2]");	
	public static By Locator_Button_OverDraftProtectionSomeSavingsWithoutChecking = 	By.cssSelector("form#savingsForm button[ng-class*=santanderAccountProtector][ng-click*=N]");
	public static By Locator_Button_RejectOnlineBanking = 								By.cssSelector("button[ng-click*=rejectEnroll]");

}
