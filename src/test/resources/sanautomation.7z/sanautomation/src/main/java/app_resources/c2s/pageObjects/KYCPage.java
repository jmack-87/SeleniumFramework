package app_resources.c2s.pageObjects;

import org.openqa.selenium.By;

public class KYCPage {

	public static By Locator_RadioButton_FamilyStatusNo = 					By.xpath("//fieldset[@id='customerIsPep-block']/div[2]/label");
	public static By Locator_RadioButton_IsOfficerQuestionNo = 				By.cssSelector("fieldset#cIsOfficerOfGambling-block div[class*=val02]");
	public static By Locator_Checkbox_CheckingAccount = 					By.cssSelector("fieldset#productsReq-block input[ng-true-value*='01']");
	public static By Locator_Checkbox_SavingsAccount = 						By.cssSelector("fieldset#productsReq-block input[ng-true-value*='02']");
	public static By Locator_DropDown_PurposeOfClientRelationship = 		By.cssSelector("fieldset#purposeOfAccount-block select[class*=purposeOfAccount]");
	public static int Text_Index_PurposeOfClientRelationshipIndex = 		1;
	public static By Locator_RadioButton_ExpectInternationalTransNo = 		By.xpath("//fieldset[@id='expectsInternTrans-block']/div/div[1]");
	public static int Text_Index_TransactionAmountsIndex = 					1;	
	public static By Locator_DropDown_ExpectedMonthlyDeposit = 				By.cssSelector("fieldset#expMonthDolValCashDepos-block select[class*=expMonthDolValCashDepos]");
	public static By Locator_DropDown_ExpectedMonthlyWithdrawal = 			By.cssSelector("fieldset#expMonthDolValCaWitdraw-block select[class*=expMonthDolValCaWitdraw]");
	public static By Locator_DropDown_ExpectedMonthlyDebitTrans = 			By.cssSelector("fieldset#expMonthDolValDebiTrans-block select[class*=expMonthDolValDebiTrans]");
	public static By Locator_DropDown_ExpectedMonthlyCreditTrans = 			By.cssSelector("fieldset#expMonthDolValCredTrans-block select[class*=expMonthDolValCredTrans]");
	public static By Locator_Checkbox_ConsumerChecking = 					By.cssSelector("fieldset#productsApplied-block input[ng-true-value*=\"01\"]");
	public static By Locator_Checkbox_ConsumerSavings = 					By.cssSelector("fieldset#productsApplied-block input[ng-true-value*=\"02\"]");
	public static By Locator_Button_ContinueToPrinting = 					By.cssSelector("div#kycController button[ng-click*=preSendFormResponses]");
	public static By Locator_Button_PopUpVerify = 							By.cssSelector("div#info button[class*='btn-basic ng-binding ng-scope']");

}
