package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class CustomerService {


	public static By Locator_AccountServices_FormTitle =										By.cssSelector("span.titulo");
	public static By Locator_AccountServices_Link_HelpWithThisPage =							By.xpath("//span[@class='texto']/parent::a");
	public static By Locator_Button_DeletePaymentAccountConfirmButton =							By.xpath("//a[@id='main_btnConfirm_enlace']/span"); // missing from properties
	public static By Locator_Button_ExternalAccount_AddNewAccountConfirmButton =				By.cssSelector("a#main_btnConfirm_enlace");
	public static By Locator_Button_ExternalAccount_AddNewAccountContinueButton =				By.cssSelector("a#main_btnContinue_enlace"); // missing from properties
	public static By Locator_Button_ManageAccountsActionsGoButtonFirst =						By.xpath("//*[@id='main_comboFila_2_cbBoton0']");
	public static By Locator_ContactUsAndHelp_Link_BranchOffice_FindBranch =					By.cssSelector("div[id*='CntBra'] a[id*='txtCntbra']");
	public static By Locator_ContactUsAndHelp_Link_Email_SendEmail =							By.cssSelector("div#main\\.lytEmail a[id*='txtEmail']");
	public static By Locator_ContactUsAndHelp_Link_Print =										By.cssSelector("a#print");
	public static By Locator_ContactUsAndHelp_Link_SecurityAdvice_LaunchSecurityCenter =		By.cssSelector("div#main\\.lytSecurity a[id*='txtEnlaceSec']");
	public static By Locator_ContactUsAndHelp_TextContainer_FormTitle =							By.cssSelector("span.titulo");
	public static By Locator_DropDown_ManageAccountActionsFirst =								By.xpath("//*[@id='main_comboFila_2_cbCombo0']");
	public static By Locator_Image_ContactUsAndHelp_FormTitle =									By.cssSelector("div[id*='Imagen'] img");
	public static By Locator_LeftNav_Button_AccountServices =									By.cssSelector("a#Account\\ Services");
	public static By Locator_LeftNav_Button_AccountServices_Active =							By.cssSelector("li.active a#Account\\ Services");
	public static By Locator_LeftNav_Button_ATMAndDebitCardServices =							By.cssSelector("a#ATM\\ \\&\\ \\Debit\\ Card\\ Services");
	public static By Locator_LeftNav_Button_ATMAndDebitCardServices_Active =					By.cssSelector("li.active a#ATM\\ \\&\\ \\Debit\\ Card\\ Services");
	public static By Locator_LeftNav_Button_ContactUsAndHelp =									By.cssSelector("a#Contact\\ Us\\ \\&\\ Help");
	public static By Locator_LeftNav_Button_ContactUsAndHelp_Active =							By.cssSelector("li.active a#Contact\\ Us\\ \\&\\ Help");
	public static By Locator_LeftNav_Button_CreditCardServices =								By.cssSelector("a#Credit\\ Card\\ Services");
	public static By Locator_LeftNav_Button_CreditCardServices_Active =							By.cssSelector("li.active a#Credit\\ Card\\ Services");
	public static By Locator_LeftNav_Button_MyProfileAndPreferences =							By.cssSelector("a#My\\ Profile\\ \\&\\ Preferences");
	public static By Locator_LeftNav_Button_MyProfileAndPreferences_Active =					By.cssSelector("li.active a#My\\ Profile\\ \\&\\ Preferences");
	public static By Locator_LeftNav_TextContainer_MenuTitle =									By.cssSelector("h2.customerService");
	public static By Locator_LeftTabs_Button_ATMAndDebitCardServices =							By.cssSelector("a#ATM\\ \\&\\ \\Debit\\ Card\\ Services");
	public static By Locator_LeftTabs_Button_ATMAndDebitCardServices_Active =					By.cssSelector("li.active a#ATM\\ \\&\\ \\Debit\\ Card\\ Services");
	public static By Locator_LeftTabs_CreditCardServices =										By.cssSelector("a#Credit\\ Card\\ Services");
	public static By Locator_Link_AddPaymentAccount =											By.xpath("//div[@class='NavEnlace_v2 operaciones NavEnlace_v2LayoutContent']/ul/li/a/span");
	public static By Locator_Link_ExternalAccount_BackToCardPayment =							By.xpath("//*[@class='NavEnlace_v2 operaciones NavEnlace_v2LayoutContent']/ul/li/a/span");
	public static By Locator_Link_ManagePaymentAccount =										By.xpath("//*[@id=' managePaymentAccount']");
	public static By Locator_Text_DeletePaymentAccountConfirmBanner =							By.xpath("//div[@class='intRight']/div/p/span[2]");
	public static By Locator_Text_ExternalAccount_ConfirmationMessage =							By.cssSelector("div[id*='infAlerta'] span.title"); // missing from properties
	public static By Locator_Text_ExternalAccount_FullAccountNumberConfirm =					By.xpath("//*[@id='main_dtcPrincipal_table']/tbody/tr[1]/td");
	public static By Locator_Text_ExternalAccount_NicknameConfirm =								By.xpath("//*[@id='main_dtcPrincipal_table']/tbody/tr[3]/td");
	public static By Locator_Text_ExternalAccount_RoutingNumberConfirm =						By.xpath("//*[@id='main_dtcPrincipal_table']/tbody/tr[2]/td");
	public static By Locator_Text_ExternalAccount_SummeryAccountNumber =						By.xpath("//*[@id='main_dtcPpal_table']/tbody/tr[1]/td");
	public static By Locator_Text_ExternalAccount_SummeryNickname =								By.xpath("//*[@id='main_dtcPpal_table']/tbody/tr[3]/td");
	public static By Locator_Text_ExternalAccount_SummeryRoutingNumber =						By.xpath("//*[@id='main_dtcPpal_table']/tbody/tr[2]/td");
	public static By Locator_TextField_ExternalAccount_AddNewAccountNickname =					By.cssSelector("input#txtAlias");
	public static By Locator_TextField_ExternalAccount_ConfirmAccountNumber =					By.cssSelector("input#txtConfNumCuenta");
	public static By Locator_TextField_ExternalAccount_ConfirmRountingNumber =					By.cssSelector("input#txtConfNumRuta");
	public static By Locator_TextField_ExternalAccount_FullAccountNumber =						By.cssSelector("input#txtNumCuenta");
	public static By Locator_TextField_ExternalAccount_RoutingNumber =							By.cssSelector("input#txtNumRuta");
	public static By MultiLocator_ContactUsAndHelp_Link_HelpLinks = 							By.xpath("//div[contains(@id, 'Help_CONTENT')]//a[contains(@id, '_2')]");
	public static By MultiLocator_ContactUsAndHelp_TextContainer_SectionHeaders =				By.cssSelector("span.title");
	public static int Text_ExtenalAccount_Index =												0; //missing from properties
	public static int Text_Index_DeleteAccountIndex =											0; //missing from properties
	public static String MultiText_ContactUsAndHelp_SectionHeaders =							"Help,Security Advice,Phone,Email,Branch Office,Mail";
	public static String Text_AccountServices_FormTitle =										"Account Service";
	public static String Text_ContactUsAndHelp_FormTitle =										"Contact Us & Help";
	public static String Text_DeletePaymentAccount_DeletePaymentAccountConfirmMessage =			"Payment Account Deleted Successfully.";
	public static String Text_ExternalAccount_ConfirmationMessage =								"Payment Account Added Successfully.";
	public static String Text_ExternalAccount_NewAccountNickname =								"External_";
	public static String Text_ExternalAccount_NewAccountNumber =								"135792468";
	public static String Text_ExternalAccount_NewAccountRouting =								"072404058";
	public static String Text_LeftNav_MenuTitle =												"Customer Service";


//	Locator_AccountServices_FormTitle("CustomerService.Locator.AccountServices.FormTitle"),
//	Locator_AccountServices_Link_HelpWithThisPage("CustomerService.Locator.AccountServices.Link.HelpWithThisPage"),
//	Locator_Button_DeletePaymentAccountConfirmButton("CustomerServive.Locator.DeletePaymentAccountConfirmButton"),
//	Locator_Button_ExternalAccount_AddNewAccountConfirmButton("CustomerService.Locator.Button.ExternalAccount.AddNewAccountConfirmButton"),
//	Locator_Button_ExternalAccount_AddNewAccountContinueButton("CustomerService.Locator.Button.ExternalAccount.AddNewAccountContinueButton"),
//	Locator_Button_ManageAccountsActionsGoButtonFirst("CustomerService.Locator.Button.ManageAccountActionsGoButtonFirst"),
//	Locator_ContactUsAndHelp_Link_BranchOffice_FindBranch("CustomerService.Locator.ContactUsAndHelp.Link.BranchOffice.FindABranch"),
//	Locator_ContactUsAndHelp_Link_Email_SendEmail("CustomerService.Locator.ContactUsAndHelp.Link.Email.SendEmail"),
//	Locator_ContactUsAndHelp_Link_Print("CustomerService.Locator.ContactUsAndHelp.Link.Print"),
//	Locator_ContactUsAndHelp_Link_SecurityAdvice_LaunchSecurityCenter("CustomerService.Locator.ContactUsAndHelp.Link.SecurityAdvice.LaunchSecurityCenter"),
//	Locator_ContactUsAndHelp_TextContainer_FormTitle("CustomerService.Locator.ContactUsAndHelp.TextContainer.FormTitle"),
//	Locator_DropDown_ManageAccountActionsFirst("CustomerService.Locator.DropDown.ManageAccountActionsFirst"),
//	Locator_Image_ContactUsAndHelp_FormTitle("CustomerService.Locator.Image.ContactUsAndHelp.FormTitle"),
//	Locator_LeftNav_Button_AccountServices("CustomerService.Locator.LeftNav.AccountServices"),
//	Locator_LeftNav_Button_AccountServices_Active("CustomerService.Locator.LeftNav.AccountServices.Active"),
//	Locator_LeftNav_Button_ATMAndDebitCardServices("CustomerService.Locator.LeftNav.ATMAndDebitCardServices"),
//	Locator_LeftNav_Button_ATMAndDebitCardServices_Active("CustomerService.Locator.LeftNav.ATMAndDebitCardServices.Active"),
//	Locator_LeftNav_Button_ContactUsAndHelp("CustomerService.Locator.LeftNav.ContactUsAndHelp"),
//	Locator_LeftNav_Button_ContactUsAndHelp_Active("CustomerService.Locator.LeftNav.ContactUsAndHelp.Active"),
//	Locator_LeftNav_Button_CreditCardServices("CustomerService.Locator.LeftNav.CreditCardServices"),
//	Locator_LeftNav_Button_CreditCardServices_Active("CustomerService.Locator.LeftNav.CreditCardServices.Active"),
//	Locator_LeftNav_Button_MyProfileAndPreferences("CustomerService.Locator.LeftNav.MyProfileAndPreferences"),
//	Locator_LeftNav_Button_MyProfileAndPreferences_Active("CustomerService.Locator.LeftNav.MyProfileAndPreferences.Active"),
//	Locator_LeftNav_TextContainer_MenuTitle("CustomerService.Locator.LeftNav.TextContainer.MenuTitle"),
//	Locator_Link_AddPaymentAccount("CustomerService.Locator.Link.AddPaymentAccount"),
//	Locator_Link_ExternalAccount_BackToCardPayment("CustomerService.Locator.link.BackToCardPayment"),
//	Locator_Link_ManagePaymentAccount("CustomerService.Locator.Link.ManagePaymentAccounts"),
//	Locator_Text_DeletePaymentAccountConfirmBanner("CustomerService.Locator.Text.DeletePaymentAccountConfirmBanner"),
//	Locator_Text_ExternalAccount_ConfirmationMessage("CustomerService.Locator.Text.ExternalAccount.ConfirmMessage"),
//	Locator_Text_ExternalAccount_FullAccountNumberConfirm("CustomerService.Locator.Text.ExternalAccount.FullAccountNumberConfirm"),
//	Locator_Text_ExternalAccount_NicknameConfirm("CustomerService.Locator.Text.ExternalAccount.NicknameConfirm"),
//	Locator_Text_ExternalAccount_RoutingNumberConfirm("CustomerService.Locator.Text.ExternalAccount.RoutingNumberNumberConfirm"),
//	Locator_Text_ExternalAccount_SummeryAccountNumber("CustomerService.Locator.Text.ExternalAccount.SummeryAccountNumber"),
//	locator_Text_ExternalAccount_SummeryNickname("CustomerService.Locator.Text.ExternalAccount.SummeryNickname"),
//	locator_Text_ExternalAccount_SummeryRoutingNumber("CustomerService.Locator.Text.ExternalAccount.SummeryRoutingNumber"),
//	Locator_TextField_ExternalAccount_AddNewAccountNickname("CustomerService.Locator.TextFeild.ExternalAccount.AddNewAccountNickname"),
//	Locator_TextField_ExternalAccount_ConfirmAccountNumber("CustomerService.Locator.TextFeild.ExternalAccount.ConfirmAccountNumber"),
//	Locator_TextField_ExternalAccount_ConfirmRountingNumber("CustomerService.Locator.TextFeild.ExternalAccount.ConfirmRoutingNumber"),
//	Locator_TextField_ExternalAccount_FullAccountNumber("CustomerService.Locator.TextFeild.ExternalAccount.FullAccountNumber"),
//	Locator_TextField_ExternalAccount_RoutingNumber("CustomerService.Locator.TextFeild.ExternalAccount.RoutingNumber"),
//	MultiLocator_ContactUsAndHelp_TextContainer_SectionHeaders("CustomerService.MultiLocator.ContactUsAndHelp.TextContainer.SectionHeaders"),
//	MultiText_ContactUsAndHelp_SectionHeaders("CustomerService.MultiText.ContactUsAndHelp.ContactUsAndHelp.SectionHeaders"),
//	Text_AccountServices_FormTitle("CustomerService.Text.AccountServices.FormTitle"),
//	Text_ContactUsAndHelp_FormTitle("CustomerService.Text.ContactUsAndHelp.FormTitle"),
//	Text_DeletePaymentAccount_DeletePaymentAccountConfirmMessage("CustomerService.Text.DeletePaymentAccountConfirmMessage"),
//	Text_ExtenalAccount_Index("CustomerService.Text.Index.ExtenalAccount"),
//	Text_ExternalAccount_ConfirmationMessage("CustomerService.Text.ExternalAccount.ConfirmMessage"),
//	Text_ExternalAccount_NewAccountNickname("CustomerService.Text.ExtenalAccount.NewAccountNickname"),
//	Text_ExternalAccount_NewAccountNumber("CustomerService.Text.ExtenalAccount.NewAccountNumber"),
//	Text_ExternalAccount_NewAccountRouting("CustomerService.Text.ExtenalAccount.NewAccountRouting"),
//	Text_Index_DeleteAccountIndex("CustomerService.Text.Index.DeleteAccountOptionIndex"),
//	Text_LeftNav_MenuTitle("CustomerService.Text.LeftNav.MenuTitle"),


//	CustomerService.Locator.AccountServices.FormTitle=span.titulo@@@css
//	CustomerService.Locator.AccountServices.Link.HelpWithThisPage=//span[@class='texto']/parent::a@@@xpath
//	CustomerService.Locator.Button.ExternalAccount.AddNewAccountConfirmButton=a#main_btnConfirm_enlace@@@css
//	CustomerService.Locator.Button.ManageAccountActionsGoButtonFirst=//*[@id="main_comboFila_2_cbBoton0"]@@@xpath
//	CustomerService.Locator.ContactUsAndHelp.Link.BranchOffice.FindABranch=div[id*=CntBra] a[id*=txtCntbra]@@@css
//	CustomerService.Locator.ContactUsAndHelp.Link.Email.SendEmail=div#main\\.lytEmail a[id*=txtEmail]@@@css
//	CustomerService.Locator.ContactUsAndHelp.Link.Print=a#print@@@css
//	CustomerService.Locator.ContactUsAndHelp.Link.SecurityAdvice.LaunchSecurityCenter=div#main\\.lytSecurity a[id*=txtEnlaceSec]@@@css
//	CustomerService.Locator.ContactUsAndHelp.TextContainer.FormTitle=span.titulo@@@css
//	CustomerService.Locator.DropDown.ManageAccountActionsFirst=//*[@id="main_comboFila_2_cbCombo0"]@@@xpath
//	CustomerService.Locator.Image.ContactUsAndHelp.FormTitle=div[id*=Imagen] img@@@css
//	CustomerService.Locator.LeftNav.AccountServices.Active=li.active a#Account\\ Services@@@css
//	CustomerService.Locator.LeftNav.AccountServices=a#Account\\ Services@@@css
//	CustomerService.Locator.LeftNav.ATMAndDebitCardServices.Active=li.active a#ATM\\ \\&\\ \\Debit\\ Card\\ Services@@@css
//	CustomerService.Locator.LeftNav.ATMAndDebitCardServices=a#ATM\\ \\&\\ \\Debit\\ Card\\ Services@@@css
//	CustomerService.Locator.LeftNav.ContactUsAndHelp.Active=li.active a#Contact\\ Us\\ \\&\\ Help@@@css
//	CustomerService.Locator.LeftNav.ContactUsAndHelp=a#Contact\\ Us\\ \\&\\ Help@@@css
//	CustomerService.Locator.LeftNav.CreditCardServices.Active=li.active a#Credit\\ Card\\ Services@@@css
//	CustomerService.Locator.LeftNav.CreditCardServices=a#Credit\\ Card\\ Services@@@css
//	CustomerService.Locator.LeftNav.MyProfileAndPreferences.Active=li.active a#My\\ Profile\\ \\&\\ Preferences@@@css
//	CustomerService.Locator.LeftNav.MyProfileAndPreferences=a#My\\ Profile\\ \\&\\ Preferences@@@css
//	CustomerService.Locator.LeftNav.TextContainer.MenuTitle=h2.customerService@@@css
//	CustomerService.Locator.LeftTabs.ATMAndDebitCardServices.Active=li.active a#ATM\\ \\&\\ \\Debit\\ Card\\ Services@@@css
//	CustomerService.Locator.LeftTabs.ATMAndDebitCardServices=a#ATM\\ \\&\\ \\Debit\\ Card\\ Services@@@css
//	CustomerService.Locator.LeftTabs.CreditCardServices=a#Credit\\ Card\\ Services@@@css
//	CustomerService.Locator.LeftTabs.MyProfileAndPreferences.Active=li.active a#My\\ Profile\\ \\&\\ Preferences@@@css
//	CustomerService.Locator.Link.AddPaymentAccount=//div[@class="NavEnlace_v2 operaciones NavEnlace_v2LayoutContent"]/ul/li/a/span@@@xpath
//	CustomerService.Locator.link.BackToCardPayment=//*[@class="NavEnlace_v2 operaciones NavEnlace_v2LayoutContent"]/ul/li/a/span@@@xpath
//	CustomerService.Locator.Link.ManagePaymentAccounts=//*[@id=" managePaymentAccount"]@@@xpath
//	CustomerService.Locator.Text.DeletePaymentAccountConfirmBanner=//div[@class="intRight"]/div/p/span[2]@@@xpath
//	CustomerService.Locator.Text.ExternalAccount.FullAccountNumberConfirm=//*[@id="main_dtcPrincipal_table"]/tbody/tr[1]/td@@@xpath
//	CustomerService.Locator.Text.ExternalAccount.NicknameConfirm=//*[@id="main_dtcPrincipal_table"]/tbody/tr[3]/td@@@xpath
//	CustomerService.Locator.Text.ExternalAccount.RoutingNumberNumberConfirm=//*[@id="main_dtcPrincipal_table"]/tbody/tr[2]/td@@@xpath
//	CustomerService.Locator.Text.ExternalAccount.SummeryAccountNumber=//*[@id="main_dtcPpal_table"]/tbody/tr[1]/td@@@xpath
//	CustomerService.Locator.Text.ExternalAccount.SummeryNickname=//*[@id="main_dtcPpal_table"]/tbody/tr[3]/td@@@xpath
//	CustomerService.Locator.Text.ExternalAccount.SummeryRoutingNumber=//*[@id="main_dtcPpal_table"]/tbody/tr[2]/td@@@xpath
//	CustomerService.Locator.TextFeild.ExternalAccount.AddNewAccountNickname=input#txtAlias@@@css
//	CustomerService.Locator.TextFeild.ExternalAccount.ConfirmAccountNumber=input#txtConfNumCuenta@@@css
//	CustomerService.Locator.TextFeild.ExternalAccount.ConfirmRoutingNumber=input#txtConfNumRuta@@@css
//	CustomerService.Locator.TextFeild.ExternalAccount.FullAccountNumber=input#txtNumCuenta@@@css
//	CustomerService.Locator.TextFeild.ExternalAccount.RoutingNumber=input#txtNumRuta@@@css
//	CustomerService.MultiLocator.ContactUsAndHelp.TextContainer.SectionHeaders=span.title@@@css
//	CustomerService.MultiText.ContactUsAndHelp.ContactUsAndHelp.SectionHeaders=Help,Security Advice,Phone,Email,Branch Office,Mail
//	CustomerService.Text.AccountServices.FormTitle=Account Service
//	CustomerService.Text.ContactUsAndHelp.FormTitle=Contact Us & Help
//	CustomerService.Text.DeletePaymentAccountConfirmMessage=Payment Account Deleted Successfully.
//	CustomerService.Text.ExtenalAccount.NewAccountNickname=External_
//	CustomerService.Text.ExtenalAccount.NewAccountNumber=135792468
//	CustomerService.Text.ExtenalAccount.NewAccountRouting=072404058
//	CustomerService.Text.ExternalAccount.ConfirmMessage=Payment Account Added Successfully.
//	CustomerService.Text.LeftNav.MenuTitle=Customer Service
//	CustomerServive.Locator.DeletePaymentAccountConfirmButton=//a[@id="main_btnConfirm_enlace"]/span@@@xpath


}
