package app_resources.c2s.pageObjects;

import org.openqa.selenium.By;

public class QualificationPage {

	public static By Locator_Button_GoToProducts = 			By.cssSelector("div#qualifileContainer button[ng-click^=continueToProducts]");
	public static By Locator_Text_CustomerNumber = 			By.cssSelector("div#customerNumber p.ng-binding");
	public static By Locator_Text_DocumentNumber = 			By.cssSelector("div#documentCode p.ng-binding");
	public static By Locator_Text_Employer = 				By.cssSelector("div#employer p.ng-binding");
	public static By Locator_Text_Occupation = 				By.cssSelector("div#occupation p.ng-binding");
	public static By Locator_Text_HomePhone = 				By.cssSelector("div#homePhone span");

}
