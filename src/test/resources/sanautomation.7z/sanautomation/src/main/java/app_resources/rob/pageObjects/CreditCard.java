package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class CreditCard {


	public static By Locator_CreditCard_Image_CreditCardImage =									By.xpath("//img[@id='imgPrimera_title_1']");
	public static By Locator_CreditCard_LeftNav_Button_Overview =								By.cssSelector("div#leftContent a#Overview");
	public static By Locator_CreditCard_LeftNav_Button_Overview_Active =						By.cssSelector("div#leftContent li.active a#Overview");
	public static By Locator_CreditCard_Link_InstantCardHold =									By.xpath("//a[contains(@id,'MakePayment') and contains(@onclick, 'main.dtcPrimero.Onclick(id)')]");
	public static By Locator_CreditCard_Link_MakePayment_First =								By.xpath("(//a[@id='MakePayment'])[1]");
	public static By Locator_CreditCard_Link_MakePayment_Second =								By.xpath("//a[contains(@id,'MakePayment') and contains(@onclick, 'main.dtcSegundo.Onclick(id)')]");
	public static By Locator_CreditCard_Link_RedeemPoints_Overview =							By.cssSelector("a#RedeemPoints");
	public static By Locator_CreditCard_Link_SetUpAutoPay_First =								By.xpath("//a[contains(@id,'SetUp') and contains(@onclick, 'main.dtcPrimero.Onclick(id)')]");
	public static By Locator_CreditCard_Link_SetUpAutoPay_Second =								By.xpath("//a[contains(@id,'SetUp') and contains(@onclick, 'main.dtcSegundo.Onclick(id)')]");
	public static By Locator_LeftNav_Button_Alerts =											By.cssSelector("div#leftContent a#Alerts");
	public static By Locator_LeftNav_Button_Alerts_Active =										By.cssSelector("div#leftContent li.active > a#Alerts");
	public static By Locator_LeftNav_Button_CreditCardActivity =								By.cssSelector("div#leftContent a[id='Credit Card Activity']");
	public static By Locator_LeftNav_Button_CreditCardActivity_Active =							By.cssSelector("div#leftContent li.active > a[id='Credit Card Activity']");
	public static By Locator_LeftNav_Button_CreditCardPayment =									By.cssSelector("div#leftContent a[id='Credit Card Payment']");
	public static By Locator_LeftNav_Button_CreditCardPayment_Active =							By.cssSelector("div#leftContent li.active > a[id='Credit Card Payment']");
	public static By Locator_LeftNav_Button_CreditCardServices =								By.cssSelector("div#leftContent a[id='Credit Card Services']");
	public static By Locator_LeftNav_Button_CreditCardServices_Active =							By.cssSelector("div#leftContent li.active > a[id='Credit Card Services']");
	public static By Locator_LeftNav_Button_Overview =											By.cssSelector("div#leftContent a#Overview");
	public static By Locator_LeftNav_Button_Overview_Active =									By.cssSelector("div#leftContent li.active a#Overview");
	public static By Locator_LeftNav_Button_Rewards =											By.cssSelector("div#leftContent a#Rewards");
	public static By Locator_LeftNav_Button_Rewards_Active =									By.cssSelector("div#leftContent li.active > a#Rewards");
	public static By Locator_LeftNav_Button_StatementsAndDocuments =							By.cssSelector("div#leftContent a[id='Statements & Documents']");
	public static By Locator_LeftNav_Button_StatementsAndDocuments_Active =						By.cssSelector("div#leftContent li.active > a[id='Statements & Documents']");
	public static By Locator_LeftNav_TextContainer_Title =										By.cssSelector("h2.creditcards");
	public static By Locator_Overview_Container_Card_First =									By.xpath("(//div[contains(@id, 'main.cntTarjetas')])[1]");
	public static By Locator_Overview_Image_Card_First =										By.xpath("(//div[contains(@id, 'main.img')]//a/img)[1]");
	public static By Locator_Overview_Link_Card_First =											By.xpath("((//div[contains(@id, 'main.cntTarjetas')])[1]//div[@class='lyTexto']//a)[1]");
	public static By Locator_Overview_Link_Card_Hold_First =									By.xpath("((//div[contains(@id, 'main.cntTarjetas')])[1]//div[@class='lyTexto']//a)[2]");
	public static By Locator_Overview_Link_Card_MakePayemnt_First =								By.xpath("(//a[@id='MakePayment'])[1]");
	public static By Locator_Overview_Link_Card_Redeem_First =									By.xpath("(//a[@id='RedeemPoints'])[1]");
	public static By Locator_Overview_Link_Card_SetupModify_First =								By.xpath("(//a[@id='SetUp'])[1]");
	public static By Locator_Overview_Link_HelpWithThisPage =									By.cssSelector("a[title^=Help]");
	public static By Locator_Overview_Link_Print =												By.cssSelector("a#imprimir");
	public static By Locator_Overview_TextContainer_Card_AutopayInstructions_First =			By.xpath("(//h1[contains(text(), 'Instructions:')]/parent::th/following-sibling::td)[1]");
	public static By Locator_Overview_TextContainer_Card_AutopayState_First =					By.xpath("(//h1[contains(text(), 'Autopay:')]/parent::th/following-sibling::td)[1]");
	public static By Locator_Overview_TextContainer_Card_Number_First =							By.xpath("(//p[contains(@class, 'simplemarco ')])[1]");
	public static By Locator_Overview_TextContainer_Title =										By.cssSelector("span.titulo");
	public static By MultiLocator_Overview_Container_Cards =									By.cssSelector("div[id^='main.cntTarjetas']");
	public static String Locator_CreditCard_Text_OverviewTitle =								"Credit Card Overview";
	public static String Text_LeftNav_Title =													"Credit Card";
	public static String Text_Overview_Card_AutopayInstructions_Minimum =						"minimum amount due";
	public static String Text_Overview_Card_AutopayInstructions_Statement =						"statement balance";
	public static String Text_Overview_Title =													"Credit Card Overview";


//	Locator_CreditCard_Image_CreditCardImage("CreditCard.Locator.Image.CreditCardImage"),
//	Locator_CreditCard_LeftNav_Button_Overview("CreditCard.Locator.LeftTabs.Overview"),
//	Locator_CreditCard_LeftNav_Button_Overview_Active("CreditCard.Locator.LeftTabs.Overview.Active.Active"),
//	Locator_CreditCard_Link_InstantCardHold("CreditCard.Locator.Link.InstantCardHold"),
//	Locator_CreditCard_Link_MakePayment_First("CreditCard.Locator.Overview.MakePaymentFirst"),
//	Locator_CreditCard_Link_MakePayment_Second("CreditCard.Locator.Overview.MakePaymentSecond"),
//	Locator_CreditCard_Link_RedeemPoints_Overview("CreditCard.Locator.Link.RedeemPoints"),
//	Locator_CreditCard_Link_SetUpAutoPay_First("CreditCard.Locator.Overview.SetUpAutopayFirst"),
//	Locator_CreditCard_Link_SetUpAutoPay_Second("CreditCard.Locator.Overview.SetUpAutopaySecond"),
//	Locator_CreditCard_Text_OverviewTitle("CreditCard.Locator.Text.OverviewTitle"),
//	Locator_LeftNav_Button_Alerts("CreditCard.Locator.LeftNav.Alerts"),
//	Locator_LeftNav_Button_Alerts_Active("CreditCard.Locator.LeftNav.Alerts.Active"),
//	Locator_LeftNav_Button_CreditCardActivity("CreditCard.Locator.LeftNav.CreditCardActivity"),
//	Locator_LeftNav_Button_CreditCardActivity_Active("CreditCard.Locator.LeftNav.CreditCardActivity.Active"),
//	Locator_LeftNav_Button_CreditCardPayment("CreditCard.Locator.LeftNav.CreditCardPayment"),
//	Locator_LeftNav_Button_CreditCardPayment_Active("CreditCard.Locator.LeftNav.CreditCardPayment.Active"),
//	Locator_LeftNav_Button_CreditCardServices("CreditCard.Locator.LeftNav.CreditCardServices"),
//	Locator_LeftNav_Button_CreditCardServices_Active("CreditCard.Locator.LeftNav.CreditCardServices.Active"),
//	Locator_LeftNav_Button_Overview("CreditCard.Locator.LeftNav.Overview"),
//	Locator_LeftNav_Button_Overview_Active("CreditCard.Locator.LeftNav.Overview.Active"),
//	Locator_LeftNav_Button_Rewards("CreditCard.Locator.LeftNav.Rewards"),
//	Locator_LeftNav_Button_Rewards_Active("CreditCard.Locator.LeftNav.Rewards.Active"),
//	Locator_LeftNav_Button_StatementsAndDocuments("CreditCard.Locator.LeftNav.StatementsAndDocuments"),
//	Locator_LeftNav_Button_StatementsAndDocuments_Active("CreditCard.Locator.LeftNav.StatementsAndDocuments.Active"),
//	Locator_LeftNav_TextContainer_Title("CreditCard.Locator.LeftNav.TextContainer.Title"),
//	Locator_Overview_Container_Card_First("CreditCard.Locator.Overview.Container.Card.First"),
//	Locator_Overview_Image_Card_First("CreditCard.Locator.Overview.Image.Card.First"),
//	Locator_Overview_Link_Card_First("CreditCard.Locator.Overview.Link.Card.First"),
//	Locator_Overview_Link_Card_Hold_First("CreditCard.Locator.Overview.Link.Card.First"),
//	Locator_Overview_Link_Card_MakePayemnt_First("CreditCard.Locator.Overview.Link.Card.MakePayment.First"),
//	Locator_Overview_Link_Card_Redeem_First("CreditCard.Locator.Overview.Link.Card.Redeem.First"),
//	Locator_Overview_Link_Card_SetupModify_First("CreditCard.Locator.Overview.Link.Card.SetupModify.First"),
//	Locator_Overview_Link_HelpWithThisPage("CreditCard.Locator.Overview.Link.HelpWithThisPage"),
//	Locator_Overview_Link_Print("CreditCard.Locator.Overview.Link.Print"),
//	Locator_Overview_TextContainer_Card_AutopayInstructions_First("CreditCard.Locator.Overview.TextContainer.Card.AutopayInstructions.First"),
//	Locator_Overview_TextContainer_Card_AutopayState_First("CreditCard.Locator.Overview.TextContainer.Card.AutopayState.First"),
//	Locator_Overview_TextContainer_Card_Number_First("CreditCard.Locator.Overview.TextContainer.Card.Number.First"),
//	Locator_Overview_TextContainer_Title("CreditCard.Locator.Overview.TextContainer.Title"),
//	MultiLocator_Overview_Container_Cards("CreditCard.MultiLocator.Overview.Container.Cards"),
//	Text_LeftNav_Title("CreditCard.Text.LeftNav.Title"),
//	Text_Overview_Card_AutopayInstructions_Minimum("CreditCard.Text.Overview.Card.AutopayInstructions.Minimum"),
//	Text_Overview_Card_AutopayInstructions_Statement("CreditCard.Text.Overview.Card.AutopayInstructions.Statement"),
//	Text_Overview_Title("CreditCard.Text.Overview.Title"),


//	CreditCard.Locator.Image.CreditCardImage=//img[@id='imgPrimera_title_1']@@@xpath
//	CreditCard.Locator.LeftNav.Alerts.Active=div#leftContent li.active > a#Alerts@@@css
//	CreditCard.Locator.LeftNav.Alerts=div#leftContent a#Alerts@@@css
//	CreditCard.Locator.LeftNav.CreditCardActivity.Active=div#leftContent li.active > a#Credit\\ Card\\ Activity@@@css
//	CreditCard.Locator.LeftNav.CreditCardActivity=div#leftContent a#Credit\\ Card\\ Activity@@@css
//	CreditCard.Locator.LeftNav.CreditCardPayment.Active=div#leftContent li.active > a#Credit\\ Card\\ Payment@@@css
//	CreditCard.Locator.LeftNav.CreditCardPayment=div#leftContent a#Credit\\ Card\\ Payment@@@css
//	CreditCard.Locator.LeftNav.CreditCardServices.Active=div#leftContent li.active > a#Credit\\ Card\\ Services@@@css
//	CreditCard.Locator.LeftNav.CreditCardServices=div#leftContent a#Credit\\ Card\\ Services@@@css
//	CreditCard.Locator.LeftNav.Overview.Active=div#leftContent li.active a#Overview@@@css
//	CreditCard.Locator.LeftNav.Overview=div#leftContent a#Overview@@@css
//	CreditCard.Locator.LeftNav.Rewards.Active=div#leftContent li.active > a#Rewards@@@css
//	CreditCard.Locator.LeftNav.Rewards=div#leftContent a#Rewards@@@css
//	CreditCard.Locator.LeftNav.StatementsAndDocuments.Active=div#leftContent li.active > a#Statements\\ \\&\\ Documents@@@css
//	CreditCard.Locator.LeftNav.StatementsAndDocuments=div#leftContent a#Statements\\ \\&\\ Documents@@@css
//	CreditCard.Locator.LeftNav.TextContainer.Title=h2.creditcards@@@css
//	CreditCard.Locator.LeftTabs.Alerts.Active=li.active a#Alerts@@@css
//	CreditCard.Locator.LeftTabs.Alerts=a#Alerts@@@css
//	CreditCard.Locator.LeftTabs.CreditCardActivity.Active=li.active a#Credit\\ Card\\ Activity@@@css
//	CreditCard.Locator.LeftTabs.CreditCardActivity=a#Credit\\ Card\\ Activity@@@css
//	CreditCard.Locator.LeftTabs.CreditCardPayment.Active=li.active a#Credit\\ Card\\ Payment@@@css
//	CreditCard.Locator.LeftTabs.CreditCardPayment=a#Credit\\ Card\\ Payment@@@css
//	CreditCard.Locator.LeftTabs.CreditCardServices.Active=li.active a#Credit\\ Card\\ Services@@@css
//	CreditCard.Locator.LeftTabs.CreditCardServices=a#Credit\\ Card\\ Services@@@css
//	CreditCard.Locator.LeftTabs.Overview.Active=li.active a#Overview@@@css
//	CreditCard.Locator.LeftTabs.Overview=a#Overview@@@css
//	CreditCard.Locator.LeftTabs.Rewards=a#Rewards@@@css
//	CreditCard.Locator.LeftTabs.StatementsAndDocuments.Active=li.active a#Statements\\ \\&\\ Documents@@@css
//	CreditCard.Locator.LeftTabs.StatementsAndDocuments=a#Statements\\ \\&\\ Documents@@@css
//	CreditCard.Locator.Link.InstantCardHold=//*[@class='marco simplemarco ']/a[2]@@@xpath
//	CreditCard.Locator.Link.RedeemPoints=a#RedeemPoints@@@css
//	CreditCard.Locator.Overview.Container.Card.First=(//div[contains(@id, 'main.cntTarjetas')])[1]@@@xpath
//	CreditCard.Locator.Overview.Image.Card.First=(//div[contains(@id, 'main.img')]//a/img)[1]@@@xpath
//	CreditCard.Locator.Overview.Link.Card.First=((//div[contains(@id, 'main.cntTarjetas')])[1]//div[@class='lyTexto']//a)[1]@@@xpath
//	CreditCard.Locator.Overview.Link.Card.Hold.First=((//div[contains(@id, 'main.cntTarjetas')])[1]//div[@class='lyTexto']//a)[2]@@@xpath
//	CreditCard.Locator.Overview.Link.Card.MakePayment.First=(//a[@id='MakePayment'])[1]@@@xpath
//	CreditCard.Locator.Overview.Link.Card.Redeem.First=(//a[@id='RedeemPoints'])[1]@@@xpath
//	CreditCard.Locator.Overview.Link.Card.SetupModify.First=(//a[@id='SetUp'])[1]@@@xpath
//	CreditCard.Locator.Overview.Link.HelpWithThisPage=a[title^=Help]@@@css
//	CreditCard.Locator.Overview.Link.Print=a#imprimir@@@css
//	CreditCard.Locator.Overview.MakePaymentFirst=//a[contains(@id,'MakePayment') and contains(@onclick, 'main.dtcPrimero.Onclick(id)')]@@@xpath
//	CreditCard.Locator.Overview.MakePaymentSecond=//a[contains(@id,'MakePayment') and contains(@onclick, 'main.dtcSegundo.Onclick(id)')]@@@xpath
//	CreditCard.Locator.Overview.SetUpAutopayFirst=//a[contains(@id,'SetUp') and contains(@onclick, 'main.dtcPrimero.Onclick(id)')]@@@xpath
//	CreditCard.Locator.Overview.SetupAutopaySecond=//a[contains(@id,'SetUp') and contains(@onclick, 'main.dtcSegundo.Onclick(id)')]@@@xpath
//	CreditCard.Locator.Overview.TextContainer.Card.AutopayInstructions.First=(//h1[contains(text(), 'Instructions:')]/parent::th/following-sibling::td)[1]@@@xpath
//	CreditCard.Locator.Overview.TextContainer.Card.AutopayState.First=(//h1[contains(text(), 'Autopay:')]/parent::th/following-sibling::td)[1]@@@xpath
//	CreditCard.Locator.Overview.TextContainer.Card.Number.First=(//p[contains(@class, 'simplemarco ')])[1]@@@xpath
//	CreditCard.Locator.Overview.TextContainer.Title=span.titulo@@@css
//	CreditCard.Locator.Text.OverviewTitle=//*[@id='main_titPrincipal_REPAINT']/span[1]@@@xpath
//	CreditCard.MultiLocator.Overview.Container.Cards=div[id^='main.cntTarjetas']@@@css
//	CreditCard.Text.LeftNav.Title=Credit Card
//	CreditCard.Text.Overview.Card.AutopayInstructions.Minimum=minimum amount due
//	CreditCard.Text.Overview.Card.AutopayInstructions.Statement=statement balance
//	CreditCard.Text.Overview.Title=Credit Card Overview


}
