package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class Transfer {


//	public static By Locator_Button_Continue =											By.cssSelector(""); //missing from properties file
	public static By Locator_Button_Continue_ModifyTransfer =							By.cssSelector("a.continue"); //missing from properties file
	public static By Locator_Button_Select =											By.xpath("//a[contains(@id,'btnSelect')]");
	public static By Locator_Calendar_TransferDate =									By.cssSelector("input[title='Calendar']");
	public static By Locator_DropDown_AccountFrom =										By.xpath("//select[contains(@id,'slcCuentaDesde')]");
	public static By Locator_DropDown_AccountTo =										By.cssSelector("select#slcCuentaHasta");
	public static By Locator_DropDown_Frequency =										By.cssSelector("select#slcFrecuencia");
	public static By Locator_DropDownOption_UnsecuredLOC =								By.xpath("//option[contains(text(),'Unsecured LOC')]");
	public static By Locator_LeftNav_Button_ManageAccounts =							By.cssSelector("a[id='Manage Accounts']");
	public static By Locator_LeftNav_Button_ManageAccounts_Active =						By.cssSelector("li.active a[id='Manage Accounts']");
	public static By Locator_LeftNav_Button_PendingTransfer =							By.cssSelector("a[id='Pending Transfer']");
	public static By Locator_LeftNav_Button_PendingTransfer_Active =					By.cssSelector("li.active a[id='Pending Transfer']");
	public static By Locator_LeftNav_Button_Transfer =									By.cssSelector("a[id='Transfer Funds']");
	public static By Locator_LeftNav_Button_Transfer_Active =							By.cssSelector("li.active a[id='Transfer Funds']");
	public static By Locator_LeftNav_Button_TransferHistory =							By.cssSelector("a[id='Transfer History']");
	public static By Locator_LeftNav_Button_TransferHistory_Active =					By.cssSelector("li.active a[id='Transfer History']");
//	public static By Locator_ModifyTransferTextField_Date_Day =							By.cssSelector(""); //missing from properties file
//	public static By Locator_ModifyTransferTextField_Date_Month =						By.cssSelector(""); //missing from properties file
//	public static By Locator_ModifyTransferTextField_Date_Year =						By.cssSelector(""); //missing from properties file
	public static By Locator_PendingTransfer_Actions_Dropdown =							By.xpath("//select[contains(@id,'main_slnTabla_0')]");
	public static By Locator_PendingTransfer_Amount =									By.xpath("//*[@id,'main_tblTabla_CELL:0.3']");
	public static By Locator_PendingTransfer_Button_Go =								By.xpath("//input[contains(@id,'main_slnTabla_0')]");
	public static By Locator_PendingTransfer_Frequency =								By.xpath("//*[@id,'main_tblTabla_CELL:0.4']");
	public static By Locator_PendingTransfer_TransferDate =								By.xpath("//*[@id,'main_tblTabla_CELL:0.0']");
	public static By Locator_Text_EnterTransferAmountError =							By.xpath("//p[contains(text(),'enter a transfer amount greater than zero')]");
	public static By Locator_Text_NoToAccountError =									By.xpath("//p[contains(text(),'select an Account')]");
	public static By Locator_Text_TransactionCompletedConfirmation =					By.xpath("//span[contains(text(),'Confirmation: Transaction completed successfully')]");
	public static By Locator_Text_TransferAmountGreaterThanAvailableBalanceError =		By.xpath("//p[contains(text(),'transfer amount entered is greater')]");
	public static By Locator_Text_TransferDeletedConfirmation =							By.xpath("//span[contains(text(),'Confirmation : Transfer Deleted Successfully.')]");
	public static By Locator_TextContainer_BreadCrumb_Active =							By.cssSelector("li.activo span:first-child");
//	public static By Locator_TextContainer_BreadCrumb_ConfirmDetails_Active =			By.cssSelector(""); //missing from properties file
	public static By Locator_TextContainer_ModifyTransfer_Title =						By.cssSelector("span.titulo"); //missing from properties file
	public static By Locator_TextContainer_TransferConfirmation_Title =					By.cssSelector("span.titulo");
	public static By Locator_TextContainer_Transfer_SegmentTitle =						By.cssSelector("span.title");
	public static By Locator_TextField_Date_Day =										By.xpath("//input[contains(@id,'iDay')]");
	public static By Locator_TextField_Date_Month =										By.xpath("//input[contains(@id,'iMonth')]");
	public static By Locator_TextField_Date_Year =										By.xpath("//input[contains(@id,'iYear')]");
	public static By Locator_TextField_TransferAmount =									By.cssSelector("input#impImporte");
	public static By Locator_Transfer_BetweenMySantanderAccounts =						By.cssSelector("li:not(.active) > span#Between > a");
	public static By Locator_Transfer_BetweenMySantanderAccounts_Active =				By.cssSelector("li.active > span#Between > a");
	public static By Locator_Transfer_ToSomeonElse =									By.cssSelector("li:not(.active) > span#ToSomeone > a");
	public static By Locator_Transfer_ToSomeonElse_Active =								By.cssSelector("li.active > span#ToSomeone > a");
	public static By Text_BusinessDayTransferError =									By.xpath("//p[contains(text(),'between Monday and Friday')]");
	public static By Text_EnterTransferAmountError =									By.xpath("//p[contains(text(),'enter a transfer amount greater than zero')]");
	public static By Text_NoToAccountError =											By.xpath("//p[contains(text(),'select an Account')]");
	public static By Text_TransactionCompletedConfirmation =							By.xpath("//span[contains(text(),'Confirmation: Transaction completed successfully')]");
	public static By Text_TransferAmountGreaterThanAvailableBalanceError =				By.xpath("//p[contains(text(),'transfer amount entered is greater')]");
	public static String CompoundLocator_TextContainer_TransferConfirmations =			"//h1[contains(text(), '~~~')]/parent::th/following-sibling::td";
	public static String Locator_Input_Amount =											"10000";
	public static String Locator_Text_TransferConfirmation_Title =						"Transfer Funds";
	public static String Text_BreadCrumb_ConfirmDetails =								"Confirm Details";
	public static String Text_BreadCrumb_EnterDetails =									"Enter Details";
	public static String Text_BreadCrumb_Summary =										"Summary";
	public static String Text_Checking =												"CHECKING";
	public static String Text_Frequency_Annually =										"Annually";
	public static String Text_Frequency_BiWeekly =										"Biweekly";
	public static String Text_Frequency_Monthly =										"Monthly";
	public static String Text_Frequency_OneTime =										"One-time transfer";
	public static String Text_Frequency_Quartly =										"Quarterly";
	public static String Text_Frequency_SemiAnnually =									"Semi Annually";
	public static String Text_Frequency_Weekly =										"Weekly";
	public static String Text_ModifyTransfer_Title =									"Modify Transfer";
//	public static String Text_NoPendingTransfers =										""; //missing from properties file
	public static String Text_PendingTransfer_Actions_DeleteTransfer =					"Delete Transfer";
	public static String Text_PendingTransfer_Actions_ModifyTransfer =					"Modify Transfer";
	public static String Text_PendingTransfer_Actions_TransferDetails =					"Transfer Details";
	public static String Text_Saving =													"SAVINGS";
	public static String Text_TransferConfirmation_Amount =								"Amount";
	public static String Text_TransferConfirmation_Title =								"Transfer Funds";
	public static String Text_Transfer_SegmentTitle =									"Transfer Details";


//	Locator_Button_Continue("Transfer.Locator.Button.Continue"),
//	Locator_Button_Continue_ModifyTransfer("Transfer.Locator.Button.Continue.ModifyTransfer"),
//	Locator_Button_Select("Transfer.Locator.Button.Select"),
//	Locator_Calendar_TransferDate("Transfer.Locator.Calendar.TransferDate"),
//	Locator_DropDown_AccountFrom("Transfer.Locator.DropDown.AccountFrom"),
//	Locator_DropDown_AccountTo("Transfer.Locator.DropDown.AccountTo"),
//	Locator_DropDown_Frequency("Transfer.Locator.DropDown.Frequency"),
//	Locator_DropDownOption_UnsecuredLOC("Transfer.Locator.DropDownOption.UnsecuredLOC"),
//	Locator_Input_Amount("Transfer.Text.AmountToTransfer"),
//	Locator_LeftNav_Button_ManageAccounts("Transfer.Locator.LeftNav.Button.ManageAccounts"),
//	Locator_LeftNav_Button_ManageAccounts_Active("Transfer.Locator.LeftNav.Button.ManageAccounts.Active"),
//	Locator_LeftNav_Button_PendingTransfer("Transfer.Locator.LeftNav.Button.PendingTransfer"),
//	Locator_LeftNav_Button_PendingTransfer_Active("Transfer.Locator.LeftNav.Button.PendingTransfer.Active"),
//	Locator_LeftNav_Button_TransferFunds("Transfer.Locator.LeftNav.Button.TransferFunds"),
//	Locator_LeftNav_Button_TransferFunds_Active("Transfer.Locator.LeftNav.Button.TransferFunds.Active"),
//	Locator_LeftNav_Button_TransferHistory("Transfer.Locator.LeftNav.Button.TransferHistory"),
//	Locator_LeftNav_Button_TransferHistory_Active("Transfer.Locator.LeftNav.Button.TransferHistory.Active"),
//	Locator_ModifyTransfer_TextField_Date_Day("Transfer.Locator.ModifyTransfer.TextField.Date.Day"),
//	Locator_ModifyTransfer_TextField_Date_Month("Transfer.Locator.ModifyTransfer.TextField.Date.Month"),
//	Locator_ModifyTransfer_TextField_Date_Year("Transfer.Locator.ModifyTransfer.TextField.Date.Year"),
//	Locator_PendingTransfer_Actions_Dropdown("Transfer.Locator.PendingTransfer.Actions.Dropdown"),
//	Locator_PendingTransfer_Amount("Transfer.Locator.PendingTransfer.Amount"),
//	Locator_PendingTransfer_Button_Go("Transfer.Locator.PendingTransfer.Button.Go"),
//	Locator_PendingTransfer_Frequency("Transfer.Locator.PendingTransfer.Frequency"),
//	Locator_PendingTransfer_TransferDate("Transfer.Locator.PendingTransfer.TransferDate"),
//	Locator_Text_EnterTransferAmountError("Transfer.Locator.Text.EnterTransferAmountError"),
//	Locator_Text_NoToAccountError("Transfer.Locator.Text.NoToAccountError"),
//	Locator_Text_TransactionCompletedConfirmation("Transfer.Locator.Text.TransactionCompletedConfirmation"),
//	Locator_Text_TransferAmountGreaterThanAvailableBalanceError("Transfer.Locator.Text.TransferAmountGreaterThanAvailableBalanceError"),
//	Locator_Text_TransferConfirmation_Title("Transfer.Text.TransferConfirmation.Title"),
//	Locator_Text_TransferDeletedConfirmation("Transfer.Locator.Text.TransferDeletedConfirmation"),
//	Locator_TextContainer_BreadCrumb_Active("Transfer.Locator.TextContainer.BreadCrumb.Active"),
//	Locator_TextContainer_BreadCrumb_ConfirmDetails_Active("Transfer.Locator.TextContainer.BreadCrumb.ConfirmDetails.Active"),
//	Locator_TextContainer_ModifyTransfer_Title("Transfer.Locator.TextContainer.ModifyTransfer.Title"),
//	Locator_TextContainer_TransferConfirmation_Amount("Transfer.Locator.TextContainer.TransferConfirmation.Amount"),
//	Locator_TextContainer_TransferConfirmation_Title("Transfer.Locator.TextContainer.TransferConfirmation.Title"),
//	Locator_TextContainer_TransferFunds_SegmentTitle("Transfer.Locator.TextContainer.TransferFunds.SegmentTitle"),
//	Locator_TextField_Date_Day("Transfer.Locator.TextField.Date.Day"),
//	Locator_TextField_Date_Month("Transfer.Locator.TextField.Date.Month"),
//	Locator_TextField_Date_Year("Transfer.Locator.TextField.Date.Year"),
//	Locator_TextField_TransferAmount("Transfer.Locator.TextField.TransferAmount"),
//	Locator_TransferFunds_BetweenMySantanderAccounts("Transfer.Locator.TransferFunds.BetweenMySantanderAccounts"),
//	Locator_TransferFunds_BetweenMySantanderAccounts_Active("Transfer.Locator.TransferFunds.BetweenMySantanderAccounts.Active"),
//	Locator_TransferFunds_ToSomeonElse("Transfer.Locator.TransferFunds.ToSomeonElse"),
//	Locator_TransferFunds_ToSomeonElse_Active("Transfer.Locator.TransferFunds.ToSomeonElse.Active"),
//	Text_BreadCrumb_ConfirmDetails("Transfer.Text.BreadCrumb.ConfirmDetails"),
//	Text_BreadCrumb_EnterDetails("Transfer.Text.BreadCrumb.EnterDetails"),
//	Text_BreadCrumb_Summary("Transfer.Text.BreadCrumb.Summary"),
//	Text_Checking("Transfer.Text.Checking"),
//	Text_EnterTransferAmountError("Transfer.Text.EnterTransferAmountError"),
//	Text_Frequency_Anually("Transfer.Text.Frequency.Annually"),
//	Text_Frequency_BiWeekly("Transfer.Text.Frequency.BiWeekly"),
//	Text_Frequency_Monthly("Transfer.Text.Frequency.Monthly"),
//	Text_Frequency_OneTime("Transfer.Text.Frequency.OneTime"),
//	Text_Frequency_Quartly("Transfer.Text.Frequency.Quarterly"),
//	Text_Frequency_SemiAnnually("Transfer.Text.Frequency.SemiAnnually"),
//	Text_Frequency_Weekly("Transfer.Text.Frequency.Weekly"),
//	Text_ModifyTransfer_Title("Transfer.Text.ModifyTransfer.Title"),
//	Text_NoPendingTransfers("Transfer.Text.NoPendingTransfers"),
//	Text_NoToAccountError("Transfer.Text.NoToAccountError"),
//	Text_PendingTransfer_Actions_DeleteTransfer("Transfer.Text.PendingTransfer.Actions.DeleteTransfer"),
//	Text_PendingTransfer_Actions_ModifyTransfer("Transfer.Text.PendingTransfer.Actions.ModifyTransfer"),
//	Text_PendingTransfer_Actions_TransferDetails("Transfer.Text.PendingTransfer.Actions.TransferDetails"),
//	Text_Saving("Transfer.Text.Saving"),
//	Text_TransactionCompletedConfirmation("Transfer.Text.TransactionCompletedConfirmation"),
//	Text_TransferAmountGreaterThanAvailableBalanceError("Transfer.Text.TransferAmountGreaterThanAvailableBalanceError"),
//	Text_TransferConfirmation_Amount("Transfer.Text.TransferConfirmation.Amount"),
//	Text_TransferConfirmation_Title("Transfer.Text.TransferConfirmation.Title"),
//	Text_TransferFunds_SegmentTitle("Transfer.Text.TransferFunds.SegmentTitle"),
//	Text_BusinessDayTransferError("Transfer.Text.BusinessDayTransferError"),


//	Transfer.Locator.Button.Select=//a[contains(@id,"btnSelect")]@@@xpath
//	Transfer.Locator.Calendar.TransferDate=input[title=Calendar]@@@css
//	Transfer.Locator.DropDown.AccountFrom=//select[contains(@id,'slcCuentaDesde')]@@@xpath
//	Transfer.Locator.DropDown.AccountTo=select#slcCuentaHasta@@@css
//	Transfer.Locator.DropDown.Frequency=select#slcFrecuencia@@@css
//	Transfer.Locator.DropDownOption.UnsecuredLOC=//option[contains(text(),'Unsecured LOC')]@@@xpath
//	Transfer.Locator.LeftNav.Button.ManageAccounts.Active=li.active a#Manage\\ Accounts@@@css
//	Transfer.Locator.LeftNav.Button.ManageAccounts=a#Manage\\ Accounts@@@css
//	Transfer.Locator.LeftNav.Button.PendingTransfer.Active=li.active a#Pending\\ Transfer@@@css
//	Transfer.Locator.LeftNav.Button.PendingTransfer=a#Pending\\ Transfer@@@css
//	Transfer.Locator.LeftNav.Button.TransferFunds.Active=li.active a#Transfer\\ Funds@@@css
//	Transfer.Locator.LeftNav.Button.TransferFunds=a#Transfer\\ Funds@@@css
//	Transfer.Locator.LeftNav.Button.TransferHistory.Active=li.active a#Transfer\\ History@@@css
//	Transfer.Locator.LeftNav.Button.TransferHistory=a#Transfer\\ History@@@css
//	Transfer.Locator.Text.EnterTransferAmountError=//p[contains(text(),'enter a transfer amount greater than zero')]@@@xpath
//	Transfer.Locator.Text.NoToAccountError=//p[contains(text(),'select an Account')]@@@xpath
//	Transfer.Locator.TextContainer.BreadCrumb.Active=li.activo span:first-child@@@css
//	Transfer.Locator.TextContainer.TransferConfirmation.Amount=//h1[contains(text(), "~~~")]/parent::th/following-sibling::td@@@xpath
//	Transfer.Locator.TextContainer.TransferConfirmation.Title=span.titulo@@@css
//	Transfer.Locator.TextContainer.TransferFunds.SegmentTitle=span.title@@@css
//	Transfer.Locator.TextField.TransferAmount=input#impImporte@@@css
//	Transfer.Locator.TransferFunds.BetweenMySantanderAccounts.Active=li.active > span#Between > a@@@css
//	Transfer.Locator.TransferFunds.BetweenMySantanderAccounts=li:not(.active) > span#Between > a@@@css
//	Transfer.Locator.TransferFunds.ToSomeonElse.Active=li.active > span#ToSomeone > a@@@css
//	Transfer.Locator.TransferFunds.ToSomeonElse=li:not(.active) > span#ToSomeone > a@@@css
//	Transfer.Text.AmountToTransfer=10000
//	Transfer.Text.BreadCrumb.ConfirmDetails=Confirm Details
//	Transfer.Text.BreadCrumb.EnterDetails=Enter Details
//	Transfer.Text.BreadCrumb.Summary=Summary
//	Transfer.Text.Checking=CHECKING
//	Transfer.Text.EnterTransferAmountError=//p[contains(text(),'enter a transfer amount greater than zero')]@@@xpath
//	Transfer.Text.Frequency.Annually=Annually
//	Transfer.Text.Frequency.BiWeekly=Biweekly
//	Transfer.Text.Frequency.Monthly=Monthly
//	Transfer.Text.Frequency.OneTime=One-time transfer
//	Transfer.Text.Frequency.Quarterly=Quarterly
//	Transfer.Text.Frequency.SemiAnnually=Semi Annually
//	Transfer.Text.Frequency.Weekly=Weekly
//	Transfer.Text.NoToAccountError=//p[contains(text(),'select an Account')]@@@xpath
//	Transfer.Text.Saving=SAVINGS
//	Transfer.Text.TransactionCompletedConfirmation=//span[contains(text(),'Confirmation: Transaction completed successfully')]@@@xpath
//	Transfer.Text.TransferAmountGreaterThanAvailableBalanceError=//p[contains(text(),'transfer amount entered is greater')]@@@xpath
//	Transfer.Text.TransferConfirmation.Amount=Amount
//	Transfer.Text.TransferConfirmation.Title=Transfer Funds
//	Transfer.Text.TransferFunds.SegmentTitle=Transfer Details
//	Transfer.Locator.TextField.Date.Month=//input[contains(@id,"iMonth")]@@@xpath
//	Transfer.Locator.TextField.Date.Year=//input[contains(@id,"iYear")]@@@xpath
//	Transfer.Locator.TextField.Date.Day=//input[contains(@id,"iDay")]@@@xpath
//	Transfer.Locator.PendingTransfer.TransferDate=//*[@id,"main_tblTabla_CELL:0.0"]@@@xpath
//	Transfer.Locator.PendingTransfer.Amount=//*[@id,"main_tblTabla_CELL:0.3"]@@@xpath
//	Transfer.Locator.PendingTransfer.Button.Go=//input[contains(@id,"main_slnTabla_0")]@@@xpath
//	Transfer.Locator.PendingTransfer.Frequency=//*[@id,"main_tblTabla_CELL:0.4"]@@@xpath
//	Transfer.Locator.PendingTransfer.Actions.Dropdown=//select[contains(@id,"main_slnTabla_0")]@@@xpath
//	Transfer.Text.PendingTransfer.Actions.DeleteTransfer=Delete Transfer
//	Transfer.Text.PendingTransfer.Actions.ModifyTransfer=Modify Transfer
//	Transfer.Text.PendingTransfer.Actions.TransferDetails=Transfer Details
//	Transfer.Locator.Text.TransferDeletedConfirmation=//span[contains(text(),"Confirmation : Transfer Deleted Successfully.")]@@@xpath
//	Transfer.Text.BusinessDayTransferError=//p[contains(text(),'between Monday and Friday')]@@@xpath
//	Transfer.Locator.ProductType.


}
