package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class ShowHideNickname {


	public static By Locator_CheckBox_CheckingAccount =							By.cssSelector("input#main_inputTabla_1_idCheck_00");
	public static By Locator_CheckBox_CreditAccount =							By.cssSelector("input#main_iptCards_idCheck_00");
	public static By Locator_CheckBox_SavingsAccount =							By.cssSelector("input#main_inputTabla_1_idCheck_01");
	public static By Locator_CheckBox_SelectAll =								By.cssSelector("input#chkTodos");
	public static By Locator_Image_ShowHideNicknameChangedSuccessfully =		By.cssSelector("span.confirmacion");
	public static By Locator_SubTitle_ShowHideNicknameAccounts =				By.xpath("//span[contains(text(),'Show, Hide and Nickname Accounts')]");
	public static By Locator_TextField_CheckingAccount_Nickname =				By.cssSelector("input#main_inputTabla_1_textAndPsw11");
	public static By Locator_TextField_CheckingAccount_Order =					By.cssSelector("input#main_inputTabla_1_textAndPsw21");
	public static By Locator_TextField_CreditAccount_Nickname =					By.cssSelector("input#main_iptCredits_textAndPsw10");
	public static By Locator_TextField_CreditAccount_Order =					By.cssSelector("input#main_iptCredits_textAndPsw20");
	public static By Locator_TextField_SavingsAccount_Nickname =				By.cssSelector("input#main_inputTabla_1_textAndPsw10");
	public static By Locator_TextField_SavingsAccount_Order =					By.cssSelector("input#main_inputTabla_1_textAndPsw20");
	public static By MultiLocator_CheckBox_CheckSaveMoneyMarketSelect =			By.xpath("//div[@id='main.tblTabla']//input[@type='checkbox']");
	public static By MultiLocator_CheckBox_CreditCardSelect =					By.xpath("//div[@id='main.tblCards']//input[@type='checkbox']");
	public static By MultiLocator_TextField_CheckSaveMoneyMarketAccount =		By.cssSelector("div[id='main.tblTabla'] td[id$='.1'] span");
	public static By MultiLocator_TextField_CheckSaveMoneyMarketNicknames =		By.xpath("//div[@id='main.tblTabla']//input[contains(@id,'Psw1')]");
	public static By MultiLocator_TextField_CheckSaveMoneyMarketOrder =			By.xpath("//div[@id='main.tblTabla']//input[contains(@id,'Psw2')]");
	public static By MultiLocator_TextField_CreditCardAccount =					By.cssSelector("div[id='main.tblCards'] td[id$='.1'] span");
	public static By MultiLocator_TextField_CreditCardNicknames =				By.xpath("//div[@id='main.tblCards']//input[contains(@id,'Psw1')]");
	public static By MultiLocator_TextField_CreditCardOrder =					By.xpath("//div[@id='main.tblCards']//input[contains(@id,'Psw2')]");


//	Locator_CheckBox_CheckingAccount("ShowHideNickname.Locator.CheckBox.CheckingAccount"),
//	Locator_CheckBox_CreditAccount("ShowHideNickname.Locator.CheckBox.CreditAccount"),
//	Locator_CheckBox_SavingsAccount("ShowHideNickname.Locator.CheckBox.SavingsAccount"),
//	Locator_CheckBox_SelectAll("ShowHideNickname.Locator.CheckBox.SelectAll"),
//	Locator_Image_ShowHideNicknameChangedSuccessfully("ShowHideNickname.Locator.Image.ShowHideNicknameChangedSuccessfully"),
//	Locator_SubTitle_ShowHideNicknameAccounts("ShowHideNickname.Locator.SubTitle.ShowHideNicknameAccounts"),
//	Locator_TextField_CheckingAccount_Nickname("ShowHideNickname.Locator.TextField.CheckingAccount.Nickname"),
//	Locator_TextField_CheckingAccount_Order("ShowHideNickname.Locator.TextField.CheckingAccount.Order"),
//	Locator_TextField_CreditAccount_Nickname("ShowHideNickname.Locator.TextField.CreditAccount.Nickname"),
//	Locator_TextField_CreditAccount_Order("ShowHideNickname.Locator.TextField.CrediAccount.Order"),
//	Locator_TextField_SavingsAccount_Nickname("ShowHideNickname.Locator.TextField.SavingsAccount.Nickname"),
//	Locator_TextField_SavingsAccount_Order("ShowHideNickname.Locator.TextField.SavingsAccount.Order"),
//	MultiLocator_CheckBox_CheckSaveMoneyMarketSelect("ShowHideNickName.MultiLocator.CheckBox.CheckSaveMoneyMarketSelect"),
//	MultiLocator_CheckBox_CreditCardSelect("ShowHideNickName.MultiLocator.CheckBox.CreditCardSelect"),
//	MultiLocator_TextField_CheckSaveMoneyMarketAccount("ShowHideNickName.MultiLocator.TextField.CheckSaveMoneyAccount"),
//	MultiLocator_TextField_CheckSaveMoneyMarketNicknames("ShowHideNickName.MultiLocator.TextField.CheckSaveMoneyNicknames"),
//	MultiLocator_TextField_CheckSaveMoneyMarketOrder("ShowHideNickName.MultiLocator.TextField.CheckSaveMoneyMarketOrder"),
//	MultiLocator_TextField_CreditCardAccount("ShowHideNickName.MultiLocator.TextField.CreditCardAccount"),
//	MultiLocator_TextField_CreditCardNicknames("ShowHideNickName.MultiLocator.TextField.CreditCardNicknames"),
//	MultiLocator_TextField_CreditCardOrder("ShowHideNickName.MultiLocator.TextField.CreditCardOrder"),


//	ShowHideNickname.Locator.CheckBox.CheckingAccount1=input#main_inputTabla_1_idCheck_00@@@css
//	ShowHideNickname.Locator.CheckBox.CheckingAccount2=input#main_inputTabla_2_idCheck_00@@@css
//	ShowHideNickname.Locator.CheckBox.CheckingAccount=input#main_inputTabla_1_idCheck_00@@@css
//	ShowHideNickname.Locator.CheckBox.CreditAccount1=input#main_iptCredits_idCheck_00@@@css
//	ShowHideNickname.Locator.CheckBox.CreditAccount=input#main_iptCards_idCheck_00@@@css
//	ShowHideNickname.Locator.CheckBox.SavingsAccount=input#main_inputTabla_1_idCheck_01@@@css
//	ShowHideNickname.Locator.CheckBox.SelectAll=input#chkTodos@@@css
//	ShowHideNickname.Locator.Image.ShowHideNicknameChangedSuccessfully=span.confirmacion@@@css
//	ShowHideNickname.Locator.Input.Nickname.CheckingEdited="Checking Edited"
//	ShowHideNickname.Locator.Input.Nickname.CheckingEditedChanged="Checking Edited 2.0"
//	ShowHideNickname.Locator.Input.Nickname.SavingsEdited="Savings Edited"
//	ShowHideNickname.Locator.Input.Nickname.SavingsEditedChanged="Savings Edited 1.0"
//	ShowHideNickname.Locator.Input.Order1=1
//	ShowHideNickname.Locator.Input.Order2=2
//	ShowHideNickname.Locator.SubTitle.ShowHideNicknameAccounts=//span[contains(text(),'Show, Hide and Nickname Accounts')]@@@xpath
//	ShowHideNickname.Locator.TextField.CheckingAccount.Nickname=input#main_inputTabla_1_textAndPsw11@@@css
//	ShowHideNickname.Locator.TextField.CheckingAccount.Order=input#main_inputTabla_1_textAndPsw21@@@css
//	ShowHideNickname.Locator.TextField.CheckingAccount1.Nickname=input#main_inputTabla_1_textAndPsw10@@@css
//	ShowHideNickname.Locator.TextField.CheckingAccount1.Order=input#main_inputTabla_1_textAndPsw20@@@css
//	ShowHideNickname.Locator.TextField.CheckingAccount2.Nickname=input#main_inputTabla_1_textAndPsw10@@@css
//	ShowHideNickname.Locator.TextField.CheckingAccount2.Order=input#main_inputTabla_1_textAndPsw20@@@css
//	ShowHideNickname.Locator.TextField.CreditAccount.Nickname=input#main_iptCredits_textAndPsw10@@@css
//	ShowHideNickname.Locator.TextField.CreditAccount.Order=input#main_iptCredits_textAndPsw20@@@css
//	ShowHideNickname.Locator.TextField.CreditAccount1.Nickname=input#main_iptCredits_textAndPsw10@@@css
//	ShowHideNickname.Locator.TextField.CreditAccount1.Order=input#main_iptCredits_textAndPsw20@@@css
//	ShowHideNickname.Locator.TextField.SavingsAccount.Nickname=input#main_inputTabla_1_textAndPsw10@@@css
//	ShowHideNickname.Locator.TextField.SavingsAccount.Order=input#main_inputTabla_1_textAndPsw20@@@css
//	ShowHideNickName.MultiLocator.CheckBox.CheckSaveMoneyMarketSelect=//div[@id='main.tblTabla']//input[@type='checkbox']@@@xpath
//	ShowHideNickName.MultiLocator.CheckBox.CreditCardSelect=//div[@id='main.tblCards']//input[@type='checkbox']@@@xpath
//	ShowHideNickName.MultiLocator.TextField.CheckSaveMoneyAccount=div#main\\.tblTabla td[id$='.1'] span@@@css
//	ShowHideNickName.MultiLocator.TextField.CheckSaveMoneyMarketOrder=//div[@id='main.tblTabla']//input[contains(@id,'Psw2')]@@@xpath
//	ShowHideNickName.MultiLocator.TextField.CheckSaveMoneyNicknames=//div[@id='main.tblTabla']//input[contains(@id,'Psw1')]@@@xpath
//	ShowHideNickName.MultiLocator.TextField.CreditCardAccount=div#main\\.tblCards td[id$='.1'] span@@@css
//	ShowHideNickName.MultiLocator.TextField.CreditCardNicknames=//div[@id='main.tblCards']//input[contains(@id,'Psw1')]@@@xpath
//	ShowHideNickName.MultiLocator.TextField.CreditCardOrder=//div[@id='main.tblCards']//input[contains(@id,'Psw2')]@@@xpath


}
