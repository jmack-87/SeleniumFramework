package app_resources.c2s.pageObjects;

import org.openqa.selenium.By;

public class PrintingAndSummary {

	public static By Locator_Button_PrintAllDocuments = 			By.cssSelector("div#documents-to-print button[ng-click*=printAll]");
	public static By Locator_Button_ContinueToSummary = 			By.cssSelector("div#documentPrintingContainer button[ng-click*=continue]");
	public static By Locator_Button_FinishButton = 					By.cssSelector("div#summaryContainer button[ng-click*=finish]");			
	public static By Locator_Button_ReturnToONEYes = 				By.xpath("//div[@id='success'][@class='message-content']/message-buttons/div/button[1]");	
	public static String Text_PDFWindowTitle = 						"";
	public static String Text_ReturnWindowTitle = 					"Account Opening";

}
