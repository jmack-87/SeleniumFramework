package AlmReporting;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Nayan Bhavsar.
 */
public class ParseXMLResponse {
    Map<String, ArrayList> map = new HashMap<String, ArrayList>();

    public  ParseXMLResponse(String xmlResponseMessage)  {

        Document doc = null;
        try {
            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(xmlResponseMessage));
            doc = db.parse(is);

        }catch(Exception ex){
            ex.printStackTrace();
        }

        NodeList nodes = doc.getElementsByTagName("Entity");

        for (int i = 0; i < nodes.getLength() ; i++) {

            Element element = (Element) nodes.item(i);

            NodeList nd =  element.getElementsByTagName("Field");

            for (int n = 0; n < nd.getLength() ; n++){

                if (nd.item(n) != null && nd.item(n).hasAttributes()) {
                    String AttrValue = "";
                    String AttrKey = nd.item(n).getAttributes().item(0).getTextContent();
                    //  System.out.println("Attribute name:=" + AttrKey);

                    ///    if (AttrKey.equalsIgnoreCase(FieldKey)) {

                    if (nd.item(n).hasChildNodes()) {
                        Element childElement = (Element) nd.item(n);
                        if (childElement.getElementsByTagName("Value").getLength() > 0) {
                            AttrValue = childElement.getElementsByTagName("Value").item(0).getTextContent();
                            //   System.out.println("Attribute value:=" + AttrValue);
                        }
                    }

                    //   }

                    AddMapValue(AttrKey, AttrValue);
                }
            }


        }


    }

    private void AddMapValue(String AttrKey, String AttrValue){
        ArrayList ar = null;
        if (map.containsKey(AttrKey)){
            ar = map.get(AttrKey);

            ar.add(AttrValue);

        }else{
            ar = new ArrayList<String>();
            ar.add(AttrValue);
        }

        map.put(AttrKey, ar);
    }


    public ArrayList getValues(String FieldKey){
        return  map.get(FieldKey);
    }

    public String getValue(String FieldKey, int index){
        return map.get(FieldKey).get(index).toString();
    }

    public int getKeySize(String FieldKey){
        return map.get(FieldKey).size();
    }

    /*
    @Test
    public void Testvv(){
        StringBuilder sb = new StringBuilder();
        String line = null;
        String filePath = "C:\\Users\\mdaud\\Desktop\\NodeJStesting\\test.xml";
        try {


            FileReader fr = new FileReader(filePath);

            BufferedReader br = new BufferedReader(fr);

            while((line = br.readLine()) != null){
                sb.append(line);
            }

            br.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



        try {
            ParseXMLResponseV(sb.toString());
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }

        System.out.println(getValue("hierarchical-path", 0));

    }
    */
}
