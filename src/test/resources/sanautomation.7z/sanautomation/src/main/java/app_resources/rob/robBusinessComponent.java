package app_resources.rob;


import common_resources.utility;
import common_resources.database_tools.LDAPQuery;
import common_resources.database_tools.LDAPQueryHelper;
import common_resources.enumerations.DateOptions;
import common_resources.enumerations.PaymentOptions;
import common_resources.enumerations.RandomOptions;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import app_resources.rob.pageObjects.Accounts;
import app_resources.rob.pageObjects.Alerts;
import app_resources.rob.pageObjects.BillPay;
import app_resources.rob.pageObjects.Common;
import app_resources.rob.pageObjects.ContactUs;
import app_resources.rob.pageObjects.CreditCard;
import app_resources.rob.pageObjects.CreditCardPayment;
import app_resources.rob.pageObjects.CustomerService;
//import app_resources.rob.pageObjects.Enrollment;
//import app_resources.rob.pageObjects.ForgotPassword;
//import app_resources.rob.pageObjects.ForgotUserId;
import app_resources.rob.pageObjects.LoginPage;
import app_resources.rob.pageObjects.LogoutPage;
import app_resources.rob.pageObjects.MyProfileAndPreferences;
import app_resources.rob.pageObjects.QuickTransfer;
import app_resources.rob.pageObjects.RobNoTMXLogin;
import app_resources.rob.pageObjects.RobRegTMXLogin;
import app_resources.rob.pageObjects.RobTMXLogin;
import app_resources.rob.pageObjects.ShowHideNickname;
import app_resources.rob.pageObjects.Transfer;


/*
    *Author: Nayan Bhavsar
    *Description: All Subscribe related functions
    *date:
*/
/**
 *
 * @author
 *
 */
public class robBusinessComponent extends utility {

	private String compoundPlaceholder = "~~~";


	/* COMMON - START */
	private String errorMessage;

	private LocalDate paymentDate = LocalDate.now();
	private DayOfWeek dayOfWeek = LocalDate.now().getDayOfWeek();
	private String paymentDay = "" + paymentDate.getDayOfMonth();
	private String month = "" + paymentDate.getMonthValue();
	private String year = "" + paymentDate.getYear();
	private String paymentAmount;

	private WebElement we;
	private List<WebElement> weArray = new ArrayList<WebElement>();

	private DateTimeFormatter displayedDateFormat = DateTimeFormatter.ofPattern("M/d/yyyy h:mm a").withZone(ZoneId.systemDefault());
	private DateTimeFormatter expectedDateFormat = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").withZone(ZoneId.systemDefault());
	private DateTimeFormatter debugDateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneId.systemDefault());
	private DateTimeFormatter paymentFieldsDateFormat = DateTimeFormatter.ofPattern("MM/dd/YYYY").withZone(ZoneId.systemDefault());

	private String regEx = "\\d{2}/\\d{2}/\\d{4} \\d+:\\d{2} (am|pm) [A-Z]+";
	private Pattern pattern = Pattern.compile(regEx);
	private Matcher match;

	private Random randomizer = new Random(System.currentTimeMillis());
	/* COMMON - END */

	/* BILLPAY - START */
	private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMMM d, YYYY").withZone(ZoneId.systemDefault());
	/* BILLPAY - END */

	/* CREDITCARD - START */
	private String last4 = ".*\\*\\d{4}.*";
	private Pattern last4pattern = Pattern.compile(last4);

	private String autopayState;
	/* CREDITCARD - END */

	/* CREDITCARDPAYMENT - START */
	private String ccLast4;
	private String acLast4;
	private String email;
	private String dueDate;
	private int recordsDisplayed;
	private int recordsOfTotal;
	private int newRecordsDisplayed;
	private int newRecordsOfTotal;
	private String formatedDate;
	private String date;

	private String dateRegEx = "\\d{2}/\\d{2}/\\d{4}";
	private Pattern datePattern = Pattern.compile(dateRegEx);
	private LocalDateTime today = LocalDateTime.now(ZoneId.systemDefault());
	private LocalDateTime tomorrow = today.plusDays(1);
	/* CREDITCARDPAYMENT - END */

	/* SHOWHIDENICKNAME - START */
	private String disabledCheckingAccount;
	private String disabledCreditCardAccount;
	private String originalCheckingFirstNickname;
	private String originalCreditFirstNickname;
	private String tempCheckingNickname;
	private String tempCreditNickname;
	private List<String> ccAccountLast4s = new ArrayList<String>();
	private List<String> ccNicknames = new ArrayList<String>();
	private List<String> chAccountLast4s = new ArrayList<String>();
	private List<String> chNicknames = new ArrayList<String>();
	private List<Integer> ccIndexes = new ArrayList<Integer>();
	private List<Integer> chIndexes = new ArrayList<Integer>();
	/* SHOWHIDENICKNAME - END */

	/* QUICKTRANSFERS - START */
	LocalDate todayDate = LocalDate.now(ZoneId.systemDefault());
	LocalDate tomorrowDate = todayDate.plusDays(1);
	DateTimeFormatter dtfr = DateTimeFormatter.ofPattern("d");
	String tomorrowQt = dtfr.format(tomorrowDate);
	/* QUICKTRANSFERS - END */

	/* TRANSFERFUNDS - START */
	private String amount;
	private int pass = 0;
	/* TRANSFERFUNDS - END */

	/* ALERTS - START */
	private String account;
	private String email_Alerts;
	private int adjustedEnabledCount = 0;

	private String regEx_Alerts = "\\*{3}-\\*{3}-\\d{4}";
	private Pattern pattern_Alerts = Pattern.compile(regEx_Alerts);
	private Matcher match_Alerts;
	/* ALERTS - END */


	/**
	 *
	 * @param struserid
	 * @param strpassword
	 */
	public void fnROBLogin(String struserid, String strpassword) {

		fnEnterText(LoginPage.userID, struserid);

		fnEnterText(LoginPage.password, strpassword);

		fnClickObject(LoginPage.loginButton);
		hard_wait(5);

	}


	/**
	 *
	 * @return
	 */
	public Boolean fnROBLogout() {

		fnClickObject(LogoutPage.objLogOut);
		hard_wait(5000);

		if (fnObjectExist(LogoutPage.objMenu, 5)) {
			return true;
		} else {
			return false;
		}

	}

















































	/* COMMON -  START */

	/**
	 * Launch regular rob login page url.
	 */
	public void launchPage() {

		getUrl(RobRegTMXLogin.Text_URL);

	}


	/**
	 * Launch regular rob login page url.
	 *
	 * @param url (String) target url to launch (excel data)
	 */
	public void launchPage(String url) {

		getUrl(url);
//		fnReportLog("PASSED", String.format("Launched %s", url), String.format("Could not launch %s", url), false);

		if (wd.getCurrentUrl().length() > 0) {
			fnReportLog("Passed", String.format("URL launched: %s", url), "URL launched.", false);
		} else {
			fnReportLog("Failed", String.format("URL launched: %s", url), "URL not launched.", false);
			ss.fail(String.format("Could not launch url: %s", url));
		}

	}


	/**
	 * Set user id text field to target value
	 *
	 * @param userName (String) user id from test data
	 */
	public void setUserName(String userName) {

		sendText(RobRegTMXLogin.Locator_TextField_UserId, userName);

	}


	/**
	 * Set password field to target value
	 *
	 * @param password (String) user password from test data
	 */
	public void setPassword(String password ) {

		sendText(RobTMXLogin.Locator_TextField_Password, password);

	}


	/**
	 * Click submit
	 */
	public void submitLogin() {

		clickElement(RobNoTMXLogin.Locator_Button_Submit);

	}


	/**
	 * Perform all login operations in one go
	 */
	public void completeLogin(String userName, String password) {

		launchPage();
		setUserName(userName);
		setPassword(password);
		submitLogin();

	}


	/**
	 * Confirm log on destination: Accounts, Overview
	 */
	public void confirmDefaultPage() {

		confirmActiveNavigationButton(Common.Locator_Header_Button_AccountsTab_Active);
		confirmActiveNavigationButton(Accounts.Locator_LeftNav_Button_OverviewTab_Active);

	}


	/**
	 * Confirm existence of top navigation buttons (tabs)
	 */
	public void confirmTopNavigation() {

		confirmElementExistence(Common.Locator_Header_Button_AccountsTab);
		confirmElementExistence(Common.Locator_Header_Button_TransferTab);
		confirmElementExistence(Common.Locator_Header_Button_BillPayTab);
		confirmElementExistence(Common.Locator_Header_Button_MortgageTab);
		confirmElementExistence(Common.Locator_Header_Button_CreditCardsTab);
		confirmElementExistence(Common.Locator_Header_Button_InvestmentsTab);
		confirmElementExistence(Common.Locator_Header_Button_CustomerServiceTab);
		ss.takeScreenShot();

	}


	/**
	 * Log out of application
	 */
	public void logout() {

		clickElement(Common.Locator_Header_Button_Logout);
		waitForPageLoaded();
		confirmElementNonExistence(Common.Locator_Header_Button_Logout, 10);
		ss.takeScreenShot();

	}


	/**
	 * Confirm existence of logout button
	 */
	public void confirmLogoutButton() {

		confirmElementExistence(Common.Locator_Header_Button_Logout);
		ss.takeScreenShot();

	}


	/**
	 * Confirm existence of help center link
	 */

	public void confirmHelpCenterLink() {
		confirmElementExistence(Common.Locator_Header_Link_HelpCenter);
		ss.takeScreenShot();

	}


	/**
	 * Given a comparison string, confirm match at 'Welcome <userName>' element
	 *
	 * @param name (String) comparison value
	 */
	public void confirmUserName(String name) {

		confirmTextValue(Common.Locator_Header_TextContainer_WelcomeName, name);
		ss.takeScreenShot();

	}


	/**
	 * Confirm santander logo element is present in header
	 */
	public void confirmLogoPresence() {

		checkForBrokenImage(Common.Locator_Header_Image_Logo);
		ss.takeScreenShot();

	}


	/**
	 * Confirm santander logo element is present in header
	 */
	public void confirmLogoPresence(int wait) {

		checkForBrokenImage(Common.Locator_Header_Image_Logo, wait);
		ss.takeScreenShot();

	}


	/**
	 * Pull text content from known node, ensure Last login date-time conforms to expected formatting
	 */
	public void confirmLastLoginDatePattern() {

		we = confirmElementExistence(Common.Locator_Header_TextContainer_WelcomeName);
		String fullText = we.getText();

		String displayedDate = fullText.substring(fullText.indexOf(":")+1).trim().replace("at ", "");

		match = pattern.matcher(displayedDate);
		errorMessage = String.format("Could not find a match.");
		ss.assertTrue(match.find(), errorMessage);

	}


	/**
	 * Pull text content from known node, pull prior login date from LDAP, ensure Last login date-time matches LDAP +/-60s
	 */
	public void confirmLastLoginDateTime(String userId) {

		LDAPQueryHelper ldqh = new LDAPQueryHelper();

		we = confirmElementExistence(Common.Locator_Header_TextContainer_WelcomeName);
		String fullText = we.getText();

		String displayedDate = fullText.substring(fullText.indexOf(":")+1).trim().replace("at ", "").toUpperCase();
		displayedDate = displayedDate.substring(0, displayedDate.indexOf("M")+1);

		String ldapDate = ldqh.getAttribute_ByAttribute_AndValue(LDAPQuery.LDAP_KEY_PRIORLOGON, LDAPQuery.LDAP_KEY_USERNAME, userId); // ex. 20180625102406

		System.out.format("Comparing %s's last login [LDAP]%s:[ROB]%s%n", userId, ldapDate, displayedDate);

		LocalDateTime foundDate = LocalDateTime.parse(displayedDate, displayedDateFormat);
		LocalDateTime expectedDate = LocalDateTime.parse(ldapDate, expectedDateFormat);

		Duration dur = Duration.between(foundDate, expectedDate);

		ss.assertTrue(60 > dur.abs().getSeconds(), "Last Login not within tolerance.");
		ss.takeScreenShot();

	}


	/**
	 * Switch to main santander window.
	 *
	 * @param by
	 */
	public void switchToWindow() {

		switchToWindowByTitle(Common.Text_MainWindowTitle);

	}


	/**
	 * Confirm target element exists. Must pass an 'active' locator.
	 *
	 * @param by
	 */
	public void confirmActiveNavigationButton(By by) {

		// would be nice to have a common 'active' state against which to test generic elements, unfortunately, there is not
		waitForPageCompletelyLoaded(30);
		confirmElementExistence(by, "Active element was not found.");
		ss.takeScreenShot();

	}


	/**
	 * Confirm target image is not broken (missing).
	 *
	 * @param by
	 */
	public void confirmImageNotBroken(By by) {

		checkForBrokenImage(by);
		ss.takeScreenShot();

	}


	/**
	 * Confirm presence of Apply Online widget and of its component parts
	 */

	public void confirmApplyOnlineWidgetAndComponents() {

		confirmElementExistence(Common.Locator_ApplyOnline_Container);
		confirmImageNotBroken(Common.Locator_ApplyOnline_Image);
		confirmElementExistence(Common.Locator_ApplyOnline_Link_CheckingAccounts);
		confirmElementExistence(Common.Locator_ApplyOnline_Link_SavingsAccounts);
		confirmElementExistence(Common.Locator_ApplyOnline_Link_Mortgages);
		confirmElementExistence(Common.Locator_ApplyOnline_Link_CreditCards);
		/*
		 * Only available if some application process is incomplete. Since this is impossible to predict, disable.
		 * confirmElementExistence(Common.Locator_ApplyOnline_Link_ResumeApplication());
		 */
		ss.takeScreenShot();

	}


	/**
	 * Navigate to target tab
	 *
	 * @param by
	 */
	public void navigateToMainTab(By by) {

		clickElement(by);

	}


	/**
	 * Navigate to target tab and confirm
	 *
	 * @param by (By)
	 * @param validationBy (By)
	 */
	public void navigateToMainTab(By by, By validationBy) {

		clickElement(by);
		ss.assertTrue((we = confirmElementExistence(validationBy, 60)) instanceof WebElement, "Could not confirm navigation endpoint.");

	}


	/**
	 * Navigate to target tab and confirm
	 *
	 * @param by (By)
	 * @param validationBy (By)
	 */
	public void navigateToMainTab(WebElement w, By validationBy) {

		clickElement(w);
		ss.assertTrue((we = confirmElementExistence(validationBy, 60)) instanceof WebElement, "Could not confirm navigation endpoint.");

	}


	/**
	 * Navigate to target tab and confirm
	 *
	 * @param by (String) properties file locator key
	 * @param validationBy (String) properties file locator for post-navigation confirmation
	 * @param maxWait (int) maximum wait time in seconds
	 */
	public void navigateToMainTab(By by, By validationBy, int maxWait) {

		clickElement(by);
		ss.assertTrue((we = confirmElementExistence(validationBy, maxWait)) instanceof WebElement, "Could not confirm navigation endpoint.");

	}


	/**
	 * Shortcut method to wrap typical ROB logon validations
	 * @param welcomeName (String)
	 */
	public void confirmLogin(String welcomeName, String userId) {

		confirmLogoPresence(60);
		confirmUserName(welcomeName);
		confirmLastLoginDateTime(userId);

	}


	/**
	 * Return a formatted date string corresponding to the nearest random future week day
	 *
	 * @return (String) date formatted MM/dd/YYYY ex. 10/03/2018
	 */
	public String futureWeekdayDateFormattedMMDDYYYY() {

		LocalDate date = LocalDate.now();
		DayOfWeek day = date.getDayOfWeek();

		// fast-forward weekend date to nearest future MONDAY
		while ((DayOfWeek.SATURDAY == day) || (DayOfWeek.SUNDAY == day)) {
			date = date.plusDays(1);
			day = date.getDayOfWeek();
		}

		// randomize weekday
		date = date.plusDays(randomizer.nextInt(5)); // 0 - 4
		return paymentFieldsDateFormat.format(date);

	}


	/**
	 * Return a formatted date string corresponding to the nearest random future weekend day
	 *
	 * @return (String) date formatted MM/dd/YYYY ex. 10/03/2018
	 */
	public String futureWeekendDateFormattedMMDDYYYY() {

		LocalDate date = LocalDate.now();
		DayOfWeek day = date.getDayOfWeek();

		// fast-forward week date to nearest future SATURDAY
		while ((DayOfWeek.SATURDAY != day) && (DayOfWeek.SUNDAY != day)) {
			date = date.plusDays(1);
			day = date.getDayOfWeek();
		}

		// randomize weekend
		date = date.plusDays(randomizer.nextInt(2)); // 0 - 1
		return paymentFieldsDateFormat.format(date);

	}


	/**
	 * Return a formatted date string corresponding to today
	 *
	 * @return (String) date formatted MM/dd/YYYY ex. 10/03/2018
	 */
	public String todayDateFormattedMMDDYYYY() {

		LocalDate date = LocalDate.now();
		return paymentFieldsDateFormat.format(date);

	}


	/**
	 * Return a formatted date string corresponding to tomorrow
	 *
	 * @return (String) date formatted MM/dd/YYYY ex. 10/03/2018
	 */
	public String tomorrowDateFormattedMMDDYYYY() {

		LocalDate date = LocalDate.now().plusDays(1);
		return paymentFieldsDateFormat.format(date);

	}


	/**
	 * Return a formatted date string corresponding to the nearest future business day
	 *
	 * @return (String) date formatted MM/dd/YYYY ex. 10/03/2018
	 */
	public String nextBusinessDateFormattedMMDDYYYY() {

		LocalDate date = LocalDate.now().plusDays(1);
		//TODO: compare date against known non-business dates list, increment such that date != non-business dates
		return paymentFieldsDateFormat.format(date);

	}


	/**
	 * Format the date into a String in MM/DD/YYYY format for screen comparison
	 */
	public String formatDate(LocalDate date) {

		String format;
		String curDate = "";

		if (date.getMonthValue() < 10 && !month.contains("[0*]")) {
			this.month = "0"+this.month;
		}

		if (date.getDayOfMonth() < 10 && !paymentDay.contains("[0*]")) {
			curDate = "0" + date.getDayOfMonth();
		} else {
			curDate = "" + date.getDayOfMonth();
		}

		format = "" + this.month + "/" + curDate + "/" + this.year;

		return format;

	}


	/**
	 * Set future date for payment
	 */
	public String setPaymentDateFuture(LocalDate paymentDate) {

		paymentDate = LocalDate.now().plusDays(7);
		paymentDay = "" + paymentDate.getDayOfMonth();
		month = "" + paymentDate.getMonthValue();
		year = "" + paymentDate.getYear();
		return formatDate(paymentDate);

	}


	/**
	 * Set dater for tommorrow for payment
	 */
	public String setPaymentTommorrow(LocalDate paymentDate) {

		paymentDate = LocalDate.now().plusDays(1);
		paymentDay = "" + paymentDate.getDayOfMonth();
		month = "" + paymentDate.getMonthValue();
		year = "" + paymentDate.getYear();
		return formatDate(paymentDate);

	}


	/**
	 * Set dater for next month for payment
	 */
	public String setPaymentNextMonth(LocalDate paymentDate) {

		paymentDate = LocalDate.now().plusMonths(1);
		paymentDay = "" + paymentDate.getDayOfMonth();
		month = "" + paymentDate.getMonthValue();
		year = "" + paymentDate.getYear();
		return formatDate(paymentDate);

	}


	/**
	 *  Confirm and update the date of payment for Weekend payments.
	 *  If test is run on a week day, will move payment date forward to the next Saturday
	 */
	public String confirmDateWeekend(LocalDate paymentDate) {

		switch (paymentDate.getDayOfWeek()) {
			case SATURDAY:
				break;
			case SUNDAY:
				break;
			default:
				// not sat or sun, so add days until saturday
				do {
					paymentDate = paymentDate.plusDays(1);
				} while (paymentDate.getDayOfWeek() != DayOfWeek.SATURDAY);

				// randomize weekend day sat or sun
				paymentDate = paymentDate.plusDays(randomizer.nextInt(2));
				break;
		}

		paymentDay = "" + paymentDate.getDayOfMonth();
		month = "" + paymentDate.getMonthValue();
		year = "" + paymentDate.getYear();
		return formatDate(paymentDate);

	}


	/**
	 *  Confirm and update the date of payment for Weekend payments.
	 *  If test is run on a week day, will move payment date forward to the next Saturday
	 */
	public String confirmDateWeekday(LocalDate paymentDate) {

		switch (paymentDate.getDayOfWeek()) {
			case MONDAY:
				break;
			case TUESDAY:
				break;
			case WEDNESDAY:
				break;
			case THURSDAY:
				break;
			default:
				// not a weekday Mon - Thur
				do {
					paymentDate = paymentDate.plusDays(1);
				} while (paymentDate.getDayOfWeek() != DayOfWeek.MONDAY);

				// randomize weekend day Mon - Thur
				paymentDate = paymentDate.plusDays(randomizer.nextInt(4));
				break;
		}

		paymentDay = "" + paymentDate.getDayOfMonth();
		month = "" + paymentDate.getMonthValue();
		year = "" + paymentDate.getYear();
		return formatDate(paymentDate);

	}

	/* COMMON - END */


	/* BILL PAY - START */

	/**
	 * Confirm existence of top navigation buttons (tabs)
	 */

	public void confirmBillPayLeftNavigation() {

		//System.out.format("[LOG]: <[%s:%s] confirm left navigation buttons.>%n", id, testName);
		confirmTextValue(BillPay.Locator_LeftNav_TextContainer_Title, BillPay.Text_LeftNav_Title);

		confirmElementExistence(BillPay.Locator_LeftNav_Button_PaymentCenter);
		confirmElementExistence(BillPay.Locator_LeftNav_Button_Activity);
		confirmElementExistence(BillPay.Locator_LeftNav_Button_Messages);
		confirmElementExistence(BillPay.Locator_LeftNav_Button_Help);
		ss.takeScreenShot();

	}


	/**
	 * Confirm form title
	 */
	public void confirmBillPayFormTitle() {

		confirmTextValue(BillPay.Locator_PaymentCenter_TextContainer_Title, BillPay.Text_PaymentCenter_Title);

	}


	/**
	 * Confirm Overview content header
	 */
	public void confirmContentHeader_BillPay() {

		confirmTextValue(BillPay.Locator_PaymentCenter_TextContainer_Header, BillPay.Text_PaymentCenter_Header);

	}


	/**
	 * Confirm Payment Center right accordions
	 */
	public void confirmRightAccordions() {

		confirmElementExistence(BillPay.Locator_PaymentCenter_Link_RightAccordion_Reminders_Expanded);
		confirmElementExistence(BillPay.Locator_PaymentCenter_Link_RightAccordion_PendingPayments_Expanded);
		confirmElementExistence(BillPay.Locator_PaymentCenter_Link_RightAccordion_RecentPayments_Expanded);
		/* TODO: If no recent payments, is not displayed
		confirmElementExistence(BillPay.Locator_PaymentCenter_DropDown_RightAccordion_RecentPayments_Filter);
		confirmElementExistence(BillPay.Locator_PaymentCenter_Link_RightAccordion_RecentPayments_ViewActivity);
		 */

	}


	/**
	 * Confirm minimum Payment Center body content
	 */
	public void confirmBillPayContentBody() {

		confirmBillPayFormTitle();
		confirmContentHeader_BillPay();
		confirmElementExistence(BillPay.Locator_PaymentCenter_Button_AddCompanyPerson);
		confirmElementExistence(BillPay.Locator_PaymentCenter_Button_MakePayments);

	}


	/**
	 * Confirm Test region screen and proceed
	 */
	public void confirmAndEnterTestRegion() {

		confirmElementExistence(BillPay.Locator_TestRegion_Button_Proceed);

		confirmTextValue(BillPay.Locator_TestRegion_TextContainer_Title, BillPay.Text_TestRegion_Title);
		confirmTextValue(BillPay.Locator_TestRegion_TextContainer_Date, dtf.format(LocalDateTime.now()));

		clickElement(BillPay.Locator_TestRegion_Button_Proceed);

	}


	/**
	 * Confirm Test region screen and proceed
	 */
	public void submitPaymentToFirstPayee(String paymentAmount) {

		List<Float> amountsList = new ArrayList<Float>();

		weArray = confirmElementsExistenceOrNone(BillPay.MultiLocator_TextContainer_PendingPaymentAmounts);

		for (WebElement w: weArray) {
			amountsList.add(Float.parseFloat(w.getText().replace("$", "")));
		}

		Float payment = Float.parseFloat(paymentAmount);
		do  {
			payment = payment + randomizer.nextFloat();
		} while (hasAmount(payment, amountsList));
		paymentAmount = String.format("%.2f", payment);

		// confirm first payee exists
		we = confirmElementExistence(BillPay.Locator_PaymentCenter_Container_Payee_First);

		// click first account dropdown
		clickElement(confirmElementExistence(we, BillPay.Locator_PaymentCenter_CustomDropDown_Payee_FromAccount));
		//clickElement(BillPay.Locator_PaymentCenter_CustomDropDown_Payment_PayFrom_First);

		// confirm dropdown has expanded
		confirmElementExistence(BillPay.Locator_PaymentCenter_CustomDropDown_Payment_PayFrom_First_Expanded);

		// click first account (usually already selected. click is benign.)
		clickElement(BillPay.Locator_PaymentCenter_CustomDropDown_Payment_PayFrom_First_Account);

		// click first account dropdown (to close)
		clickElement(BillPay.Locator_PaymentCenter_CustomDropDown_Payee_FromAccount);

		// enter amount into amount field
		sendText(BillPay.Locator_PaymentCenter_TextField_Payment_Amount_First, paymentAmount);

		// click calendar widget
		clickElement(BillPay.Locator_PaymentCenter_Button_Payment_DeliverBy_First);

		// confirm widget is visible
		confirmElementExistence(BillPay.Locator_PaymentCenter_Container_Payment_DatePicker);

		// click earliest available date
		clickElement(BillPay.Locator_PaymentCenter_Button_Payment_DatePicker_EarliestAvailable);
		ss.takeScreenShot();

		// click make payments button
		clickElement(BillPay.Locator_PaymentCenter_Button_MakePayments);
		ss.takeScreenShot();

		// click submit button
		clickElement(BillPay.Locator_PaymentCenter_Button_ReviewPayemnts_Submit);
		ss.takeScreenShot();

		// click return to payment center button
		clickElement(BillPay.Locator_PaymentCenter_Button_PaymentConfirmation_ReturnToPaymentCenter);
		waitForPageCompletelyLoaded();

		// confirm payment is in pending list
		confirmElementExistence(By.xpath(BillPay.CompoundLocator_PaymentCenter_TextContainer_RightAccordion_PendingPayments_PaymentAmount.replace(compoundPlaceholder, paymentAmount)));
		ss.takeScreenShot();


	}


	/**
	 * Helper method. Checks if a given float is found in a list of floats
	 *
	 * @param payment (Float) value to compare against
	 * @param amountsList (List<Float>) list of floats
	 *
	 * @return (boolean) does list contain target float
	 */
	private boolean hasAmount(Float payment, List<Float> amountsList) {

		boolean containsAmount = false;

		for (Float am: amountsList) {
			if ((Math.round(am * 100.0) / 100.0) == (Math.round(payment * 100.0) / 100.0)) {
				containsAmount = true;
			} else {
				containsAmount = false;
			}
		}
		return containsAmount;

	}

	/* BILL PAY - END */


	/* CREDIT CARD - START */

	/**
	 * Confirm existence of top navigation buttons (tabs)
	 */
	public void confirmCreditCardLeftNavigation() {

		confirmTextValue(CreditCard.Locator_LeftNav_TextContainer_Title, CreditCard.Text_LeftNav_Title);
		confirmElementExistence(CreditCard.Locator_LeftNav_Button_Overview);
		confirmElementExistence(CreditCard.Locator_LeftNav_Button_CreditCardPayment);
		confirmElementExistence(CreditCard.Locator_LeftNav_Button_CreditCardServices);
		confirmElementExistence(CreditCard.Locator_LeftNav_Button_StatementsAndDocuments);
		confirmElementExistence(CreditCard.Locator_LeftNav_Button_Rewards);
		confirmElementExistence(CreditCard.Locator_LeftNav_Button_Alerts);
		ss.takeScreenShot();

	}


	/**
	 * Confirm existence of help with this page link
	 */
	public void confirmHelpWithThisPageLink_CreditCard() {

		//System.out.format("[LOG]: <[%s:%s] confirm Help with this page link.>%n", id, testName);
		confirmElementExistence(CreditCard.Locator_Overview_Link_HelpWithThisPage);
		ss.takeScreenShot();

	}


	/**
	 * Confirm existence of print link
	 */
	public void confirmPrintLink_CreditCard() {

		//System.out.format("[LOG]: <[%s:%s] confirm print link.>%n", id, testName);
		confirmElementExistence(CreditCard.Locator_Overview_Link_Print);
		ss.takeScreenShot();

	}


	/**
	 * Confirm form title
	 */
	public void confirmCreditCardFormTitle() {

		confirmTextValue(CreditCard.Locator_Overview_TextContainer_Title, CreditCard.Text_Overview_Title);

	}


	/**
	 * Confirm Overview content footer
	 */
	public void confirmCreditCardContentBody() {

		// confirm at least one card exists
		weArray  = confirmElementsExistence(CreditCard.MultiLocator_Overview_Container_Cards, 60);
		int cardsCount = weArray.size();
		ss.assertTrue(cardsCount > 0, "No credit cards displayed.");

		// confirm first card image is displayed
		checkForBrokenImage(CreditCard.Locator_Overview_Image_Card_First);

		// confirm card link
		confirmElementExistence(CreditCard.Locator_Overview_Link_Card_First);

		// confirm hold link
		confirmElementExistence(CreditCard.Locator_Overview_Link_Card_Hold_First);

		// confirm account number looks like *####
		String accountNumber = confirmElementExistence(CreditCard.Locator_Overview_TextContainer_Card_Number_First).getText();
		//System.out.format("[DEBUG]: <[%s:%s] comparing: %s>%n", id, testName, accountNumber);
		match = last4pattern.matcher(accountNumber);
		ss.assertTrue(match.find(), "Account number did not match pattern.");

		// confirm Make Payment link
		confirmElementExistence(CreditCard.Locator_Overview_Link_Card_MakePayemnt_First);

		// confirm Set up / Modify link
		confirmElementExistence(CreditCard.Locator_Overview_Link_Card_SetupModify_First);

		// extract autopay state
		we = confirmElementExistence(CreditCard.Locator_Overview_TextContainer_Card_AutopayState_First);
		autopayState = we.getText().trim();

		// confirm Redeem link
		confirmElementExistence(CreditCard.Locator_Overview_Link_Card_Redeem_First);
		ss.takeScreenShot();

	}


	/**
	 * Confirm Overview and form content
	 */
	public void confirmOverview() {

		confirmCreditCardLeftNavigation();
		confirmPrintLink_CreditCard();
		confirmHelpWithThisPageLink_CreditCard();
		confirmCreditCardFormTitle();
		confirmCreditCardContentBody();

	}


	/**
	 * Validate Credit Card Overview Landing page
	 */
	public void validateCreditCardLandingPage() {

		// Validate that Overview Title is present
		confirmElementExistence(CreditCard.Locator_Overview_TextContainer_Title);

		// Validate that the credit card image is not broken
		checkForBrokenImage(CreditCard.Locator_CreditCard_Image_CreditCardImage);

		// Validate that Make a payment link is present
		confirmElementExistence(CreditCard.Locator_CreditCard_Link_MakePayment_First);

		// Validate that Set up Autopay link is present
		confirmElementExistence(CreditCard.Locator_CreditCard_Link_SetUpAutoPay_First);

		// Validate that Redeem Points Link is present
		confirmElementExistence(CreditCard.Locator_CreditCard_Link_RedeemPoints_Overview);

		// Validate that Instant Card Hold is Present
		confirmElementExistence(CreditCard.Locator_CreditCard_Link_InstantCardHold);

		// Take a Screen shot for later inspection
		ss.takeScreenShot();

	}


	/**
	 * Click in the Overview Link to make a Payment
	 */
	public void clickMakePaymentFirst() {

		clickElement(CreditCard.Locator_CreditCard_Link_MakePayment_First);
		confirmElementExistence(CreditCardPayment.Locator_SubTab_OneTimePayment_Active);

	}


	/**
	 * Click in the Overview Link to Set up Autopay
	 */
	public void clickSetUpAutoPayFirst() {

		clickElement(CreditCard.Locator_CreditCard_Link_SetUpAutoPay_First);

	}


	/**
	 * expose autopayState
	 *
	 * @return (String)
	 */
	public String getAutopayState() {

		return autopayState;

	}

	/* CREDIT CARD - END */


	/* CREDIT CARD PAYMENT - START */

	/**
	 * Confirm Payments page
	 */
	public void confirmPaymentPage(boolean ccFaqCheckFlag) {

		// faq
		if (ccFaqCheckFlag) {
			confirmElementExistence(CreditCardPayment.Locator_Container_FAQ);
			confirmTextValue(CreditCardPayment.Locator_TextContainer_FAQ_Title, CreditCardPayment.Text_FAQ_Title);
			confirmTextValue(CreditCardPayment.Locator_TextContainer_FAQ_FormTitle, CreditCardPayment.Text_FAQ_FormTitle);
			ss.assertTrue(confirmElementsExistence(CreditCardPayment.MultiLocator_Link_FAQ_Questions).size() > 0, "Missing FAQ links.");
		}

		// form title
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FormTitle, CreditCardPayment.Text_FormTitle);

		// tabs (active)
		confirmElementExistence(CreditCardPayment.Locator_Link_OneTimePayment_Active);
		confirmElementExistence(CreditCardPayment.Locator_Link_OneTimePending);
		confirmElementExistence(CreditCardPayment.Locator_Link_Autopay);

		// bread crumb
		confirmTextValue(CreditCardPayment.Locator_TextContainer_BreadCrumb, CreditCardPayment.Text_BreadCrumb_EnterDetails);

		// to dropdown
		confirmElementExistence(CreditCardPayment.Locator_DropDown_CreditCard);

		// go button
		confirmElementExistence(CreditCardPayment.Locator_Button_Go);

		// segment titles
		confirmMultiElementTextByElement(CreditCardPayment.MultiLocator_TextContainer_SegmentTitles, CreditCardPayment.MultiText_SegmentTitles);

		// email
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_Email);

		// extract email address
		email = we.getText();
		email = email.substring(email.indexOf(":")+1);

		// update contact details link
		confirmElementExistence(CreditCardPayment.Locator_Link_UpdateContactDetails);

		// account From
		confirmElementExistence(CreditCardPayment.Locator_DropDown_AccountFrom);

		// add account link
		confirmElementExistence(CreditCardPayment.Locator_Link_AddAcount);

		// payment options list
		confirmMultiElementTextByElement(CreditCardPayment.MultiLocator_TextContainer_PaymentOptions, CreditCardPayment.MultiText_PaymentOptions);

		// payment options radio buttons?
		confirmElementExistence(CreditCardPayment.Locator_RadioButton_MinimumPayment);
		confirmElementExistence(CreditCardPayment.Locator_RadioButton_StatementBalance);
		confirmElementExistence(CreditCardPayment.Locator_RadioButton_CurrentBalance);
		confirmElementExistence(CreditCardPayment.Locator_RadioButton_OtherAmount);

		// other field
		confirmElementExistence(CreditCardPayment.Locator_TextField_OtherAmount);

		// due date [pattern match]
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_DueDate);
		String dueDate = we.getText();
		match = datePattern.matcher(dueDate);
		ss.assertTrue(match.find(), String.format("Invalid date format."));

		// payment month
		int month = jseExecuteInteger(CreditCardPayment.Script_String_GetFieldValue, CreditCardPayment.Locator_TextContainer_PaymentDate_Month);
		ss.assertTrue(month == today.getMonthValue(), "Default month does not match current month.");

		// payment day
		int day = jseExecuteInteger(CreditCardPayment.Script_String_GetFieldValue, CreditCardPayment.Locator_TextContainer_PaymentDate_Day);
		ss.assertTrue(day == today.getDayOfMonth(), "Default month does not match current month.");

		// payment year
		int year = jseExecuteInteger(CreditCardPayment.Script_String_GetFieldValue, CreditCardPayment.Locator_TextContainer_PaymentDate_Day);
		ss.assertTrue(year == today.getDayOfMonth(), "Default month does not match current month.");

		// payment calendar widget
		confirmElementExistence(CreditCardPayment.Locator_Button_Calendar);

		// autopay link
		confirmElementExistence(CreditCardPayment.Locator_Link_SetUpAutopay);

		// pending column headers [date, from, to, amount, status]
		confirmMultiElementText(CreditCardPayment.MultiLocator_TextContainer_PendingTableHeaders, CreditCardPayment.MultiText_PendingTableHeaders);

		// records count [extract for before+after]
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_Records);
		String displayed = we.getText();
		String ofTotal = displayed;
		displayed = displayed.substring(0, displayed.indexOf("-"));
		ofTotal = ofTotal.substring(ofTotal.indexOf("-")+1, ofTotal.indexOf(" "));
		recordsDisplayed = Integer.parseInt(displayed);
		recordsOfTotal = Integer.parseInt(ofTotal);
			// assert that pending list remains within a single pagination page
		ss.assertTrue(recordsOfTotal <= 9, "Pagination complexity limit exceeded.");

		// continue button
		confirmElementExistence(CreditCardPayment.Locator_Button_Continue);

	}


	/**
	 * Verify on confirm details page
	 */
	public void confirmPaymentDetails() {

		// print link
		confirmElementExistence(CreditCardPayment.Locator_Link_Print);

		// form title
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FormTitle, CreditCardPayment.Text_Details_FormTitle);

		// bread crumb
		confirmTextValue(CreditCardPayment.Locator_TextContainer_BreadCrumb, CreditCardPayment.Text_BreadCrumb_ConfirmDetails);

		// segment title
		confirmMultiElementTextByElement(CreditCardPayment.MultiLocator_TextContainer_Details_SegmentTitles, CreditCardPayment.MultiText_Details_SegmentTitles);

		// last4 from
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_FromAccount, acLast4);

		// last4 to
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_ToAccount, ccLast4);

		// amount
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Amount, paymentAmount);

		// due date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_DueDate, dueDate);

		// payment date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_PaymentDate, tomorrow.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));

		// email matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Email, email);

		// do not radio
		we = confirmElementExistence(CreditCardPayment.Locator_RadioButton_Details_NotAcceptTCs);
		ss.assertTrue(jseExecuteBoolean(CreditCardPayment.Script_Boolean_RadioButtonChecked, we), "Radio button not selected unexpectedly.");

		// do radio
		we = confirmElementExistence(CreditCardPayment.Locator_RadioButton_Details_AcceptTCs);
		ss.assertFalse(jseExecuteBoolean(CreditCardPayment.Script_Boolean_RadioButtonChecked, we), "Radio button selected unexpectedly.");

		// back link
		confirmElementExistence(CreditCardPayment.Locator_Link_Back);

		// cancel button
		confirmElementExistence(CreditCardPayment.Locator_Button_Details_Cancel);

		// confirm button
		confirmElementExistence(CreditCardPayment.Locator_Button_Details_Confirm);

		// set Accept T&Cs
		clickElement(CreditCardPayment.Locator_RadioButton_Details_AcceptTCs);
		ss.assertTrue(jseExecuteBoolean(CreditCardPayment.Script_Boolean_RadioButtonChecked, CreditCardPayment.Locator_RadioButton_Details_AcceptTCs), "Radio button not selected.");

		// click confirm details
		navigateToMainTab(CreditCardPayment.Locator_Button_Details_Confirm, CreditCardPayment.Locator_TextContainer_Summary_SuccessMessage);

	}


	/**
	 * Confirm Summary page
	 */
	public void confirmPaymentSummary() {

		// print link
		confirmElementExistence(CreditCardPayment.Locator_Link_Print);

		// form title
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FormTitle, CreditCardPayment.Text_Summary_FormTitle);

		// bread crumb
		confirmTextValue(CreditCardPayment.Locator_TextContainer_BreadCrumb, CreditCardPayment.Text_BreadCrumb_Summary);

		// success message
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Summary_SuccessMessage, CreditCardPayment.Text_Summary_SuccessMessage);

		// segment title
		confirmMultiElementTextByElement(CreditCardPayment.MultiLocator_TextContainer_Summary_SegmentTitles, CreditCardPayment.MultiText_Summary_SegmentTitles);

		// last4 from
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_FromAccount, acLast4);

		// last4 to
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_ToAccount, ccLast4);

		// amount
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Amount, paymentAmount);

		// due date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_DueDate, dueDate);

		// payment date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_PaymentDate, tomorrow.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));

		// email matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Email, email);

		// autopay link
		confirmElementExistence(CreditCardPayment.Locator_Link_Summary_SetUpAutopay);

		// see pending link
		confirmElementExistence(CreditCardPayment.Locator_link_SeePendingPayments);

		// back link
		confirmElementExistence(CreditCardPayment.Locator_Link_Back);

	}


	/**
	 * Confirm One-time Payment pending status
	 */
	public void confirmPaymentPending() {

		// navigate to credit card payment
		navigateToMainTab(CreditCard.Locator_LeftNav_Button_CreditCardPayment, CreditCardPayment.Locator_DropDown_CreditCard);
		confirmTextValue(CreditCardPayment.Locator_TextContainer_BreadCrumb, CreditCardPayment.Text_BreadCrumb_EnterDetails);

		// already scheduled
		// TODO: need persistence engine in order to track this.
		//confirmTextValue(CreditCardPayment.Locator_Link_AlreadyScheduled, this.runtimeData.paymentAmount);
		//confirmTextValue(CreditCardPayment.Locator_Link_AlreadyScheduled, date);

		// records count [extract for before+after]
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_Records);
		String displayed = we.getText();
		String ofTotal = displayed;
		displayed = displayed.substring(0, displayed.indexOf("-"));
		ofTotal = ofTotal.substring(ofTotal.indexOf("-") + 1, ofTotal.indexOf(" "));
		newRecordsDisplayed = Integer.parseInt(displayed);
		newRecordsOfTotal = Integer.parseInt(ofTotal);
		if (recordsOfTotal == 0) {
			ss.assertTrue(newRecordsDisplayed == recordsDisplayed + 1, "Pending payment unaccounted for.");
			ss.assertTrue(newRecordsOfTotal == recordsOfTotal + 1, "Pending payment unaccounted for.");
		} else {
			ss.assertTrue(newRecordsDisplayed == 1, "Pending payment unaccounted for.");
			ss.assertTrue(newRecordsOfTotal == recordsOfTotal + 1, "Pending payment unaccounted for.");
		}

		// get all (single-page) pending payment rows
		weArray = confirmElementsExistence(CreditCardPayment.MultiLocator_Container_PendingPayments);
			// pull payment date from latest row, assert contains target date [Note: newRecordsOfTotal is a count, but java indexes from zero. thus, count - 1 == targetIndex]
		we = confirmElementExistence(weArray.get(newRecordsOfTotal - 1), CreditCardPayment.Locator_TextContainer_PendingPayment_PaymentDate);
		ss.assertTrue(we.getText().contains(tomorrow.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"))), "Payment Date does not match.");
			// pull from account from latest row, assert contains target account [Note: newRecordsOfTotal is a count, but java indexes from zero. thus, count - 1 == targetIndex]
		we = confirmElementExistence(weArray.get(newRecordsOfTotal - 1), CreditCardPayment.Locator_TextContainer_PendingPayment_FromAccount);
		ss.assertTrue(we.getText().contains(acLast4), "From account does not match.");
			// pull to account from latest row, assert contains target account [Note: newRecordsOfTotal is a count, but java indexes from zero. thus, count - 1 == targetIndex]
		we = confirmElementExistence(weArray.get(newRecordsOfTotal - 1), CreditCardPayment.Locator_TextContainer_PendingPayment_ToAccount);
		ss.assertTrue(we.getText().contains(ccLast4), "To Account does not match.");
			// pull amount from latest row, assert contains target amount [Note: newRecordsOfTotal is a count, but java indexes from zero. thus, count - 1 == targetIndex]
		we = confirmElementExistence(weArray.get(newRecordsOfTotal - 1), CreditCardPayment.Locator_TextContainer_PendingPayment_Amount);
		ss.assertTrue(we.getText().contains(paymentAmount), "Amount does not match.");

	}


	/**
	 * Confirm payment details match most recent/last entry in Pending list
	 */
	public void confirmPaymentPendingList() {

		// go to One-time Pending Payment List
		navigateToMainTab(CreditCardPayment.Locator_Link_OneTimePending, CreditCardPayment.Locator_Link_OneTimePending_Active);

		// print
		confirmElementExistence(CreditCardPayment.Locator_Link_Print);

		// help
		confirmElementExistence(CreditCardPayment.Locator_Link_PendingList_Help);

		// form title
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FormTitle, CreditCardPayment.Text_PendingList_FormTitle);

		// confirm tabs
		confirmElementExistence(CreditCardPayment.Locator_Link_OneTimePayment);
		confirmElementExistence(CreditCardPayment.Locator_Link_OneTimePending_Active);
		confirmElementExistence(CreditCardPayment.Locator_Link_Autopay);

		// segment title
		confirmMultiElementTextByElement(CreditCardPayment.MultiLocator_TextContainer_SegmentTitles, CreditCardPayment.MultiText_PendingList_SegmentTitles);

		// table headers
		confirmMultiElementTextByElement(CreditCardPayment.MultiLocator_TextContainer_PendingList_TableHeaders, CreditCardPayment.MultiText_PendingList_TableHeaders);

		// records count [extract for before+after]
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_Records);
		String displayed = we.getText();
		String ofTotal = displayed;
		displayed = displayed.substring(0, displayed.indexOf("-"));
		ofTotal = ofTotal.substring(ofTotal.indexOf("-")+1, ofTotal.indexOf(" "));
		newRecordsDisplayed = Integer.parseInt(displayed);
		newRecordsOfTotal = Integer.parseInt(ofTotal);
		if (recordsOfTotal == 0) {
			ss.assertTrue(newRecordsDisplayed == recordsDisplayed + 1, "Pending payment unaccounted for.");
			ss.assertTrue(newRecordsOfTotal == recordsOfTotal + 1, "Pending payment unaccounted for.");
		} else {
			ss.assertTrue(newRecordsDisplayed == 1, "Pending payment unaccounted for.");
			ss.assertTrue(newRecordsOfTotal == recordsOfTotal + 1, "Pending payment unaccounted for.");
		}

		// get all (single-page) pending payment rows
		weArray = confirmElementsExistence(CreditCardPayment.MultiLocator_Container_PendingList_PendingPayments);
			// pull payment date from latest row, assert contains target date [Note: newRecordsOfTotal is a count, but java indexes from zero. thus, count - 1 == targetIndex]
		we = confirmElementExistence(weArray.get(newRecordsOfTotal - 1), CreditCardPayment.Locator_TextContainer_PendingPayment_PaymentDate);
		ss.assertTrue(we.getText().contains(tomorrow.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"))), "Payment Date does not match.");
			// pull from account from latest row, assert contains target account [Note: newRecordsOfTotal is a count, but java indexes from zero. thus, count - 1 == targetIndex]
		we = confirmElementExistence(weArray.get(newRecordsOfTotal - 1), CreditCardPayment.Locator_TextContainer_PendingPayment_FromAccount);
		ss.assertTrue(we.getText().contains(acLast4), "From account does not match.");
			// pull to account from latest row, assert contains target account [Note: newRecordsOfTotal is a count, but java indexes from zero. thus, count - 1 == targetIndex]
		we = confirmElementExistence(weArray.get(newRecordsOfTotal - 1), CreditCardPayment.Locator_TextContainer_PendingPayment_ToAccount);
		ss.assertTrue(we.getText().contains(ccLast4), "To Account does not match.");
			// pull amount from latest row, assert contains target amount [Note: newRecordsOfTotal is a count, but java indexes from zero. thus, count - 1 == targetIndex]
		we = confirmElementExistence(weArray.get(newRecordsOfTotal - 1), CreditCardPayment.Locator_TextContainer_PendingPayment_Amount);
		ss.assertTrue(we.getText().contains(paymentAmount), "Amount does not match.");
			// check dropdown
		confirmElementExistence(weArray.get(newRecordsOfTotal - 1), CreditCardPayment.Locator_DropDown_PendingPayment_Actions);
			// check go button
		confirmElementExistence(weArray.get(newRecordsOfTotal - 1), CreditCardPayment.Locator_Button_PendingPayment_Go);

	}


	/**
	 * Delete pending payment
	 */
	public void deleteOneTimePayment() {

		// set target payment to delete
		we = confirmElementExistence(weArray.get(newRecordsOfTotal - 1), CreditCardPayment.Locator_DropDown_PendingPayment_Actions);
		setDropdownByPartialVisibleText(we, CreditCardPayment.Text_PendingList_Delete);

		// go button
		we = confirmElementExistence(weArray.get(newRecordsOfTotal - 1), CreditCardPayment.Locator_Button_PendingPayment_Go);
		navigateToMainTab(we, CreditCardPayment.Locator_Button_Details_Confirm);

	}


	/**
	 * Confirm Delete confirmation page
	 */
	public void confirmDeleteOneTimeDetails() {

		// print
		confirmElementExistence(CreditCardPayment.Locator_Link_Summary_Print);

		// form title
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FormTitle, CreditCardPayment.Text_Delete_Details_FormTitle);

		// breadcrumb
		confirmTextValue(CreditCardPayment.Locator_TextContainer_BreadCrumb, CreditCardPayment.Text_Delete_Details_BreadCrumb_Confirm);

		// segment title
		confirmMultiElementText(CreditCardPayment.MultiLocator_TextContainer_SegmentTitles, CreditCardPayment.MultiText_Delete_Details_SegmentTitles);

		// last4 from
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_FromAccount, acLast4);

		// last4 to
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_ToAccount, ccLast4);

		// amount
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Amount, paymentAmount);

		// due date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_DueDate, dueDate);

		// payment date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_PaymentDate, tomorrow.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));

		// email matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Email, email);

		// back
		confirmElementExistence(CreditCardPayment.Locator_Link_Delete_Details_Back);

		// cancel button
		confirmElementExistence(CreditCardPayment.Locator_Button_Details_Cancel);

		// confirm button
		confirmElementExistence(CreditCardPayment.Locator_Button_Details_Confirm);

	}


	/**
	 * Click confirm button on delete details page
	 */
	public void delete() {

		navigateToMainTab(CreditCardPayment.Locator_Button_Details_Confirm, CreditCardPayment.Locator_TextContainer_Summary_SuccessMessage);

	}


	/**
	 * Confirm Delete summary page
	 */
	public void confirmDeleteOneTimeSummary() {

		// print link
		confirmElementExistence(CreditCardPayment.Locator_Link_Summary_Print);

		// form title
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FormTitle, CreditCardPayment.Text_Delete_Summary_FormTitle);

		// bread crumb
		confirmTextValue(CreditCardPayment.Locator_TextContainer_BreadCrumb, CreditCardPayment.Text_Delete_Summary_BreadCrumb);

		// success message
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Summary_SuccessMessage, CreditCardPayment.Text_Delete_Summary_SuccessMessage);

		// segment title
		confirmMultiElementTextByElement(CreditCardPayment.MultiLocator_TextContainer_Summary_SegmentTitles, CreditCardPayment.MultiText_Delete_Summary_SegmentTitles);

		// last4 from
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_FromAccount, acLast4);

		// last4 to
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_ToAccount, ccLast4);

		// amount
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Amount, paymentAmount);

		// due date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_DueDate, dueDate);

		// payment date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_PaymentDate, tomorrow.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));

		// email matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Email, email);

		// Go to credit card payments link
		confirmElementExistence(CreditCardPayment.Locator_Link_Delete_Summary_GoToPayments);

		// see pending link
		confirmElementExistence(CreditCardPayment.Locator_Link_Delete_Summary_SeePendingPayments);

		// back link
		confirmElementExistence(CreditCardPayment.Locator_Link_Delete_Details_Back);

	}


	/**
	 * Select credit card account to make payment
	 */
	public void selectAccountFrom() {

		smartScroll(CreditCardPayment.Locator_DropDown_AccountFrom);
		setDropdownByIndex(CreditCardPayment.Locator_DropDown_AccountFrom, 1);

	}


	/**
	 * Select another Credit Card account to make payment")
	 */
	public void changeToAnotherCreditCardOnTopOfPage() {

		confirmElementExistence(CreditCardPayment.Locator_DropDown_CreditCard);
		// TODO: change to other dropdown values
		clickElement(CreditCardPayment.Locator_Button_Go);

	}


	/**
	 * Payment option: minimum payment due
	 */
	public void minimumPaymentDuePayment() {

		clickElement(CreditCardPayment.Locator_RadioButton_MinimumPayment);

	}


	/**
	 * Payment option: Statement Balance
	 */
	public void statementBalancePayment() {

		clickElement(CreditCardPayment.Locator_RadioButton_StatementBalance);

	}


	/**
	 * Payment option: Current Balance due
	 */
	public void currentBalanceDuePaymnent() {

		clickElement(CreditCardPayment.Locator_RadioButton_CurrentBalance);

	}


	/**
	 * Payment option: other amount
	 */
	public void otherAmountPayment(String paymentAmount) {

		clickElement(CreditCardPayment.Locator_RadioButton_OtherAmount);
		sendText(CreditCardPayment.Locator_TextField_OtherAmount, paymentAmount);

	}


	/**
	 * Change payment date to something else other than default
	 */
	public void changePaymentDate() {

		confirmElementExistence(Transfer.Locator_Calendar_TransferDate);
			// TODO: change dates

	}


	/**
	 * Setup autopay
	 */
	public void setupAutopay() {

		confirmElementExistence(CreditCardPayment.Locator_Link_SetUpAutopay);
			// TODO: after clicking link

	}


	/**
	 * Update contact details link
	 */
	public void updateContactDetailsLinky() {

		confirmElementExistence(CreditCardPayment.Locator_Link_UpdateContactDetails);
			// TODO: after clicking link

	}


	/**
	 * Add another account to account from
	 */
	public void addCreditCardAccount() {

		confirmElementExistence(CreditCardPayment.Locator_Link_AddAcount);
			// TODO: after clicking link

	}


	/**
	 * Click continue after enter details for credit card payment
	 */
	public void clickContinue() {

		we = smartScroll(Common.Locator_Button_Continue);
		clickElement(we);

	}


	/**
	 * Configure payment details.
	 *
	 * @param accountFrom (String) account number paying from (runtimeData)
	 * @param paymentType (enum)
	 * @param dateType (enum)
	 *
	 * @return (String) formatted date string
	 */
	public String enterOneTimePaymentDetails(String accountFrom, PaymentOptions paymentType, DateOptions dateType) {

		ss.assertTrue(PaymentOptions.OTHER != paymentType, "Amount required when attempting Other payment amount.");

		// scroll to and set dropdown
		we = smartScroll(CreditCardPayment.Locator_DropDown_AccountFrom);
		setDropdownByPartialVisibleText(we, accountFrom.substring(accountFrom.length()-4));

		// select radio button
		switch (paymentType) {
			case MINIMUM:
				clickElement(CreditCardPayment.Locator_RadioButton_MinimumPayment);
				break;
			case STATEMENT:
				clickElement(CreditCardPayment.Locator_RadioButton_StatementBalance);
				break;
			case CURRENT:
				clickElement(CreditCardPayment.Locator_RadioButton_CurrentBalance);
				break;
			default:
				clickElement(CreditCardPayment.Locator_RadioButton_CurrentBalance);
				break;
		}

		// get date as required
		switch (dateType) {
			case TODAY:
				this.date = todayDateFormattedMMDDYYYY();
				break;
			case TOMORROW:
				this.date = tomorrowDateFormattedMMDDYYYY();
				break;
			case WEEKDAY:
				this.date = futureWeekdayDateFormattedMMDDYYYY();
				break;
			case WEEKEND:
				this.date = futureWeekendDateFormattedMMDDYYYY();
				break;
			default:
				this.date = todayDateFormattedMMDDYYYY();
		}

		String[] datePieces = this.date.split("/");
		String month = datePieces[0];
		String day = datePieces[1];
		String year = datePieces[2];

		we = smartScroll(CreditCardPayment.Locator_TextField_PaymentMonth);
		sendText(we, month);
		sendText(CreditCardPayment.Locator_TextField_PaymentDay, day);
		sendText(CreditCardPayment.Locator_TextField_PaymentYear, year);

		return this.date;

	}


	/**
	 * Configure payment details.
	 *
	 * @param accountFrom (String) account number paying from (runtimeData)
	 * @param paymentType (enum)
	 * @param dateType (enum)
	 * @param amount (String)
	 *
	 * @return (String) formatted date string
	 */
	public String enterOneTimePaymentDetails(String accountFrom, PaymentOptions paymentType, DateOptions dateType, RandomOptions randomPayment, String paymentAmount) {

		// scroll to and set dropdown
		we = smartScroll(CreditCardPayment.Locator_DropDown_AccountFrom);
		setDropdownByPartialVisibleText(we, accountFrom);

		// select radio button
		switch (paymentType) {
			case MINIMUM:
				clickElement(CreditCardPayment.Locator_RadioButton_MinimumPayment);
				break;
			case STATEMENT:
				clickElement(CreditCardPayment.Locator_RadioButton_StatementBalance);
				break;
			case CURRENT:
				clickElement(CreditCardPayment.Locator_RadioButton_CurrentBalance);

				// extract current balance
				we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_CurrentBalance);
				String rawAmount = we.getText();
				rawAmount = rawAmount.substring(rawAmount.indexOf("$") + 1);
				paymentAmount = rawAmount;

				break;
			case OTHER:
				clickElement(CreditCardPayment.Locator_RadioButton_OtherAmount);

				switch (randomPayment) {
					case RANDOMIZED:
						sendText(CreditCardPayment.Locator_TextField_OtherAmount, randomizedPayment(paymentAmount));
						break;
					case DEFAULT:
						sendText(CreditCardPayment.Locator_TextField_OtherAmount, paymentAmount);
						break;
					default:
						sendText(CreditCardPayment.Locator_TextField_OtherAmount, paymentAmount);
						break;
				}

				break;
			default:
				clickElement(CreditCardPayment.Locator_RadioButton_CurrentBalance);
				break;
		}

		// get date as required
		switch (dateType) {
			case TODAY:
				//System.out.println("Today");
				this.date = todayDateFormattedMMDDYYYY();
				break;
			case TOMORROW:
				//System.out.println("Tomorrow");
				this.date = tomorrowDateFormattedMMDDYYYY();
				break;
			case WEEKDAY:
				//System.out.println("Weekday");
				this.date = futureWeekdayDateFormattedMMDDYYYY();
				break;
			case WEEKEND:
				//System.out.println("Weekend");
				this.date = futureWeekendDateFormattedMMDDYYYY();
				break;
			default:
				//System.out.println("Today");
				this.date = todayDateFormattedMMDDYYYY();
				break;
		}

		String[] datePieces = this.date.split("/");
		String month = datePieces[0];
		String day = datePieces[1];
		String year = datePieces[2];

		we = smartScroll(CreditCardPayment.Locator_TextField_PaymentMonth);
		sendText(we, month);
		sendText(CreditCardPayment.Locator_TextField_PaymentDay, day);
		sendText(CreditCardPayment.Locator_TextField_PaymentYear, year);

		return this.date;

	}


	/**
	 * Click continue after enter details for credit card payment
	 */
	public void submitPayment(String toAccount, String fromAccount) {

		// pull to account last4
		ccLast4 = jseExecuteString(CreditCardPayment.Script_String_CurrentSelectedDropDownValue, CreditCardPayment.Locator_DropDown_CreditCard);
		ccLast4 = ccLast4.substring(ccLast4.indexOf("*") + 1);
		ss.assertTrue(ccLast4.equals(toAccount), "Dropdown selected value does not match expected.");

		// extract last4, balance
		acLast4 = jseExecuteString(CreditCardPayment.Script_String_CurrentSelectedDropDownValue, CreditCardPayment.Locator_DropDown_AccountFrom);
		Float balance = Float.parseFloat(acLast4.substring(acLast4.indexOf("$") + 1));
		acLast4 = acLast4.substring(acLast4.indexOf("*") + 1, acLast4.indexOf("$"));
		acLast4 = acLast4.substring(0, acLast4.indexOf("-")).trim();
		ss.assertTrue(acLast4.equals(fromAccount), "Dropdown selected value does not match expected.");
		ss.assertTrue(balance > 1.0, "Insufficient from account balance.");

		// extract due date
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_DueDate);
		dueDate = we.getText();

		// submit
		smartScroll(CreditCardPayment.Locator_Button_Continue);
		navigateToMainTab(CreditCardPayment.Locator_Button_Continue, CreditCardPayment.Locator_RadioButton_Details_NotAcceptTCs);

	}


	/**
	 * Configure and submit One-time Payment
	 */
	public void submitOneTimePayment(String toAccount, String fromAccount, String amount) {

		// set to
		setDropdownByPartialVisibleText(CreditCardPayment.Locator_DropDown_CreditCard, toAccount);

		// go button
		clickElement(CreditCardPayment.Locator_Button_Go);

		// pull last4
		ccLast4 = jseExecuteString(CreditCardPayment.Script_String_CurrentSelectedDropDownValue, CreditCardPayment.Locator_DropDown_CreditCard);
		ccLast4 = ccLast4.substring(ccLast4.indexOf("*"));
		ss.assertTrue(ccLast4.contains(toAccount), String.format("Expected to contain: %s, Found: %s%n", toAccount, ccLast4));


		// set from
		setDropdownByPartialVisibleText(CreditCardPayment.Locator_DropDown_AccountFrom, fromAccount);

		//extract last4, balance
		acLast4 = jseExecuteString(CreditCardPayment.Script_String_CurrentSelectedDropDownValue, CreditCardPayment.Locator_DropDown_AccountFrom);
		Float balance = Float.parseFloat(acLast4.substring(acLast4.indexOf("$")+1));
		acLast4 = acLast4.substring(acLast4.indexOf("*"), acLast4.indexOf("$"));
		acLast4 = acLast4.substring(0, acLast4.indexOf("-")).trim();
		ss.assertTrue(acLast4.contains(fromAccount), "Dropdown selected value does not match expected.");
		ss.assertTrue(balance > 1.0, "Insufficient from account balance.");

		// set Other Amount
		clickElement(CreditCardPayment.Locator_RadioButton_OtherAmount);

		// set amount
		paymentAmount = String.format("%.2f", Float.parseFloat(amount) + randomizer.nextFloat());
		sendText(CreditCardPayment.Locator_TextField_OtherAmount_Enabled, paymentAmount);

		// set date
		String day = String.format("%d", tomorrow.getDayOfMonth());
		clickElement(CreditCardPayment.Locator_Button_Calendar);
		confirmElementExistence(CreditCardPayment.Locator_Container_CalendarWidget);
		clickElement(By.cssSelector(CreditCardPayment.CompoundLocator_Link_CalendarWidget_TargetDate.replace(compoundPlaceholder, day)));

		// extract due date
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_DueDate);
		dueDate = we.getText();

		System.out.format("From: %s, To: %s%n", acLast4, ccLast4);

		// submit
		clickElement(CreditCardPayment.Locator_Button_Continue);

	}


	/**
	 * Summary page page confirmation from One Time Payments
	 */
	public void summaryPageForOneTimePayment(String fromAccount, String creditCardNumber) {

		//Confirm stored Account information is the same as is on screen
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_AccountFromConfirm);
		ss.assertTrue(fromAccount.contains(we.getText().substring(we.getText().length() - 4, we.getText().length())));

		//Confirm stored Credit Card information is the same as is on screen
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_CreditCardConfirm);
		ss.assertTrue(creditCardNumber.contains(we.getText().substring(we.getText().length() - 4, we.getText().length())));

		//Confirm that the stored Date information is the same as on screen
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_DateConfirm);
		ss.assertTrue(we.getText().contains(formatedDate));

	}


	/**
	 * Verify on confirm details page for one time Payment
	 */
	public void confirmDetailsOneTimePayment(String fromAccount, String creditCardNumber, String paymentAmount) {

		// Confirm stored Account information is the same as is on screen
		//this.formatedDate= common.formatDate();
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_AccountFromConfirm);
		ss.assertTrue(fromAccount.contains(we.getText().substring(we.getText().length() - 4, we.getText().length())));

		//Confirm stored Credit Card information is the same as is on screen
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_CreditCardConfirm);
		ss.assertTrue(creditCardNumber.contains(we.getText().substring(we.getText().length() - 4, we.getText().length())));

		//Confirm that the stored Date information is the same as on screen
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_DateConfirm);
		ss.assertTrue(we.getText().contains(formatDate(paymentDate)));

		//save the payment amount for later validation

		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_AmountConfirm);

		paymentAmount = we.getText();
		//common.setPaymentAmount(this.runtimeData.paymentAmount);
		//System.out.println("DEBug: reaches set payment method" +this.runtimeData.paymentAmount);
		//After validation complete payment
		smartScroll(CreditCardPayment.Locator_TextContainer_ByClickingConfirm);
		clickElement(CreditCardPayment.Locator_RadioButton_AcceptConditions);
		clickElement(Common.Locator_ConfirmDetails_Button_Confirm);

	}


	/**
	 * Delete first pending payment
	 */
	public void deleteFirstPendingPayment() {

		clickElement(Common.Locator_Header_Button_CreditCardsTab);
		clickElement(CreditCard.Locator_CreditCard_Link_MakePayment_First);
		clickElement(CreditCardPayment.Locator_SubTab_OneTimePendingPayment);
		setDropdownByIndex(CreditCardPayment.Locator_DropDown_PendingPaymentDropDownFirst, CreditCardPayment.Text_PendingPayments_DeletePaymentIndex);
		clickElement(CreditCardPayment.Locator_Button_PendingPayments_Go_First);
		clickElement(Common.Locator_ConfirmDetails_Button_Confirm);

		// Confirm that the Payment has been deleted
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_DeletePendingPaymentBanner);
		ss.assertTrue(we.getText().contains(CreditCardPayment.Text_PendingPayments_DeletePendingPaymentsBannerText));

	}


	/**
	 * Validate Autopay landing page
	 */
	public void confirmEntryAutopay() {

		// autopay in OFF state
		ss.assertTrue(getAutopayState().toLowerCase().equals("off"), "Autopay already established.");

		// faq
		confirmElementExistence(CreditCardPayment.Locator_Container_FAQ);
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FAQ_Title, CreditCardPayment.Text_FAQ_Title);
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FAQ_FormTitle, CreditCardPayment.Text_FAQ_FormTitle);
		ss.assertTrue(confirmElementsExistence(CreditCardPayment.MultiLocator_Link_FAQ_Questions).size() > 0, "Missing FAQ links.");

		// Confirm form Title
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FormTitle, CreditCardPayment.Text_FormTitle);

		// Confirm one-time payment tab: inactive
		confirmElementExistence(CreditCardPayment.Locator_Link_OneTimePayment);

		// Confirm one-time payment pending tab: inactive
		confirmElementExistence(CreditCardPayment.Locator_Link_OneTimePending);

		// Confirm autopay tab: active
		confirmElementExistence(CreditCardPayment.Locator_Link_Autopay_Active);

		// Confirm active breadcrumb
		confirmTextValue(CreditCardPayment.Locator_TextContainer_BreadCrumb, CreditCardPayment.Text_BreadCrumb_EnterDetails);

		// Confirm credit card dropdown
		confirmElementExistence(CreditCardPayment.Locator_DropDown_CreditCard);

		// Confirm go button
		confirmElementExistence(CreditCardPayment.Locator_Button_Go);

		// Confirm segment titles
		confirmMultiElementText(CreditCardPayment.MultiLocator_TextContainer_SegmentTitles, CreditCardPayment.MultiText_Autopay_SegmentTitles);

		// Confirm email container
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_Email);

		// extract email address
		email = we.getText();
		email = email.substring(email.indexOf(":")+1);


		// Confirm update contact details link
		confirmElementExistence(CreditCardPayment.Locator_Link_UpdateContactDetails);

		// Confirm from account drop-down
		confirmElementExistence(CreditCardPayment.Locator_DropDown_AccountFrom);

		// Confirm add an account Link
		confirmElementExistence(CreditCardPayment.Locator_Link_AddAcount);

		// Confirm payment options
		confirmElementExistence(CreditCardPayment.Locator_RadioButton_MinimumPayment);
		confirmElementExistence(CreditCardPayment.Locator_RadioButton_StatementBalance);

		// Confirm continue button
		confirmElementExistence(CreditCardPayment.Locator_Button_Continue);

		// Take a Screen shot for later inspection
		ss.takeScreenShot();

	}


	/**
	 * Setup autopay, Takes locator for payment option
	 */
	public PaymentOptions setupAutopay(String ccLast4, String acLast4, PaymentOptions paymentOption) {

		setDropdownByPartialVisibleText(CreditCardPayment.Locator_DropDown_CreditCard, ccLast4);
		clickElement(CreditCardPayment.Locator_Button_Go);
		we = smartScroll(CreditCardPayment.Locator_DropDown_AccountFrom);
		setDropdownByPartialVisibleText(we, acLast4);

		switch (paymentOption) {
			case MINIMUM:
				clickElement(CreditCardPayment.Locator_RadioButton_MinimumPayment);
				break;
			case STATEMENT:
				clickElement(CreditCardPayment.Locator_RadioButton_StatementBalance);
				break;
			case CANCEL:
				clickElement(CreditCardPayment.Locator_RadioButton_CancelAutopay);
				break;
			default:
				clickElement(CreditCardPayment.Locator_RadioButton_MinimumPayment);
				break;
		}

		return paymentOption;

	}


	/**
	 * Validate Autopay confirmation page
	 */
	public void confirmDetailsPage(PaymentOptions paymentOption) {

		// Confirm print link
		confirmElementExistence(CreditCardPayment.Locator_Link_Print);

		// Confirm form title
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FormTitle, CreditCardPayment.Text_SetUpAutopay_Title);

		// Confirm active bread crumb
		confirmTextValue(CreditCardPayment.Locator_TextContainer_BreadCrumb, CreditCardPayment.Text_BreadCrumb_ConfirmDetails);

		// Confirm segment titles
		confirmMultiElementTextByElement(CreditCardPayment.MultiLocator_TextContainer_SegmentTitles, CreditCardPayment.MultiText_Autopay_Details_SegmentTitles);

		// last4 from
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_FromAccount, acLast4);

		// last4 to
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_ToAccount, ccLast4);

		// due date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_DueDate, dueDate);

		// payment date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_PaymentDate, date);

		// Confirm email matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Email, email);

		// do not radio, checked
		we = confirmElementExistence(CreditCardPayment.Locator_RadioButton_Details_NotAcceptTCs);
		ss.assertTrue(jseExecuteBoolean(CreditCardPayment.Script_Boolean_RadioButtonChecked, we), "Radio button not selected unexpectedly.");

		// do radio, unchecked
		we = confirmElementExistence(CreditCardPayment.Locator_RadioButton_Details_AcceptTCs);
		ss.assertFalse(jseExecuteBoolean(CreditCardPayment.Script_Boolean_RadioButtonChecked, we), "Radio button selected unexpectedly.");

		// cancel button
		confirmElementExistence(CreditCardPayment.Locator_Button_Details_Cancel);

		// Confirm confirm button
		confirmElementExistence(CreditCardPayment.Locator_Button_Details_Confirm);

		// back link
		confirmElementExistence(CreditCardPayment.Locator_Link_Autopay_Back);

		// Take a Screen shot for later inspection
		ss.takeScreenShot();

		// set Accept T&Cs
		clickElement(CreditCardPayment.Locator_RadioButton_Details_AcceptTCs);
		ss.assertTrue(jseExecuteBoolean(CreditCardPayment.Script_Boolean_RadioButtonChecked, CreditCardPayment.Locator_RadioButton_Details_AcceptTCs), "Radio button not selected.");

		// click confirm details
		clickElement(CreditCardPayment.Locator_Button_Details_Confirm);

	}


	/**
	 * Verify on confirm details page Autopay
	 */
	public void confirmDetailsAutopay(PaymentOptions paymentOption) {

		// Confirm print link
		confirmElementExistence(CreditCardPayment.Locator_Link_Print);

		// Confirm form title
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FormTitle, CreditCardPayment.Text_SetUpAutopay_Title);

		// Confirm active bread crumb
		confirmTextValue(CreditCardPayment.Locator_TextContainer_BreadCrumb, CreditCardPayment.Text_BreadCrumb_ConfirmDetails);

		// Confirm segment titles
		confirmMultiElementTextByElement(CreditCardPayment.MultiLocator_TextContainer_SegmentTitles, CreditCardPayment.MultiText_Autopay_Details_SegmentTitles);

		// last4 from
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_FromAccount, acLast4);

		// last4 to
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_ToAccount, ccLast4);

		// payment option
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_PaymentOption, paymentOption.toString());

		// due date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_DueDate, dueDate);

		// Confirm email matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Email, email);

		// do not radio, checked
		we = confirmElementExistence(CreditCardPayment.Locator_RadioButton_Details_NotAcceptTCs);
		ss.assertTrue(jseExecuteBoolean(CreditCardPayment.Script_Boolean_RadioButtonChecked, we), "Radio button not selected unexpectedly.");

		// do radio, unchecked
		we = confirmElementExistence(CreditCardPayment.Locator_RadioButton_Details_AcceptTCs);
		ss.assertFalse(jseExecuteBoolean(CreditCardPayment.Script_Boolean_RadioButtonChecked, we), "Radio button selected unexpectedly.");

		// cancel button
		confirmElementExistence(CreditCardPayment.Locator_Button_Details_Cancel);

		// Confirm confirm button
		confirmElementExistence(CreditCardPayment.Locator_Button_Details_Confirm);

		// back link
		confirmElementExistence(CreditCardPayment.Locator_Link_Autopay_Back);

		// Take a Screen shot for later inspection
		ss.takeScreenShot();

	}


	/**
	 * Agree to conditions and click submit
	 */
	public void submitAutopayConfirmation() {

		// set Accept T&Cs
		clickElement(CreditCardPayment.Locator_RadioButton_Details_AcceptTCs);
		ss.assertTrue(jseExecuteBoolean(CreditCardPayment.Script_Boolean_RadioButtonChecked, CreditCardPayment.Locator_RadioButton_Details_AcceptTCs), "Radio button not selected.");

		// click confirm details
		navigateToMainTab(CreditCardPayment.Locator_Button_Details_Confirm, CreditCardPayment.Locator_TextContainer_Autopay_SummaryBanner);


	}


	/**
	 * Summary page page confirmation from autopay
	 */
	public void confirmSummaryAutopay(PaymentOptions paymentOption) {

		// Confirm print link
		confirmElementExistence(CreditCardPayment.Locator_Link_Print);

		// Confirm form title
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FormTitle, CreditCardPayment.Text_SetUpAutopay_Title);

		// Confirm active bread crumb
		confirmTextValue(CreditCardPayment.Locator_TextContainer_BreadCrumb, CreditCardPayment.Text_BreadCrumb_Summary);

		// confirm success banner
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Autopay_SummaryBanner, CreditCardPayment.Text_Autopay_SummaryBanner);

		// Confirm segment titles
		confirmMultiElementTextByElement(CreditCardPayment.MultiLocator_TextContainer_Summary_SegmentTitles, CreditCardPayment.MultiText_Autopay_Details_SegmentTitles);

		// last4 from
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_FromAccount, acLast4);

		// last4 to
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_ToAccount, ccLast4);

		// payment option
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_PaymentOption, paymentOption.toString());

		// due date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_DueDate, dueDate);

		// Confirm email matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Email, email);

		// go to payment link
		confirmElementExistence(CreditCardPayment.Locator_Link_Autopay_Summary_GoToPayments);

		// back link
		confirmElementExistence(CreditCardPayment.Locator_Link_Autopay_Back);

		// Take a Screen shot for later inspection
		ss.takeScreenShot();

	}


	/**
	 * Check overview and autopay configuration screen queues for autopay enablement and type
	 */
	public void confirmAutopayEnabled(PaymentOptions paymentOption) {

		// navigate to credit card overview
		navigateToMainTab(Common.Locator_Header_Button_CreditCardsTab, Common.Locator_Header_Button_CreditCardsTab_Active);

		// confirm ON indicator for first credit card
		confirmCreditCardContentBody();
		ss.assertTrue(getAutopayState().toLowerCase().equals("on"), "Autopay enablement could not be confirmed.");

		// confirm instructions
		switch (paymentOption) {
			case MINIMUM:
				confirmTextValue(CreditCard.Locator_Overview_TextContainer_Card_AutopayInstructions_First, CreditCard.Text_Overview_Card_AutopayInstructions_Minimum);
				break;
			case STATEMENT:
				confirmTextValue(CreditCard.Locator_Overview_TextContainer_Card_AutopayInstructions_First, CreditCard.Text_Overview_Card_AutopayInstructions_Statement);
				break;
			default:
				confirmTextValue(CreditCard.Locator_Overview_TextContainer_Card_AutopayInstructions_First, CreditCard.Text_Overview_Card_AutopayInstructions_Minimum);
				break;
		}

		// navigate to first credit card autopay
		navigateToMainTab(CreditCard.Locator_CreditCard_Link_SetUpAutoPay_First, CreditCard.Locator_LeftNav_Button_CreditCardPayment_Active);

		// confirm radio button selection
		switch (paymentOption) {
			case MINIMUM:
				ss.assertTrue(jseExecuteBoolean(CreditCardPayment.Script_Boolean_RadioButtonChecked, CreditCardPayment.Locator_RadioButton_AutopayMinPayment));
				break;
			case STATEMENT:
				ss.assertTrue(jseExecuteBoolean(CreditCardPayment.Script_Boolean_RadioButtonChecked, CreditCardPayment.Locator_RadioButton_AutopayStatmentBalance));
				break;
			default:
				ss.assertTrue(jseExecuteBoolean(CreditCardPayment.Script_Boolean_RadioButtonChecked, CreditCardPayment.Locator_RadioButton_AutopayMinPayment));
				break;
		}

		// confirm cancel radio button present
		confirmElementExistence(CreditCardPayment.Locator_RadioButton_CancelAutopay);

	}


	/**
	 * submit autopay cancellation
	 */
	public void submitCancelAutopay(String toAccount, String fromAccount) {

		// pull account last4
		ccLast4 = jseExecuteString(CreditCardPayment.Script_String_CurrentSelectedDropDownValue, CreditCardPayment.Locator_DropDown_CreditCard);
		ccLast4 = ccLast4.substring(ccLast4.indexOf("*") + 1);
		ss.assertTrue(ccLast4.equals(toAccount), "Dropdown selected value does not match expected.");

		// extract last4, balance
		acLast4 = jseExecuteString(CreditCardPayment.Script_String_CurrentSelectedDropDownValue, CreditCardPayment.Locator_DropDown_AccountFrom);
		Float balance = Float.parseFloat(acLast4.substring(acLast4.indexOf("$") + 1));
		acLast4 = acLast4.substring(acLast4.indexOf("*") + 1, acLast4.indexOf("$"));
		acLast4 = acLast4.substring(0, acLast4.indexOf("-")).trim();
		ss.assertTrue(acLast4.equals(fromAccount), "Dropdown selected value does not match expected.");
		ss.assertTrue(balance > 1.0, "Insufficient from account balance.");

		// extract due date
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_DueDate);
		dueDate = we.getText();

		// submit cancel autopay
		smartScroll(CreditCardPayment.Locator_Button_Continue);
		navigateToMainTab(Common.Locator_Button_Continue, CreditCardPayment.Locator_Button_Details_Cancel);

	}


	/**
	 * Details page confirmation from autopay cancellation
	 */
	public void confirmCancelDetails(PaymentOptions paymentOption) {

		// Confirm print link
		confirmElementExistence(CreditCardPayment.Locator_Link_Print);

		// Confirm form title
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FormTitle, CreditCardPayment.Text_SetUpAutopay_Title);

		// Confirm active bread crumb
		confirmTextValue(CreditCardPayment.Locator_TextContainer_BreadCrumb, CreditCardPayment.Text_BreadCrumb_ConfirmDetails);

		// Confirm segment titles
		confirmMultiElementTextByElement(CreditCardPayment.MultiLocator_TextContainer_SegmentTitles, CreditCardPayment.MultiText_Autopay_Details_SegmentTitles);

		// last4 from
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_FromAccount, acLast4);

		// last4 to
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_ToAccount, ccLast4);

		// payment option
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_PaymentOption, paymentOption.toString());

		// due date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_DueDate, dueDate);

		// Confirm email matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Email, email);

		// cancel button
		confirmElementExistence(CreditCardPayment.Locator_Button_Details_Cancel);

		// Confirm confirm button
		confirmElementExistence(CreditCardPayment.Locator_Button_Details_Confirm);

		// back link
		confirmElementExistence(CreditCardPayment.Locator_Link_Autopay_Back);

		// Take a Screen shot for later inspection
		ss.takeScreenShot();

	}


	/**
	 * Submit autopay cancellation details confirmation
	 */
	public void submitCancelConfirmation() {

		// submit cancel autopay details confirmation
		navigateToMainTab(Common.Locator_ConfirmDetails_Button_Confirm, CreditCardPayment.Locator_TextContainer_Autopay_CancelBanner);

	}


	/**
	 * Confirm autopay cancellation summary
	 *
	 * @param paymentOption (PaymentOptions) payment option enum for content checking
	 */
	public void confirmCancelSummaryAutopay(PaymentOptions paymentOption) {

		// Confirm print link
		confirmElementExistence(CreditCardPayment.Locator_Link_Print);

		// Confirm form title
		confirmTextValue(CreditCardPayment.Locator_TextContainer_FormTitle, CreditCardPayment.Text_SetUpAutopay_Title);

		// Confirm active bread crumb
		confirmTextValue(CreditCardPayment.Locator_TextContainer_BreadCrumb, CreditCardPayment.Text_BreadCrumb_Summary);

		// confirm success banner
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Autopay_CancelBanner, CreditCardPayment.Text_Autopay_CancelBanner);

		// Confirm segment titles
		confirmMultiElementTextByElement(CreditCardPayment.MultiLocator_TextContainer_Summary_SegmentTitles, CreditCardPayment.MultiText_Autopay_Details_SegmentTitles);

		// last4 from
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_FromAccount, acLast4);

		// last4 to
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_ToAccount, ccLast4);

		// payment option
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_PaymentOption, paymentOption.toString());

		// due date matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_DueDate, dueDate);

		// Confirm email matches
		confirmTextValue(CreditCardPayment.Locator_TextContainer_Details_Email, email);

		// go to payment link
		confirmElementExistence(CreditCardPayment.Locator_Link_Autopay_Summary_GoToPayments);

		// back link
		confirmElementExistence(CreditCardPayment.Locator_Link_Autopay_Back);

		// Take a Screen shot for later inspection
		ss.takeScreenShot();

	}


	/**
	 * Cancel autopay to clean up test
	 */
	public void cancelAutoPayFirst() {

		clickElement(Common.Locator_Header_Button_CreditCardsTab);
		clickElement(CreditCard.Locator_CreditCard_Link_SetUpAutoPay_First);
		clickElement(CreditCardPayment.Locator_RadioButton_CancelAutopay);
		clickElement(Common.Locator_Button_Continue);
		clickElement(Common.Locator_ConfirmDetails_Button_Confirm);

		// Confirm confirmation banner is displayed
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_Autopay_CancelBanner);
		ss.assertTrue(we.getText().contains(CreditCardPayment.Text_Autopay_CancelBanner));

	}


	/**
	 * Add an external account for credit card payment
	 */
	public void clickExternalPaymentAccountFromAutopay() {

		clickElement(CreditCardPayment.Locator_Link_ExternalAccount_AddNewAccount);

	}


	/**
	 * Add an external account for credit card payment
	 */
	public void returnToCardPayment() {

		// click back to payment
		clickElement(CustomerService.Locator_Link_ExternalAccount_BackToCardPayment);

	}


	/**
	 * Click Autopay Sub-Tab
	 */
	public void clickAutopaySubTab() {

		clickElement(CreditCardPayment.Locator_SubTab_Autopay_ExternalAccountReturn);

	}


	/**
	 * Select an extenal or secondary account by Text
	 */
	public void selectOtherAccountByText(String AccountText) {

		setDropdownByPartialVisibleText(CreditCardPayment.Locator_DropDown_AccountFrom, AccountText);

	}


	/**
	 * Verify on confirm details page Autopay
	 */
	public void confirmAutopayExternalAccountDetails(String paymentOption, String creditCardNumber) {

		System.out.println("DEBUG: reaches previous pof confirm autopay external accout det scr 5");

		//Confirm stored Account information is the same as is on screen
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_AccountFromConfirm);
		ss.assertTrue(we.getText().contains(CustomerService.Text_ExternalAccount_NewAccountNickname));

		//Confirm stored Credit Card information is the same as is on screen
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_CreditCardConfirm);
		ss.assertTrue(creditCardNumber.contains(we.getText().substring(we.getText().length() - 4, we.getText().length())));

		//Confirm Payment Option on screen is as expected
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_PaymentOption_Confirm);
		ss.assertTrue(we.getText().contains(paymentOption));

		//After validation complete payment
		smartScroll(CreditCardPayment.Locator_TextContainer_ByClickingConfirm);
		clickElement(CreditCardPayment.Locator_RadioButton_AcceptConditions);
		//clickElement(CreditCardPayment.Locator_Link_AutopayBackLink);
		clickElement(Common.Locator_ConfirmDetails_Button_Confirm);

	}


	/**
	 * Summary page page confirmation from autopay
	 */
	public void summaryPageForAutopayExtenalAccounts(String paymentOption, String creditCardNumber) {

		//Confirm confirmation banner is displayed
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_Autopay_SummaryBanner);
		ss.assertTrue(we.getText().contains(CreditCardPayment.Text_Autopay_SummaryBanner));

		//Confirm stored Account information is the same as is on screen
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_AccountFromConfirm);
		ss.assertTrue(we.getText().contains(CustomerService.Text_ExternalAccount_NewAccountNickname));

		//Confirm stored Credit Card information is the same as is on screen
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_CreditCardConfirm);
		ss.assertTrue(creditCardNumber.contains(we.getText().substring(we.getText().length() - 4, we.getText().length())));

		//Confirm Payment Option on screen is as expected
		we = confirmElementExistence(CreditCardPayment.Locator_TextContainer_PaymentOption_Confirm);
		ss.assertTrue(we.getText().contains(paymentOption));

	}


	/**
	 * Add random 100ths to payment
	 *
	 * @param paymentAmount (String) whole dollar amount unto which to append random 100ths (0.00 - 0.99)
	 *
	 * @return (String)
	 */
	public String randomizedPayment(String paymentAmount) {

		return String.format("%.2f", Float.parseFloat(paymentAmount) + randomizer.nextFloat());

	}

	/* CREDIT CARD PAYMENT - END */


	/* SHOW HIDE NICKNAME -  START */

	/**
	 * navigate to Show hide nickname page from customer service->my profile and preferences
	 */
	public void navigateToShowHideAndNicknameAccountsPage() {

		clickElement(Common.Locator_Header_Button_CustomerServiceTab);
		clickElement(CustomerService.Locator_LeftNav_Button_MyProfileAndPreferences);
		confirmElementExistence(MyProfileAndPreferences.Locator_SubTitle_MyProfileAndPreferences);
		clickElement(MyProfileAndPreferences.Locator_Link_ShowHideNicknameAccoounts);
		confirmElementExistence(ShowHideNickname.Locator_SubTitle_ShowHideNicknameAccounts);

	}


	/**
	 * Click the checkbox next to first checking account, extract account number.
	 * Click the checkbox next to first credit account, extract account number
	 *
	 * <p><strong>REQUIRES AT LEAST TWO (2) CHECKING AND TWO (2) CREDIT CARD</strong>
	 */
	public void hideFirstCheckingAndFirstCreditCard() {

		// click first checking account checkbox
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_CheckBox_CheckSaveMoneyMarketSelect);
		clickElement(weArray.get(0));

		// get account number for first checking account
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_TextField_CheckSaveMoneyMarketAccount);
		disabledCheckingAccount = weArray.get(0).getText();
		//System.out.format("[DEBUG]: <[%s:%s] disabled checking account: %s>%n", id, testName, disabledCheckingAccount);

		// click first credit account checkbox
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_CheckBox_CreditCardSelect);
		clickElement(weArray.get(0));

		// get account number for first credit card
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_TextField_CreditCardAccount);
		disabledCreditCardAccount = weArray.get(0).getText();
		//System.out.format("[DEBUG]: <[%s:%s] disabled credit account: %s>%n", id, testName, disabledCreditCardAccount);

		ss.takeScreenShot();

		// scroll to and click continue button
		smartScroll(Common.Locator_Button_Continue);
		clickElement(Common.Locator_Button_Continue);

		// handle confirmation of changes page
		handleConfirmChangesPage();

		// handle summary of changes page
		handleSummaryPage();

	}


	/**
	 * Confirm changes on Confirm details page
	 */
	public void handleConfirmChangesPage() {

		confirmTextValue(Common.Locator_TextContainer_BreadCrumb_Active, Common.Text_BreadCrumb_ConfirmDetails);
		clickElement(Common.Locator_ConfirmDetails_Button_Confirm);

	}


	/**
	 * Message shown that show hide nickname account was changed on  summary page
	 */
	public void handleSummaryPage() {

		confirmElementExistence(ShowHideNickname.Locator_Image_ShowHideNicknameChangedSuccessfully);
		clickElement(Common.Locator_Header_Button_AccountsTab);
		confirmElementExistence(Accounts.Locator_LeftNav_Button_OverviewTab_Active);

	}


	/**
	 * Confirm that hidden accounts do not show in accounts page
	 */
	public void confirmAbsenceOfDisabledAccounts() {

		// check that disabled checking account number is not found among checking accounts
		weArray.clear();
		weArray = confirmElementsExistence(Accounts.MultiLocator_Overview_TextContainer_CheckSaveMoneyMarketAccounts);
		//System.out.format("[DEBUG]: <[%s:%s] account count: %d>%n", id, testName, weArray.size());
		for (WebElement element: weArray) {
			//System.out.format("[DEBUG]: <[%s:%s] %s:%s>%n", id, testName, element.getText().trim().replace("\n", ""), disabledCheckingAccount);
			ss.assertFalse(element.getText().contains(disabledCheckingAccount), String.format("Expected to contain: %s, Found: %s%n", disabledCheckingAccount, element.getText()));
		}

		// check that disabled credit account number is not found among checking accounts
		weArray.clear();
		weArray = confirmElementsExistence(Accounts.MultiLocator_Overview_TextContainer_CreditCardAccounts);
		//System.out.format("[DEBUG]: <[%s:%s] account count: %d>%n", id, testName, weArray.size());
		for (WebElement element: weArray) {
			//System.out.format("[DEBUG]: <[%s:%s] %s:%s>%n", id, testName, element.getText().trim().replace("\n", ""), disabledCreditCardAccount);
			ss.assertFalse(element.getText().contains(disabledCreditCardAccount), String.format("Expected to contain: %s, Found: %s%n", disabledCreditCardAccount, element.getText()));
		}

		ss.takeScreenShot();

	}


	/**
	 * Change order of two checking and two credit accounts
	 * Change nickname of first checking and first credit account
	 */
	public void changeOrderAndNickname() {

		navigateToShowHideAndNicknameAccountsPage();

		// toggle all accounts to 'checked'
		clickElement(ShowHideNickname.Locator_CheckBox_SelectAll);

		// change the nickname of first checking account store oldname and newname
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_TextField_CheckSaveMoneyMarketNicknames);
		we = null;
		we = weArray.get(0);
		originalCheckingFirstNickname = we.getAttribute("value");
		tempCheckingNickname = String.format("MOD-%s", originalCheckingFirstNickname.substring(4, 19));
		sendText(we, tempCheckingNickname);

		// change the nickname of first credit account store oldname and newname
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_TextField_CreditCardNicknames);
		we = null;
		we = weArray.get(0);
		originalCreditFirstNickname = we.getAttribute("value");
		tempCreditNickname = String.format("MOD-%s", originalCreditFirstNickname.substring(4, 19));
		sendText(we, tempCreditNickname);

		// randomize order of checking accounts
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_TextField_CheckSaveMoneyMarketOrder);

		//get available indexes
		chIndexes.clear();
		for (int i = 0; i < weArray.size(); i++) {
			chIndexes.add(i);
		}

		//randomize indexes
		Collections.shuffle(chIndexes);

		//set credit accounts indexes
		for (int i = 0; i < chIndexes.size(); i++) {
			sendText(weArray.get(i), String.format("%d", chIndexes.get(i) + 1));
		}

		//get cc account numbers corresponding to reordered indexes
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_TextField_CheckSaveMoneyMarketAccount);
		chAccountLast4s = new ArrayList<String>();
		for (int i = 0; i < chIndexes.size(); i++) {
			chAccountLast4s.add(weArray.get(chIndexes.indexOf(i)).getText());
		}

		//get cc account names corresponding to reordered indexes
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_TextField_CheckSaveMoneyMarketNicknames);
		chNicknames = new ArrayList<String>();
		for (int i = 0; i < chIndexes.size(); i++) {
			chNicknames.add(weArray.get(chIndexes.indexOf(i)).getAttribute("value"));
		}

//		//DEBUG
//		System.out.format("[DEBUG]: <[%s:%s] ", id, testName);
//		for (String s: chAccountLast4s) {
//			System.out.format("%s,", s);
//		}
//		System.out.format(">%n");
//
//		//DEBUG
//		System.out.format("[DEBUG]: <[%s:%s] ", id, testName);
//		for (String s: chNicknames) {
//			System.out.format("%s,", s);
//		}
//		System.out.format(">%n");

		// randomize order of credit accounts
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_TextField_CreditCardOrder);

		//get current indexes
		ccIndexes.clear();
		for (int i = 0; i < weArray.size(); i++) {
			ccIndexes.add(i);
		}

		//randomize indexes
		Collections.shuffle(ccIndexes);

		//set credit accounts indexes
		for (int i = 0; i < ccIndexes.size(); i++) {
			sendText(weArray.get(i), String.format("%d", ccIndexes.get(i) + 1));
		}

		//get cc account numbers corresponding to reordered indexes
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_TextField_CreditCardAccount);
		ccAccountLast4s = new ArrayList<String>();
		for (int i = 0; i < ccIndexes.size(); i++) {
			ccAccountLast4s.add(weArray.get(ccIndexes.indexOf(i)).getText());
		}

		//get cc account numbers corresponding to reordered indexes
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_TextField_CreditCardNicknames);
		ccNicknames = new ArrayList<String>();
		for (int i = 0; i < ccIndexes.size(); i++) {
			ccNicknames.add(weArray.get(ccIndexes.indexOf(i)).getAttribute("value"));
		}

//		//DEBUG
//		System.out.format("[DEBUG]: <[%s:%s] ", id, testName);
//		for (String s: ccAccountLast4s) {
//			System.out.format("%s,", s);
//		}
//		System.out.format(">%n");
//
//		//DEBUG
//		System.out.format("[DEBUG]: <[%s:%s] ", id, testName);
//		for (String s: ccNicknames) {
//			System.out.format("%s,", s);
//		}
//		System.out.format(">%n");

		ss.takeScreenShot();

		// scroll to and click continue
		smartScroll(Common.Locator_Button_Continue);
		clickElement(Common.Locator_Button_Continue);

		// handle confirmation of changes page
		handleConfirmChangesPage();

		// handle summary page
		handleSummaryPage();

	}


	/**
	 * Confirm re-ordering of accounts and nickname updates
	 */
	public void confirmOrderAndNickname() {

			// confirm checking name and order
			weArray.clear();
			weArray = confirmElementsExistence(Accounts.MultiLocator_Overview_TextContainer_CheckSaveMoneyMarketNicknames);

			//System.out.format("[DEBUG]: <[%s:%s] found: \'%s\'; Expected: \'%s\'>%n", id, testName, weArray.size(), chNicknames.size());
			ss.assertTrue(weArray.size() == chNicknames.size(), "Table size mismatch.");
			for (int i = 0; i < weArray.size(); i++) {
				//System.out.format("[DEBUG]: <[%s:%S] comparing Observed: \'%s\'; Anticipated: \'%s\'>%n", id, testName, weArray.get(i).getText().trim(), chNicknames.get(i).trim());
				ss.assertTrue((weArray.get(i).getText().trim()).equals(chNicknames.get(i).trim()), String.format("Found: \'%s\'; Expected: \'%s\'.", weArray.get(i).getText().trim(), chNicknames.get(i).trim()));
			}

			// confirm credit name and order
			weArray.clear();
			weArray = confirmElementsExistence(Accounts.MultiLocator_Overview_TextContainer_CreditCardNicknames);
			//System.out.format("[DEBUG]: <[%s:%s] found: \'%s\'; Expected: \'%s\'>%n", id, testName, weArray.size(), ccNicknames.size());
			ss.assertTrue(weArray.size() == ccNicknames.size(), "Table size mismatch.");
			for (int i = 0; i < weArray.size(); i++) {
				//System.out.format("[DEBUG]: <[%s:%S] comparing Observed: \'%s\'; Anticipated: \'%s\'>%n", id, testName, weArray.get(i).getText().trim(), ccNicknames.get(i).trim());
				ss.assertTrue((weArray.get(i).getText().trim()).equals(ccNicknames.get(i).trim()), String.format("Found: \'%s\'; Expected: \'%s\'.", weArray.get(i).getText().trim(), ccNicknames.get(i).trim()));
			}

			ss.takeScreenShot();
		}


	/**
	 * Revert order and nickname of savings edited and checking edited, tear down
	 */
	public void revertChanges_ShowHideNickName() {

		navigateToShowHideAndNicknameAccountsPage();

		// clear both checking fields, thus resetting names
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_TextField_CheckSaveMoneyMarketNicknames);
		for (WebElement w: weArray) {
			w.clear();
		}

		// clear both credit card fields, thus resetting names
		weArray.clear();
		weArray = confirmElementsExistence(ShowHideNickname.MultiLocator_TextField_CreditCardNicknames);
		for (WebElement w: weArray) {
			w.clear();
		}

		ss.takeScreenShot();

		// scroll to and click continue
		smartScroll(Common.Locator_Button_Continue);
		clickElement(Common.Locator_Button_Continue);

		// handle confirmation of changes page
		handleConfirmChangesPage();

		// handle summary page
		handleSummaryPage();

		// verify changed names are not found
		confirmReversion();

	}


	/**
	 * Verify that modified account does NOT show in accounts page
	 */
	public void confirmReversion() {

		// confirm custom checking name not found
		weArray.clear();
		weArray = confirmElementsExistence(Accounts.MultiLocator_Overview_TextContainer_CheckSaveMoneyMarketNicknames);
		for (WebElement element: weArray) {
			ss.assertFalse(element.getText().contains(tempCheckingNickname), "Modified account name found. Data reversion incomplete.");
		}


		// confirm custom credit card name not found
		weArray.clear();
		weArray = confirmElementsExistence(Accounts.MultiLocator_Overview_TextContainer_CreditCardNicknames);
		for (WebElement element: weArray) {
			ss.assertFalse(element.getText().contains(tempCreditNickname), "Modified account name found. Data reversion incomplete.");
		}

		ss.takeScreenShot();

	}

	/* SHOW HIDE NICKNAME - END */


	/* QUICK TRANSFERS - START */

	/**
	 * Confirm presence of Quick Transfer widget and of its component parts
	 */
	public void confirmQuickTransferWidgetAndComponents() {

		confirmElementExistence(QuickTransfer.Locator_Container);
		confirmTextValue(QuickTransfer.Locator_TextContainer_Title, QuickTransfer.Locator_Text_Title);
		confirmElementExistence(QuickTransfer.Locator_Select_From);
		confirmElementExistence(QuickTransfer.Locator_Select_To);
		confirmElementExistence(QuickTransfer.Locator_TextField_Date_Month);
		confirmElementExistence(QuickTransfer.Locator_TextField_Date_Day);
		confirmElementExistence(QuickTransfer.Locator_TextField_Date_Year);
		confirmElementExistence(QuickTransfer.Locator_Button_Calendar);
		confirmElementExistence(QuickTransfer.Locator_TextField_Amount);
		confirmElementExistence(QuickTransfer.Locator_Button_Go);
		ss.takeScreenShot();

	}

	/**
	 * Trigger the loading of From/To dropdown entries
	 */
	public void loadAccounts() {

		clickElement(QuickTransfer.Locator_Select_From);
		confirmElementExistence(QuickTransfer.Locator_Image_Waiting, 5, 100);
		confirmElementNonExistence(QuickTransfer.Locator_Image_Waiting, 15);
		confirmElementExistence(QuickTransfer.Locator_Image_Waiting_Hidden);
		clickElement(QuickTransfer.Locator_Select_From);

	}


	/**
	 * Set from account using partial text match
	 */
	public void setFromAccount_QuickTransfer(String fromAccount) {

		setDropdownByPartialVisibleText(QuickTransfer.Locator_Select_From, fromAccount);

	}


	/**
	 * Set to account using partial text match
	 */
	public void setToAccount_QuickTransfer(String toAccount) {

		setDropdownByPartialVisibleText(QuickTransfer.Locator_Select_To, toAccount);

	}


	/**
	 * Opens calendar widget, clicks on whatever date corresponds to 'tomorrow',
	 * confirm text entry field for day matches desrted selection
	 */
	public void setDate() {

		clickElement(QuickTransfer.Locator_Button_Calendar);
		confirmElementExistence(QuickTransfer.Locator_Container_CalendarWidget);
		confirmElementExistence(By.xpath(QuickTransfer.CompoundLocator_Container_CalendarWidget_TargetDate.replace(compoundPlaceholder, tomorrowQt)));
		clickElement(By.xpath(QuickTransfer.CompoundLocator_Container_CalendarWidget_TargetDate.replace(compoundPlaceholder, tomorrowQt)));

		String dateFieldText = jseExecuteString(QuickTransfer.Script_String_getElementValueText, QuickTransfer.Locator_TextField_Date_Day);
		ss.assertTrue(dateFieldText.equals(tomorrowQt));
		ss.takeScreenShot();

	}


	/**
	 * Set the amount of amount textfield
	 */
	public void setAmount(String paymentAmount) {

		sendText(QuickTransfer.Locator_TextField_Amount, paymentAmount); // includes screenshot

	}


	/**
	 * Click Go button
	 */
	public void submit() {

		navigateToMainTab(QuickTransfer.Locator_Button_Go, Common.Locator_Header_Button_TransferTab_Active, 60);
		ss.takeScreenShot();

	}


	/**
	 * Confirm key Confirmation page content
	 */
	public void confirmQuickTransferSubmission() {

		// confirm top nav active button
		confirmActiveNavigationButton(Common.Locator_Header_Button_TransferTab_Active);

		// confirm left nav active button
		confirmActiveNavigationButton(Transfer.Locator_LeftNav_Button_Transfer_Active);

		// confirm form title
		confirmTextValue(Transfer.Locator_TextContainer_TransferConfirmation_Title, Transfer.Text_TransferConfirmation_Title);

		// confirm breadcrumb active text
		confirmTextValue(Transfer.Locator_TextContainer_BreadCrumb_Active, Transfer.Text_BreadCrumb_ConfirmDetails);

		// confirm Confirm button
		confirmElementExistence(Common.Locator_ConfirmDetails_Button_Confirm);

	}

	/* QUICK TRANSFERS - END */


	/* CUSTOMER SERVICE - START */

	/**
	 * Click help question, switch to daughter window, verify content, close daughter window, switch to parent
	 */
	private void checkHelpQuestion(WebElement w) {

		// click first question
	 	clickElement(w);

	 	// confirm at least one (1) daughter window launches
	 	ss.assertTrue(waitForMoreHandles(), "No daughter windows detected. Expected at least one (1).");

	 	// switch to daughter window
		String currentHandle = switchToDaughterWindow()[0];

		// confirm daughter window content
		confirmElementExistence(ContactUs.Locator_HelpQA_TextContainer_RateThisAnswer);
		ss.takeScreenShot();

		// close daughter window
		closeWindow();

		// return to parent window
		switchToWindowByHandle(currentHandle);

	}


	/**
	 * Verify user is on Contact Us and Help page under the CustomerSerice Header tab and following elements are present according to
	 */
	public void confirmContactUsAndHelpPage() {

		// confirm active leftNav button
		confirmActiveNavigationButton(CustomerService.Locator_LeftNav_Button_ContactUsAndHelp_Active);

		// confirm form title
		confirmTextValue(CustomerService.Locator_ContactUsAndHelp_TextContainer_FormTitle, CustomerService.Text_ContactUsAndHelp_FormTitle);

		// confirm title image
		checkForBrokenImage(CustomerService.Locator_Image_ContactUsAndHelp_FormTitle);

		// confirm print link
		confirmElementExistence(CustomerService.Locator_ContactUsAndHelp_Link_Print);

		// confirm segment headers
		confirmMultiElementText(CustomerService.MultiLocator_ContactUsAndHelp_TextContainer_SectionHeaders, CustomerService.MultiText_ContactUsAndHelp_SectionHeaders);

		// scroll to and confirm segment links
		smartScroll(CustomerService.Locator_ContactUsAndHelp_Link_SecurityAdvice_LaunchSecurityCenter);
		smartScroll(CustomerService.Locator_ContactUsAndHelp_Link_Email_SendEmail);
		smartScroll(CustomerService.Locator_ContactUsAndHelp_Link_BranchOffice_FindBranch);

		// scroll to and ensure help question functionality
		//this.we = smartScroll(ContactUs.Locator_Help_Link_QA1);
		weArray = confirmElementsExistence(CustomerService.MultiLocator_ContactUsAndHelp_Link_HelpLinks);
		checkHelpQuestion(weArray.get(randomizer.nextInt(weArray.size())));

		//take a screenshot of page
		ss.takeScreenShot();

	}


	/**
	 *
	 */
	public void confirmAccountServicesPage() {

		//confirm active top nav button
		confirmActiveNavigationButton(Common.Locator_Header_Button_CustomerServiceTab_Active);

		// confirm active left nav button
		confirmActiveNavigationButton(CustomerService.Locator_LeftNav_Button_AccountServices_Active);

		// confirm left nav title
		confirmTextValue(CustomerService.Locator_LeftNav_TextContainer_MenuTitle, CustomerService.Text_LeftNav_MenuTitle);

		// confirm form title
		confirmTextValue(CustomerService.Locator_AccountServices_FormTitle, CustomerService.Text_AccountServices_FormTitle);

		// confirm help link
		confirmHelpWithThisPageLink_CustomerService();

	}


	/**
	 * Confirm existence of help with this page link
	 */
	public void confirmHelpWithThisPageLink_CustomerService() {

		//System.out.format("[LOG]: <[%s:%s] confirm Help with this page link.>%n", id, testName);
		confirmElementExistence(CustomerService.Locator_AccountServices_Link_HelpWithThisPage);
		ss.takeScreenShot();

	}


	/**
	 * Fully creates and confirms an external account for a user.
	 */
	public void createPaymentAccountFromAddAccountPage() {

		addExternalPaymentAccount();
		clickElement(CustomerService.Locator_Button_ExternalAccount_AddNewAccountContinueButton);
		confirmExternalPaymentAccount();
		clickElement(CustomerService.Locator_Button_ExternalAccount_AddNewAccountConfirmButton);
		confirmExternalPaymentAccountSummary();

	}


	/**
	 * Add an external Payment Account
	 */
	public void addExternalPaymentAccount() {

		//enter account number
		sendText(CustomerService.Locator_TextField_ExternalAccount_FullAccountNumber, CustomerService.Text_ExternalAccount_NewAccountNumber);
		sendText(CustomerService.Locator_TextField_ExternalAccount_ConfirmAccountNumber, CustomerService.Text_ExternalAccount_NewAccountNumber);

		//enter routing number
		sendText(CustomerService.Locator_TextField_ExternalAccount_RoutingNumber, CustomerService.Text_ExternalAccount_NewAccountRouting);
		sendText(CustomerService.Locator_TextField_ExternalAccount_ConfirmRountingNumber, CustomerService.Text_ExternalAccount_NewAccountRouting);

		//enter nickname
		sendText(CustomerService.Locator_TextField_ExternalAccount_AddNewAccountNickname, CustomerService.Text_ExternalAccount_NewAccountNickname + String.format("%05d", randomizer.nextInt(100000)));

	}


	/**
	 * Confirm the information from external account creation
	 */
	public void confirmExternalPaymentAccount() {

		//Confirm stored Account information is the same as is on screen
		we = confirmElementExistence(CustomerService.Locator_Text_ExternalAccount_FullAccountNumberConfirm);
		ss.assertTrue(we.getText().contains(CustomerService.Text_ExternalAccount_NewAccountNumber));

		//Confirm stored Routing number is the same as on screen
		we = confirmElementExistence(CustomerService.Locator_Text_ExternalAccount_RoutingNumberConfirm);
		ss.assertTrue(we.getText().contains(CustomerService.Text_ExternalAccount_NewAccountRouting));

		//Confirm stored Nickname is the same as on screen
		we = confirmElementExistence(CustomerService.Locator_Text_ExternalAccount_NicknameConfirm);
		ss.assertTrue(we.getText().contains(CustomerService.Text_ExternalAccount_NewAccountNickname));

	}


	/**
	 * Confirm successfully landed on external account creation summary page and double verify information
	 */
	public void confirmExternalPaymentAccountSummary() {

		//Confirm confirmation banner is displayed
		we = confirmElementExistence(CustomerService.Locator_Text_ExternalAccount_ConfirmationMessage);
		ss.assertTrue(we.getText().contains(CustomerService.Text_ExternalAccount_ConfirmationMessage));

		//Confirm stored Account information is the same as is on screen
		we = confirmElementExistence(CustomerService.Locator_Text_ExternalAccount_SummeryAccountNumber);
		ss.assertTrue(we.getText().contains(CustomerService.Text_ExternalAccount_NewAccountNumber));

		//Confirm stored Routing number is the same as on screen
		we = confirmElementExistence(CustomerService.Locator_Text_ExternalAccount_SummeryRoutingNumber);
		ss.assertTrue(we.getText().contains(CustomerService.Text_ExternalAccount_NewAccountRouting));

		//Confirm stored Nickname is the same as on screen
		we = confirmElementExistence(CustomerService.Locator_Text_ExternalAccount_SummeryNickname
				);
		ss.assertTrue(we.getText().contains(CustomerService.Text_ExternalAccount_NewAccountNickname));

	}


	/**
	 * Delete an external account for credit card payment. Will delete the first Account in the list.
	 */
	public void deleteExternalPaymentAccount() {

		navigateToManagePaymentAccounts();
		setDropdownByIndex(CustomerService.Locator_DropDown_ManageAccountActionsFirst, CustomerService.Text_Index_DeleteAccountIndex);
		clickElement(CustomerService.Locator_Button_ManageAccountsActionsGoButtonFirst);
		clickElement(CustomerService.Locator_Button_DeletePaymentAccountConfirmButton);

		//Confirm Account has been Deleted Successfully
		we = confirmElementExistence(CustomerService.Locator_Text_DeletePaymentAccountConfirmBanner);
		ss.assertTrue(we.getText().contains(CustomerService.Text_DeletePaymentAccount_DeletePaymentAccountConfirmMessage));

	}


	/**
	 * Navigate to Manage Payment Accounts.
	 */
	public void navigateToManagePaymentAccounts() {

		clickElement(Common.Locator_Header_Button_CustomerServiceTab);
		clickElement(CustomerService.Locator_LeftNav_Button_CreditCardServices);
		clickElement(CustomerService.Locator_Link_ManagePaymentAccount);

	}


	/**
	 * Fully creates and confirms an external account for a user from the home page.
	 */
	public void createPaymentAccountFromHomePage() {

		navigateToManagePaymentAccounts();
		clickElement(CustomerService.Locator_Link_AddPaymentAccount);
		addExternalPaymentAccount();
		clickElement(CustomerService.Locator_Button_ExternalAccount_AddNewAccountContinueButton);
		confirmExternalPaymentAccount();
		clickElement(CustomerService.Locator_Button_ExternalAccount_AddNewAccountConfirmButton);
		confirmExternalPaymentAccountSummary();

	}

	/* CUSTOMER SERVICE - END */


	/* TRANSFER FUNDS - START */

	/**
	 * check error conditions
	 */
	public void checkErrorCondition(By errorLocator) {

		submitTransfer();
		confirmElementExistence(errorLocator);

	}


	/**
	 * Select account to receive money to
	 */
	public void setToAccount_Transfer(String partialTextKey) {

		setDropdownByPartialVisibleText(Transfer.Locator_DropDown_AccountTo, partialTextKey);

	}


	/**
	 * Select account to receive money to
	 */
	public void setFromAccount_Transfer(String partialTextKey) {

		setDropdownByPartialVisibleText(Transfer.Locator_DropDown_AccountFrom, partialTextKey);

	}


	/**
	 * Enter amount to transfer
	 */
	public String enterTransferAmount(String paymentAmount) {

		amount = String.format("%.2f", Float.parseFloat(paymentAmount)/((998.0 * pass) + 1) );
		System.out.format("Pass #%d, Entering: %s%n", pass, amount);
		sendText_staleSafe(Transfer.Locator_TextField_TransferAmount, amount);
		pass++;
		return amount;

	}


	/**
	 * Select one time transfer frequency from dropdown
	 */
	public void setTransferFrequency(String transferTypeKey) {

		setDropdownByVisibleText(Transfer.Locator_DropDown_Frequency, transferTypeKey);

	}


	/**
	 * Click continue
	 */
	public void submitTransfer() {

		clickElement(Transfer.Locator_Button_Select);
		clickElement(Common.Locator_Button_Continue);

	}


	/**
	 * Click and verify confirm details
	 */
	public void confirmTransfer() {

		confirmTextValue(Transfer.Locator_TextContainer_BreadCrumb_Active, Transfer.Text_BreadCrumb_ConfirmDetails);
		confirmTextValue(By.xpath(Transfer.CompoundLocator_TextContainer_TransferConfirmations.replace(compoundPlaceholder, Transfer.Text_TransferConfirmation_Amount)), amount);
		clickElement(Common.Locator_ConfirmDetails_Button_Confirm);

	}


	/**
	 * View changes on summary page
	 */
	public void confirmSummaryPage() {

		confirmTextValue(Transfer.Locator_TextContainer_BreadCrumb_Active, Transfer.Text_BreadCrumb_Summary);
		confirmElementExistence(Transfer.Text_TransactionCompletedConfirmation);
		confirmTextValue(By.xpath(Transfer.CompoundLocator_TextContainer_TransferConfirmations.replace(compoundPlaceholder, Transfer.Text_TransferConfirmation_Amount)), amount);

	}


	/**
	 * View changes on summary page
	 */
	public void confirmSummaryPage(By confirmationElementKey) {

		//confirmElementExistence(Common.Locator_SubTitle_Summary);
		confirmElementExistence(confirmationElementKey);
		//confirmDynamicTextValue(Transfer.Locator_TextContainer_TransferConfirmation_Amount, Transfer.Text_TransferConfirmation_Amount, amount);

	}


	/**
	 * View changes on summary page
	 */
	public void enterTransferDate(String date) {

		sendText(Transfer.Locator_TextField_Date_Month, date.substring(0, 2));
		sendText(Transfer.Locator_TextField_Date_Day, date.substring(3, 5));
		sendText(Transfer.Locator_TextField_Date_Year, date.substring(6));
	}


	/**
	 * Confirm Transfer Funds page
	 */
	public void confirmTransferPage() {

		confirmElementExistence(Transfer.Locator_LeftNav_Button_Transfer_Active);
		confirmElementExistence(Transfer.Locator_Transfer_BetweenMySantanderAccounts_Active);
		confirmElementExistence(Transfer.Locator_Transfer_ToSomeonElse);
		confirmTextValue(Transfer.Locator_TextContainer_BreadCrumb_Active, Transfer.Text_BreadCrumb_EnterDetails);
		confirmTextValue(Transfer.Locator_TextContainer_Transfer_SegmentTitle, Transfer.Text_Transfer_SegmentTitle);
		confirmElementExistence(Transfer.Locator_Button_Select);
		confirmElementExistence(Common.Locator_Button_Continue);

	}


	/**
	 * Confirm Modify Transfer Funds page
	 */
	public void confirmModifyTransferPage() {

		confirmElementExistence(Transfer.Locator_LeftNav_Button_PendingTransfer_Active);
		confirmTextValue(Transfer.Locator_TextContainer_ModifyTransfer_Title, Transfer.Text_ModifyTransfer_Title);
		confirmTextValue(Transfer.Locator_TextContainer_Transfer_SegmentTitle, Transfer.Text_Transfer_SegmentTitle);
		//confirmElementExistence(Transfer.Locator_Button_Select);

	}


	/**
	 * confirm changes on pending transactions
	 */
	public void navigateToPendingTransferPage() {

		clickElement(Common.Locator_Header_Button_TransferTab);
		clickElement(Transfer.Locator_LeftNav_Button_PendingTransfer);

	}


	/**
	 * confirm transaction is pending
	 */
	public void confirmPendingTransferPage(String date, String frequency) {

		// should be using confirmDynamicText()
		System.out.println("DEBUg: values all good" +frequency+" "+amount+" "+date);
		we = confirmTextValue(Transfer.Locator_PendingTransfer_TransferDate, date);
		System.out.println("DEBUg: date all good" +date);
		//this.ss.assertTrue(we.getText().contains(date));
		we = confirmTextValue(Transfer.Locator_PendingTransfer_Amount, amount);
		System.out.println("DEBUg: ammoutn all good" +amount);
		//this.ss.assertTrue(we.getText().contains(amount));
		we = confirmTextValue(Transfer.Locator_PendingTransfer_Frequency, frequency);
		//this.ss.assertTrue(we.getText().contains(frequency));
		System.out.println("DEBUg: frequency all good" +frequency);
	}


	/**
	 * pending transfers
	 */
	public void pendingTransfer(String date, String frequency) {

		navigateToPendingTransferPage();
		//confirmPendingTransferPage(date, frequency);
	}


	/**
	 * delete transfers
	 */
	public void deleteTransfer() {

		//add validation for clicks on navigate to pending transfer page
		navigateToPendingTransferPage();
		setDropdownByVisibleText(Transfer.Locator_PendingTransfer_Actions_Dropdown, Transfer.Text_PendingTransfer_Actions_DeleteTransfer);
		clickElement(Transfer.Locator_PendingTransfer_Button_Go);
		confirmTransfer();
		confirmSummaryPage(Transfer.Locator_Text_TransferDeletedConfirmation);

	}


	/**
	 * modify transfers page
	 */
	public void modifyTransfer() {

		navigateToPendingTransferPage();
		setDropdownByVisibleText(Transfer.Locator_PendingTransfer_Actions_Dropdown, Transfer.Text_PendingTransfer_Actions_ModifyTransfer);
		clickElement(Transfer.Locator_PendingTransfer_Button_Go);

	}

	/* TRANSFER FUNDS - END */


	/* ALERTS - START */

	/**
	 * Activating sms alerts if not already activated
	 */
	public void activateAlerts() {

		confirmElementExistence(Alerts.Locator_Text_NotActivatedAlerts);
		clickElement(Alerts.Locator_Button_Activate);
		confirmElementExistence(Alerts.Locator_Title_ActivateAlertsService);

	}


	/**
	 * Click on Enable/Disable SMS
	 */
	public void enableDisableSMS() {

		clickElement(Alerts.Locator_Button_EnableSMS);

	}


	/**
	 * Update your contact details
	 */
	public void updateContactDetails() {

		clickElement(Alerts.Locator_Link_UpdateYourContactDetails);
		confirmElementExistence(Alerts.Locator_ManageContactDetails_Title_ManageContactDetials);

	}


	/**
	 * Add contact details from Manage Contact Details page
	 */
	public void addContactFromManageContact() {

		clickElement(Alerts.Locator_ManageContactDetails_AddContactDetail);
		confirmElementExistence(Alerts.Locator_ManageContactDetails_AddContactDetail);

	}


	/**
	 * Enter new contact details on Add contact details page
	 */
	public void addTelephoneToPersonalContact() {

		setDropdownByValue(Alerts.Locator_AddContactDetails_TypeDropdown, Alerts.Locator_AddContactDetails_Type_Dropdown_Telephone);
		setDropdownByValue(Alerts.Locator_AddContactDetails_DescriptionDropdown, Alerts.Locator_AddContactDetails_Description_Dropdown_Personal);
		sendText(Alerts.Locator_AddContactDetails_NumberEmailAddress_TextField_NumberEmail, Alerts.Locator_AddContactDetails_NumberEmailAddress_Text_PerNumber);
		clickElement(Alerts.Locator_AddContactDetails_Preferred_RadioButton_Yes);
		clickElement(Common.Locator_Button_Continue);
		confirmChanges();

	}


	/**
	 * Enter new contact details on Add contact details page
	 */
	public void addTelephoneToBusinessContact() {

		setDropdownByValue(Alerts.Locator_AddContactDetails_TypeDropdown, Alerts.Locator_AddContactDetails_Type_Dropdown_Telephone);
		setDropdownByValue(Alerts.Locator_AddContactDetails_DescriptionDropdown, Alerts.Locator_AddContactDetails_Description_Dropdown_Business);
		sendText(Alerts.Locator_AddContactDetails_NumberEmailAddress_TextField_NumberEmail, Alerts.Locator_AddContactDetails_NumberEmailAddress_Text_BusNumber);
		clickElement(Alerts.Locator_AddContactDetails_Preferred_RadioButton_Yes);
		clickElement(Common.Locator_Button_Continue);
		confirmChanges();

	}


	/**
	 * Enter new contact details on Add contact details page
	 */
	public void addCellPhoneToPersonalContact() {

		setDropdownByValue(Alerts.Locator_AddContactDetails_TypeDropdown, Alerts.Locator_AddContactDetails_Type_Dropdown_CellPhone);
		setDropdownByValue(Alerts.Locator_AddContactDetails_DescriptionDropdown, Alerts.Locator_AddContactDetails_Description_Dropdown_Personal);
		sendText(Alerts.Locator_AddContactDetails_NumberEmailAddress_TextField_NumberEmail, Alerts.Locator_AddContactDetails_NumberEmailAddress_Text_PerNumber);
		clickElement(Alerts.Locator_AddContactDetails_Preferred_RadioButton_Yes);
		clickElement(Common.Locator_Button_Continue);
		confirmChanges();

	}


	/**
	 * Enter new contact details on Add contact details page
	 */
	public void addCellPhoneToBusinessContact() {

		setDropdownByValue(Alerts.Locator_AddContactDetails_TypeDropdown, Alerts.Locator_AddContactDetails_Type_Dropdown_CellPhone);
		setDropdownByValue(Alerts.Locator_AddContactDetails_DescriptionDropdown, Alerts.Locator_AddContactDetails_Description_Dropdown_Business);
		sendText(Alerts.Locator_AddContactDetails_NumberEmailAddress_TextField_NumberEmail, Alerts.Locator_AddContactDetails_NumberEmailAddress_Text_BusNumber);
		clickElement(Alerts.Locator_AddContactDetails_Preferred_RadioButton_Yes);
		clickElement(Common.Locator_Button_Continue);
		confirmChanges();

	}


	/**
	 * Enter new contact details on Add contact details page
	 */
	public void addEmailToPersonalContact() {

		setDropdownByValue(Alerts.Locator_AddContactDetails_TypeDropdown, Alerts.Locator_AddContactDetails_Type_Dropdown_Email);
		setDropdownByValue(Alerts.Locator_AddContactDetails_DescriptionDropdown, Alerts.Locator_AddContactDetails_Description_Dropdown_Personal);
		sendText(Alerts.Locator_AddContactDetails_NumberEmailAddress_TextField_NumberEmail, Alerts.Locator_AddContactDetails_NumberEmailAddress_Text_PerEmail);
		clickElement(Alerts.Locator_AddContactDetails_Preferred_RadioButton_Yes);
		clickElement(Common.Locator_Button_Continue);
		confirmChanges();

	}


	/**
	 * Enter new contact details on Add contact details page
	 */
	public void addEmailToBusinessContact() {

		setDropdownByValue(Alerts.Locator_AddContactDetails_TypeDropdown, Alerts.Locator_AddContactDetails_Type_Dropdown_Email);
		setDropdownByValue(Alerts.Locator_AddContactDetails_DescriptionDropdown, Alerts.Locator_AddContactDetails_Description_Dropdown_Business);
		sendText(Alerts.Locator_AddContactDetails_NumberEmailAddress_TextField_NumberEmail, Alerts.Locator_AddContactDetails_NumberEmailAddress_Text_BusEmail);
		clickElement(Alerts.Locator_AddContactDetails_Preferred_RadioButton_Yes);
		clickElement(Common.Locator_Button_Continue);
		confirmChanges();

	}


	/**
	 * Confirm from content of Alerts page
	 */
	public void confirmAlertsPage() {

		// fail quick if data is not properly prepared
		ss.assertTrue(jseExecuteBoolean(Alerts.Script_Boolean_ElementNotHasAttributeChecked, Alerts.Locator_CheckBox_InternationalTransaction_Enable), "Test data misconfigured.");

		// help with this page link
		confirmElementExistence(Alerts.Locator_Link_HelpWithThisPage);

		// form title
		confirmTextValue(Alerts.Locator_TextContainer_FormTitle, Alerts.Text_FormTitle);

		// activate cell phone link
		confirmElementExistence(Alerts.Locator_Link_ActivateCellPhoneNumber);

		// Contact Preferences segment title
		confirmTextValue(Alerts.Locator_TextContainer_SectionTitle_ContactPreferences, Alerts.Text_SectionTitle_ContactPreferences);

		// extract email address
		email_Alerts = confirmElementExistence(Alerts.Locator_TextContainer_ContactPreferences_Email).getText();

		// cell phone mask(?)
		String phoneMasked = confirmElementExistence(Alerts.Locator_TextContainer_ContactPreferences_CellPhoneNumber).getText();

		if (!phoneMasked.contains(Alerts.Text_ActivateCellPhone)) {
			match_Alerts = pattern_Alerts.matcher(phoneMasked);
			ss.assertTrue(match_Alerts.find(), String.format("Phone number <%s> masked?: %s", phoneMasked, match_Alerts.find()));
		}

		// change contact preferences link
		confirmElementExistence(Alerts.Locator_Link_ClickHere_ChangeContactPreferences);

		// segment headers
		confirmMultiElementText(Alerts.MultiLocator_TextContainer_SubSectionTitles, Alerts.MultiText_SubSectionTitles);

		// fraud alerts, account update, contact change
		confirmMultiElementText(Alerts.MultiLocator_TextContainer_AutoNotificationTypes, Alerts.MultiText_AutoNotificationTypes);

		// check for SMS enabled/disabled indicator image and get src
		we = smartScroll(Alerts.Locator_Image_SMSEnabledDisabled);
		String imageSrc = we.getAttribute("src");

		// if src indicates enabled, check button text for disable que
		if (imageSrc.contains(Alerts.Text_Image_SMSEnabled)) {
			confirmTextValue(Alerts.Locator_Button_SMSEnableDisable, Alerts.Text_Button_SMSDisabled);
		}

		// if src indicates disabled, check button text for enable que
		if (imageSrc.contains(Alerts.Text_Image_SMSDisabled)) {
			confirmTextValue(Alerts.Locator_Button_SMSEnableDisable, Alerts.Text_Button_SMSEnabled);
		}

		// accounts tab - active
		confirmElementExistence(Alerts.Locator_Link_Accounts_Active);

		// credit cards tab - inactive
		confirmElementExistence(Alerts.Locator_Link_CreditCards);

		// Statements tab - inactive
		confirmElementExistence(Alerts.Locator_Link_Statements);

		// Security tab - inactive
		confirmElementExistence(Alerts.Locator_Link_Security);

		// Account number dropdown
		we = confirmElementExistence(Alerts.Locator_DropDown_AccountNumber);

		// get current selected last4 (*####) from dropdown
		Select sel = new Select(we);
		account = sel.getFirstSelectedOption().getText();
		account = account.substring(account.indexOf("*"));

		// Go button
		confirmElementExistence(Alerts.Locator_Button_Go);

		// table column names
		confirmMultiElementText(Alerts.MultiLocator_TextContainer_TableHeaders, Alerts.MultiText_TableHeaders);

		// Accounts
		// alerts configuration segments
		weArray = confirmElementsExistence(Alerts.MultiLocator_AlertOptions);

		for (WebElement w: weArray) {
			confirmElementExistence(w, Alerts.Locator_AlertOption_CheckBox_GENERIC_Enable);
			confirmElementExistence(w, Alerts.Locator_AlertOption_TextContainer_GENERIC_NotifyMe);
			confirmElementExistence(w, Alerts.Locator_AlertOption_CheckBox_GENERIC_DeliveryMethod_Email);
			confirmElementExistence(w, Alerts.Locator_AlertOption_CheckBox_GENERIC_DeliveryMethod_SMS);
		}

		// restore button
		smartScroll(Alerts.Locator_Button_Restore);

		// update button
		confirmElementExistence(Alerts.Locator_Button_Update);

		// footer link: view
		confirmElementExistence(Alerts.Locator_Link_ViewAlertsHistory);

		// footer link: change status
		confirmElementExistence(Alerts.Locator_Link_ChangeAlertsStatus);

		// footer link: change profile
		confirmElementExistence(Alerts.Locator_Link_ChangeAlertsProfile);

		// Credit Cards
		smartScroll(Alerts.Locator_Link_CreditCards);
		clickElement(Alerts.Locator_Link_CreditCards);

		// tab link states
		confirmElementExistence(Alerts.Locator_Link_Accounts);
		confirmElementExistence(Alerts.Locator_Link_CreditCards_Active);
		confirmElementExistence(Alerts.Locator_Link_Statements);
		confirmElementExistence(Alerts.Locator_Link_Security);

		// alerts configuration segments
		weArray = confirmElementsExistence(Alerts.MultiLocator_AlertOptions);

		for (WebElement w: weArray) {
			confirmElementExistence(w, Alerts.Locator_AlertOption_CheckBox_GENERIC_Enable);
			confirmElementExistence(w, Alerts.Locator_AlertOption_TextContainer_GENERIC_NotifyMe);
			confirmElementExistence(w, Alerts.Locator_AlertOption_CheckBox_GENERIC_DeliveryMethod_Email);
			confirmElementExistence(w, Alerts.Locator_AlertOption_CheckBox_GENERIC_DeliveryMethod_SMS);
		}

		// footer link: view
		confirmElementExistence(Alerts.Locator_Link_ViewAlertsHistory);

		// footer link: change status
		confirmElementExistence(Alerts.Locator_Link_ChangeAlertsStatus);

		// footer link: change profile
		confirmElementExistence(Alerts.Locator_Link_ChangeAlertsProfile);

		// Statements
		smartScroll(Alerts.Locator_Link_Statements);
		clickElement(Alerts.Locator_Link_Statements);

		confirmElementExistence(Alerts.Locator_Link_Accounts);
		confirmElementExistence(Alerts.Locator_Link_CreditCards);
		confirmElementExistence(Alerts.Locator_Link_Statements_Active);
		confirmElementExistence(Alerts.Locator_Link_Security);
		alertsConfigSection();

		// Security
		smartScroll(Alerts.Locator_Link_Security);
		clickElement(Alerts.Locator_Link_Security);

		confirmElementExistence(Alerts.Locator_Link_Accounts);
		confirmElementExistence(Alerts.Locator_Link_CreditCards);
		confirmElementExistence(Alerts.Locator_Link_Statements);
		confirmElementExistence(Alerts.Locator_Link_Security_Active);
		alertsConfigSection();

		// return to Accounts
		smartScroll(Alerts.Locator_Link_Accounts);
		clickElement(Alerts.Locator_Link_Accounts);
		waitForPageCompletelyLoaded();

	}


	/**
	 * Check for the contents of the alerts configuration table
	 */
	private void alertsConfigSection() {

		// alerts configuration segments
		weArray = confirmElementsExistence(Alerts.MultiLocator_AlertOptions);

		// check each segment for enable checkbox, Notify text container, email and SMS checkboxes
		for (WebElement w: weArray) {
			confirmElementExistence(w, Alerts.Locator_AlertOption_CheckBox_GENERIC_Enable);
			confirmElementExistence(w, Alerts.Locator_AlertOption_TextContainer_GENERIC_NotifyMe);
			confirmElementExistence(w, Alerts.Locator_AlertOption_CheckBox_GENERIC_DeliveryMethod_Email);
			confirmElementExistence(w, Alerts.Locator_AlertOption_CheckBox_GENERIC_DeliveryMethod_SMS);
		}

		// restore button
		smartScroll(Alerts.Locator_Button_Restore);

		// update button
		confirmElementExistence(Alerts.Locator_Button_Update);

		// footer link: view
		confirmElementExistence(Alerts.Locator_Link_ViewAlertsHistory);

		// footer link: change status
		confirmElementExistence(Alerts.Locator_Link_ChangeAlertsStatus);

		// footer link: change profile
		confirmElementExistence(Alerts.Locator_Link_ChangeAlertsProfile);

	}


	/**
	 * Manage alerts: activate the alert and email for balance less than zero
	 */
	public void enableInternationalTransactionAlert() {

		// count enabled alert types
		int initialEnabledCount = jseExecuteInteger(Alerts.Script_Integer_CountAllEnabledAlerts);

		// scroll to and enable balance International Transaction alert
		we = smartScroll(Alerts.Locator_CheckBox_InternationalTransaction_Enable);
		jseExecuteVoid(Alerts.Script_Void_Click, we);
		confirmElementExistence(Alerts.Locator_CheckBox_InternationalTransaction_Enable_Checked);

		// enable balance International Transaction email
		we = confirmElementExistence(Alerts.Locator_CheckBox_InternationalTransaction_Email);
		jseExecuteVoid(Alerts.Script_Void_Click, we);
		confirmElementExistence(Alerts.Locator_CheckBox_InternationalTransaction_Email_Checked);

		// count enabled alert types, assert one was added
		adjustedEnabledCount = jseExecuteInteger(Alerts.Script_Integer_CountAllEnabledAlerts);
		ss.assertTrue(adjustedEnabledCount == (initialEnabledCount + 1), String.format("Expected %d, found %d.%n", adjustedEnabledCount, initialEnabledCount+1));

		// scroll to and click update button
		smartScroll(Alerts.Locator_Button_Update);
		clickElement(Alerts.Locator_Button_Update);

	}


	/**
	 * confirm selected alert has check mark on the confirm details page
	 */
	public void confirmDetails_Alerts() {

		// form title
		confirmTextValue(Alerts.Locator_TextContainer_FormTitle, Alerts.Text_Details_FormTitle);

		// bread crumb
		confirmTextValue(Alerts.Locator_TextContainer_BreadCrumb, Alerts.Text_Details_BreadCrumb);

		// confirm table content
		confirmAlertDetails(false);

		// cancel button
		confirmElementExistence(Alerts.Locator_Button_Details_Cancel);

		// confirm button
		smartScroll(Alerts.Locator_Button_Details_Confirm);

		// click confirm
		clickElement(Alerts.Locator_Button_Details_Confirm);

	}


	/**
	 * Confirm appropriate Summary page validations, according to reversion status (true|false)
	 *
	 * @param revert (Boolean) are details checks for reversion?
	 */
	private void confirmSummary(Boolean revert) {

		// print link
		confirmElementExistence(Alerts.Locator_Link_Summary_Print);

		// form title
		confirmTextValue(Alerts.Locator_TextContainer_FormTitle, Alerts.Text_Summary_FormTitle);

		// bread crumb
		confirmTextValue(Alerts.Locator_TextContainer_BreadCrumb, Alerts.Text_Summary_BreadCrumb);

		// confirmation message
		confirmTextValue(Alerts.Locator_Text_AlertsUpdatedSuccess, Alerts.Text_Summary_SuccessMessage);

		// confirm table details
		confirmAlertDetails(revert);

	}


	/**
	 * Confirm Summary page reflects enabled alerts
	 */
	public void confirmSummaryPageUpdated() {

		// confirm summary page has been updated
		confirmSummary(false);

	}


	/**
	 * confirm table content common to details and summary page
	 */
	private void confirmAlertDetails(Boolean revert) {

		// account number match
		confirmTextValue(Alerts.Locator_TextContainer_Details_AccountNumber, account);

		// segment title
		confirmTextValue(Alerts.Locator_TextContainer_Details_SegmentTitle, Alerts.Text_Details_SegmentTitle);

		// table headers
		confirmMultiElementText(Alerts.MultiLocator_TextContainer_TableHeaders, Alerts.MultiText_TableHeaders);

		// checked count
		int enabledAlerts = confirmElementsExistenceOrNone(Alerts.Locator_Image_InternationalTransaction_Check).size();
		ss.assertTrue(adjustedEnabledCount == enabledAlerts, String.format("Expected %d, found %d.%n", adjustedEnabledCount, enabledAlerts));

		if (!revert) {

			// International Transaction checked
			confirmElementExistence(Alerts.Locator_Image_InternationalTransaction_Check);

			// email match
			confirmTextValue(Alerts.Locator_TextContainer_InternationalTransaction_Delivery, email_Alerts);

		} else {

			// International Transaction checked
			confirmElementExistence(Alerts.Locator_Image_InternationalTransaction_Unchecked);

			// email match
			confirmNotTextValue(Alerts.Locator_TextContainer_InternationalTransaction_Delivery, email_Alerts);

		}

		// back link
		confirmElementExistence(Alerts.Locator_Link_Back);

	}


	/**
	 * tRevert changes made for alerts
	 */
	public void revertChanges_Alerts() {

		// scroll to and click back to alerts link
		we = smartScroll(Alerts.Locator_Link_Back);
		navigateToMainTab(Alerts.Locator_Link_Back, Alerts.Locator_CheckBox_InternationalTransaction_Enable);

		// confirm enabled alerts count
		int initialEnabledCount = jseExecuteInteger(Alerts.Script_Integer_CountAllEnabledAlerts);
		ss.assertTrue(initialEnabledCount == adjustedEnabledCount, String.format("Expected %d, found %d.%n", adjustedEnabledCount, initialEnabledCount));

		// confirm International Transaction enabled
		ss.assertTrue(jseExecuteBoolean(Alerts.Script_Boolean_CheckedAndAttributeCheckedIsChecked, Alerts.Locator_CheckBox_InternationalTransaction_Enable), "Unexpectedly disabled.");

		// disable International Transaction checkbox
		jseExecuteVoid(Alerts.Script_Void_Click, Alerts.Locator_CheckBox_InternationalTransaction_Enable);
		ss.assertTrue(jseExecuteBoolean(Alerts.Script_Boolean_NotCheckedAndNoCheckedClass, Alerts.Locator_CheckBox_InternationalTransaction_Enable), "Could not disable alert.");

		// confirm International Transaction email enabled
		confirmElementExistence(Alerts.Locator_CheckBox_InternationalTransaction_Email_Checked);

		// disable International Transaction email checkbox
		clickElement(Alerts.Locator_CheckBox_InternationalTransaction_Email);

		// count enabled alert types, assert one was added
		adjustedEnabledCount = jseExecuteInteger(Alerts.Script_Integer_CountAllEnabledAlerts);
		ss.assertTrue(adjustedEnabledCount == (initialEnabledCount - 1), String.format("Expected %d, found %d.%n", initialEnabledCount-1, adjustedEnabledCount));

		// click update button
		clickElement(Alerts.Locator_Button_Update);

		// confirm details
		confirmAlertDetails(true);

		// click confirm button
		clickElement(Alerts.Locator_Button_Details_Confirm);

		// confirm summary page reversion
		confirmSummary(true);

	}


	/**
	 * confirm unselected alert has red x mark on the confirm details page
	 */
	public void alertActivatedXMarkConfirm() {

		confirmElementExistence(Alerts.Locator_Image_InternationalTransaction_Unchecked);

	}


	/**
	 * confirm changes on confirm details and summary page
	 */
	public void confirmChanges() {

		confirmTextValue(Common.Locator_TextContainer_BreadCrumb_Active, Common.Text_BreadCrumb_ConfirmDetails);
		clickElement(Common.Locator_ConfirmDetails_Button_Confirm);

		confirmTextValue(Common.Locator_TextContainer_BreadCrumb_Active, Common.Text_BreadCrumb_Summary);

	}


	/**
	 * after making changes, scroll down to click confirm button
	 */
	public void clickConfirmButton() {

		smartScroll(Common.Locator_ConfirmDetails_Button_Confirm);
		clickElement(Common.Locator_ConfirmDetails_Button_Confirm);

	}

	/* ALERTS - END */

	/* ACCOUNTS - START */

	/**
	 * Confirm existence of top navigation buttons (tabs)
	 */
	public void confirmLeftNavigation() {

		confirmTextValue(Accounts.Locator_LeftNav_TextContainer_Title, Accounts.Text_LeftNav_Title);
		confirmElementExistence(Accounts.Locator_LeftNav_Button_OverviewTab);
		confirmElementExistence(Accounts.Locator_LeftNav_Button_AccountDetailsAndActivityTab);
		confirmElementExistence(Accounts.Locator_LeftNav_Button_AccountServicesTab);
		confirmElementExistence(Accounts.Locator_LeftNav_Button_ATMAndDebitCardServicesTab);
		confirmElementExistence(Accounts.Locator_LeftNav_Button_StatementsAndDocumentsTab);
		confirmElementExistence(Accounts.Locator_LeftNav_Button_AlertsTab);

		ss.takeScreenShot();

	}


	/**
	 * Confirm existence of help with this page link
	 */
	public void confirmHelpWithThisPageLink() {

		//System.out.format("[LOG]: <[%s:%s] confirm Help with this page link.>%n", id, testName);
		confirmElementExistence(Accounts.Locator_Overview_Link_HelpWithThisPage);
		ss.takeScreenShot();

	}


	/**
	 * Confirm existence of print link
	 */
	public void confirmPrintLink_Accounts() {

		//System.out.format("[LOG]: <[%s:%s] confirm print link.>%n", id, testName);
		confirmElementExistence(Accounts.Locator_Overview_Link_Print);
		ss.takeScreenShot();

	}


	/**
	 * Confirm form title
	 */
	public void confirmFormTitle() {

		confirmTextValue(Accounts.Locator_Overview_TextContainer_Title, Accounts.Text_Overview_Title);

	}


	/**
	 * Confirm Overview content header
	 */
	public void confirmContentHeader_Accounts() {

		confirmTextValue(Accounts.Locator_Overview_TextContainer_Header_Title, Accounts.Text_Overview_Header_Title);
		confirmElementExistence(Accounts.Locator_Overview_Link_Header_ShowHide);

	}


	/**
	 * Confirm Overview content footer
	 */
	public void confirmContentBody() {

		confirmContentTableColumnNames();
		/*
		 * TODO: account line-level confirmations?
		 * -Account name
		 * -account number [format]
		 * -available balance [format]
		 * -current balance [format]
		 * -actions-dropdown (entries)
		 * -actions-gobutton
		 */

	}


	/**
	 * Confirm Overview content footer
	 */
	public void confirmContentFooter() {

		confirmTextValue(Accounts.Locator_Overview_TextContainer_Paginator_Numbers, Accounts.Text_Overview_Paginator_Numbers);

	}


	/**
	 * Pulls content table column names, compares against
	 */
	public void confirmContentTableColumnNames() {

		if ((weArray = confirmElementsExistence(Accounts.MultiLocator_Overview_TextContainer_CheckingTableColumns)).size() > 0) {
			confirmMultiElementText(Accounts.MultiLocator_Overview_TextContainer_CheckingTableColumns, Accounts.MultiText_Overview_CheckingTableColumns);
		}

		if ((weArray = confirmElementsExistence(Accounts.MultiLocator_Overview_TextContainer_CreditCardsTableColumns)).size() > 0) {
			confirmMultiElementText(Accounts.MultiLocator_Overview_TextContainer_CreditCardsTableColumns, Accounts.MultiText_Overview_CreditCardsTableColumns);
		}

	}

	/* ACCOUNTS - END */


}
