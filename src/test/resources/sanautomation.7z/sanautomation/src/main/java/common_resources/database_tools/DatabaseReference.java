package common_resources.database_tools;

public class DatabaseReference {


	// #com.santander.Base.PageObjects.ROB.Common: for database access
	public final static String jdbcClassName = "com.ibm.db2.jcc.DB2Driver";
	public final static String url = "jdbc:db2://vipaddes.mx.sov.pre.corp:5002/DSQG";
	public final static String user = "DESJDM";
	public final static String password = "QA987654";

	// #com.santander.Base.DatabaseToos.LDAPQuery: for LDAP access
	public final static String ldapFactory = "com.sun.jndi.ldap.LdapCtxFactory";
	public final static String ldapURL = "ldap://ldap.mx.sov.pre.corp:2389";
	public final static String ldapPass = "RBKS2010";
	public final static String ldapContext = "ou=Usuarios,cn=Particulares,o=BanksphereInternet,o=Sovereign,c=US,o=Grupo Santander";


}
