package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class BillPay {


//	public static By CompoundLocator_PaymentCenter_TextContainer_RightAccordion_PendingPayments_PaymentAmount =		By.xpath("//a[starts-with(@id, 'amt-col-minimodule-')]/span[@class='pmt-amt' and contains(text(),'~~~')]"); //now String
	public static By Locator_Header_Button_BillPayTab =																By.cssSelector("a[alt=BillPay]");
	public static By Locator_Header_Button_BillPayTab_Active =														By.cssSelector("li.activo a[alt=BillPay]");
	public static By Locator_LeftNav_Button_Activity =																By.xpath("//a[contains(@class,'maintabs') and contains(text(),'Activity')]");
	public static By Locator_LeftNav_Button_Activity_Active =														By.xpath("//li[contains(@class,'active')]//a[contains(@class,'maintabs') and contains(text(),'Activity')]");
	public static By Locator_LeftNav_Button_Help =																	By.xpath("//a[contains(@class,'maintabs') and contains(text(),'Help')]");
	public static By Locator_LeftNav_Button_Help_Active =															By.xpath("//li[contains(@class,'active')]//a[contains(@class,'maintabs') and contains(text(),'Help')]");
	public static By Locator_LeftNav_Button_Messages =																By.xpath("//a[contains(@class,'maintabs') and contains(text(),'Messages')]");
	public static By Locator_LeftNav_Button_Messages_Active =														By.xpath("//li[contains(@class,'active')]//a[contains(@class,'maintabs') and contains(text(),'Messages')]");
	public static By Locator_LeftNav_Button_PaymentCenter =															By.xpath("//a[contains(@class,'maintabs') and contains(text(),'Payment Center')]");
	public static By Locator_LeftNav_Button_PaymentCenter_Active =													By.xpath("//li[contains(@class,'active')]//a[contains(@class,'maintabs') and contains(text(),'Payment Center')]");
	public static By Locator_LeftNav_TextContainer_Title =															By.cssSelector("span.billpayIcon");
	public static By Locator_PaymentCenter_Button_AddCompanyPerson =												By.cssSelector("a#btnAddPayee");
	public static By Locator_PaymentCenter_Button_MakePayments =													By.cssSelector("button#makePayments");
	public static By Locator_PaymentCenter_Button_Payment_DatePicker_EarliestAvailable =							By.xpath("(//div[@id='datepicker-container' and @aria-hidden='false']//a[contains(@aria-label, 'available')])[1]");
	public static By Locator_PaymentCenter_Button_Payment_DeliverBy_First =											By.xpath("//button[starts-with(@id,'calendar-button')][1]");
	public static By Locator_PaymentCenter_Button_Payment_PayFrom_First =											By.xpath("(//button[starts-with(@id,'fasb-button-')])[1]");
	public static By Locator_PaymentCenter_Button_PaymentConfirmation_ReturnToPaymentCenter =						By.cssSelector("button#finishedButton");
	public static By Locator_PaymentCenter_Button_ReviewPayemnts_Submit =											By.cssSelector("button#submitPaymentsButton");
	public static By Locator_PaymentCenter_Container_Payee_First =													By.xpath("(//div[@class='payee--container-inner'])[1]");
	public static By Locator_PaymentCenter_Container_Payment_DatePicker =											By.cssSelector("div#datepicker-container[aria-hidden='false']");
	public static By Locator_PaymentCenter_CustomDropDown_Payee_FromAccount =										By.cssSelector("button[id^='fasb']");
	public static By Locator_PaymentCenter_CustomDropDown_Payment_PayFrom_First =									By.xpath("(//ul[@id='fa-list' and @aria-hidden='false']/li)[1]/span[not(contains(@class, 'is-hidden'))]");
	public static By Locator_PaymentCenter_CustomDropDown_Payment_PayFrom_First_Account =							By.xpath("(//li[starts-with(@id,'fasb-option')])[1]");
	public static By Locator_PaymentCenter_CustomDropDown_Payment_PayFrom_First_Collapsed =							By.xpath("(//input[starts-with(@id,'fasb-edit') and @aria-expanded='false'])[1]");
	public static By Locator_PaymentCenter_CustomDropDown_Payment_PayFrom_First_Expanded =							By.xpath("(//input[starts-with(@id,'fasb-edit') and @aria-expanded='true'])[1]");
//	public static By Locator_PaymentCenter_DropDown_RightAccordion_PendingPayments_Filter =							By.cssSelector(""); // missing from properties
	public static By Locator_PaymentCenter_DropDown_RightAccordion_RecentPayments_Filter =							By.cssSelector("select#recent-payments-account-filter-selectlist.input-select-account");
	public static By Locator_PaymentCenter_DropDown_RightAccordion_Reminders_Filter =								By.cssSelector("select#payment-reminders-filter-selectlist.input-select-account");
	public static By Locator_PaymentCenter_Link_Payment_AutoPay_First =												By.xpath("//li[starts-with(@id,'rbn-tab-act-')][1]/a");
	public static By Locator_PaymentCenter_Link_Payment_Activity_First =											By.xpath("//li[starts-with(@id,'rbn-tab-apm-')][1]/a");
	public static By Locator_PaymentCenter_Link_Payment_Details_First =												By.xpath("(//a[starts-with(@id,'payee-details-')])[1]");
	public static By Locator_PaymentCenter_Link_Payment_PaymentName_First =											By.xpath("//h3[starts-with(@id,'name-')][1]");
	public static By Locator_PaymentCenter_Link_Payment_Reminders_First =											By.xpath("//li[starts-with(@id,'rbn-tab-rem-')][1]/a");
	public static By Locator_PaymentCenter_Link_RightAccordion_PendingPayments_Collapsed =							By.cssSelector("div#pending-payments-module.closed");
	public static By Locator_PaymentCenter_Link_RightAccordion_PendingPayments_Expanded =							By.cssSelector("div#pending-payments-module.open");
	public static By Locator_PaymentCenter_Link_RightAccordion_RecentPayments_Collapsed =							By.cssSelector("div#recent-payments-module.closed");
	public static By Locator_PaymentCenter_Link_RightAccordion_RecentPayments_Expanded =							By.cssSelector("div#recent-payments-module.open");
	public static By Locator_PaymentCenter_Link_RightAccordion_RecentPayments_ViewActivity =						By.cssSelector("div#recent-payments-view-activity a");
	public static By Locator_PaymentCenter_Link_RightAccordion_Reminders_Collapsed =								By.cssSelector("div#payment-reminders-module.closed");
	public static By Locator_PaymentCenter_Link_RightAccordion_Reminders_Expanded =									By.cssSelector("div#payment-reminders-module.open");
	public static By Locator_PaymentCenter_TextContainer_Header =													By.cssSelector("div.primary-mod > h2");
	public static By Locator_PaymentCenter_TextContainer_RightAccordion_PendingPayments_PaymountAmount =			By.xpath("//a[starts-with(@id,'amt-col-minimodule-'')]/span[@class='pmt-amt']"); // missing from enums
	public static By Locator_PaymentCenter_TextContainer_Title =													By.cssSelector("h1.page-header");
	public static By Locator_PaymentCenter_TextField_Payment_Amount_First =											By.xpath("//input[starts-with(@id,'amt-')][1]");
	public static By Locator_PaymentCenter_TextField_Payment_DeliverBy_First =										By.xpath("//input[starts-with(@id,'dtt-')][1]");
	public static By Locator_TestRegion_Button_Proceed =															By.cssSelector("a.btn");
	public static By Locator_TestRegion_TextContainer_Date =														By.cssSelector("span.fr");
	public static By Locator_TestRegion_TextContainer_Title =														By.cssSelector("h2.test-region-title");
	public static By MultiLocator_TextContainer_PendingPaymentAmounts =												By.cssSelector("div#pending-payments-module tbody:not(.is-hidden) span.pmt-amt");
	public static String CompoundLocator_PaymentCenter_TextContainer_RightAccordion_PendingPayments_PaymentAmount =	"//a[starts-with(@id, 'amt-col-minimodule-')]/span[@class='pmt-amt' and contains(text(),'~~~')]";
	public static String Text_LeftNav_Title =																		"billpay";
	public static String Text_PaymentCenter_Header =																"Pay Bills";
	public static String Text_PaymentCenter_Title =																	"Payment Center";
	public static String Text_TestRegion_Title =																	"billpay test region";


//	BillPay.CompoundLocator.PaymentCenter.TextContainer.RightAccordion.PendingPayments.PaymountAmount=//a[starts-with(@id,"amt-col-minimodule-")]/span[@class="pmt-amt" and contains(text(),"~~~")]@@@xpath
//	BillPay.Locator.Header.Button.BillPayTab.Active=li.activo a[alt=BillPay]@@@css
//	BillPay.Locator.Header.Button.BillPayTab=a[alt=BillPay]@@@css
//	BillPay.Locator.LeftNav.Button.Activity.Active=//li[contains(@class,"active")]//a[contains(@class,"maintabs") and contains(text(),"Activity")]@@@xpath
//	BillPay.Locator.LeftNav.Button.Activity=//a[contains(@class,"maintabs") and contains(text(),"Activity")]@@@xpath
//	BillPay.Locator.LeftNav.Button.Help.Active=//li[contains(@class,"active")]//a[contains(@class,"maintabs") and contains(text(),"Help")]@@@xpath
//	BillPay.Locator.LeftNav.Button.Help=//a[contains(@class,"maintabs") and contains(text(),"Help")]@@@xpath
//	BillPay.Locator.LeftNav.Button.Messages.Active=//li[contains(@class,"active")]//a[contains(@class,"maintabs") and contains(text(),"Messages")]@@@xpath
//	BillPay.Locator.LeftNav.Button.Messages=//a[contains(@class,"maintabs") and contains(text(),"Messages")]@@@xpath
//	BillPay.Locator.LeftNav.Button.PaymentCenter.Active=//li[contains(@class,"active")]//a[contains(@class,"maintabs") and contains(text(),"Payment Center")]@@@xpath
//	BillPay.Locator.LeftNav.Button.PaymentCenter=//a[contains(@class,"maintabs") and contains(text(),"Payment Center")]@@@xpath
//	BillPay.Locator.PaymentCenter.Button.AddCompanyPerson=a#btnAddPayee@@@css
//	BillPay.Locator.PaymentCenter.Button.MakePayments=button#makePayments@@@css
//	BillPay.Locator.PaymentCenter.Button.Payment.DatePicker.EarliestAvailable=(//div[@id='datepicker-container' and @aria-hidden='false']//a[contains(@aria-label, 'available')])[1]@@@xpath
//	BillPay.Locator.PaymentCenter.Button.Payment.DeliverBy.First=//button[starts-with(@id,'calendar-button')][1]@@@xpath
//	BillPay.Locator.PaymentCenter.Button.Payment.PayFrom.First=@@@xpath
//	BillPay.Locator.PaymentCenter.Button.PaymentConfirmation.ReturnToPaymentCenter=@@@css
//	BillPay.Locator.PaymentCenter.Button.ReviewPayments.Submit=@@@css
//	BillPay.Locator.PaymentCenter.Container.Payee.First=@@@xpath
//	BillPay.Locator.PaymentCenter.Container.Payment.DatePicker=@@@css
//	BillPay.Locator.PaymentCenter.CustomDropDown.Payee.FromAccount=@@@css
//	BillPay.Locator.PaymentCenter.CustomDropDown.Payment.PayFrom.First.Account=@@@xpath
//	BillPay.Locator.PaymentCenter.CustomDropDown.Payment.PayFrom.First.Collapsed=@@@xpath
//	BillPay.Locator.PaymentCenter.CustomDropDown.Payment.PayFrom.First.Expanded=@@@xpath
//	BillPay.Locator.PaymentCenter.CustomDropDown.Payment.PayFrom.First=@@@xpath
//	BillPay.Locator.PaymentCenter.Dropdown.RightAccordion.RecentPayments.Filter=@@@css
//	BillPay.Locator.PaymentCenter.Dropdown.RightAccordion.Reminders.Filter=@@@css
//	BillPay.Locator.PaymentCenter.Link.Payment.Activity.First=@@@xpath
//	BillPay.Locator.PaymentCenter.Link.Payment.AutoPay.First=@@@xpath
//	BillPay.Locator.PaymentCenter.Link.Payment.Details.First=@@@xpath
//	BillPay.Locator.PaymentCenter.Link.Payment.PaymentName.First=@@@xpath
//	BillPay.Locator.PaymentCenter.Link.Payment.Reminders.First=@@@xpath
//	BillPay.Locator.PaymentCenter.Link.RightAccordion.PendingPayments.Collapsed=@@@css
//	BillPay.Locator.PaymentCenter.Link.RightAccordion.PendingPayments.Expended=@@@css
//	BillPay.Locator.PaymentCenter.Link.RightAccordion.RecentPayments.Collapsed=@@@css
//	BillPay.Locator.PaymentCenter.Link.RightAccordion.RecentPayments.Expanded=@@@css
//	BillPay.Locator.PaymentCenter.Link.RightAccordion.RecentPayments.ViewActivity=@@@css
//	BillPay.Locator.PaymentCenter.Link.RightAccordion.Reminders.Collapsed=@@@css
//	BillPay.Locator.PaymentCenter.Link.RightAccordion.Reminders.Expanded=@@@css
//	BillPay.Locator.PaymentCenter.TextContainer.Header=@@@css
//	BillPay.Locator.PaymentCenter.TextContainer.RightAccordion.PendingPayments.PaymountAmount=@@@xpath
//	BillPay.Locator.PaymentCenter.TextContainer.Title=@@@css
//	BillPay.Locator.PaymentCenter.TextField.Payment.Amount.First=@@@xpath
//	BillPay.Locator.PaymentCenter.TextField.Payment.DeliverBy.First=@@@xpath
//	BillPay.Locator.TestRegion.Button.Proceed=@@@css
//	BillPay.Locator.TestRegion.TextContainer.Date=@@@css
//	BillPay.Locator.TestRegion.TextContainer.Title=@@@css
//	BillPay.Locator.TextContainer.Title=span.billpayIcon@@@css
//	BillPay.MultiLocator.TextContainer.PendingPaymentAmounts=div#pending-payments-module tbody:not(.is-hidden) span.pmt-amt@@@css
//	BillPay.Text.LeftNav.Title=billpay
//	BillPay.Text.PaymentCenter.Header=Pay Bills
//	BillPay.Text.PaymentCenter.Title=Payment Center
//	BillPay.Text.TestRegion.Title=billpay test region


//	CompoundLocator_PaymentCenter_TextContainer_RightAccordion_PendingPayments_PaymentAmount("BillPay.CompoundLocator.PaymentCenter.TextContainer.RightAccordion.PendingPayments.PaymountAmount"),
//	Locator_Header_Button_BillPayTab("BillPay.Locator.Header.Button.BillPayTab"),
//	Locator_Header_Button_BillPayTab_Active("BillPay.Locator.Header.Button.BillPayTab.Active"),
//	Locator_LeftNav_Button_Activity("BillPay.Locator.LeftNav.Button.Activity"),
//	Locator_LeftNav_Button_Activity_Active("BillPay.Locator.LeftNav.Button.Activity.Active"),
//	Locator_LeftNav_Button_Help("BillPay.Locator.LeftNav.Button.Help"),
//	Locator_LeftNav_Button_Help_Active("BillPay.Locator.LeftNav.Button.Help.Active"),
//	Locator_LeftNav_Button_Messages("BillPay.Locator.LeftNav.Button.Messages"),
//	Locator_LeftNav_Button_Messages_Active("BillPay.Locator.LeftNav.Button.Messages.Active"),
//	Locator_LeftNav_Button_PaymentCenter("BillPay.Locator.LeftNav.Button.PaymentCenter"),
//	Locator_LeftNav_Button_PaymentCenter_Active("BillPay.Locator.LeftNav.Button.PaymentCenter.Active"),
//	Locator_LeftNav_TextContainer_Title("BillPay.Locator.TextContainer.Title"),
//	Locator_PaymentCenter_Button_AddCompanyPerson("BillPay.Locator.PaymentCenter.Button.AddCompanyPerson"),
//	Locator_PaymentCenter_Button_MakePayments("BillPay.Locator.PaymentCenter.Button.MakePayments"),
//	Locator_PaymentCenter_Button_Payment_DatePicker_EarliestAvailable("BillPay.Locator.PaymentCenter.Button.Payment.DatePicker.EarliestAvailable"), // div#datepicker-container[aria-hidden=false] a[aria-label$="Earliest available"]
//	Locator_PaymentCenter_Button_Payment_DeliverBy_First("BillPay.Locator.PaymentCenter.Button.Payment.DeliverBy.First"), // //button[starts-with(@id,"calendar-button")][1]
//	Locator_PaymentCenter_Button_Payment_PayFrom_First("BillPay.Locator.PaymentCenter.Button.Payment.PayFrom.First"), // //button[starts-with(@id,"fasb-button-")][1]
//	Locator_PaymentCenter_Button_PaymentConfirmation_ReturnToPaymentCenter("BillPay.Locator.PaymentCenter.Button.PaymentConfirmation.ReturnToPaymentCenter"), // button#finishedButton
//	Locator_PaymentCenter_Button_ReviewPayemnts_Submit("BillPay.Locator.PaymentCenter.Button.ReviewPayments.Submit"), // button#submitPaymentsButton
//	Locator_PaymentCenter_Container_Payee_First("BillPay.Locator.PaymentCenter.Container.Payee.First"),
//	Locator_PaymentCenter_Container_Payment_DatePicker("BillPay.Locator.PaymentCenter.Container.Payment.DatePicker"), // div#datepicker-container[aria-hidden=false]
//	Locator_PaymentCenter_CustomDropDown_Payee_FromAccount("BillPay.Locator.PaymentCenter.CustomDropDown.Payee.FromAccount"),
//	Locator_PaymentCenter_CustomDropDown_Payment_PayFrom_First("BillPay.Locator.PaymentCenter.CustomDropDown.Payment.PayFrom.First"), // //div[starts-with(@id,"fasb-")][1]
//	Locator_PaymentCenter_CustomDropDown_Payment_PayFrom_First_Account("BillPay.Locator.PaymentCenter.CustomDropDown.Payment.PayFrom.First.Account"), // //ul[@id="fa-list"][1][@aria-hidden="false"]/li[1]/span[1]
//	Locator_PaymentCenter_CustomDropDown_Payment_PayFrom_First_Collapsed("BillPay.Locator.PaymentCenter.CustomDropDown.Payment.PayFrom.First.Collapsed"), // //ul[@id="fa-list"][1][@aria-expanded="false"]
//	Locator_PaymentCenter_CustomDropDown_Payment_PayFrom_First_Expanded("BillPay.Locator.PaymentCenter.CustomDropDown.Payment.PayFrom.First.Expanded"), // //ul[@id="fa-list"][1][@aria-expanded="true"]
//	Locator_PaymentCenter_DropDown_RightAccordion_PendingPayments_Filter("BillPay.Locator.PaymentCenter.Dropdown.RightAccordion.PendingPayments.Filter"),
//	Locator_PaymentCenter_DropDown_RightAccordion_RecentPayments_Filter("BillPay.Locator.PaymentCenter.Dropdown.RightAccordion.RecentPayments.Filter"),
//	Locator_PaymentCenter_DropDown_RightAccordion_Reminders_Filter("BillPay.Locator.PaymentCenter.Dropdown.RightAccordion.Reminders.Filter"),
//	Locator_PaymentCenter_Link_Payment_Activity_First("BillPay.Locator.PaymentCenter.Link.Payment.Activity.First"), // //li[starts-with(@id,"rbn-tab-act-")][1]/a
//	Locator_PaymentCenter_Link_Payment_AutoPay_First("BillPay.Locator.PaymentCenter.Link.Payment.AutoPay.First"),  // //li[starts-with(@id,"rbn-tab-apm-")][1]/a
//	Locator_PaymentCenter_Link_Payment_Details_First("BillPay.Locator.PaymentCenter.Link.Payment.Details.First"), // //a[starts-with(@id,"payee-details-")][1]
//	Locator_PaymentCenter_Link_Payment_PaymentName_First("BillPay.Locator.PaymentCenter.Link.Payment.PaymentName.First"), // //h3[starts-with(@id,"name-")][1]
//	Locator_PaymentCenter_Link_Payment_Reminders_First("BillPay.Locator.PaymentCenter.Link.Payment.Reminders.First"), // //li[starts-with(@id,"rbn-tab-rem-")][1]/a
//	Locator_PaymentCenter_Link_RightAccordion_PendingPayments_Collapsed("BillPay.Locator.PaymentCenter.Link.RightAccordion.PendingPayments.Collapsed"),
//	Locator_PaymentCenter_Link_RightAccordion_PendingPayments_Expanded("BillPay.Locator.PaymentCenter.Link.RightAccordion.PendingPayments.Expended"),
//	Locator_PaymentCenter_Link_RightAccordion_RecentPayments_Collapsed("BillPay.Locator.PaymentCenter.Link.RightAccordion.RecentPayments.Collapsed"),
//	Locator_PaymentCenter_Link_RightAccordion_RecentPayments_Expanded("BillPay.Locator.PaymentCenter.Link.RightAccordion.RecentPayments.Expanded"),
//	Locator_PaymentCenter_Link_RightAccordion_RecentPayments_ViewActivity("BillPay.Locator.PaymentCenter.Link.RightAccordion.RecentPayments.ViewActivity"),
//	Locator_PaymentCenter_Link_RightAccordion_Reminders_Collapsed("BillPay.Locator.PaymentCenter.Link.RightAccordion.Reminders.Collapsed"),
//	Locator_PaymentCenter_Link_RightAccordion_Reminders_Expanded("BillPay.Locator.PaymentCenter.Link.RightAccordion.Reminders.Expanded"),
//	Locator_PaymentCenter_TextContainer_Header("BillPay.Locator.PaymentCenter.TextContainer.Header"),
//	Locator_PaymentCenter_TextContainer_Title("BillPay.Locator.PaymentCenter.TextContainer.Title"),
//	Locator_PaymentCenter_TextField_Payment_Amount_First("BillPay.Locator.PaymentCenter.TextField.Payment.Amount.First"), // //input[starts-with(@id,"amt-")][1]
//	Locator_PaymentCenter_TextField_Payment_DeliverBy_First("BillPay.Locator.PaymentCenter.TextField.Payment.DeliverBy.First"), // //input[starts-with(@id,"dtt-")][1]
//	Locator_TestRegion_Button_Proceed("BillPay.Locator.TestRegion.Button.Proceed"),
//	Locator_TestRegion_TextContainer_Date("BillPay.Locator.TestRegion.TextContainer.Date"),
//	Locator_TestRegion_TextContainer_Title("BillPay.Locator.TestRegion.TextContainer.Title"),
//	MultiLocator_TextContainer_PendingPaymentAmounts("BillPay.MultiLocator.TextContainer.PendingPaymentAmounts"),
//	Text_LeftNav_Title("BillPay.Text.LeftNav.Title"),
//	Text_PaymentCenter_Header("BillPay.Text.PaymentCenter.Header"),
//	Text_PaymentCenter_Title("BillPay.Text.PaymentCenter.Title"),
//	Text_TestRegion_Title("BillPay.Text.TestRegion.Title"),


}
