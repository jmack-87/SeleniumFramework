package common_resources;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.asserts.Assertion;
import org.testng.asserts.IAssert;

/**
 *
 * @author Jerimiah Mack
 *
 */
public class ScreenShot extends Assertion {

	private LocalDateTime date;
	private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");


	private RemoteWebDriver driver;


	/**
	 * Constructor
	 *
	 * @param driver RemoteWebDriver
	 */
	public ScreenShot(RemoteWebDriver driver) {

		this.driver = driver;

	}


	/**
	 * Take a screenshot
	 *
	 * @author x923749
	 */
	public void takeScreenShot() {

		date = LocalDateTime.now();
		boolean success = true;

		File file = this.driver.getScreenshotAs(OutputType.FILE);
		Path dir = Paths.get("target/"+utility.curTestSet);

		String screenShotPath = "target/"+utility.curTestSet+"/"+utility.appScriptName+"_"+date.format(formatter)+".png";
		System.out.format("Attempting to create screenshot: %s", screenShotPath);

		try {
			if (Files.notExists(dir, LinkOption.NOFOLLOW_LINKS)) {
				success = (new File("target/"+utility.curTestSet)).mkdir();
			}

			if (success) {
				Files.copy(file.toPath(), new File(screenShotPath).toPath());
			}
		} catch (IOException ie) {
			System.out.format(" ...failed!%n");
		} finally {
			System.out.format(" ...done!%n");
		}

	}


	/**
	 *  Always take a screenshot if Assert fails
	 *
	 *  @param assertCommand (IAssert<?>) testNG assert type
	 *  @param er (AssertionError) testng assertion error content
	 *
	 *  @author x923749
	 */
	@Override
	public void onAssertFailure(IAssert<?> assertCommand, AssertionError er) {

		takeScreenShot();

	}


	/**
	* Invoked when an assert succeeds. Meant to be overridden by subclasses.
	*/
	@Override
	public void onAssertSuccess(IAssert<?> assertCommand) {

		//TODO: something generic on every assert PASS

	}


}
