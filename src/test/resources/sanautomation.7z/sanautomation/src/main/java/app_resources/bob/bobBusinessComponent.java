package app_resources.bob;

import common_resources.utility;

public class bobBusinessComponent extends utility {

	//TODO: bob stuff

	public void fnBOBLogin(String user, String pass) {

	}

}
