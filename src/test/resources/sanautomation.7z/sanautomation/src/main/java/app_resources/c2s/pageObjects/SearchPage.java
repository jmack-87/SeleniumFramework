package app_resources.c2s.pageObjects;

import org.openqa.selenium.By;

public class SearchPage {

	public static By Locator_Img_SearchLink = 							By.cssSelector("div#mobileMenuScroller div[tooltip*='Customer Search']");
	public static By Locator_DropDown_SearchName = 						By.xpath("//option[@value='Name']/parent::select");
	public static By Locator_DropDown_SearchBusiness = 					By.xpath("//option[@value='Business']/parent::select");
	public static By Locator_DropDown_SearchInclusive = 				By.xpath("//option[@value='Inclusive']/parent::select");
	public static By Locator_Button_Submit = 							By.cssSelector("button#btn-search");
	public static int Text_Name_Index = 								2;
	public static int Text_Equals_Index = 								0;
	public static By Locator_Button_ProspectTab = 						By.xpath("//div[@class='customerSearch-notselected'][@id='prospectTab']");
	public static String Text_BusinessDropDown_ConsumerText = 			"Consumer";
	public static int Text_BusinessDropDown_ConsumerIndex = 			0;
	public static By Locator_TextField_ConsumerFirstName = 				By.xpath("//input[@class='ng-pristine ng-valid'][@ng-model='name']");
	public static By Locator_TextField_ConsumerLastName = 				By.xpath("//input[@tabindex='5'][@class='ng-pristine ng-valid'][@ng-model='lastName']");
	public static By Locator_Text_FirstSearchEntry = 					By.xpath("//li[@class='listItem ng-scope']/a/div/table/tbody/tr/td");
	public static String CompoundLocator_Text_SearchEntryByFNumber = 	"div#customer-search-results a[href*='/crm/customers/#/~~~']";
	
}
