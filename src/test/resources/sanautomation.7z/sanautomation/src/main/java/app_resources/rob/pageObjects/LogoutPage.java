package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class LogoutPage {


    public static By objLogOut = By.id("logoff");
    public static By objMenu = By.name("FirstLevelOption");


}
