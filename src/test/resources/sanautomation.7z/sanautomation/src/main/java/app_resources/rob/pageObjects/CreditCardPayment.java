package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class CreditCardPayment {


	public static By Locator_Button_Calendar = 											By.cssSelector("input[id$=iCalen]");
	public static By Locator_Button_Continue = 											By.cssSelector("a.continue");
	public static By Locator_Button_Details_Cancel = 									By.cssSelector("a.cancel");
	public static By Locator_Button_Details_Confirm = 									By.cssSelector("a.confirm");
	public static By Locator_Button_Go = 												By.cssSelector("input.boton");
	public static By Locator_Button_PendingPayment_Go = 								By.cssSelector("input");
	public static By Locator_Button_PendingPayments_Go_First = 							By.cssSelector("input#main_comboFila_2_cbBoton0");
	public static By Locator_Container_CalendarWidget = 								By.cssSelector("div[id$='PopCal']");
	public static By Locator_Container_FAQ = 											By.cssSelector("div.helpFaq");
	public static By Locator_DropDown_AccountFrom = 									By.cssSelector("select#slcCuenta");
	public static By Locator_DropDown_CreditCard = 										By.cssSelector("select[id$='selectAction']");
	public static By Locator_DropDown_PendingPayment_Actions = 							By.cssSelector("select");
	public static By Locator_DropDown_PendingPaymentDropDownFirst = 					By.cssSelector("select#main_comboFila_2_cbAccion0");
	public static By Locator_Link_AddAcount = 											By.cssSelector("div[id$='txtEnlaceCuenta'] a");
	public static By Locator_Link_AlreadyScheduled = 									By.cssSelector("a#Already");
	public static By Locator_Link_Autopay = 											By.cssSelector("li:not(.active) span#Autopay a");
	public static By Locator_Link_Autopay_Active = 										By.cssSelector("li.active span#Autopay a");
	public static By Locator_Link_Autopay_Back = 										By.cssSelector("a.fback");
	public static By Locator_Link_Autopay_Summary_GoToPayments = 						By.cssSelector("a#Goto");
	public static By Locator_Link_Back = 												By.cssSelector("a#idBack");
	public static By Locator_Link_Delete_Details_Back = 								By.cssSelector("a.fback");
	public static By Locator_Link_Delete_Summary_GoToPayments = 						By.cssSelector("a#idViewCredit");
	public static By Locator_Link_Delete_Summary_SeePendingPayments = 					By.cssSelector("a#Pendiente");
	public static By Locator_Link_ExternalAccount_AddNewAccount = 						By.cssSelector("a#addAcc"); //xpath: //*[@id="addAcc"]
	public static By Locator_Link_OneTimePayment = 										By.cssSelector("li:not(.active) span#OnetimePayment a");
	public static By Locator_Link_OneTimePayment_Active = 								By.cssSelector("li.active span#OnetimePayment a");
	public static By Locator_Link_OneTimePending = 										By.cssSelector("li:not(.active) span#OnetimePendingPaymentList a, li:not(.active) span#OneTimePending a");
	public static By Locator_Link_OneTimePending_Active = 								By.cssSelector("li.active span#OneTimePending a");
	public static By Locator_Link_PendingList_Help = 									By.cssSelector("a#help");
	public static By Locator_Link_Print = 												By.cssSelector("a#Imprimir");
	public static By Locator_link_SeePendingPayments = 									By.cssSelector("div[id$='enlPie'] a:not([id])");
	public static By Locator_Link_SetUpAutopay = 										By.cssSelector("a#SeleccionSetUpAutopay");
//	public static By Locator_Link_SetupAutopay = 										By.cssSelector("a#SeleccionSetUpAutopay"); //duplicate: SetUp vs Setup
	public static By Locator_Link_Summary_Print = 										By.cssSelector("a#imprimir");
	public static By Locator_Link_Summary_SetUpAutopay = 								By.cssSelector("a#idSetup");
	public static By Locator_Link_UpdateContactDetails = 								By.cssSelector("div[id$='txtChangeMail'] a");
	public static By Locator_RadioButton_AcceptConditions = 							By.cssSelector("input#rdbConsentimiento");
	public static By Locator_RadioButton_AutopayMinPayment = 							By.xpath("//*[@id='rdbPagoMin']");
	public static By Locator_RadioButton_AutopayStatmentBalance = 						By.xpath("//*[@id='rdbBalance']");
	public static By Locator_RadioButton_CancelAutopay = 								By.cssSelector("input#rdbCancel");
	public static By Locator_RadioButton_CurrentBalance = 								By.cssSelector("input#rdbCurrentBalance");
	public static By Locator_RadioButton_CurrentBalance_Disabled = 						By.cssSelector("input#rdbCurrentBalance:disabled");
	public static By Locator_RadioButton_CurrentBalance_Enabled = 						By.cssSelector("input#rdbCurrentBalance:not(disabled)");
	public static By Locator_RadioButton_Details_AcceptTCs = 							By.cssSelector("input#rdbConsentimiento");
	public static By Locator_RadioButton_Details_NotAcceptTCs = 						By.cssSelector("input#rdbNoConsentimiento");
	public static By Locator_RadioButton_MinimumPayment = 								By.cssSelector("input#rdbPagoMin");
	public static By Locator_RadioButton_MinimumPayment_Disabled = 						By.cssSelector("input#rdbPagoMin:disabled");
	public static By Locator_RadioButton_MinimumPayment_Enabled = 						By.cssSelector("input#rdbPagoMin:not(disabled)");
	public static By Locator_RadioButton_NoAcceptConditions = 							By.cssSelector("input#rdbNoConsentimiento");
	public static By Locator_RadioButton_OtherAmount = 									By.cssSelector("input#rdbOtraCantidad");
	public static By Locator_RadioButton_OtherAmount_Disabled = 						By.cssSelector("input#rdbOtraCantidad:disabled");
	public static By Locator_RadioButton_OtherAmount_Enabled = 							By.cssSelector("input#rdbOtraCantidad:not(disabled)");
	public static By Locator_RadioButton_StatementBalance = 							By.cssSelector("input#rdbBalance");
	public static By Locator_RadioButton_StatementBalance_Disabled = 					By.cssSelector("input#rdbBalance:disabled");
	public static By Locator_RadioButton_StatementBalance_Enabled = 					By.cssSelector("input#rdbBalance:not(disabled)");
	public static By Locator_SubTab_Autopay = 											By.xpath("//li[contains(@class,'after last')]//a[contains(text(),'Autopay')]");
	public static By Locator_SubTab_Autopay_Active = 									By.xpath("//li[contains(@class,'active claseFF last')]//a[contains(text(),'Autopay')]");
	public static By Locator_SubTab_Autopay_ExternalAccountReturn = 					By.xpath("//*[@class='InternetAtSubCabPestana pr']/ul/li[3]/span/a"); //anonymous node
	public static By Locator_SubTab_OneTimePayment = 									By.xpath("//li[contains(@class,'first')]//a[contains(text(),'One-Time Payment')]");
	public static By Locator_SubTab_OneTimePayment_Active = 							By.xpath("//li[contains(@class,'active claseFF first')]//a[contains(text(),'One-Time Payment')]");
	public static By Locator_SubTab_OneTimePendingPayment = 							By.xpath("//a[contains(text(),'One-Time Pending Payment List')]");
	public static By Locator_SubTab_OneTimePendingPayment_Active = 						By.xpath("//li[contains(@class,'active claseFF')]//a[contains(text(),'One-Time Pending Payment List')]");
	public static By Locator_TextContainer_AccountFromConfirm = 						By.xpath("//table[contains(@id,'Ppal')]//h1[contains(text(),'Account from')]/../following-sibling::td");
	public static By Locator_TextContainer_AmountConfirm = 								By.xpath("//table[contains(@id,'Ppal')]//h1[contains(text(),'Payment Amount')]/../following-sibling::td"); //missing form properties
	public static By Locator_TextContainer_Autopay_AlreadyScheduledBanner = 			By.cssSelector("div[id$='infAutopay'] span.title");
	public static By Locator_TextContainer_Autopay_CancelBanner = 						By.cssSelector("div.confirmation span.title");
	public static By Locator_TextContainer_Autopay_SummaryBanner = 						By.cssSelector("div.confirmation span.subtitle");
	public static By Locator_TextContainer_BreadCrumb = 								By.cssSelector("li.activo span:not(.arrow");
	public static By Locator_TextContainer_ByClickingConfirm = 							By.xpath("//p[contains(text(),'By clicking the \"Confirm\" button')]");
	public static By Locator_TextContainer_CreditCardConfirm = 							By.xpath("//*[@class='contenido']/table/tbody/tr[2]/td"); //absolute
	public static By Locator_TextContainer_CreditCardPayment = 							By.xpath("//p[contains(text(),'credit card payment using')]");
	public static By Locator_TextContainer_CreditCardPaymentTitle = 					By.cssSelector("span.titulo");
	public static By Locator_TextContainer_CurrentBalance = 							By.cssSelector("div[id$='CurrentBalance'] label");
	public static By Locator_TextContainer_DateConfirm = 								By.xpath("//*[@class='contenido']/table/tbody/tr[5]/td"); //absolute //anonymous node
	public static By Locator_TextContainer_DeletePendingPaymentBanner = 				By.cssSelector("span.subtitle");
	public static By Locator_TextContainer_Details_Amount = 							By.xpath("//h1[contains(text(),'Amount:')]/parent::th/following-sibling::td");
	public static By Locator_TextContainer_Details_DueDate = 							By.xpath("//h1[contains(text(),'Due Date:')]/parent::th/following-sibling::td");
	public static By Locator_TextContainer_Details_Email = 								By.cssSelector("div[id$='txtPreferedMail']");
	public static By Locator_TextContainer_Details_FromAccount = 						By.xpath("//h1[contains(text(),'from:')]/parent::th/following-sibling::td");
	public static By Locator_TextContainer_Details_PaymentDate = 						By.xpath("//h1[contains(text(),'Payment Date:')]/parent::th/following-sibling::td");
	public static By Locator_TextContainer_Details_PaymentOption = 						By.xpath("//h1[contains(text(),'Payment Option:')]/parent::th/following-sibling::td");
	public static By Locator_TextContainer_Details_ToAccount = 							By.xpath("//h1[contains(text(),'to:')]/parent::th/following-sibling::td");
	public static By Locator_TextContainer_DueDate = 									By.cssSelector("div[id$='PagoValue'] p, span[id^='lblFechaVenc']");
	public static By Locator_TextContainer_Email = 										By.cssSelector("div[id$='txtPreferedMail'] p, div[id$='txtConfirmationEmail'] p");
	public static By Locator_TextContainer_FAQ_FormTitle = 								By.cssSelector("div.helpFaq h5");
	public static By Locator_TextContainer_FAQ_Title = 									By.cssSelector("div.helpFaq h4");
	public static By Locator_TextContainer_FormTitle = 									By.cssSelector("span.titulo");
//	public static By Locator_TextContainer_MakePayment_OneTimePaymentBanner = 			By.cssSelector(""); //missing from properties
	public static By Locator_TextContainer_PaymentDate_Day = 							By.cssSelector("span.dia input");
	public static By Locator_TextContainer_PaymentDate_Month = 							By.cssSelector("span.mes input");
	public static By Locator_TextContainer_PaymentDate_Year = 							By.cssSelector("span.anho input");
	public static By Locator_TextContainer_PaymentOption_Confirm = 						By.xpath("//table[contains(@id,'Principal')]//h1[contains(text(),'Payment Option')]/../following-sibling::td"); //missing for properties
	public static By Locator_TextContainer_PendingPayment_Amount = 						By.cssSelector("td:nth-of-type(4)");
	public static By Locator_TextContainer_PendingPayment_FromAccount = 				By.cssSelector("td:nth-of-type(2)");
	public static By Locator_TextContainer_PendingPayment_PaymentDate = 				By.cssSelector("td:nth-of-type(1)");
	public static By Locator_TextContainer_PendingPayment_ToAccount = 					By.cssSelector("td:nth-of-type(3)");
	public static By Locator_TextContainer_Records = 									By.cssSelector("div.numeros");
	public static By Locator_TextContainer_Summary_SuccessMessage = 					By.cssSelector("div[id*='infMsg'] span.subtitle");
	public static By Locator_TextField_OtherAmount = 									By.cssSelector("input#impOtraCantidad");
	public static By Locator_TextField_OtherAmount_Disabled = 							By.cssSelector("input#impOtraCantidad:disable");
	public static By Locator_TextField_OtherAmount_Enabled = 							By.cssSelector("input#impOtraCantidad:not(disabled)");
	public static By Locator_TextField_PaymentDay = 									By.xpath("//*[@id='main.formCC_SinglePayment_1.cfeFechaPago.iDay']"); //anonymous node
	public static By Locator_TextField_PaymentMonth = 									By.xpath("//*[@id='main.formCC_SinglePayment_1.cfeFechaPago.iMonth']"); //anonymous node
	public static By Locator_TextField_PaymentYear = 									By.xpath("//*[@id='main.formCC_SinglePayment_1.cfeFechaPago.iYear']"); //anonymous node
	public static By MultiLocator_Container_PendingList_PendingPayments = 				By.cssSelector("tbody tr");
	public static By MultiLocator_Container_PendingPayments = 							By.cssSelector("tbody[id*='PendingPayments'] tr");
	public static By MultiLocator_Link_FAQ_Questions = 									By.cssSelector("div.helpFaq a");
	public static By MultiLocator_TextContainer_Details_SegmentTitles = 				By.cssSelector("div[id$='dtcPrincipal'] span.title");
	public static By MultiLocator_TextContainer_PaymentOptions = 						By.cssSelector("div[id*='Opciones'] label[for^='rdb']");
	public static By MultiLocator_TextContainer_PendingList_TableHeaders = 				By.cssSelector("thead span");
	public static By MultiLocator_TextContainer_PendingTableHeaders = 					By.cssSelector("thead span");
	public static By MultiLocator_TextContainer_SegmentTitles = 						By.cssSelector("span.title");
	public static By MultiLocator_TextContainer_Summary_SegmentTitles = 				By.cssSelector("div[id*='dtcPpal'] span.title");
	public static int Text_PendingPayments_DeletePaymentIndex = 						0; //missing from properties
	public static String CompoundLocator_Link_CalendarWidget_TargetDate = 				"div[id$='PopCal'] a[id*='day_~~~']";
	public static String MultiText_Autopay_Details_SegmentTitles = 						"Autopay Details";
	public static String MultiText_Autopay_SegmentTitles = 								"Autopay Details";
	public static String MultiText_Delete_Details_SegmentTitles = 						"Delete One-time Credit Card Payment";
	public static String MultiText_Delete_Summary_SegmentTitles = 						"Delete Manual Credit Card Pending Payment";
	public static String MultiText_Details_SegmentTitles = 								"One-time Credit Card Payment Details";
	public static String MultiText_PaymentOptions = 									"Minimum,Statement,Current,Other";
	public static String MultiText_PendingList_SegmentTitles = 							"Pending Payments List";
	public static String MultiText_PendingList_TableHeaders = 							"Payment Date,Account from,Credit Card to,Amount,Payment Status,Actions";
	public static String MultiText_PendingTableHeaders = 								"Payment Date,Account From,Credit Card To,Amount,Payment Status";
	public static String MultiText_SegmentTitles = 										"One-time Credit Card Payment Details,Pending Payments List";
	public static String MultiText_Summary_SegmentTitles = 								"One-time Credit Card Payment Details";
	public static String Script_Boolean_RadioButtonChecked = 							"return arguments[0].checked == true;";
	public static String Script_String_CurrentSelectedDropDownValue = 					"return arguments[0].options[arguments[0].selectedIndex].text;";
	public static String Script_String_GetFieldValue = 									"return parseInt(arguments[0].value);";
//	public static String Text_Account_AccountFrom = 									""; //missing from properties
//	public static String Text_Account_AccountFromJohnMarksIndex = 						""; //missing from properties
//	public static String Text_Account_Index = 											""; //missing from properties
	public static String Text_Autopay_AlreadyScheduledBanner_Minimum = 					"autopay scheduled for your minimum amount due";
	public static String Text_Autopay_AlreadyScheduledBanner_Statement = 				"autopay scheduled for your statement balance";
	public static String Text_Autopay_CancelBanner = 									"Autopay cancelled successfully.";
	public static String Text_Autopay_ConfirmBanner = 									"Autopay Set Up or Modified Successfully.";
	public static String Text_Autopay_SummaryBanner = 									"Autopay Set Up or Modified Successfully.";
	public static String Text_BreadCrumb_ConfirmDetails = 								"Confirm Details";
	public static String Text_BreadCrumb_EnterDetails = 								"Enter Details";
	public static String Text_BreadCrumb_Summary = 										"Summary";
//	public static String Text_CreditCard_Index = 										""; //missing from properties
//	public static String Text_CreditCard_LastNumbers = 									""; //missing from properties
	public static String Text_Delete_Details_BreadCrumb_Confirm = 						"Confirm Details";
	public static String Text_Delete_Details_FormTitle = 								"Delete One-time Credit Card Payment";
	public static String Text_Delete_Summary_BreadCrumb = 								"Summary";
	public static String Text_Delete_Summary_FormTitle = 								"Delete One-time Credit Card Payment";
	public static String Text_Delete_Summary_SuccessMessage = 							"Deleted Successfully";
//	public static String Text_DeletePendingPaymentBannerText = 							""; //missing from enums
	public static String Text_Details_FormTitle = 										"Make a One-time Credit Card Payment";
	public static String Text_FAQ_FormTitle = 											"Frequently Asked Questions";
	public static String Text_FAQ_Title = 												"If you need help";
	public static String Text_FormTitle = 												"Credit Card Payment";
//	public static String Text_Index_AccountFrom = 										"0"; //missing from enums
	public static String Text_JohnMarks_AccountFromJohnMarks_SimpleChecking7731 = 		"Simply right checking - *7731";
//	public static String Text_OneTimePaymentTitle = 									""; //missing from properties
	public static String Text_PaymentOption_MinPayment = 								"Minimum amount due";
	public static String Text_PaymentOption_StatmentBalance = 							"Statement balance";
	public static String Text_PendingList_Delete = 										"Delete";
	public static String Text_PendingList_FormTitle = 									"Credit Card Payment";
	public static String Text_PendingPayments_DeletePendingPaymentsBannerText = 		"One-time Credit Card Payment Deleted Successfully."; //missing from properties
	public static String Text_SetUpAutopay_Title = 										"Set up or Modify an Autopay";
	public static String Text_Summary_FormTitle = 										"Make a One-time Credit Card Payment";
	public static String Text_Summary_SuccessMessage = 									"Completed Successfully";


//	CompoundLocator_Link_CalendarWidget_TargetDate("CreditCardPayment.CompoundLocator.Link.CalendarWidget.TargetDate"),
//	Locator_Button_Calendar("CreditCardPayment.Locator.Button.Calendar"),
//	Locator_Button_Continue("CreditCardPayment.Locator.Button.Continue"),
//	Locator_Button_Details_Cancel("CreditCardPayment.Locator.Button.Details.Cancel"),
//	Locator_Button_Details_Confirm("CreditCardPayment.Locator.Button.Details.Confirm"),
//	Locator_Button_Go("CreditCardPayment.Locator.Button.Go"),
//	Locator_Button_PendingPayment_Go("CreditCardPayment.Locator.Button.PendingPayment.Go"),
//	Locator_Button_PendingPayments_Go_First("CreditCardPayment.Locator.Button.PendingPayments.Go.First"),
//	Locator_Container_CalendarWidget("CreditCardPayment.Locator.Container.CalendarWidget"),
//	Locator_Container_FAQ("CreditCardPayment.Locator.Container.FAQ"),
//	Locator_DropDown_AccountFrom("CreditCardPayment.Locator.DropDown.AccountFrom"),
//	Locator_DropDown_CreditCard("CreditCardPayment.Locator.DropDown.CreditCard"),
//	Locator_DropDown_PendingPayment_Actions("CreditCardPayment.Locator.DropDown.PendingPayment.Actions"),
//	Locator_DropDown_PendingPaymentDropDownFirst("CreditCardPayment.Locator.DropDown.PendingPaymentsFirst"),
//	Locator_Link_AddAcount("CreditCardPayment.Locator.Link.AddAcount"),
//	Locator_Link_AlreadyScheduled("CreditCardPayment.Locator.Link.AlreadyScheduled"),
//	Locator_Link_Autopay("CreditCardPayment.Locator.Link.Autopay"),
//	Locator_Link_Autopay_Active("CreditCardPayment.Locator.Link.Autopay.Active"),
//	Locator_Link_Autopay_Back("CreditCardPayment.Locator.Link.Autopay.Back"),
//	Locator_Link_Autopay_Summary_GoToPayments("CreditCardPayment.Locator.Link.Autopay.Summary.GoToPayments"),
//	Locator_Link_Back("CreditCardPayment.Locator.Link.Back"),
//	Locator_Link_Delete_Details_Back("CreditCardPayment.Locator.Link.Delete.Details.Back"),
//	Locator_Link_Delete_Summary_GoToPayments("CreditCardPayment.Locator.Link.Delete.Summary.GoToPayments"),
//	Locator_Link_Delete_Summary_SeePendingPayments("CreditCardPayment.Locator.Link.Delete.Summary.SeePendingPayments"),
//	Locator_Link_ExternalAccount_AddNewAccount("CreditCardPayment.Locator.Link.ExtenalAccount.AddNewAccount"),
//	Locator_Link_OneTimePayment("CreditCardPayment.Locator.Link.OneTimePayment"),
//	Locator_Link_OneTimePayment_Active("CreditCardPayment.Locator.Link.OneTimePayment.Active"),
//	Locator_Link_OneTimePending("CreditCardPayment.Locator.Link.OneTimePending"),
//	Locator_Link_OneTimePending_Active("CreditCardPayment.Locator.Link.OneTimePending.Active"),
//	Locator_Link_PendingList_Help("CreditCardPayment.Locator.Link.PendingList.Help"),
//	Locator_Link_Print("CreditCardPayment.Locator.Link.Print"),
//	Locator_link_SeePendingPayments("CreditCardPayment.Locator.Link.SeePendingPayments"),
//	Locator_Link_SetUpAutopay("CreditCardPayment.Locator.Link.SetUpAutopay"),
//	Locator_Link_SetupAutopay("CreditCardPayment.Locator.Link.SetupAutopay"),
//	Locator_Link_Summary_Print("CreditCardPayment.Locator.Link.Summary.Print"),
//	Locator_Link_Summary_SetUpAutopay("CreditCardPayment.Locator.Link.Summary.SetUpAutopay"),
//	Locator_Link_UpdateContactDetails("CreditCardPayment.Locator.Link.UpdateContactDetails"),
//	Locator_RadioButton_AcceptConditions("CreditCardPayment.Locator.RadioButton.AcceptConditions"),
//	Locator_RadioButton_AutopayMinPayment("CreditCardPayment.Locator.RadioButton.Autopay.MinPayment"),
//	Locator_RadioButton_AutopayStatmentBalance("CreditCardPayment.Locator.RadioButton.Autopay.StatementBalance"),
//	Locator_RadioButton_CancelAutopay("CreditCardPayment.Locator.RadioButton.CancelAutopay"),
//	Locator_RadioButton_CurrentBalance("CreditCardPayment.Locator.RadioButton.CurrentBalance"),
//	Locator_RadioButton_CurrentBalance_Disabled("CreditCardPayment.Locator.RadioButton.CurrentBalance.Disabled"),
//	Locator_RadioButton_CurrentBalance_Enabled("CreditCardPayment.Locator.RadioButton.CurrentBalance.Enabled"),
//	Locator_RadioButton_Details_AcceptTCs("CreditCardPayment.Locator.RadioButton.Details.AcceptTCs"),
//	Locator_RadioButton_Details_NotAcceptTCs("CreditCardPayment.Locator.RadioButton.Details.NotAcceptTCs"),
//	Locator_RadioButton_MinimumPayment("CreditCardPayment.Locator.RadioButton.MinimumPayment"),
//	Locator_RadioButton_MinimumPayment_Disabled("CreditCardPayment.Locator.RadioButton.MinimumPayment.Disabled"),
//	Locator_RadioButton_MinimumPayment_Enabled("CreditCardPayment.Locator.RadioButton.MinimumPayment.Enabled"),
//	Locator_RadioButton_NoAcceptConditions("CreditCardPayment.Locator.RadioButton.NoAcceptConditions"),
//	Locator_RadioButton_OtherAmount("CreditCardPayment.Locator.RadioButton.OtherAmount"),
//	Locator_RadioButton_OtherAmount_Disabled("CreditCardPayment.Locator.RadioButton.OtherAmount.Disabled"),
//	Locator_RadioButton_OtherAmount_Enabled("CreditCardPayment.Locator.RadioButton.OtherAmount.Enabled"),
//	Locator_RadioButton_StatementBalance("CreditCardPayment.Locator.RadioButton.StatementBalance"),
//	Locator_RadioButton_StatementBalance_Disabled("CreditCardPayment.Locator.RadioButton.StatementBalance.Disabled"),
//	Locator_RadioButton_StatementBalance_Enabled("CreditCardPayment.Locator.RadioButton.StatementBalance.Enabled"),
//	Locator_SubTab_Autopay("CreditCardPayment.Locator.SubTab.Autopay"),
//	Locator_SubTab_Autopay_Active("CreditCardPayment.Locator.SubTab.Autopay.Active"),
//	Locator_SubTab_Autopay_ExternalAccountReturn("CreditCardPayment.Locator.SubTab.Autopay.ExternalAccountReturn"),
//	Locator_SubTab_OneTimePayment("CreditCardPayment.Locator.SubTab.OneTimePayment"),
//	Locator_SubTab_OneTimePayment_Active("CreditCardPayment.Locator.SubTab.OneTimePayment.Active"),
//	Locator_SubTab_OneTimePendingPayment("CreditCardPayment.Locator.SubTab.OneTimePendingPayment"),
//	Locator_SubTab_OneTimePendingPayment_Active("CreditCardPayment.Locator.SubTab.OneTimePendingPayment.Active"),
//	Locator_TextContainer_AccountFromConfirm("CreditCardPayment.Locator.TextContainer.AccountFromConfirm"),
//	Locator_TextContainer_AmountConfirm("CreditCardPayment.Locator.TextContainer.AmountConfirm"),
//	Locator_TextContainer_Autopay_AlreadyScheduledBanner("CreditCardPayment.Locator.TextContainer.Autopay.AlreadyScheduledBanner"),
//	Locator_TextContainer_Autopay_CancelBanner("CreditCardPayment.Locator.TextContainer.Autopay.CancelBanner"),
//	Locator_TextContainer_Autopay_SummaryBanner("CreditCardPayment.Locator.TextContainer.Autopay.SummaryBanner"),
//	Locator_TextContainer_BreadCrumb("CreditCardPayment.Locator.TextContainer.BreadCrumb"),
//	Locator_TextContainer_ByClickingConfirm("CreditCardPayment.Locator.TextContainer.ByClickingConfirm"),
//	Locator_TextContainer_CreditCardConfirm("CreditCartPayment.Locator.TextContainer.CreditCardConfirm"),
//	Locator_TextContainer_CreditCardPayment("CredtiCardPayment.Locator.TextContainer.CreditCardPayment"),
//	Locator_TextContainer_CreditCardPaymentTitle("CreditCardPayment.Locator.TextContainer.CreditCardPaymentTitle"),
//	Locator_TextContainer_CurrentBalance("CreditCardPayment.Locator.TextContainer.CurrentBalance"),
//	Locator_TextContainer_DateConfirm("CreditCardPayment.Locator.TextContainer.DateConfirm"),
//	Locator_TextContainer_DeletePendingPaymentBanner("CreditCardPayment.Locator.TextContainer.DeletePendingPaymentBanner"),
//	Locator_TextContainer_Details_Amount("CreditCardPayment.Locator.TextContainer.Details.Amount"),
//	Locator_TextContainer_Details_DueDate("CreditCardPayment.Locator.TextContainer.Details.DueDate"),
//	Locator_TextContainer_Details_Email("CreditCardPayment.Locator.TextContainer.Details.Email"),
//	Locator_TextContainer_Details_FromAccount("CreditCardPayment.Locator.TextContainer.Details.FromAccount"),
//	Locator_TextContainer_Details_PaymentDate("CreditCardPayment.Locator.TextContainer.Details.PaymentDate"),
//	Locator_TextContainer_Details_PaymentOption("CreditCardPayment.Locator.TextContainer.Details.PaymentOption"),
//	Locator_TextContainer_Details_ToAccount("CreditCardPayment.Locator.TextContainer.Details.ToAccount"),
//	Locator_TextContainer_DueDate("CreditCardPayment.Locator.TextContainer.DueDate"),
//	Locator_TextContainer_Email("CreditCardPayment.Locator.TextContainer.Email"),
//	Locator_TextContainer_FAQ_FormTitle("CreditCardPayment.Locator.TextContainer.FAQ.FormTitle"),
//	Locator_TextContainer_FAQ_Title("CreditCardPayment.Locator.TextContainer.FAQ.Title"),
//	Locator_TextContainer_FormTitle("CreditCardPayment.Locator.TextContainer.FormTitle"),
//	Locator_TextContainer_MakePayment_OneTimePaymentBanner("CreditCardPayment.Locator.TextContainer.MakePayment.OneTimePaymentBanner"),
//	Locator_TextContainer_PaymentDate_Day("CreditCardPayment.Locator.TextContainer.PaymentDate.Day"),
//	Locator_TextContainer_PaymentDate_Month("CreditCardPayment.Locator.TextContainer.PaymentDate.Month"),
//	Locator_TextContainer_PaymentDate_Year("CreditCardPayment.Locator.TextContainer.PaymentDate.Year"),
//	Locator_TextContainer_PaymentOption_Confirm("CreditCardPayment.Locator.TextContainer.PaymentOption.Confirmation"),
//	Locator_TextContainer_PendingPayment_Amount("CreditCardPayment.Locator.TextContainer.PendingPayment.Amount"),
//	Locator_TextContainer_PendingPayment_FromAccount("CreditCardPayment.Locator.TextContainer.PendingPayment.FromAccount"),
//	Locator_TextContainer_PendingPayment_PaymentDate("CreditCardPayment.Locator.TextContainer.PendingPayment.PaymentDate"),
//	Locator_TextContainer_PendingPayment_ToAccount("CreditCardPayment.Locator.TextContainer.PendingPayment.ToAccount"),
//	Locator_TextContainer_Records("CreditCardPayment.Locator.TextContainer.Records"),
//	Locator_TextContainer_Summary_SuccessMessage("CreditCardPayment.Locator.TextContainer.Summary.SuccessMessage"),
//	Locator_TextField_OtherAmount("CreditCardPayment.Locator.TextField.OtherAmount"),
//	Locator_TextField_OtherAmount_Disabled("CreditCardPayment.Locator.TextField.OtherAmount.Disabled"),
//	Locator_TextField_OtherAmount_Enabled("CreditCardPayment.Locator.TextField.OtherAmount.Enabled"),
//	Locator_TextField_PaymentDay("CreditCardPayment.Locator.TextFeild.PaymentDay"),
//	Locator_TextField_PaymentMonth("CreditCardPayment.Locator.TextField.PaymentMonth"),
//	Locator_TextField_PaymentYear("CreditCardPayment.Locator.TextField.PaymentYear"),
//	MultiLocator_Container_PendingList_PendingPayments("CreditCardPayment.MultiLocator.Container.PendingList.PendingPayments"),
//	MultiLocator_Container_PendingPayments("CreditCardPayment.MultiLocator.Container.PendingPayments"),
//	MultiLocator_Link_FAQ_Questions("CreditCardPayment.MultiLocator.Link.FAQ.Questions"),
//	MultiLocator_TextContainer_Details_SegmentTitles("CreditCardPayment.MultiLocator.TextContainer.Details.SegmentTitles"),
//	MultiLocator_TextContainer_PaymentOptions("CreditCardPayment.MultiLocator.TextContainer.PaymentOptions"),
//	MultiLocator_TextContainer_PendingList_TableHeaders("CreditCardPayment.MultiLocator.TextContainer.PendingList.TableHeaders"),
//	MultiLocator_TextContainer_PendingTableHeaders("CreditCardPayment.MultiLocator.TextContainer.PendingTableHeaders"),
//	MultiLocator_TextContainer_SegmentTitles("CreditCardPayment.MultiLocator.TextContainer.SegmentTitles"),
//	MultiLocator_TextContainer_Summary_SegmentTitles("CreditCardPayment.MultiLocator.TextContainer.Summary.SegmentTitles"),
//	MultiText_Autopay_Details_SegmentTitles("CreditCardPayment.MultiText.Autopay.Details.SegmentTitles"),
//	MultiText_Autopay_SegmentTitles("CreditCardPayment.MultiText.Autopay.SegmentTitles"),
//	MultiText_Delete_Details_SegmentTitles("CreditCardPayment.MultiText.Delete.Details.SegmentTitles"),
//	MultiText_Delete_Summary_SegmentTitles("CreditCardPayment.MultiText.Delete.Summary.SegmentTitles"),
//	MultiText_Details_SegmentTitles("CreditCardPayment.MultiText.Details.SegmentTitles"),
//	MultiText_PaymentOptions("CreditCardPayment.MultiText.PaymentOptions"),
//	MultiText_PendingList_SegmentTitles("CreditCardPayment.MultiText.PendingList.SegmentTitles"),
//	MultiText_PendingList_TableHeaders("CreditCardPayment.MultiText.PendingList.TableHeaders"),
//	MultiText_PendingTableHeaders("CreditCardPayment.MultiText.PendingTableHeaders"),
//	MultiText_SegmentTitles("CreditCardPayment.MultiText.SegmentTitles"),
//	MultiText_Summary_SegmentTitles("CreditCardPayment.MultiText.Summary.SegmentTitles"),
//	Script_Boolean_RadioButtonChecked("CreditCardPayment.Script.Boolean.RadioButtonChecked"),
//	Script_String_CurrentSelectedDropDownValue("CreditCardPayment.Script.String.CurrentSelectedDropDownValue"),
//	Script_String_GetFieldValue("CreditCardPayment.Script.String.GetFieldValue"),
//	Text_Account_AccountFrom("CreditCardPayment.Text.Account.AccountFrom"),
//	Text_Account_AccountFromJohnMarksIndex("CreditCardPayment.Text.Index.AccountFromJohnMarks"),
//	Text_Account_Index("CreditCardPayment.Text.Index.AccountFrom"),
//	Text_Autopay_AlreadyScheduledBanner_Minimum("CreditCardPayment.Text.Autopay.AlreadyScheduledBanner.Minimum"),
//	Text_Autopay_AlreadyScheduledBanner_Statement("CreditCardPayment.Text.Autopay.AlreadyScheduledBanner.Statement"),
//	Text_Autopay_CancelBanner("CreditCardPayment.Text.Autopay.CancelBanner"),
//	Text_Autopay_ConfirmBanner("CreditCardPayment.Text.Autopay.ConfirmBanner"),
//	Text_Autopay_SummaryBanner("CreditCardPayment.Text.Autopay.SummaryBanner"),
//	Text_BreadCrumb_ConfirmDetails("CreditCardPayment.Text.BreadCrumb.ConfirmDetails"),
//	Text_BreadCrumb_EnterDetails("CreditCardPayment.Text.BreadCrumb.EnterDetails"),
//	Text_BreadCrumb_Summary("CreditCardPayment.Text.BreadCrumb.Summary"),
//	Text_CreditCard_Index("CreditCardPayment.Text.Index.CreditCard"),
//	Text_CreditCard_LastNumbers("CreditCardPayment.Text.CreditCard.LastNumbers"),
//	Text_Delete_Details_BreadCrumb_Confirm("CreditCardPayment.Text.Delete.Details.BreadCrumb.Confirm"),
//	Text_Delete_Details_FormTitle("CreditCardPayment.Text.Delete.Details.FormTitle"),
//	Text_Delete_Summary_BreadCrumb("CreditCardPayment.Text.Delete.Summary.BreadCrumb"),
//	Text_Delete_Summary_FormTitle("CreditCardPayment.Text.Delete.Summary.FormTitle"),
//	Text_Delete_Summary_SuccessMessage("CreditCardPayment.Text.Delete.Summary.SuccessMessage"),
//	Text_Details_FormTitle("CreditCardPayment.Text.Details.FormTitle"),
//	Text_FAQ_FormTitle("CreditCardPayment.Text.FAQ.FormTitle"),
//	Text_FAQ_Title("CreditCardPayment.Text.FAQ.Title"),
//	Text_FormTitle("CreditCardPayment.Text.FormTitle"),
//	Text_JohnMarks_AccountFromJohnMarks_SimpleChecking7731("CreditCardPayment.Text.JohnMarks.AccountFromJohnMarks.SimpleChecking7731"),
//	Text_OneTimePaymentTitle("CreditCardPayment.Text.OnetimePaymentTitle"),
//	Text_PaymentOption_MinPayment("CreditCardPayment.Text.PaymentOption.MinPayment"),
//	Text_PaymentOption_StatmentBalance("CreditCardPayment.Text.PaymentOption.StatmentBalance"),
//	Text_PendingList_Delete("CreditCardPayment.Text.PendingList.Delete"),
//	Text_PendingList_FormTitle("CreditCardPayment.Text.PendingList.FormTitle"),
//	Text_PendingPayments_DeletePaymentIndex("CreditCardPayment.Index.DeletePendingPaymentIndex"),
//	Text_PendingPayments_DeletePendingPaymentsBannerText("CreditCardPayment.Text.PendingPayments.DeletePendingPaymentBannerText"),
//	Text_SetUpAutopay_Title("CreditCardPayment.Text.SetUpAutopay.Title"),
//	Text_Summary_FormTitle("CreditCardPayment.Text.Summary.FormTitle"),
//	Text_Summary_SuccessMessage("CreditCardPayment.Text.Summary.SuccessMessage"),


//	CreditCardPayment.CompoundLocator.Link.CalendarWidget.TargetDate=div[id$='PopCal'] a[id*='day_~~~']@@@css
//	CreditCardPayment.Locator.Button.Calendar=input[id$=iCalen]@@@css
//	CreditCardPayment.Locator.Button.Continue=a.continue@@@css
//	CreditCardPayment.Locator.Button.Details.Cancel=a.cancel@@@css
//	CreditCardPayment.Locator.Button.Details.Confirm=a.confirm@@@css
//	CreditCardPayment.Locator.Button.Go=input.boton@@@css
//	CreditCardPayment.Locator.Button.PendingPayment.Go=input@@@css
//	CreditCardPayment.Locator.Button.PendingPayments.Go.First=input#main_comboFila_2_cbBoton0@@@css
//	CreditCardPayment.Locator.Container.CalendarWidget=div[id$='PopCal']@@@css
//	CreditCardPayment.Locator.Container.FAQ=div.helpFaq@@@css
//	CreditCardPayment.Locator.DropDown.AccountFrom=select#slcCuenta@@@css
//	CreditCardPayment.Locator.DropDown.CreditCard=select[id$='selectAction']@@@css
//	CreditCardPayment.Locator.DropDown.PendingPayment.Actions=select@@@css
//	CreditCardPayment.Locator.DropDown.PendingPaymentsFirst=select#main_comboFila_2_cbAccion0@@@css
//	CreditCardPayment.Locator.Link.AddAcount=div[id$='txtEnlaceCuenta'] a@@@css
//	CreditCardPayment.Locator.Link.AlreadyScheduled=a#Already@@@css
//	CreditCardPayment.Locator.Link.Autopay.Active=li.active span#Autopay a@@@css
//	CreditCardPayment.Locator.Link.Autopay.Back=a.fback@@@css
//	CreditCardPayment.Locator.Link.Autopay.Summary.GoToPayments=a#Goto@@@css
//	CreditCardPayment.Locator.Link.Autopay=li:not(.active) span#Autopay a@@@css
//	CreditCardPayment.Locator.Link.Back=a#idBack@@@css
//	CreditCardPayment.Locator.Link.Delete.Details.Back=a.fback@@@css
//	CreditCardPayment.Locator.Link.Delete.Summary.GoToPayments=a#idViewCredit@@@css
//	CreditCardPayment.Locator.Link.Delete.Summary.SeePendingPayments=a#Pendiente@@@css
//	CreditCardPayment.Locator.Link.ExtenalAccount.AddNewAccount=//*[@id="addAcc"]@@@xpath
//	CreditCardPayment.Locator.Link.OneTimePayment.Active=li.active span#OnetimePayment a@@@css
//	CreditCardPayment.Locator.Link.OneTimePayment=li:not(.active) span#OnetimePayment a@@@css
//	CreditCardPayment.Locator.Link.OneTimePending.Active=li.active span#OneTimePending a@@@css
//	CreditCardPayment.Locator.Link.OneTimePending=li:not(.active) span#OnetimePendingPaymentList a, li:not(.active) span#OneTimePending a@@@css
//	CreditCardPayment.Locator.Link.PendingList.Help=a#help@@@css
//	CreditCardPayment.Locator.Link.Print=a#Imprimir@@@css
//	CreditCardPayment.Locator.Link.SeePendingPayments=div[id$='enlPie'] a:not([id])@@@css
//	CreditCardPayment.Locator.Link.SetUpAutopay=a#SeleccionSetUpAutopay@@@css
//	CreditCardPayment.Locator.Link.Summary.Print=a#imprimir@@@css
//	CreditCardPayment.Locator.Link.Summary.SetUpAutopay=a#idSetup@@@css
//	CreditCardPayment.Locator.Link.UpdateContactDetails=div[id$='txtChangeMail'] a@@@css
//	CreditCardPayment.Locator.PaymentOption.Confirmation=//*[@class="contenido"]/table/tbody/tr[3]/td@@@xpath
//	CreditCardPayment.Locator.RadioButton.AcceptConditions=input#rdbConsentimiento@@@css
//	CreditCardPayment.Locator.RadioButton.Autopay.MinPayment=//*[@id="rdbPagoMin"]@@@xpath
//	CreditCardPayment.Locator.RadioButton.Autopay.StatementBalance=//*[@id="rdbBalance"]@@@xpath
//	CreditCardPayment.Locator.RadioButton.CancelAutopay=input#rdbCancel@@@css
//	CreditCardPayment.Locator.RadioButton.CurrentBalance.Disabled=input#rdbCurrentBalance:disabled@@@css
//	CreditCardPayment.Locator.RadioButton.CurrentBalance.Enabled=input#rdbCurrentBalance:not(disabled)@@@css
//	CreditCardPayment.Locator.RadioButton.CurrentBalance=input#rdbCurrentBalance@@@css
//	CreditCardPayment.Locator.RadioButton.Details.AcceptTCs=input#rdbConsentimiento@@@css
//	CreditCardPayment.Locator.RadioButton.Details.NotAcceptTCs=input#rdbNoConsentimiento@@@css
//	CreditCardPayment.Locator.RadioButton.MinimumPayment.Disabled=input#rdbPagoMin:disabled@@@css
//	CreditCardPayment.Locator.RadioButton.MinimumPayment.Enabled=input#rdbPagoMin:not(disabled)@@@css
//	CreditCardPayment.Locator.RadioButton.MinimumPayment=input#rdbPagoMin@@@css
//	CreditCardPayment.Locator.RadioButton.NoAcceptConditions=input#rdbNoConsentimiento@@@css
//	CreditCardPayment.Locator.RadioButton.OtherAmount.Disabled=input#rdbOtraCantidad:disabled@@@css
//	CreditCardPayment.Locator.RadioButton.OtherAmount.Enabled=input#rdbOtraCantidad:not(disabled)@@@css
//	CreditCardPayment.Locator.RadioButton.OtherAmount=input#rdbOtraCantidad@@@css
//	CreditCardPayment.Locator.RadioButton.StatementBalance.Disabled=input#rdbBalance:disabled@@@css
//	CreditCardPayment.Locator.RadioButton.StatementBalance.Enabled=input#rdbBalance:not(disabled)@@@css
//	CreditCardPayment.Locator.RadioButton.StatementBalance=input#rdbBalance@@@css
//	CreditCardPayment.Locator.SubTab.Autopay.Active=//li[contains(@class,'active claseFF last')]//a[contains(text(),'Autopay')]@@@xpath
//	CreditCardPayment.Locator.SubTab.Autopay.ExternalAccountReturn=//*[@class="InternetAtSubCabPestana pr"]/ul/li[3]/span/a@@@xpath
//	CreditCardPayment.Locator.SubTab.Autopay=//li[contains(@class,'after last')]//a[contains(text(),'Autopay')]@@@xpath
//	CreditCardPayment.Locator.SubTab.OneTimePayment.Active=//li[contains(@class,'active claseFF first')]//a[contains(text(),'One-Time Payment')]@@@xpath
//	CreditCardPayment.Locator.SubTab.OneTimePayment=//li[contains(@class,'first')]//a[contains(text(),'One-Time Payment')]@@@xpath
//	CreditCardPayment.Locator.SubTab.OneTimePendingPayment.Active=//li[contains(@class,'active claseFF')]//a[contains(text(),'One-Time Pending Payment List')]@@@xpath
//	CreditCardPayment.Locator.SubTab.OneTimePendingPayment=//a[contains(text(),'One-Time Pending Payment List')]@@@xpath
//	CreditCardPayment.Locator.TextContainer.AccountFromConfirm=//*[@class="contenido"]/table/tbody/tr[1]/td@@@xpath
//	CreditCardPayment.Locator.TextContainer.Autopay.AlreadyScheduledBanner=div[id$='infAutopay'] span.title@@@css
//	CreditCardPayment.Locator.TextContainer.Autopay.CancelBanner=div.confirmation span.title@@@css
//	CreditCardPayment.Locator.TextContainer.Autopay.SummaryBanner=div.confirmation span.subtitle@@@css
//	CreditCardPayment.Locator.TextContainer.BreadCrumb=li.activo span:not(.arrow)@@@css
//	CreditCardPayment.Locator.TextContainer.ByClickingConfirm=//p[contains(text(),'By clicking the "Confirm" button')]@@@xpath
//	CreditCardPayment.Locator.TextContainer.CreditCardConfirm=//*[@class="contenido"]/table/tbody/tr[2]/td@@@xpath
//	CreditCardPayment.Locator.TextContainer.CreditCardPayment=//p[contains(text(),'credit card payment using')]@@@xpath
//	CreditCardPayment.Locator.TextContainer.CreditCardPaymentTitle=span.titulo@@@css
//	CreditCardPayment.Locator.TextContainer.CurrentBalance=div[id$='CurrentBalance'] label@@@css
//	CreditCardPayment.Locator.TextContainer.DateConfirm=//*[@class="contenido"]/table/tbody/tr[5]/td@@@xpath
//	CreditCardPayment.Locator.TextContainer.DeletePendingPaymentBanner=//*[@class="InfoInfoMsg InfoInfoMsgLayoutContent confirmation pr"]/div[2]/div/p/span[2]@@@xpath
//	CreditCardPayment.Locator.TextContainer.Details.Amount=//h1[contains(text(),'Amount:')]/parent::th/following-sibling::td@@@xpath
//	CreditCardPayment.Locator.TextContainer.Details.DueDate=//h1[contains(text(),'Due Date:')]/parent::th/following-sibling::td@@@xpath
//	CreditCardPayment.Locator.TextContainer.Details.Email=div[id$='txtPreferedMail']@@@css
//	CreditCardPayment.Locator.TextContainer.Details.FromAccount=//h1[contains(text(),'from:')]/parent::th/following-sibling::td@@@xpath
//	CreditCardPayment.Locator.TextContainer.Details.PaymentDate=//h1[contains(text(),'Payment Date:')]/parent::th/following-sibling::td@@@xpath
//	CreditCardPayment.Locator.TextContainer.Details.PaymentOption=//h1[contains(text(),'Payment Option:')]/parent::th/following-sibling::td@@@xpath
//	CreditCardPayment.Locator.TextContainer.Details.ToAccount=//h1[contains(text(),'to:')]/parent::th/following-sibling::td@@@xpath
//	CreditCardPayment.Locator.TextContainer.DueDate=div[id$='PagoValue'] p, span[id^='lblFechaVenc']@@@css
//	CreditCardPayment.Locator.TextContainer.Email=div[id$='txtPreferedMail'] p, div[id$='txtConfirmationEmail'] p@@@css
//	CreditCardPayment.Locator.TextContainer.FAQ.FormTitle=div.helpFaq h5@@@css
//	CreditCardPayment.Locator.TextContainer.FAQ.Title=div.helpFaq h4@@@css
//	CreditCardPayment.Locator.TextContainer.FormTitle=span.titulo@@@css
//	CreditCardPayment.Locator.TextContainer.PaymentDate.Day=span.dia input@@@css
//	CreditCardPayment.Locator.TextContainer.PaymentDate.Month=span.mes input@@@css
//	CreditCardPayment.Locator.TextContainer.PaymentDate.Year=span.anho input@@@css
//	CreditCardPayment.Locator.TextContainer.PendingPayment.Amount=td:nth-of-type(4)@@@css
//	CreditCardPayment.Locator.TextContainer.PendingPayment.FromAccount=td:nth-of-type(2)@@@css
//	CreditCardPayment.Locator.TextContainer.PendingPayment.PaymentDate=td:nth-of-type(1)@@@css
//	CreditCardPayment.Locator.TextContainer.PendingPayment.ToAccount=td:nth-of-type(3)@@@css
//	CreditCardPayment.Locator.TextContainer.Records=div.numeros@@@css
//	CreditCardPayment.Locator.TextContainer.Summary.SuccessMessage=div[id*='infMsg'] span.subtitle@@@css
//	CreditCardPayment.Locator.TextFeild.PaymentDay=//*[@id="main.formCC_SinglePayment_1.cfeFechaPago.iDay"]@@@xpath
//	CreditCardPayment.Locator.TextField.OtherAmount.Disabled=input#impOtraCantidad:disabled@@@css
//	CreditCardPayment.Locator.TextField.OtherAmount.Enabled=input#impOtraCantidad:not(disabled)@@@css
//	CreditCardPayment.Locator.TextField.OtherAmount=input#impOtraCantidad@@@css
//	CreditCardPayment.Locator.TextField.PaymentMonth=//*[@id="main.formCC_SinglePayment_1.cfeFechaPago.iMonth"]@@@xpath
//	CreditCardPayment.Locator.TextField.PaymentYear=//*[@id="main.formCC_SinglePayment_1.cfeFechaPago.iYear"]@@@xpath
//	CreditCardPayment.MultiLocator.Container.PendingList.PendingPayments=tbody tr@@@css
//	CreditCardPayment.MultiLocator.Container.PendingPayments=tbody[id*='PendingPayments'] tr@@@css
//	CreditCardPayment.MultiLocator.Link.FAQ.Questions=div.helpFaq a@@@css
//	CreditCardPayment.MultiLocator.TextContainer.Details.SegmentTitles=div[id$='dtcPrincipal'] span.title@@@css
//	CreditCardPayment.MultiLocator.TextContainer.PaymentOptions=div[id*='Opciones'] label[for^='rdb']@@@css
//	CreditCardPayment.MultiLocator.TextContainer.PendingList.TableHeaders=thead span@@@css
//	CreditCardPayment.MultiLocator.TextContainer.PendingTableHeaders=thead span@@@css
//	CreditCardPayment.MultiLocator.TextContainer.SegmentTitles=span.title@@@css
//	CreditCardPayment.MultiLocator.TextContainer.Summary.SegmentTitles=div[id*='dtcPpal'] span.title@@@css
//	CreditCardPayment.MultiText.Autopay.Details.SegmentTitles=Autopay Details
//	CreditCardPayment.MultiText.Autopay.SegmentTitles=Autopay Details
//	CreditCardPayment.MultiText.Delete.Details.SegmentTitles=Delete One-time Credit Card Payment
//	CreditCardPayment.MultiText.Delete.Summary.SegmentTitles=Delete Manual Credit Card Pending Payment
//	CreditCardPayment.MultiText.Details.SegmentTitles=One-time Credit Card Payment Details
//	CreditCardPayment.MultiText.PaymentOptions=Minimum,Statement,Current,Other
//	CreditCardPayment.MultiText.PendingList.SegmentTitles=Pending Payments List
//	CreditCardPayment.MultiText.PendingList.TableHeaders=Payment Date,Account from,Credit Card to,Amount,Payment Status,Actions
//	CreditCardPayment.MultiText.PendingTableHeaders=Payment Date,Account From,Credit Card To,Amount,Payment Status
//	CreditCardPayment.MultiText.SegmentTitles=One-time Credit Card Payment Details,Pending Payments List
//	CreditCardPayment.MultiText.Summary.SegmentTitles=One-time Credit Card Payment Details
//	CreditCardPayment.Script.Boolean.RadioButtonChecked=return arguments[0].checked == true;
//	CreditCardPayment.Script.String.CurrentSelectedDropDownValue=return arguments[0].options[arguments[0].selectedIndex].text;
//	CreditCardPayment.Script.String.GetFieldValue=return parseInt(arguments[0].value);
//	CreditCardPayment.Text.Autopay.AlreadyScheduledBanner.Minimum=autopay scheduled for your minimum amount due
//	CreditCardPayment.Text.Autopay.AlreadyScheduledBanner.Statement=autopay scheduled for your statement balance
//	CreditCardPayment.Text.Autopay.CancelBanner=Autopay cancelled successfully.
//	CreditCardPayment.Text.Autopay.ConfirmBanner=Autopay Set Up or Modified Successfully.
//	CreditCardPayment.Text.Autopay.SummaryBanner=Autopay Set Up or Modified Successfully.
//	CreditCardPayment.Text.BreadCrumb.ConfirmDetails=Confirm Details
//	CreditCardPayment.Text.BreadCrumb.EnterDetails=Enter Details
//	CreditCardPayment.Text.BreadCrumb.Summary=Summary
//	CreditCardPayment.Text.Delete.Details.BreadCrumb.Confirm=Confirm Details
//	CreditCardPayment.Text.Delete.Details.FormTitle=Delete One-time Credit Card Payment
//	CreditCardPayment.Text.Delete.Summary.BreadCrumb=Summary
//	CreditCardPayment.Text.Delete.Summary.FormTitle=Delete One-time Credit Card Payment
//	CreditCardPayment.Text.Delete.Summary.SuccessMessage=Deleted Successfully
//	CreditCardPayment.Text.DeletePendingPaymentBannerText=One-time Credit Card Payment Deleted Successfully.
//	CreditCardPayment.Text.Details.FormTitle=Make a One-time Credit Card Payment
//	CreditCardPayment.Text.FAQ.FormTitle=Frequently Asked Questions
//	CreditCardPayment.Text.FAQ.Title=If you need help
//	CreditCardPayment.Text.FormTitle=Credit Card Payment
//	CreditCardPayment.Text.Index.AccountFrom=0
//	CreditCardPayment.Text.JohnMarks.AccountFromJohnMarks.SimpleChecking7731=Simply right checking - *7731
//	CreditCardPayment.Text.PaymentOption.MinPayment=Minimum amount due
//	CreditCardPayment.Text.PaymentOption.StatmentBalance=Statement balance
//	CreditCardPayment.Text.PendingList.Delete=Delete
//	CreditCardPayment.Text.PendingList.FormTitle=Credit Card Payment
//	CreditCardPayment.Text.SetUpAutopay.Title=Set up or Modify an Autopay
//	CreditCardPayment.Text.Summary.FormTitle=Make a One-time Credit Card Payment
//	CreditCardPayment.Text.Summary.SuccessMessage=Completed Successfully


}
