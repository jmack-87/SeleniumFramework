package common_resources;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.WebDriverEventListener;

public class sanlistener implements WebDriverEventListener {

	@Override
	public void beforeAlertAccept(WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterAlertAccept(WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterAlertDismiss(WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void beforeAlertDismiss(WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void beforeNavigateTo(String s, WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterNavigateTo(String s, WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void beforeNavigateBack(WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterNavigateBack(WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void beforeNavigateForward(WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterNavigateForward(WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void beforeNavigateRefresh(WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterNavigateRefresh(WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void beforeFindBy(By by, WebElement webElement, WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterFindBy(By by, WebElement webElement, WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void beforeClickOn(WebElement webElement, WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterClickOn(WebElement webElement, WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void beforeChangeValueOf(WebElement webElement, WebDriver webDriver, CharSequence[] charSequences) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterChangeValueOf(WebElement webElement, WebDriver webDriver, CharSequence[] charSequences) {
		// TODO Auto-generated method stub
	}

	@Override
	public void beforeScript(String s, WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterScript(String s, WebDriver webDriver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onException(Throwable throwable, WebDriver webDriver) {

		utility uObj = new utility();
		System.out.println("Exception occurred at " + throwable.getMessage());
		// System.out.println("Exception occurred at "+throwable.getLocalizedMessage());
		uObj.fnReportLog("Failed", "Webdriver Exception occurred at ", throwable.getMessage(), true,
				throwable.getLocalizedMessage());
	}

	@Override
	public void beforeSwitchToWindow(String windowName, WebDriver driver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterSwitchToWindow(String windowName, WebDriver driver) {
		// TODO Auto-generated method stub
	}

	@Override
	public <X> void beforeGetScreenshotAs(OutputType<X> target) {
		// TODO Auto-generated method stub
	}

	@Override
	public <X> void afterGetScreenshotAs(OutputType<X> target, X screenshot) {
		// TODO Auto-generated method stub
	}

	@Override
	public void beforeGetText(WebElement element, WebDriver driver) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterGetText(WebElement element, WebDriver driver, String text) {
		// TODO Auto-generated method stub
	}
}
