package app_resources.c2s.pageObjects;

import org.openqa.selenium.By;

public class PersonalDataPage {

	public static By Locator_Image_AddAccounts = 							By.xpath("//img[@id='Actions'][@src='/crm/apps-general/images/customer_details/icoCustomerActions.png']");
	public static By Locator_DropDownOption_OpenAccount = 					By.cssSelector("a#naoOptionsOpener");
	public static By Locator_DropDownOption_DepositAccounts = 				By.xpath("//li[@class='naoOptions']/a");
	public static By Locator_TextField_SSNSearchBox = 						By.xpath("//*[@name='snnBox'][@ng-model='snnNumber']");
	public static By Locator_Button_ExistingCustomerCheck = 				By.xpath("//button[@class='right btgrey flr nao-generic-btn ng-binding'][@ng-click='checkSSN(searchCombo,snnNumber,formSnnSearch.snnBox.$valid,formSnnSearch.snnBox.$error.required)']");
	public static By Locator_Text_NameInList = 								By.xpath("//tr[@class='ng-scope'][@ng-repeat='person in ssnList']");
	public static By Locator_Text_PersonalDataHeader = 						By.xpath("//div[@class='formBlock'][@id='personalInfo']/h2");
	public static By Locator_Button_ValidateAddress = 						By.xpath("//form[@id='newAddressForm'][@name='addrFormWidget']/button");
	public static By Locator_Button_ContinueWithoutValidatingButton = 		By.xpath("//form[@id='newAddressForm'][@name='addrFormWidget']/button[2]");
	public static By Locator_TextField_PersonalDataEmail = 					By.xpath("//input[@name='myemail'][@class='ng-pristine ng-invalid ng-invalid-required ng-valid-email ng-valid-pattern']");
	public static By Locator_DropDown_CountryOfBirthClean = 				By.xpath("//form[@class='ng-pristine ng-invalid ng-invalid-required'][@name='aditionalInfo']/ul/li/select");
	public static By Locator_DropDown_CountryOfBirthDirty = 				By.xpath("//form[@class='ng-invalid ng-invalid-required ng-dirty'][@name='aditionalInfo']/ul/li/select");
	public static By Locator_DropDown_CountryOfResidence = 					By.xpath("//form[@class='ng-invalid ng-invalid-required ng-dirty'][@name='aditionalInfo']/ul/li[2]/select");
	public static By Locator_DropDown_Citizenship = 						By.xpath("//form[@class='ng-invalid ng-invalid-required ng-dirty'][@name='aditionalInfo']/ul/li[3]/select");
	public static By Locator_DropDown_ResidentTaxStatusClean = 				By.xpath("//form[@class='ng-invalid ng-invalid-required ng-dirty'][@name='aditionalInfo']/ul/li[4]/select");
	public static By Locator_DropDown_ResidentTaxStatusDirty = 				By.xpath("//form[@class='ng-dirty ng-valid ng-valid-required'][@name='aditionalInfo']/ul/li[4]/select");
	public static int Text_Index_AddtionalPersonalInfoIndex = 				1;
	public static By Locator_Text_NewAddressesTitle = 						By.xpath("//div[@class='addressesList'][@id='new-address-list']");
	public static By Locator_TextField_EmployerNameField =					By.xpath("//input[@class='ng-pristine ng-invalid ng-invalid-required'][@ng-model='prospectFORM.employmentInfo.employerName']");
	public static By Locator_Tab_PrimaryOtherID = 							By.xpath("//div[@id='primaryIDtype']/div/div[4]");
	public static By Locator_DropDown_PrimaryOtherIDType = 					By.xpath("//div[@id='primaryID']/div/div[4]/div/div/select");
	public static int Text_Index_AmishIDType = 								1;
	public static By Locator_DropDown_PrimaryID_IssueCountry = 				By.xpath("//div[@id='employmentInfo'][@class='formRowCapture twoInRow']/select");
	public static int Text_Index_PrimaryID_IssueCountryIndex = 				1;
	public static By Locator_DropDown_PrimaryID_IssueDateMonth = 			By.xpath("//div[@id='initDate1']/div/select");
	public static By Locator_DropDown_PrimaryID_IssueDateDay = 				By.xpath("//div[@id='initDate1']/div[2]/select");
	public static By Locator_DropDown_PrimaryID_IssueDateYear = 			By.xpath("//div[@id='initDate1']/div[3]/select");
	public static By Locator_DropDown_PrimaryID_ExpireDateMonth = 			By.xpath("//div[@id='expirationDate1']/div/select");
	public static By Locator_DropDown_PrimaryID_ExpireDateDay = 			By.xpath("//div[@id='expirationDate1']/div[2]/select");
	public static By Locator_DropDown_PrimaryID_ExpireDateYear = 			By.xpath("//div[@id='expirationDate1']/div[3]/select");
	public static By Locator_DropDown_PrimaryID_StateIssued = 				By.xpath("//div[@class='formRowCapture twoInRow ng-scope'][@id='employmentInfo']/select");
	public static int Text_Index_PrimaryIDIssueDateIndex = 					1;
	public static int Text_Index_PrimaryIDExpireDateIndex = 				2;
	public static By Locator_Tab_SecondaryMedicalID = 						By.cssSelector("div#secondaryID div[ng-click*=medical]");
	public static By Locator_TextField_SecondaryIDNumber = 					By.cssSelector("div#secondaryID input[name*=idNumber2]");
	public static By Locator_DropDown_SecondaryIssueCountry = 				By.cssSelector("div#secondaryID select[ng-show*=country2Ind]");
	public static int Text_Index_SecondaryIssueCountryIndex = 				1;
	public static By Locator_Button_GoToQualification = 					By.cssSelector("div#createProspectPage button[ng-click^=formSubmit]");
	public static By Locator_Image_OpenAccountImageProspect = 				By.cssSelector("#ProspectContainerHeader div:nth-child(3) a img");
	public static By Locator_DropDown_SecondaryID_IssueDateMonth = 			By.cssSelector("div#secondaryID select[name^=initDate2Month]");
	public static By Locator_DropDown_SecondaryID_IssueDateDay = 			By.cssSelector("div#secondaryID select[name^=initDate2Day]");
	public static By Locator_DropDown_SecondaryID_IssueDateYear = 			By.cssSelector("div#secondaryID select[name^=initDate2Year]");
	public static By Locator_DropDown_Secondary_ExpireDateMonth = 			By.cssSelector("div#secondaryID select[name^=expirationDate2Month]");
	public static By Locator_DropDown_Secondary_ExpireDateDay = 			By.cssSelector("div#secondaryID select[name^=expirationDate2Day]");
	public static By Locator_DropDown_Secondary_ExpireDateYear = 			By.cssSelector("div#secondaryID select[name^=expirationDate2Year]");
	public static By Locator_DropDown_Secondary_StateIssued = 				By.cssSelector("div#secondaryID select[ng-show*=state2Ind]");
	public static int Text_Index_SecondaryIDIssueDateIndex = 				1;
	public static int Text_Index_SecondaryIDExpireDateIndex = 				2;
	public static By Locator_Button_AddressNotFoundCancel = 				By.cssSelector("div#error button.btn-basic:first-child");
	public static By Locator_Image_CustomerActionsAccount = 				By.cssSelector("div#actions-menu img#customerActions[ng-click*=\"naoLinksBox\"]");		
	public static By Locator_Button_ReQualifyCustomer = 					By.cssSelector("div#customerIdentificationAndQualification button[ng-click^=reQualifileCustomer]");

}
