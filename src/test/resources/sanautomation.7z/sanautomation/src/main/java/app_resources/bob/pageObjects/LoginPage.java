package app_resources.bob.pageObjects;

import org.openqa.selenium.By;

public class LoginPage {

	public static By verificationText;

	//TODO: bob login stuff

}
