package app_resources.c2s.pageObjects;

import org.openqa.selenium.By;

public class ONEDashboard {

	public static By Locator_Image_EngagementSummaryDropDown = 				By.cssSelector("div#engagement-container img[src*='/crm/apps-general/images/engagement_summary_chart & table/icoArrowDown_new.png']");
	public static By Locator_SantanderPremierPlusMoneyMarketSavings = 		By.cssSelector("tr#selectedAccount td[title*=\"SANTANDER PREMIER PLUS MONEY MARKET SAVING\"]");
	public static By Locator_SantanderPremierPlusChecking = 				By.cssSelector("tr#selectedAccount td[title*=\"SANTANDER PREMIER PLUS CHECKING\"]");
	public static By Locator_SantanderBasicChecking = 						By.cssSelector("tr#selectedAccount td[title*=\"SANTANDER BASIC CHECKING\"]");
	public static By Locator_SantanderSavings = 							By.cssSelector("tr#selectedAccount td[title*=\"SANTANDER SAVINGS\"]");
	public static By Locator_SantanderSelectChecking = 						By.cssSelector("tr#selectedAccount td[title*=\"SANTANDER SELECT CHECKING\"]");
	public static By Locator_SantanderSelectMoneyMarket = 					By.cssSelector("tr#selectedAccount td[title*=\"SANTANDER SELECT MONEY MARKET\"]");
	public static By Locator_SimplyRightChecking = 							By.cssSelector("tr#selectedAccount td[title*=\"SIMPLY RIGHT CHECKING\"]");
	public static By Locator_StudentValueChecking = 						By.cssSelector("tr#selectedAccount td[title*=\"STUDENT VALUE CHECKING\"]");
	public static By Locator_TeamMemberChecking = 							By.cssSelector("tr#selectedAccount td[title*=\"TEAM MEMBER CHECKING\"]");
	public static By Locator_SantanderMoneyMarketSavings = 					By.cssSelector("tr#selectedAccount td[title*=\"SANTANDER MONEY MARKET SAVINGS\"]");
	
}
