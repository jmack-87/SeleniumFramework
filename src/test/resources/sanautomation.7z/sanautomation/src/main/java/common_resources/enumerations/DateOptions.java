package common_resources.enumerations;

public enum DateOptions {

	TODAY,
	TOMORROW,
	WEEKDAY,
	WEEKEND,
	;


}
