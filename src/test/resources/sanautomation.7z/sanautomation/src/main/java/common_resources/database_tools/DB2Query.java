package common_resources.database_tools;

public class DB2Query {

	// parameterized query strings
	// NOTE: "%s" is a Java String.format(format, args) convention
	public static String Query_ContractNumber_from_Xpan_Count = 		"SELECT COUNT(*) as SIZE FROM ORG01.MPDT009 WHERE E1039_XPAN = '%s'";
	public static String Query_ContractNumber_from_Xpan = 				"SELECT E1039_CDGENTI as PREFIX, E1039_CENTALTA as INFIX, BIGINT(E1039_CUENTNU) as SUFFIX FROM ORG01.MPDT009 WHERE E1039_XPAN = '%s'";


}