package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class Alerts {


	public static By Locator_AddContactDetails_DescriptionDropdown =                                                By.cssSelector("select#slcDesciption");
	public static By Locator_AddContactDetails_NumberEmailAddress_TextField_NumberEmail =                           By.cssSelector("input#txtNumber");
	public static By Locator_AddContactDetails_Preferred_RadioButton_No =                                           By.cssSelector("input#rdbNo");
	public static By Locator_AddContactDetails_Preferred_RadioButton_Yes =                                          By.cssSelector("input#rdbYes");
	public static By Locator_AddContactDetails_Title_ContactDetails =                                               By.xpath("span[contains(text(),'Contact Details')]");
	public static By Locator_AddContactDetails_TypeDropdown =                                                       By.cssSelector("select#slcType");
	public static By Locator_AlertOption_CheckBox_GENERIC_DeliveryMethod_Email =                                    By.xpath("//input[starts-with(@id,'chkMail') or starts-with(@id,'chkEmail')]");
	public static By Locator_AlertOption_CheckBox_GENERIC_DeliveryMethod_SMS =                                      By.cssSelector("input[id^=chkPhone]");
	public static By Locator_AlertOption_CheckBox_GENERIC_Enable =                                                  By.cssSelector("input[id^=chkEnable]");
	public static By Locator_AlertOption_TextContainer_GENERIC_NotifyMe =                                           By.cssSelector("span[id^=lblLitNotify]");
	public static By Locator_Button_Activate =                                                               		By.cssSelector("a#main_btnActivate_enlace");
	public static By Locator_Button_Details_Cancel =                                                                By.cssSelector("a.cancel");
	public static By Locator_Button_Details_Confirm =                                                               By.cssSelector("a.confirm");
	public static By Locator_Button_EnableSMS =                                                               		By.cssSelector("a#main_btnSMS2_enlace");
	public static By Locator_Button_Go =                                                               				By.cssSelector("input.boton");
	public static By Locator_Button_Restore =                                                               		By.cssSelector("a[id*=Restore]");
	public static By Locator_Button_SMSEnableDisable =                                                              By.cssSelector("div.btnsolido a[id*=SMS]");
	public static By Locator_Button_Update =                                                               			By.cssSelector("a[id*=Update]");
	public static By Locator_CellPhoneNubmer_Dropdown =                                                             By.cssSelector("select#slcCell");
	public static By Locator_CellPhoneNumber_Dropdown_OptionOne =                                                   By.cssSelector("option[value=1]");
	public static By Locator_CheckBox_BalanceLessThanZero =                                                   		By.cssSelector("input#chkEnable");
	public static By Locator_CheckBox_BalanceLessThanZero_Email =                                                   By.cssSelector("input#chkMail1");
	public static By Locator_CheckBox_InternationalTransaction_Email =                                              By.xpath("//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Mail')]");
	public static By Locator_CheckBox_InternationalTransaction_Email_Checked =                                      By.xpath("//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Mail') and contains(@class, 'checked')]");
	public static By Locator_CheckBox_InternationalTransaction_Email_PreChecked =                                   By.xpath("//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Mail')][@checked]");
	public static By Locator_CheckBox_InternationalTransaction_Email_Unchecked =                                    By.xpath("//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Mail') and not(contains(@class, 'checked'))]");
	public static By Locator_CheckBox_InternationalTransaction_Enable =                                             By.xpath("//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Enable')]");
	public static By Locator_CheckBox_InternationalTransaction_Enable_Checked =                                     By.xpath("//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Enable') and contains(@class, 'checked')]");
	public static By Locator_CheckBox_InternationalTransaction_Enable_PreChecked =                                  By.xpath("//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Enable')][@checked]");
	public static By Locator_CheckBox_InternationalTransaction_Enable_Unchecked =                                   By.xpath("//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Enable') and not(contains(@class, 'checked'))]");
	public static By Locator_CheckBox_InternationalTransaction_SMS =                                                By.xpath("//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Phone')]");
	public static By Locator_CheckBox_InternationalTransaction_SMS_Checked =                                        By.xpath("//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Phone') and contains(@class, 'Enable')]");
	public static By Locator_CheckBox_InternationalTransaction_SMS_PreChecked =                                     By.xpath("//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Phone')][@checked]");
	public static By Locator_CheckBox_InternationalTransaction_SMS_Unchecked =     									By.xpath("//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Phone') and not(contains(@class, 'Enable'))]");
	public static By Locator_DropDown_AccountNumber =                                                               By.cssSelector("select[id*=AccNumber]");
	public static By Locator_Dropdown_Accounts =                                                               		By.cssSelector("select#main_slaAccNumber_selectAction");
	public static By Locator_Email_Dropdown =       																By.cssSelector("select#slcEmail");
	public static By Locator_Email_Dropdown_Option1 =                                                               By.cssSelector("option[value=1]");
	public static By Locator_ErrorMessage =                                                               			By.cssSelector("div[class='InfoInfoMsg InfoInfoMsgLayoutContent pr']");
	public static By Locator_Image_InternationalTransaction_Check =                                                 By.xpath("//span[text()[contains(.,'International')]]/parent::td/preceding-sibling::td[contains(@class,'first')]//img[contains(@src,'check')]");
	public static By Locator_Image_InternationalTransaction_Unchecked =                                             By.xpath("//span[text()[contains(.,'International')]]/parent::td/preceding-sibling::td[contains(@class,'first')]//img[contains(@src,'aspa')]");
	public static By Locator_Image_SMSEnabledDisabled =                                                             By.cssSelector("img[id*=title]");
	public static By Locator_Link_Accounts =																		By.cssSelector("li:not(.active) span[title='Accounts'] a");
	public static By Locator_Link_Accounts_Active =																	By.cssSelector("li.active span[title='Accounts'] a");
	public static By Locator_Link_CreditCards =																		By.cssSelector("li:not(.active) span[title='Credit Cards'] a");
	public static By Locator_Link_CreditCards_Active =																By.cssSelector("li.active span[title='Credit Cards'] a");
	public static By Locator_Link_Security =																		By.cssSelector("li:not(.active) span[title='Security'] a");
	public static By Locator_Link_Security_Active =																	By.cssSelector("li.active span[title='Security'] a");
	public static By Locator_Link_Statements =																		By.cssSelector("li:not(.active) span[title='Statements'] a");
	public static By Locator_Link_Statements_Active =																By.cssSelector("li.active span[title='Statements'] a");
	public static By Locator_Link_ActivateCellPhoneNumber =                                                         By.cssSelector("a#idChangeProfile");
	public static By Locator_Link_Back =                                                               				By.cssSelector("a#idBack");
	public static By Locator_Link_BackToAlerts =                                                               		By.cssSelector("a#idBack");
	public static By Locator_Link_ChangeAlertsProfile =                                                             By.cssSelector("a#idChangeYourProfile,a#CambiarPerfil");
	public static By Locator_Link_ChangeAlertsStatus =                                                              By.cssSelector("a#idChangeAlertsHistory,a#CambiarAlertas");
	public static By Locator_Link_ClickHere_ActivateCellPhone =                                                     By.cssSelector("a#idChangeProfile");
	public static By Locator_Link_ClickHere_ChangeContactPreferences =                                              By.cssSelector("p.marco > a:not(#idChangeProfile)");
	public static By Locator_Link_HelpWithThisPage =                                                                By.cssSelector("a#Ayuda");
	public static By Locator_Link_Summary_Print =    									                           	By.cssSelector("a#Imprimir");
	public static By Locator_Link_TermsAndConditions =                                                              By.cssSelector("a#main_txtTerms_enlace_1");
	public static By Locator_Link_UpdateYourContactDetails =                                                        By.xpath("//a[contains(text(),'update your contact details')]");
	public static By Locator_Link_ViewAlertsHistory =                                                               By.cssSelector("a#idViewAlerts,a#VerAlertas");
	public static By Locator_ManageContactDetails_AddContactDetail =                                                By.cssSelector("a#transfer");
	public static By Locator_ManageContactDetails_ContactDetails_CellPhone_Actions_Button_Go =                      By.cssSelector("input#main_slnTabla_0");
	public static By Locator_ManageContactDetails_ContactDetails_CellPhone_ActionsDropdown =						By.cssSelector("select.CN_Combo");
	public static By Locator_ManageContactDetails_ContactDetails_Text_CellPhone =									By.xpath("//span[contains(text(),'Cell Phone')]");
	public static By Locator_ManageContactDetails_Title_ManageContactDetials =										By.xpath("//span[contains(text(),'Manage Contact Detials')]");
//	public static By Locator_PageTab_Accounts =																		By.cssSelector("li:not(.active) span[title='Accounts'] a");
//	public static By Locator_PageTab_AccountsActive =																By.cssSelector("li.active span[title='Accounts'] a");
//	public static By Locator_PageTab_CreditCards =																	By.cssSelector("li:not(.active) span[title='Credit Cards'] a");
//	public static By Locator_PageTab_CreditCardsActive =															By.cssSelector("li.active span[title='Credit Cards'] a");
//	public static By Locator_PageTab_Security =																		By.cssSelector("li:not(.active) span[title='Security'] a");
//	public static By Locator_PageTab_SecurityActive =																By.cssSelector("li.active span[title='Security'] a");
//	public static By Locator_PageTab_Statements =																	By.cssSelector("li:not(.active) span[title='Statements'] a");
//	public static By Locator_PageTab_StatementsActive =																By.cssSelector("li.active span[title='Statements'] a");
	public static By Locator_RadioButton_Accept =																	By.cssSelector("input#rdbSiConsentimiento");
	public static By Locator_RadioButton_NoAccept =																	By.cssSelector("input#rdbNoConsentimiento");
	public static By Locator_SubTitle_Profile =																		By.xpath("//span[contains(text(),'Profile')]");
	public static By Locator_Text_AlertsUpdatedSuccess =															By.cssSelector("div[id$='infConfirmation'] span.title");
	public static By Locator_Text_NotActivatedAlerts =																By.xpath("//div[id$='infConfirmation'] span.title");
	public static By Locator_Text_SMSAutoNotificationDisabled =														By.xpath("//p[contains(text(),'SMS Auto-Notifications Disabled')]");
	public static By Locator_TextContainer_BreadCrumb = 															By.cssSelector("li.activo span:not(.arrow)");
	public static By Locator_TextContainer_ContactPreferences_CellPhoneNumber =										By.xpath("//h1[contains(string(),'Cell')]/parent::th/following-sibling::td");
	public static By Locator_TextContainer_ContactPreferences_Email =												By.xpath("//h1[contains(string(),'Email')]/parent::th/following-sibling::td");
	public static By Locator_TextContainer_Details_AccountNumber =													By.cssSelector("td.value");
	public static By Locator_TextContainer_Details_BreadCrumb =														By.cssSelector("li.activo span:not(.arrow)");
	public static By Locator_TextContainer_Details_SegmentTitle =													By.cssSelector("div[id$='cntAlerts'] span.title");
	public static By Locator_TextContainer_FormTitle =																By.cssSelector("div[id='main.titPrincipal'] span.titulo");
	public static By Locator_TextContainer_InternationalTransaction_Delivery =										By.xpath("//span[text()[contains(.,'International')]]/parent::td/following-sibling::td[contains(@class,'last')]/span");
	public static By Locator_TextContainer_SectionTitle_ContactPreferences =										By.cssSelector("div[id^='main.titContac'] span.titulo");
	public static By Locator_TextField_ActivationCode =																By.cssSelector("input#txtActivation");
	public static By Locator_Title_ActivateAlertsService =															By.xpath("//span[contains(text(),'Activate Alerts Service')]");
	public static By MultiLocator_AlertOptions =																	By.xpath("//div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]");
	public static By MultiLocator_CheckBox_CheckedEmail =															By.xpath("//div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]input[(starts-with(@id,'chkMail') or starts-with(@id, 'chkEmail')) and contains(@class,'checked')][@checked]");
	public static By MultiLocator_CheckBox_CheckedEnable =															By.xpath("//div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]input[starts-with(@id,'chkEnable') and contains(@class,'checked')][@checked]");
	public static By MultiLocator_CheckBox_CheckedSMS =																By.xpath("//div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]input[starts-with(@id, 'chkPhone') and contains(@class,'checked')][@checked]");
	public static By MultiLocator_Image_Details_Enabled =															By.xpath("//td[contains(@class,'first')]img[contains(@src,'check')]");
	public static By MultiLocator_TextContainer_AutoNotificationTypes =												By.cssSelector("span.txtPuntoRojo strong");
	public static By MultiLocator_TextContainer_SubSectionTitles =													By.cssSelector("span.title");
	public static By MultiLocator_TextContainer_TableHeaders =														By.cssSelector("div[id*=cntAlerts] th > span");
	public static String Locator_AddContactDetails_Description_Dropdown_Business =   								"Business";
	public static String Locator_AddContactDetails_Description_Dropdown_Personal = 									"Personal";
	public static String Locator_AddContactDetails_NumberEmailAddress_Text_BusEmail =                               "ghi@jkl.com";
	public static String Locator_AddContactDetails_NumberEmailAddress_Text_BusNumber =                              "9876543210";
	public static String Locator_AddContactDetails_NumberEmailAddress_Text_PerEmail =                               "abc@def.com";
	public static String Locator_AddContactDetails_NumberEmailAddress_Text_PerNumber =                              "1234567890";
	public static String Locator_AddContactDetails_Type_Dropdown_CellPhone =                                        "Cell Phone";
	public static String Locator_AddContactDetails_Type_Dropdown_Email =                                            "Email";
	public static String Locator_AddContactDetails_Type_Dropdown_Telephone =                                        "Telephone";
	public static String Locator_ManageContactDetails_ContactDetails_CellPhone_Actions_Dropdown_Delete =            "Delete";
	public static String Locator_ManageContactDetails_ContactDetails_CellPhone_Actions_Dropdown_Modify = 			"Modify";
	public static String Locator_Select_OptionOne =																	"1";
	public static String MultiText_AutoNotificationTypes =															"Fraud Alerts,Account Update,Contact Change";
	public static String MultiText_SubSectionTitles =																"Auto-Notifications,Manage Alerts";
	public static String MultiText_TableHeaders =																	"Enable,Notify me,Value,Delivery Method";
	public static String Script_Boolean_CheckedAndAttributeCheckedIsChecked =										"return arguments[0].checked == true && arguments[0].getAttribute('checked') == 'checked';";
	public static String Script_Boolean_ElementNotHasAttributeChecked =												"return !arguments[0].hasAttribute('checked');";
	public static String Script_Boolean_NotCheckedAndNoCheckedClass =												"return arguments[0].checked == false && !arguments[0].classList.contains('checked');";
	public static String Script_Integer_CountAllEnabledAlerts =														"return document.querySelectorAll(\"input[id*='Enable']:checked\").length;";
	public static String Script_Void_Click =																		"arguments[0].click()";
	public static String Text_ActivateCellPhone =																	"Activate a cell phone number";
	public static String Text_Button_SMSDisabled =																	"Disable SMS";
	public static String Text_Button_SMSEnabled =																	"Enable SMS";
	public static String Text_Details_BreadCrumb =																	"Confirm Details";
	public static String Text_Details_FormTitle =																	"Manage Alerts Accounts";
	public static String Text_Details_SegmentTitle =																"Alerts";
	public static String Text_FormTitle =																			"Alerts";
	public static String Text_Image_SMSDisabled =																	"aspa";
	public static String Text_Image_SMSEnabled =																	"check";
	public static String Text_SectionTitle_ContactPreferences =														"Contact Preferences:";
	public static String Text_Summary_BreadCrumb =																	"Summary";
	public static String Text_Summary_FormTitle =																	"Manage Alerts Accounts";
	public static String Text_Summary_SuccessMessage =																"Updated Successfully";


//	Locator_AddContactDetails_Description_Dropdown_Business("Alerts.Locator.AddContactDetails.Description.Dropdown.Business"),
//	Locator_AddContactDetails_Description_Dropdown_Personal("Alerts.Locator.AddContactDetails.Description.Dropdown.Personal"),
//	Locator_AddContactDetails_DescriptionDropdown("Alerts.Locator.AddContactDetails.DescriptionDropdown"),
//	Locator_AddContactDetails_NumberEmailAddress_Text_BusEmail("Alerts.Locator.AddContactDetails.NumberEmailAddress.Text.BusEmail"),
//	Locator_AddContactDetails_NumberEmailAddress_Text_BusNumber("Alerts.Locator.AddContactDetails.NumberEmailAddress.Text.BusNumber"),
//	Locator_AddContactDetails_NumberEmailAddress_Text_PerEmail("Alerts.Locator.AddContactDetails.NumberEmailAddress.Text.PerEmail"),
//	Locator_AddContactDetails_NumberEmailAddress_Text_PerNumber("Alerts.Locator.AddContactDetails.NumberEmailAddress.Text.PerNumber"),
//	Locator_AddContactDetails_NumberEmailAddress_TextField_NumberEmail("Alerts.Locator.AddContactDetails.NumberEmailAddress.TextField.NumberEmail"),
//	Locator_AddContactDetails_Preferred_RadioButton_No("Alerts.Locator.AddContactDetails.Preferred.RadioButton.No"),
//	Locator_AddContactDetails_Preferred_RadioButton_Yes("Alerts.Locator.AddContactDetails.Preferred.RadioButton.Yes"),
//	Locator_AddContactDetails_Title_ContactDetails("Alerts.Locator.AddContactDetails.Title.ContactDetails"),
//	Locator_AddContactDetails_Type_Dropdown_CellPhone("Alerts.Locator.AddContactDetails.Type.Dropdown.CellPhone"),
//	Locator_AddContactDetails_Type_Dropdown_Email("Alerts.Locator.AddContactDetails.Type.Dropdown.Email"),
//	Locator_AddContactDetails_Type_Dropdown_Telephone("Alerts.Locator.AddContactDetails.Type.Dropdown.Telephone"),
//	Locator_AddContactDetails_TypeDropdown("Alerts.Locator.AddContactDetails.TypeDropdown"),
//	Locator_AlertOption_CheckBox_GENERIC_DeliveryMethod_Email("Alerts.Locator.AlertOption.CheckBox.GENERIC.DeliveryMethod.Email"),
//	Locator_AlertOption_CheckBox_GENERIC_DeliveryMethod_SMS("Alerts.Locator.AlertOption.CheckBox.GENERIC.DeliveryMethod.SMS"),
//	Locator_AlertOption_CheckBox_GENERIC_Enable("Alerts.Locator.AlertOption.CheckBox.GENERIC.Enable"),
//	Locator_AlertOption_TextContainer_GENERIC_NotifyMe("Alerts.Locator.AlertOption.TextContainer.GENERIC.NotifyMe"),
//	Locator_Button_Activate("Alerts.Locator.Button.Activate"),
//	Locator_Button_Details_Cancel("Alerts.Locator.Button.Details.Cancel"),
//	Locator_Button_Details_Confirm("Alerts.Locator.Button.Details.Confirm"),
//	Locator_Button_EnableSMS("Alerts.Locator.Button.EnableSMS"),
//	Locator_Button_Go("Alerts.Locator.Button.Go"),
//	Locator_Button_Restore("Alerts.Locator.Button.Restore"),
//	Locator_Button_SMSEnableDisable("Alerts.Locator.Button.SMSEnableDisable"),
//	Locator_Button_Update("Alerts.Locator.Button.Update"),
//	Locator_CellPhoneNubmer_Dropdown("Alerts.Locator.CellPhoneNubmer.Dropdown"),
//	Locator_CellPhoneNumber_Dropdown_OptionOne("Alerts.Locator.CellPhoneNumber.Dropdown.OptionOne"),
//	Locator_CheckBox_InternationalTransaction_Email("Alerts.Locator.CheckBox.InternationalTransaction.Email"),
//	Locator_CheckBox_InternationalTransaction_Email_Checked("Alerts.Locator.CheckBox.InternationalTransaction.Email.Checked"),
//	Locator_CheckBox_InternationalTransaction_Email_PreChecked("Alerts.Locator.CheckBox.InternationalTransaction.Email.PreChecked"),
//	Locator_CheckBox_InternationalTransaction_Email_Unchecked("Alerts.Locator.CheckBox.InternationalTransaction.Email.Unchecked"),
//	Locator_CheckBox_InternationalTransaction_Enable("Alerts.Locator.CheckBox.InternationalTransaction.Enable"),
//	Locator_CheckBox_InternationalTransaction_Enable_Checked("Alerts.Locator.CheckBox.InternationalTransaction.Enable.Checked"),
//	Locator_CheckBox_InternationalTransaction_Enable_PreChecked("Alerts.Locator.CheckBox.InternationalTransaction.Enable.PreChecked"),
//	Locator_CheckBox_InternationalTransaction_Enable_Unchecked("Alerts.Locator.CheckBox.InternationalTransaction.Enable.Unchecked"),
//	Locator_CheckBox_InternationalTransaction_SMS("Alerts.Locator.CheckBox.InternationalTransaction.SMS"),
//	Locator_CheckBox_InternationalTransaction_SMS_Checked("Alerts.Locator.CheckBox.InternationalTransaction.SMS.Checked"),
//	Locator_CheckBox_InternationalTransaction_SMS_PreChecked("Alerts.Locator.CheckBox.InternationalTransaction.SMS.PreChecked"),
//	Locator_CheckBox_InternationalTransaction_SMS_Unchecked("Alerts.Locator.CheckBox.InternationalTransaction.SMS.Unchecked"),
//	Locator_DropDown_AccountNumber("Alerts.Locator.DropDown.AccountNumber"),
//	Locator_Dropdown_Accounts("Alerts.Locator.Dropdown.Accounts"),
//	Locator_Email_Dropdown("Alerts.Locator.Email.Dropdown"),
//	Locator_Email_Dropdown_Option1("Alerts.Locator.Email.Dropdown.Option1"),
//	Locator_ErrorMessage("Alerts.Locator.ErrorMessage"),
//	Locator_Image_InternationalTransaction_Check("Alerts.Locator.Image.InternationalTransaction.Check"),
//	Locator_Image_InternationalTransaction_Unchecked("Alerts.Locator.Image.InternationalTransaction.Unchecked"),
//	Locator_Image_SMSEnabledDisabled("Alerts.Locator.Image.SMSEnabledDisabled"),
//	Locator_Link_Accounts("Alerts.Locator.Link.Accounts"),
//	Locator_Link_Accounts_Active("Alerts.Locator.Link.Accounts.Active"),
//	Locator_Link_ActivateCellPhoneNumber("Alerts.Locator.Link.ActivateCellPhoneNumber"),
//	Locator_Link_Back("Alerts.Locator.Link.Back"),
//	Locator_Link_BackToAlerts("Alerts.Locator.Link.BackToAlerts"),
//	Locator_Link_ChangeAlertsProfile("Alerts.Locator.Link.ChangeAlertsProfile"),
//	Locator_Link_ChangeAlertsStatus("Alerts.Locator.Link.ChangeAlertsStatus"),
//	Locator_Link_ClickHere_ActivateCellPhone("Alerts.Locator.Link.ClickHere.ActivateCellPhone"),
//	Locator_Link_ClickHere_ChangeContactPreferences("Alerts.Locator.Link.ClickHere.ChangeContactPreferences"),
//	Locator_Link_CreditCards("Alerts.Locator.Link.CreditCards"),
//	Locator_Link_CreditCards_Active("Alerts.Locator.Link.CreditCards.Active"),
//	Locator_Link_HelpWithThisPage("Alerts.Locator.Link.HelpWithThisPage"),
//	Locator_Link_Security("Alerts.Locator.Link.Security"),
//	Locator_Link_Security_Active("Alerts.Locator.Link.Security.Active"),
//	Locator_Link_Statements("Alerts.Locator.Link.Statements"),
//	Locator_Link_Statements_Active("Alerts.Locator.Link.Statements.Active"),
//	Locator_Link_Summary_Print("Alerts.Locator.Link.Summary.Print"),
//	Locator_Link_TermsAndConditions("Alerts.Locator.Link.TermsAndConditions"),
//	Locator_Link_UpdateYourContactDetails("Alerts.Locator.Link.UpdateYourContactDetails"),
//	Locator_Link_ViewAlertsHistory("Alerts.Locator.Link.ViewAlertsHistory"),
//	Locator_ManageContactDetails_AddContactDetail("Alerts.Locator.ManageContactDetails.AddContactDetail"),
//	Locator_ManageContactDetails_ContactDetails_CellPhone_Actions_Button_Go("Alerts.Locator.ManageContactDetails.ContactDetails.CellPhone.Actions.Button.Go"),
//	Locator_ManageContactDetails_ContactDetails_CellPhone_Actions_Dropdown_Delete("Alerts.Locator.ManageContactDetails.ContactDetails.CellPhone.Actions.Dropdown.Delete"),
//	Locator_ManageContactDetails_ContactDetails_CellPhone_Actions_Dropdown_Modify("Alerts.Locator.ManageContactDetails.ContactDetails.CellPhone.Actions.Dropdown.Modify"),
//	Locator_ManageContactDetails_ContactDetails_CellPhone_ActionsDropdown("Alerts.Locator.ManageContactDetails.ContactDetails.CellPhone.ActionsDropdown"),
//	Locator_ManageContactDetails_ContactDetails_Text_CellPhone("Alerts.Locator.ManageContactDetails.ContactDetails.Text.CellPhone"),
//	Locator_ManageContactDetails_Title_ManageContactDetials("Alerts.Locator.ManageContactDetails.Title.ManageContactDetials"),
//	Locator_PageTab_Accounts("Alerts.Locator.Link.Accounts"),
//	Locator_PageTab_AccountsActive("Alerts.Locator.Link.AccountsActive"),
//	Locator_PageTab_CreditCards("Alerts.Locator.Link.CreditCards"),
//	Locator_PageTab_CreditCardsActive("Alerts.Locator.Link.CreditCardsActive"),
//	Locator_PageTab_Security("Alerts.Locator.Link.Security"),
//	Locator_PageTab_SecurityActive("Alerts.Locator.Link.SecurityActive"),
//	Locator_PageTab_Statements("Alerts.Locator.Link.Statements"),
//	Locator_PageTab_StatementsActive("Alerts.Locator.Link.StatementsActive"),
//	Locator_RadioButton_Accept("Alerts.Locator.RadioButton.Accept"),
//	Locator_RadioButton_NoAccept("Alerts.Locator.RadioButton.NoAccept"),
//	Locator_Select_OptionOne("Alerts.Locator.Select.OptionOne"),
//	Locator_SubTitle_Profile("Alerts.Locator.SubTitle.Profile"),
//	Locator_Text_AlertsUpdatedSuccess("Alerts.Locator.Text.AlertsUpdatedSuccess"),
//	Locator_Text_NotActivatedAlerts("Alerts.Locator.Text.NotActivatedAlerts"),
//	Locator_Text_SMSAutoNotificationDisabled("Alerts.Locator.Text.SMSAutoNotificationDisabled"),
//	Locator_TextContainer_BreadCrumb("Alerts.Locator.TextContainer.Details.BreadCrumb"),
//	Locator_TextContainer_ContactPreferences_CellPhoneNumber("Alerts.Locator.TextContainer.ContactPreferences.CellPhoneNumber"),
//	Locator_TextContainer_ContactPreferences_Email("Alerts.Locator.TextContainer.ContactPreferences.Email"),
//	Locator_TextContainer_Details_AccountNumber("Alerts.Locator.TextContainer.Details.AccountNumber"),
//	Locator_TextContainer_Details_SegmentTitle("Alerts.Locator.TextContainer.Details.SegmentTitle"),
//	Locator_TextContainer_FormTitle("Alerts.Locator.TextContainer.FormTitle"),
//	Locator_TextContainer_InternationalTransaction_Delivery("Alerts.TextContainer.InternationalTransaction.Delivery"),
//	Locator_TextContainer_SectionTitle_ContactPreferences("Alerts.Locator.TextContainer.SectionTitle.ContactPreferences"),
//	Locator_TextField_ActivationCode("Alerts.Locator.TextField.ActivationCode"),
//	Locator_Title_ActivateAlertsService("Alerts.Locator.Title.ActivateAlertsService"),
//	MultiLocator_AlertOptions("Alerts.MultiLocator.AlertOptions"),
//	MultiLocator_CheckBox_CheckedEmail("Alerts.MultiLocator.CheckBox.CheckedEmail"),
//	MultiLocator_CheckBox_CheckedEnable("Alerts.MultiLocator.CheckBox.CheckedEnable"),
//	MultiLocator_CheckBox_CheckedSMS("Alerts.MultiLocator.CheckBox.CheckedSMS"),
//	MultiLocator_Image_Details_Enabled("Alerts.MultiLocator.Image.Details.Enabled"),
//	MultiLocator_TextContainer_AutoNotificationTypes("Alerts.MultiLocator.TextContainer.AutoNotificationTypes"),
//	MultiLocator_TextContainer_SubSectionTitles("Alerts.MultiLocator.TextContainer.SubSectionTitles"),
//	MultiLocator_TextContainer_TableHeaders("Alerts.MultiLocator.TextContainer.TableHeaders"),
//	MultiText_AutoNotificationTypes("Alerts.MultiText.AutoNotificationTypes"),
//	MultiText_SubSectionTitles("Alerts.MultiText.SubSectionTitles"),
//	MultiText_TableHeaders("Alerts.MultiText.TableHeaders"),
//	Script_Boolean_CheckedAndAttributeCheckedIsChecked("Alerts.Script.Boolean.CheckedAndAttributeCheckedIsChecked"),
//	Script_Boolean_ElementNotHasAttributeChecked("Alerts.Script.Boolean.NotHasAttributeChecked"),
//	Script_Boolean_NotCheckedAndNoCheckedClass("Alerts.Script.Boolean.NotCheckedAndNoCheckedClass"),
//	Script_Integer_CountAllEnabledAlerts("Alerts.Script.Integer.CountAllEnabledAlerts"),
//	Script_Void_Click("Alerts.Script.Void.Click"),
//	Text_ActivateCellPhone("Alerts.Text.ActivateCellPhone"),
//	Text_Button_SMSDisabled("Alerts.Text.Button.SMSDisabled"),
//	Text_Button_SMSEnabled("Alerts.Text.Button.SMSEnabled"),
//	Text_Details_BreadCrumb("Alerts.Text.Details.BreadCrumb"),
//	Text_Details_FormTitle("Alerts.Text.Details.FormTitle"),
//	Text_Details_SegmentTitle("Alerts.Text.Details.SegmentTitle"),
//	Text_FormTitle("Alerts.Text.FormTitle"),
//	Text_Image_SMSDisabled("Alerts.Text.Image.SMSDisabled"),
//	Text_Image_SMSEnabled("Alerts.Text.Image.SMSEnabled"),
//	Text_SectionTitle_ContactPreferences("Alerts.Text.SectionTitle.ContactPreferences"),
//	Text_Summary_BreadCrumb("Alerts.Text.Summary.BreadCrumb"),
//	Text_Summary_FormTitle("Alerts.Text.Summary.FormTitle"),
//	Text_Summary_SuccessMessage("Alerts.Text.Summary.SuccessMessage"),

//	Alerts.Locator.AddContactDetails.Description.Dropdown.Business=Business
//	Alerts.Locator.AddContactDetails.Description.Dropdown.Personal=Personal
//	Alerts.Locator.AddContactDetails.Description.Dropdown=select#slcDesciption@@@css
//	Alerts.Locator.AddContactDetails.NumberEmailAddress.Text.BusEmail=ghi@jkl.com
//	Alerts.Locator.AddContactDetails.NumberEmailAddress.Text.BusNumber=9876543210
//	Alerts.Locator.AddContactDetails.NumberEmailAddress.Text.PerEmail=abc@def.com
//	Alerts.Locator.AddContactDetails.NumberEmailAddress.Text.PerNumber=1234567890
//	Alerts.Locator.AddContactDetails.NumberEmailAddress.TextField.NumberEmail=input#txtNumber@@@css
//	Alerts.Locator.AddContactDetails.Preferred.RadioButton.No=input#rdbNo@@@css
//	Alerts.Locator.AddContactDetails.Preferred.RadioButton.Yes=input#rdbYes@@@css
//	Alerts.Locator.AddContactDetails.Title.ContactDetails=//span[contains(text(),'Contact Details')]@@@xpath
//	Alerts.Locator.AddContactDetails.Type.Dropdown.CellPhone=Cell Phone
//	Alerts.Locator.AddContactDetails.Type.Dropdown.Email=Email
//	Alerts.Locator.AddContactDetails.Type.Dropdown.Telephone=Telephone
//	Alerts.Locator.AddContactDetails.Type.Dropdown=select#slcType@@@css
//	Alerts.Locator.AlertOption.CheckBox.GENERIC.DeliveryMethod.Email=//input[starts-with(@id,'chkMail') or starts-with(@id,'chkEmail')]@@@xpath
//	Alerts.Locator.AlertOption.CheckBox.GENERIC.DeliveryMethod.SMS=input[id^=chkPhone]@@@css
//	Alerts.Locator.AlertOption.CheckBox.GENERIC.Enable=input[id^=chkEnable]@@@css
//	Alerts.Locator.AlertOption.TextContainer.GENERIC.NotifyMe=span[id^=lblLitNotify]@@@css
//	Alerts.Locator.Button.Activate=a#main_btnActivate_enlace@@@css
//	Alerts.Locator.Button.Details.Cancel=a.cancel@@@css
//	Alerts.Locator.Button.Details.Confirm=a.confirm@@@css
//	Alerts.Locator.Button.EnableSMS=a#main_btnSMS2_enlace@@@css
//	Alerts.Locator.Button.Go=input.boton@@@css
//	Alerts.Locator.Button.Restore=a[id*=Restore]@@@css
//	Alerts.Locator.Button.SMSEnableDisable=div.btnsolido a[id*=SMS]@@@css
//	Alerts.Locator.Button.Update=a[id*=Update]@@@css
//	Alerts.Locator.CellPhoneNumber.Dropdown.Option1=option[value=1]@@@css
//	Alerts.Locator.CellPhoneNumber.Dropdown=select#slcCell@@@css
//	Alerts.Locator.CheckBox.BalanceLessThanZero.Email=input#chkMail1@@@css
//	Alerts.Locator.CheckBox.BalanceLessThanZero=input#chkEnable1@@@css
//	Alerts.Locator.CheckBox.InternationalTransaction.Email.Checked=//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Mail') and contains(@class, 'checked')]@@@xpath
//	Alerts.Locator.CheckBox.InternationalTransaction.Email.PreChecked=//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Mail')][@checked]@@@xpath
//	Alerts.Locator.CheckBox.InternationalTransaction.Email.Unchecked=//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Mail') and not(contains(@class, 'checked'))]@@@xpath
//	Alerts.Locator.CheckBox.InternationalTransaction.Email=//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Mail')]@@@xpath
//	Alerts.Locator.CheckBox.InternationalTransaction.Enable.Checked=//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Enable') and contains(@class, 'checked')]@@@xpath
//	Alerts.Locator.CheckBox.InternationalTransaction.Enable.PreChecked=//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Enable')][@checked]@@@xpath
//	Alerts.Locator.CheckBox.InternationalTransaction.Enable.Unchecked=//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Enable') and not(contains(@class, 'checked'))]@@@xpath
//	Alerts.Locator.CheckBox.InternationalTransaction.Enable=//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Enable')]@@@xpath
//	Alerts.Locator.CheckBox.InternationalTransaction.SMS.Checked=//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Phone') and contains(@class, 'Enable')]@@@xpath
//	Alerts.Locator.CheckBox.InternationalTransaction.SMS.PreChecked=//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Phone')][@checked]@@@xpath
//	Alerts.Locator.CheckBox.InternationalTransaction.SMS.Unchecked=//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Phone') and not(contains(@class, 'Enable'))]@@@xpath
//	Alerts.Locator.CheckBox.InternationalTransaction.SMS=//span[text()[contains(., 'International')]]/ancestor::div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[contains(@id,'Phone')]@@@xpath
//	Alerts.Locator.DropDown.AccountNumber=select[id*=AccNumber]@@@css
//	Alerts.Locator.Dropdown.Accounts=select#main_slaAccNumber_selectAction@@@css
//	Alerts.Locator.Email.Dropdown.Option1=option[value=1]@@@css
//	Alerts.Locator.Email.Dropdown=select#slcEmail@@@css
//	Alerts.Locator.ErrorMessage=div.InfoInfoMsg\\ InfoInfoMsgLayoutContent\\ pr@@@css
//	Alerts.Locator.Image.BalanceLessThanZero.Check=tr#main_tblAlerts_ROW\\:1 img[src*=check]@@@css
//	Alerts.Locator.Image.BalanceLessThanZero.X=tr#main_tblAlerts_ROW\\:1 img[src*=aspa]@@@css
//	Alerts.Locator.Image.InternationalTransaction.Check=//span[text()[contains(.,'International')]]/parent::td/preceding-sibling::td[contains(@class,'first')]//img[contains(@src,'check')]@@@xpath
//	Alerts.Locator.Image.InternationalTransaction.Unchecked=//span[text()[contains(.,'International')]]/parent::td/preceding-sibling::td[contains(@class,'first')]//img[contains(@src,'aspa')]@@@xpath
//	Alerts.Locator.Image.SMSEnabledDisabled=img[id*=title]@@@css
//	Alerts.Locator.Link.Accounts.Active=li.active span[title='Accounts'] a@@@css
//	Alerts.Locator.Link.Accounts=li:not(.active) span[title='Accounts'] a@@@css
//	Alerts.Locator.Link.ActivateCellPhoneNumber=a#idChangeProfile@@@css
//	Alerts.Locator.Link.Back=a#idBack@@@css
//	Alerts.Locator.Link.BackToAlerts=a#idBack@@@css
//	Alerts.Locator.Link.ChangeAlertsProfile=a#idChangeYourProfile,a#CambiarPerfil@@@css
//	Alerts.Locator.Link.ChangeAlertsStatus=a#idChangeAlertsHistory,a#CambiarAlertas@@@css
//	Alerts.Locator.Link.ClickHere.ActivateCellPhone=a#idChangeProfile@@@css
//	Alerts.Locator.Link.ClickHere.ChangeContactPreferences=p.marco > a:not(#idChangeProfile)@@@css
//	Alerts.Locator.Link.CreditCards.Active=li.active span[title='Credit Cards'] a@@@css
//	Alerts.Locator.Link.CreditCards=li:not(.active) span[title='Credit Cards'] a@@@css
//	Alerts.Locator.Link.HelpWithThisPage=a#Ayuda@@@css
//	Alerts.Locator.Link.Security.Active=li.active span[title='Security'] a@@@css
//	Alerts.Locator.Link.Security=li:not(.active) span[title='Security'] a@@@css
//	Alerts.Locator.Link.Statements.Active=li.active span[title='Statements'] a@@@css
//	Alerts.Locator.Link.Statements=li:not(.active) span[title='Statements'] a@@@css
//	Alerts.Locator.Link.Summary.Print=a#Imprimir@@@css
//	Alerts.Locator.Link.TermsAndConditions=a#main_txtTerms_enlace_1@@@css
//	Alerts.Locator.Link.UpdateYourContactDetails=//a[contains(text(),'update your contact details')]@@@xpath
//	Alerts.Locator.Link.ViewAlertsHistory=a#idViewAlerts,a#VerAlertas@@@css
//	Alerts.Locator.ManageContactDetails.AddContactDetail=a#transfer@@@css
//	Alerts.Locator.ManageContactDetails.ContactDetails.CellPhone.Actions.Button.Go=input#main_slnTabla_0@@@css
//	Alerts.Locator.ManageContactDetails.ContactDetails.CellPhone.Actions.Dropdown.Delete=Delete
//	Alerts.Locator.ManageContactDetails.ContactDetails.CellPhone.Actions.Dropdown.Modify=Modify
//	Alerts.Locator.ManageContactDetails.ContactDetails.CellPhone.Actions.Dropdown=select.CN_Combo@@@css
//	Alerts.Locator.ManageContactDetails.ContactDetails.Text.CellPhone=//span[contains(text(), 'Cell Phone')]@@@xpath
//	Alerts.Locator.ManageContactDetails.Title.ManageContactDetials=//span[contains(text(),'Manage Contact Detials')]@@@xpath
//	Alerts.Locator.RadioButton.Accept=input#rdbSiConsentimiento@@@css
//	Alerts.Locator.RadioButton.NoAccept=input#rdbNoConsentimiento@@@css
//	Alerts.Locator.Select.OptionOne=1
//	Alerts.Locator.SubTitle.Profile=span[contains(text(),'Profile')]@@@xpath
//	Alerts.Locator.Text.AlertsUpdatedSuccess=div[id$='infConfirmation'] span.title@@@css
//	Alerts.Locator.Text.NotActivatedAlerts=//p[contains(text(),'You have not yet activated alerts')]@@@xpath
//	Alerts.Locator.Text.SMSAutoNotificationDisabled=//p[contains(text(),'SMS Auto-Notifications Disabled')]@@@xpath
//	Alerts.Locator.TextContainer.ContactPreferences.CellPhoneNumber=//h1[contains(string(),'Cell')]/parent::th/following-sibling::td@@@xpath
//	Alerts.Locator.TextContainer.ContactPreferences.Email=//h1[contains(string(),'Email')]/parent::th/following-sibling::td@@@xpath
//	Alerts.Locator.TextContainer.Details.AccountNumber=td.value@@@css
//	Alerts.Locator.TextContainer.Details.BreadCrumb=li.activo span:not(.arrow)@@@css
//	Alerts.Locator.TextContainer.Details.SegmentTitle=div[id$='cntAlerts'] span.title@@@css
//	Alerts.Locator.TextContainer.FormTitle=div[id='main.titPrincipal'] span.titulo@@@css
//	Alerts.Locator.TextContainer.SectionTitle.ContactPreferences=div[id^='main.titContac'] span.titulo@@@css
//	Alerts.Locator.TextField.ActivationCode=input#txtActivation@@@css
//	Alerts.Locator.Title.ActivateAlertsService=//span[contains(text(),'Activate Alerts Service')]@@@xpath
//	Alerts.MultiLocator.AlertOptions=//div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]@@@xpath
//	Alerts.MultiLocator.CheckBox.CheckedEmail=//div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[(starts-with(@id,'chkMail') or starts-with(@id, 'chkEmail')) and contains(@class,'checked')][@checked]@@@xpath
//	Alerts.MultiLocator.CheckBox.CheckedEnable=//div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[starts-with(@id,'chkEnable') and contains(@class,'checked')][@checked]@@@xpath
//	Alerts.MultiLocator.CheckBox.CheckedSMS=//div[(contains(@id, 'divFormAlertsNav') or contains(@id,'divformAlertsNav')) and not(contains(@id,'Auto'))]//input[starts-with(@id, 'chkPhone') and contains(@class,'checked')][@checked]@@@xpath
//	Alerts.MultiLocator.Image.Details.Enabled=//td[contains(@class,'first')]//img[contains(@src,'check')]@@@xpath
//	Alerts.MultiLocator.TextContainer.AutoNotificationTypes=span.txtPuntoRojo strong@@@css
//	Alerts.MultiLocator.TextContainer.SubSectionTitles=span.title@@@css
//	Alerts.MultiLocator.TextContainer.TableHeaders=div[id*=cntAlerts] th > span@@@css
//	Alerts.MultiText.AutoNotificationTypes=Fraud Alerts,Account Update,Contact Change
//	Alerts.MultiText.SubSectionTitles=Auto-Notifications,Manage Alerts
//	Alerts.MultiText.TableHeaders=Enable,Notify me,Value,Delivery Method
//	Alerts.Script.Boolean.CheckedAndAttributeCheckedIsChecked=return arguments[0].checked == true && arguments[0].getAttribute('checked') == 'checked';
//	Alerts.Script.Boolean.NotCheckedAndNoCheckedClass=return arguments[0].checked == false && !arguments[0].classList.contains('checked');
//	Alerts.Script.Boolean.NotHasAttributeChecked=return !arguments[0].hasAttribute('checked');
//	Alerts.Script.Integer.CountAllEnabledAlerts=return document.querySelectorAll(\"input[id*='Enable']:checked\").length;
//	Alerts.Script.Void.Click=arguments[0].click();
//	Alerts.Text.ActivateCellPhone=Activate a cell phone number
//	Alerts.Text.Button.SMSDisabled=Disable SMS
//	Alerts.Text.Button.SMSEnabled=Enable SMS
//	Alerts.Text.Details.BreadCrumb=Confirm Details
//	Alerts.Text.Details.FormTitle=Manage Alerts Accounts
//	Alerts.Text.Details.SegmentTitle=Alerts
//	Alerts.Text.FormTitle=Alerts
//	Alerts.Text.Image.SMSDisabled=aspa
//	Alerts.Text.Image.SMSEnabled=check
//	Alerts.Text.SectionTitle.ContactPreferences=Contact Preferences:
//	Alerts.Text.Summary.BreadCrumb=Summary
//	Alerts.Text.Summary.FormTitle=Manage Alerts Accounts
//	Alerts.Text.Summary.SuccessMessage=Updated Successfully
//	Alerts.TextContainer.InternationalTransaction.Delivery=//span[text()[contains(.,'International')]]/parent::td/following-sibling::td[contains(@class,'last')]/span@@@xpath


}
