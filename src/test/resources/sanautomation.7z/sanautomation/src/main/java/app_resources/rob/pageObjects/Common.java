package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class Common {


    public static By Locator_ApplyOnline_Container = 					By.cssSelector("div.applyOnline");
    public static By Locator_ApplyOnline_Image = 						By.cssSelector("div.applyOnline img");
    public static By Locator_ApplyOnline_Link_CheckingAccounts = 		By.cssSelector("div.applyOnline a[href*='checking']");
    public static By Locator_ApplyOnline_Link_CreditCards = 			By.cssSelector("div.applyOnline a[href*='credit']");
    public static By Locator_ApplyOnline_Link_Mortgages = 				By.cssSelector("div.applyOnline a[href*='mortgage']");
    public static By Locator_ApplyOnline_Link_ResumeApplication = 		By.xpath("//div[@class='applyOnline']//a[contains(string(), 'Resume')]");
    public static By Locator_ApplyOnline_Link_SavingsAccounts = 		By.cssSelector("div.applyOnline a[href*='saving']");
    public static By Locator_Button_Cancel = 							By.cssSelector("a.cancel");
    public static By Locator_Button_Confirm =							By.cssSelector("a.confirm");
    public static By Locator_Button_Continue = 							By.cssSelector("a.continue");
    public static By Locator_ConfirmDetails_Button_Confirm = 			By.cssSelector("a.confirm");
    public static By Locator_Header_Button_AccountsTab = 				By.cssSelector("a#Accounts");
    public static By Locator_Header_Button_AccountsTab_Active = 		By.cssSelector("li.active a#Accounts");
    public static By Locator_Header_Button_BillPayTab = 				By.cssSelector("a#BillPay");
    public static By Locator_Header_Button_BillPayTab_Active = 			By.cssSelector("li.active a#BillPay");
    public static By Locator_Header_Button_CreditCardsTab = 			By.cssSelector("a[id='Credit Cards']");
    public static By Locator_Header_Button_CreditCardsTab_Active = 		By.cssSelector("li.active a[id='Credit Cards']");
    public static By Locator_Header_Button_CustomerServiceTab =			By.cssSelector("a[id='Customer Service']");
    public static By Locator_Header_Button_CustomerServiceTab_Active =	By.cssSelector("li.active a[id='Customer Service']");
    public static By Locator_Header_Button_InvestmentsTab = 			By.cssSelector("a#Investments");
    public static By Locator_Header_Button_InvestmentsTab_Active = 		By.cssSelector("li.active a#Investments");
    public static By Locator_Header_Button_Logout = 					By.cssSelector("a#logoff");
//    public static By Locator_Header_Button_Logout_Active = 				By.cssSelector(""); //missing from properties
    public static By Locator_Header_Button_MortgageTab = 				By.cssSelector("a#Mortgage");
    public static By Locator_Header_Button_MortgageTab_Active = 		By.cssSelector("li.active a#Mortgage");
    public static By Locator_Header_Button_TransferTab = 				By.cssSelector("a#Transfer");
    public static By Locator_Header_Button_TransferTab_Active = 		By.cssSelector("li.active a#Transfer");
    public static By Locator_Header_Image_Logo = 						By.cssSelector("img[alt='Santander']");
    public static By Locator_Header_Link_HelpCenter =					By.cssSelector("a#help");
    public static By Locator_Header_Link_Logo = 						By.xpath("//img[@alt='Santander']/..");
    public static By Locator_Header_TextContainer_WelcomeName = 		By.cssSelector("div.userInfo li.first");
    public static By Locator_SubTitle_ConfirmDetails =					By.xpath("//li[@class=' activo']//span[contains(text(), 'Confirm Details')]");
    public static By Locator_SubTitle_Summary =							By.xpath("//li[@class=' activo']//span[contains(text(), 'Summary')]");
    public static By Locator_TextContainer_BreadCrumb_Active = 			By.cssSelector("li.activo span:first-child");
    public static String Text_BreadCrumb_ConfirmDetails = 				"Confirm Details";
    public static String Text_BreadCrumb_EnterDetails = 				"Enter Details";
    public static String Text_BreadCrumb_Summary = 						"Summary";
    public static String Text_MainWindowTitle = 						"Santander Bank - Online Banking";


//  Locator_ApplyOnline_Container("Common.Locator.ApplyOnline.Container"),
//	Locator_ApplyOnline_Image("Common.Locator.ApplyOnline.Image"),
//	Locator_ApplyOnline_Link_CheckingAccounts("Common.Locator.ApplyOnline.Link.CheckingAccounts"),
//	Locator_ApplyOnline_Link_CreditCards("Common.Locator.ApplyOnline.Link.CreditCards"),
//	Locator_ApplyOnline_Link_Mortgages("Common.Locator.ApplyOnline.Link.Mortgages"),
//	Locator_ApplyOnline_Link_ResumeApplication("Common.Locator.ApplyOnline.Link.ResumeApplication"),
//	Locator_ApplyOnline_Link_SavingsAccounts("Common.Locator.ApplyOnline.Link.SavingsAccounts"),
//	Locator_Button_Cancel("Common.Locator.Button.Cancel"),
//	Locator_Button_Continue("Common.Locator.Button.Continue"),
//	Locator_ConfirmDetails_Button_Confirm("Common.Locator.Button.Confirm"),
//	Locator_Header_Button_AccountsTab("Common.Locator.Header.Button.AccountsTab"),
//	Locator_Header_Button_AccountsTab_Active("Common.Locator.Header.Button.AccountsTab.Active"),
//	Locator_Header_Button_BillPayTab("Common.Locator.Header.Button.BillPayTab"),
//	Locator_Header_Button_BillPayTab_Active("Common.Locator.Header.Button.BillPayTab.Active"),
//	Locator_Header_Button_CreditCardsTab("Common.Locator.Header.Button.CreditCardsTab"),
//	Locator_Header_Button_CreditCardsTab_Active("Common.Locator.Header.Button.CreditCardsTab.Active"),
//	Locator_Header_Button_CustomerServiceTab("Common.Locator.Header.Button.CustomerServiceTab"),
//	Locator_Header_Button_CustomerServiceTab_Active("Common.Locator.Header.Button.CustomerServiceTab.Active"),
//	Locator_Header_Button_InvestmentsTab("Common.Locator.Header.Button.InvestmentsTab"),
//	Locator_Header_Button_InvestmentsTab_Active("Common.Locator.Header.Button.InvestmentsTab.Active"),
//	Locator_Header_Button_Logout("Common.Locator.Header.Button.Logout"),
//	Locator_Header_Button_Logout_Active("Common.Locator.Header.Button.Logout.Active"),
//	Locator_Header_Button_MortgageTab("Common.Locator.Header.Button.MortgageTab"),
//	Locator_Header_Button_MortgageTab_Active("Common.Locator.Header.Button.MortgageTab.Active"),
//	Locator_Header_Button_TransferTab("Common.Locator.Header.Button.TransferTab"),
//	Locator_Header_Button_TransferTab_Active("Common.Locator.Header.Button.TransferTab.Active"),
//	Locator_Header_Image_Logo("Common.Locator.Header.Image.Logo"),
//	Locator_Header_Link_HelpCenter("Common.Locator.Header.Link.HelpCenter"),
//	Locator_Header_Link_Logo("Common.Locator.Header.Link.Logo"),
//	Locator_Header_TextContainer_WelcomeName("Common.Locator.Header.TextContainer.WelcomeName"),
//	Locator_TextContainer_BreadCrumb_Active("Common.Locator.TextContainer.BreadCrumb.Active"),
//	Text_BreadCrumb_ConfirmDetails("Common.Text.BreadCrumb.ConfirmDetails"),
//	Text_BreadCrumb_EnterDetails("Common.Text.BreadCrumb.EnterDetails"),
//	Text_BreadCrumb_Summary("Common.Text.BreadCrumb.Summary"),
//	Text_MainWindowTitle("Common.Text.MainWindowTitle"),


//  Common.Locator.ApplyOnline.Container=div.applyOnline@@@css
//	Common.Locator.ApplyOnline.Image=div.applyOnline img@@@css
//	Common.Locator.ApplyOnline.Link.CheckingAccounts=div.applyOnline a[href*=checking]@@@css
//	Common.Locator.ApplyOnline.Link.CreditCards=div.applyOnline a[href*=credit]@@@css
//	Common.Locator.ApplyOnline.Link.Mortgages=div.applyOnline a[href*=mortgage]@@@css
//	Common.Locator.ApplyOnline.Link.ResumeApplication=//div[@class="applyOnline"]//a[contains(string(),"Resume")]@@@xpath
//	Common.Locator.ApplyOnline.Link.SavingsAccounts=div.applyOnline a[href*=saving]@@@css
//	Common.Locator.Button.Cancel=a.cancel@@@css
//	Common.Locator.Button.Confirm=a.confirm@@@css
//	Common.Locator.Button.Continue=a.continue@@@css
//	Common.Locator.Header.Button.AccountsTab.Active=li.active a#Accounts@@@css
//	Common.Locator.Header.Button.AccountsTab=a#Accounts@@@css
//	Common.Locator.Header.Button.BillPayTab.Active=li.active a#BillPay@@@css
//	Common.Locator.Header.Button.BillPayTab=a#BillPay@@@css
//	Common.Locator.Header.Button.CreditCardsTab.Active=li.active a#Credit\\ Cards@@@css
//	Common.Locator.Header.Button.CreditCardsTab=a#Credit\\ Cards@@@css
//	Common.Locator.Header.Button.CustomerServiceTab.Active=li.active a#Customer\\ Service@@@css
//	Common.Locator.Header.Button.CustomerServiceTab=a#Customer\\ Service@@@css
//	Common.Locator.Header.Button.InvestmentsTab.Active=li.active a#Investments@@@css
//	Common.Locator.Header.Button.InvestmentsTab=a#Investments@@@css
//	Common.Locator.Header.Button.Logout=a#logoff@@@css
//	Common.Locator.Header.Button.MortgageTab.Active=li.active a#Mortgage@@@css
//	Common.Locator.Header.Button.MortgageTab=a#Mortgage@@@css
//	Common.Locator.Header.Button.TransferTab.Active=li.active a#Transfer@@@css
//	Common.Locator.Header.Button.TransferTab=a#Transfer@@@css
//	Common.Locator.Header.Image.Logo=img[alt='Santander']@@@css
//	Common.Locator.Header.Link.HelpCenter=a#help@@@css
//	Common.Locator.Header.Link.Logo=//img[@alt="Santander"]/..@@@xpath
//	Common.Locator.Header.TextContainer.WelcomeName=div.userInfo li.first@@@css
//	Common.Locator.SubTitle.ConfirmDetails=//li[@class=" activo"]//span[contains(text(),"Confirm Details")]@@@xpath
//	Common.Locator.SubTitle.Summary=li.activo span:contains('Summary')@@@css
//	Common.Locator.TextContainer.BreadCrumb.Active=li.activo span:first-child@@@css
//	Common.Text.BreadCrumb.ConfirmDetails=Confirm Details
//	Common.Text.BreadCrumb.EnterDetails=Enter Details
//	Common.Text.BreadCrumb.Summary=Summary
//	Common.Text.MainWindowTitle=Santander Bank - Online Banking


}
