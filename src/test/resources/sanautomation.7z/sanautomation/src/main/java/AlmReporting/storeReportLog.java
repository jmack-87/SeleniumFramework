package AlmReporting;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Nayan Bhavsar
 */
public class storeReportLog {
    private String expected;
    private String actual;
    private String status;
    private String timestamp;
    private String datestamp;



    public storeReportLog(String expected, String actual, String status){

        SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String[] dateTime = DATE_FORMAT.format(new Date()).split(" ");

        this.datestamp = dateTime[0];
        this.timestamp = dateTime[1];
        this.expected = expected;
        this.actual = actual;

        this.status = status;
    }


    public String getExpected(){
        return this.expected;
    }

    public String getActual(){
        return this.actual;
    }

    public String getStatus(){
        return this.status;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getDatestamp() {
        return datestamp;
    }

}
