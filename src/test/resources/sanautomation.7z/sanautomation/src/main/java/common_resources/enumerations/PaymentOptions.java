package common_resources.enumerations;

public enum PaymentOptions {

	MINIMUM("minimum"),
	STATEMENT("statement"),
	CURRENT("current"),
	OTHER("other"),
	CANCEL("cancel"),
	;

	private String str;
	PaymentOptions(String value) {str = value;}
	@Override
	public String toString() {return str;}


}
