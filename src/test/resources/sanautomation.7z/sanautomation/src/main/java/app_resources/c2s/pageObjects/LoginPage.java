package app_resources.c2s.pageObjects;

import org.openqa.selenium.By;

public class LoginPage {

	public static String URL = 						"http://einsteincrm.mx.sov.pre.corp/crm/login/#/";
	public static By Locator_Textfield_UserId = 	By.xpath("//*[@class='ng-pristine ng-valid' and @id='user']");
	public static By Locator_Textfield_Password = 	By.xpath("//*[@class='ng-pristine ng-valid'][@id='password']");
	public static By Locator_Button_Submit = 		By.xpath("//*[@class='btn-search'][@id='dologin']");

}
