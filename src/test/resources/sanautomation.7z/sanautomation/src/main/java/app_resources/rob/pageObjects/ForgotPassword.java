package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class ForgotPassword {


    public static By loginButton = By.id("btnSubmit");
    public static By password = By.name("entrada.pwd");
    public static By userID = By.name("entrada.alias");
    public static By verificationText = By.xpath("//li[@class='first']/strong[contains(.,'Welcome')]");


}
