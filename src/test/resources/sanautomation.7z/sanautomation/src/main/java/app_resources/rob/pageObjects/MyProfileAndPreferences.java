package app_resources.rob.pageObjects;

import org.openqa.selenium.By;

public class MyProfileAndPreferences {


	public static By Locator_Link_ChangeAddress =					By.cssSelector("a#main_ChangeAddress_enlace_1");
	public static By Locator_Link_ChangeAlertsServiceStatus =		By.xpath("//span[contains(text(),'Change Alerts Service'");
	public static By Locator_Link_ChangeOTP =						By.cssSelector("a#main_ChangeOTP_enlace_1");
	public static By Locator_Link_ChangePassword =					By.cssSelector("a#main_ChangePassword_enlace_1");
	public static By Locator_Link_ChangeUserId =					By.cssSelector("a#main_ChangeUserID_enlace_1");
	public static By Locator_Link_ChangeYourAlertsProfile =			By.xpath("//span[contains(text(),'Change Your Alerts Profile'");
	public static By Locator_Link_ManageAlerts =					By.xpath("//span[contains(text(),'Manage Alerts')]");
	public static By Locator_Link_ManageContactDetails =			By.cssSelector("a#main_ManageContactDetail_enlace_1");
	public static By Locator_Link_ShowHideNicknameAccoounts =		By.cssSelector("a#main_ShowAndHide_enlace_1");
	public static By Locator_SubTitle_MyProfileAndPreferences =		By.xpath("//span[contains(text(),'My Profile & Preferences')]");


//	Locator_Link_ChangeAddress("ProfilePreferneces.Locator.Link.ChangeAddress"),
//	Locator_Link_ChangeAlertsServiceStatus("ProfilePreferneces.Locator.Link.ChangeAlertsServiceStatus"),
//	Locator_Link_ChangeOTP("ProfilePreferneces.Locator.Link.ChangeOTP"),
//	Locator_Link_ChangePassword("ProfilePreferneces.Locator.Link.ChangePassword"),
//	Locator_Link_ChangeUserId("ProfilePreferneces.Locator.Link.ChangeUserId"),
//	Locator_Link_ChangeYourAlertsProfile("ProfilePreferneces.Locator.Link.ChangeYourAlertsProfile"),
//	Locator_Link_ManageAlerts("ProfilePreferneces.Locator.Link.ManageAlerts"),
//	Locator_Link_ManageContactDetails("ProfilePreferneces.Locator.Link.ManageContactDetails"),
//	Locator_Link_ShowHideNicknameAccoounts("ProfilePreferences.Locator.Link.ShowHideNicknameAccoounts"),
//	Locator_SubTitle_MyProfileAndPreferences("ProfilePreferences.Locator.SubTitle.MyProfileAndPreferences"),


//	ProfilePreferences.Locator.Link.ShowHideNicknameAccoounts=a#main_ShowAndHide_enlace_1@@@css
//	ProfilePreferences.Locator.SubTitle.MyProfileAndPreferences=//span[contains(text(),'My Profile & Preferences')]@@@xpath
//	ProfilePreferneces.Locator.Link.ChangeAddress=a#main_ChangeAddress_enlace_1@@@css
//	ProfilePreferneces.Locator.Link.ChangeAlertsServiceStatus=//span[contains(text(),'Change Alerts Service'@@@xpath
//	ProfilePreferneces.Locator.Link.ChangeOTP=a#main_ChangeOTP_enlace_1@@@css
//	ProfilePreferneces.Locator.Link.ChangePassword=a#main_ChangePassword_enlace_1@@@css
//	ProfilePreferneces.Locator.Link.ChangeUserId=a#main_ChangeUserID_enlace_1@@@css
//	ProfilePreferneces.Locator.Link.ChangeYourAlertsProfile=//span[contains(text(),'Change Your Alerts Profile'@@@xpath
//	ProfilePreferneces.Locator.Link.ManageAlerts=//span[contains(text(),'Manage Alerts')]@@@xpath
//	ProfilePreferneces.Locator.Link.ManageContactDetails=a#main_ManageContactDetail_enlace_1@@@css


}
