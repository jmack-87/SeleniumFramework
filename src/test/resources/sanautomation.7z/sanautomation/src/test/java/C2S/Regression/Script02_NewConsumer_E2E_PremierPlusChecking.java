package C2S.Regression;

import org.testng.annotations.Test;

import java.util.HashMap;

import app_resources.c2s.c2sBusinessComponent;
import app_resources.c2s.pageObjects.*;

public class Script02_NewConsumer_E2E_PremierPlusChecking extends c2sBusinessComponent {

    @Test
    public void Script02_NewConsumer_E2E_PremierPlusCheckingTest() {
        try {
            initialize_TestDataSheet("C2S.xls");
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            //Fetch test data
            HashMap<String, String> sEnvTestData = getTestData();

            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            fnDefineQuery("Select * from ROB where TestCaseNo='TC_C2S_002'");
            //Fetch test data
            HashMap<String, String> sC2STestData = getTestData();
            
            // Randomize some Customer Data to ensure Uniqueness
            randomizeInputDataConsumer(sC2STestData);

            // Log into ONE Application
            fnC2SLogin(sC2STestData.get("userId"),sC2STestData.get("password"));
    		
    		// Search for customer by name
            searchRetailCustomer();
    		
    		// Create the new prospect
            addProspect();
    		
    		// Fill in the form to create a prospect for a consumer
            enterProspectInformationConsumer();
    		
    		// Get the F-Number for the new prospect
            getFNumberFromLandingPage();
    		
    		// Begin the process to add the checking account
            goToOpenAccounts();
    		
    		// Search by SSN for customer
            searchExistingCustomer();
    		
    		// Complete the personal data form
            completePersonalDataForm();
    		
    		// Complete the Qualification Form
            passQualificationForm();
    		
    		// Choose Basic checking products
            choosePremierPlusChecking();
    		
    		// Complete Know Your Customer Form
            completeKYCForChecking();
    		
    		// Fake printing out the required documents
            printAllRequiredDocs();
    		
    		// Return to ONE portal to validate accounts created
            returnToONE();
    		
    		// Validate that the proper accounts were created on the one portal
            validateAccountsCreatedPremierPlusChecking();

        }

        catch(Exception e){
            fnReportLog("Failed","Exception occurred at ", e.getMessage() , true, e.getLocalizedMessage());
        }

    }

}
