package ROB.BuildAcceptance;

import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import app_resources.rob.robBusinessComponent;
import common_resources.utility;
import common_resources.custom_annotations.RetryOnFailCount;

/**
 *
 * @author x924469
 *
 */

public class Script08_ShowHideNickName extends robBusinessComponent {

	/**
	 * @author x924469
	 *
	 * @param isSuiteRun (boolean) basically: send an email after execution as TestNG suite
	 * @param postToALM (boolean) flag to post to ALM
	 * @param closeBrowserAfterTest (boolean) flag to close browser
	 */
	@Test(testName="Show, Hide, Nickname Accounts", description="Change visibility and order of accounts, rename nickname")
	@Parameters({"isSuiteRun", "postToALM", "closeBrowserAfterTest"})
	@RetryOnFailCount(0)
	public void Script08_ShowHideNickNameTest(
			@Optional Boolean isSuiteRun,
			@Optional Boolean postToALM,
			@Optional Boolean closeBrowserAfterTest) {

		utility.isSuiteRun = isSuiteRun == null ?  utility.isSuiteRun : isSuiteRun;
		utility.postToALM = postToALM == null ?  utility.postToALM : postToALM;
		utility.closeBrowserAfterTest = closeBrowserAfterTest == null ? utility.closeBrowserAfterTest : closeBrowserAfterTest;

		System.out.format("\tEmail?: %b%n\tALM?: %b%n\tCloseBrowser?: %b%n",
				isSuiteRun,
				postToALM,
				closeBrowserAfterTest);

		try {

            initialize_TestDataSheet("ROB.xls");

            // Fetch environment data
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            HashMap<String, String> sEnvTestData = getTestData();

            System.out.println("Environment Data:");
            sEnvTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));

            // Start browser
            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            // Fetch test data
            fnDefineQuery("Select * from ROB where TestCaseNo='TC_ROB_BUILDACCEPTANCE_008'");
            HashMap<String, String> sROBTestData = getTestData();

            System.out.println("Test Data:");

            sROBTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));


            // navigate to regular ROB login page
            System.out.println("Completing login");
			/*robRegTMXLogin.*/completeLogin(sROBTestData.get("userId"), sROBTestData.get("password"));

			// confirm login
			System.out.println("Confirming login");
			/*common.*/confirmLogin(sROBTestData.get("welcomeName"), sROBTestData.get("userId"));

			// navigate to Show Hide Nickname Page
			System.out.println("Navigating to Show Hide Nickname Page");
			/*showHideNickname.*/navigateToShowHideAndNicknameAccountsPage();

			// hide first checking and first credit card
			System.out.println("Navigating to Show Hide Nickname Page");
			/*showHideNickname.*/hideFirstCheckingAndFirstCreditCard();

			// verify if account is not shown in accounts page
			System.out.println("Verifying if account is not shown in accounts page");
			/*showHideNickname.*/confirmAbsenceOfDisabledAccounts();

			// change order and nickname
			System.out.println("Changing the order and nickname");
			/*showHideNickname.*/changeOrderAndNickname();

			// verify name changes
			System.out.println("Verifying the order and nickname");
			/*showHideNickname.*/confirmOrderAndNickname();

			// revert name changes (order is not significant)
			System.out.println("Tear down: revert name changes (order is not significant)");
			/*showHideNickname.*/revertChanges_ShowHideNickName();

		} catch (Exception e) {
			fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
		}

	}


}
