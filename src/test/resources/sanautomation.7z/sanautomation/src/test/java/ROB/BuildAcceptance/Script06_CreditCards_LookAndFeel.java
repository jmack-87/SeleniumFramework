package ROB.BuildAcceptance;

import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import app_resources.rob.robBusinessComponent;
import app_resources.rob.pageObjects.Common;
import app_resources.rob.pageObjects.CreditCard;
import common_resources.utility;
import common_resources.custom_annotations.RetryOnFailCount;


/**
 *
 * @author x923749
 *
 */
public class Script06_CreditCards_LookAndFeel extends robBusinessComponent {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Credit Cards Look & Feel", description="View the credit card page after logging into ROB")
	@Parameters({"isSuiteRun", "postToALM", "closeBrowserAfterTest"})
	@RetryOnFailCount(1)
	public void Script06_CreditCards_LookAndFeelTest (
			@Optional Boolean isSuiteRun,
			@Optional Boolean postToALM,
			@Optional Boolean closeBrowserAfterTest) {

		utility.isSuiteRun = isSuiteRun == null ?  utility.isSuiteRun : isSuiteRun;
		utility.postToALM = postToALM == null ?  utility.postToALM : postToALM;
		utility.closeBrowserAfterTest = closeBrowserAfterTest == null ? utility.closeBrowserAfterTest : closeBrowserAfterTest;

		System.out.format("\tEmail?: %b%n\tALM?: %b%n\tCloseBrowser?: %b%n",
				isSuiteRun,
				postToALM,
				closeBrowserAfterTest);

		try {

            initialize_TestDataSheet("ROB.xls");

            // Fetch environment data
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            HashMap<String, String> sEnvTestData = getTestData();

            System.out.println("Environment Data:");
            sEnvTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));

            // Start browser
            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            // Fetch test data
            fnDefineQuery("Select * from ROB where TestCaseNo='TC_ROB_BUILDACCEPTANCE_006'");
            HashMap<String, String> sROBTestData = getTestData();

            System.out.println("Test Data:");

            sROBTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));


            // navigate to regular ROB login page
            System.out.println("Completing login");
			/*robRegTMXLogin.*/completeLogin(sROBTestData.get("userId"), sROBTestData.get("password"));

			// confirm login
			System.out.println("Confirming login");
			/*common.*/confirmLogin(sROBTestData.get("welcomeName"), sROBTestData.get("userId"));

			// navigate to Credit Cards tab
			System.out.println("Navigating to Credit Cards");
			/*common.*/navigateToMainTab(Common.Locator_Header_Button_CreditCardsTab, Common.Locator_Header_Button_CreditCardsTab_Active);

			// confirm top navigation
			//common.confirmTopNavigation();
			System.out.println("Comnfirming top navigation");
			/*common.*/confirmActiveNavigationButton(Common.Locator_Header_Button_CreditCardsTab_Active);

			// confirm active left navigation
			System.out.println("Comnfirming left navigation");
			/*creditCard.*/confirmCreditCardLeftNavigation();
			/*common.*/confirmActiveNavigationButton(CreditCard.Locator_LeftNav_Button_Overview_Active);

			// confirm help and print links
			System.out.println("Confirming help, print links");
			/*creditCard.*/confirmHelpWithThisPageLink_CreditCard();
			/*creditCard.*/confirmPrintLink_CreditCard();

			// confirm header HelpCenter, LogOut link, button (generic)
			System.out.println("Confirming help center, logout links");
			/*common.*/confirmHelpCenterLink();
			/*common.*/confirmLogoutButton();

			// confirm content title
			System.out.println("Confirming credit card form title");
			/*creditCard.*/confirmCreditCardFormTitle();

			// confirm first member of body content
			System.out.println("Confirming credit card body content");
			/*creditCard.*/confirmCreditCardContentBody();

		} catch (Exception e) {
			fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
		}

	}

}
