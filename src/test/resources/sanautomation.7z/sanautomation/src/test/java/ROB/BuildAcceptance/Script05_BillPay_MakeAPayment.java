package ROB.BuildAcceptance;

import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import app_resources.rob.robBusinessComponent;
import app_resources.rob.pageObjects.BillPay;
import app_resources.rob.pageObjects.Common;
import common_resources.utility;
import common_resources.custom_annotations.RetryOnFailCount;


/**
 *
 * @author x923749
 *
 */
public class Script05_BillPay_MakeAPayment extends robBusinessComponent {

	/**
	 * @author x923749
	 *
	 * @param isSuiteRun (boolean) basically: send an email after execution as TestNG suite
	 * @param postToALM (boolean) flag to post to ALM
	 * @param closeBrowserAfterTest (boolean) flag to close browser
	 */
	@Test(testName="Make A Payment.", description="Make A Payment.")
	@Parameters({"isSuiteRun", "postToALM", "closeBrowserAfterTest"})
	@RetryOnFailCount(1)
	public void Script05_BillPay_MakeAPaymentTest(
			@Optional Boolean isSuiteRun,
			@Optional Boolean postToALM,
			@Optional Boolean closeBrowserAfterTest) {

		utility.isSuiteRun = isSuiteRun == null ?  utility.isSuiteRun : isSuiteRun;
		utility.postToALM = postToALM == null ?  utility.postToALM : postToALM;
		utility.closeBrowserAfterTest = closeBrowserAfterTest == null ? utility.closeBrowserAfterTest : closeBrowserAfterTest;

		System.out.format("\tEmail?: %b%n\tALM?: %b%n\tCloseBrowser?: %b%n",
				isSuiteRun,
				postToALM,
				closeBrowserAfterTest);

		try {

            initialize_TestDataSheet("ROB.xls");

            // Fetch environment data
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            HashMap<String, String> sEnvTestData = getTestData();

            System.out.println("Environment Data:");
            sEnvTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));

            // Start browser
            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            // Fetch test data
            fnDefineQuery("Select * from ROB where TestCaseNo='TC_ROB_BUILDACCEPTANCE_005'");
            HashMap<String, String> sROBTestData = getTestData();

            System.out.println("Test Data:");

            sROBTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));


			// navigate to regular ROB login page
            System.out.println("Completing login");
			/*robRegTMXLogin.*/completeLogin(sROBTestData.get("userId"), sROBTestData.get("password"));

			// confirm login
			System.out.println("Confirming login");
			/*common.*/confirmLogin(sROBTestData.get("welcomeName"), sROBTestData.get("userId"));

			// navigate to BillPay
			System.out.println("NAvigating to BillPay");
			/*common.*/navigateToMainTab(Common.Locator_Header_Button_BillPayTab, BillPay.Locator_Header_Button_BillPayTab_Active);

			// confirm BillPay test region screen, proceed
			System.out.println("Confirming Test region");
			/*billPay.*/confirmAndEnterTestRegion();

			// confirm left nav (including title)
			System.out.println("Confirming Left Navigation");
			/*billPay.*/confirmBillPayLeftNavigation();
			/*common.*/confirmActiveNavigationButton(BillPay.Locator_LeftNav_Button_PaymentCenter_Active);

			// confirm Payment Center right accordions
			System.out.println("Confirming right accordians");
			/*billPay.*/confirmRightAccordions(); // empty method

			// confirm Payment Center body
			System.out.println("Confirming body content");
			/*billPay.*/confirmBillPayContentBody();

			// enter data
			System.out.println("Submitting payment to first payee");
			/*billPay.*/submitPaymentToFirstPayee(sROBTestData.get("paymentAmount"));

			//TODO: cancel? (probably not necessary)

		} catch (Exception e) {
			fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
		}


	}

}
