package BOB.BuildAcceptance;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.santander.Base.TestBase;
import com.santander.Base.CustomAnnotations.RetryOnFailCount;
import com.santander.Enumerations.BOB.Common;
import com.santander.Enumerations.BOB.CreditCard;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

/**
 *
 * @author x923749
 *
 */
@Epic("BOB")
@Feature("Credit Card one time payment")
public class Script11_CreditCards_OneTimePayment extends TestBase {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Credit Cards One Time Payment", description="Make a payment on credit card")
	@Severity(SeverityLevel.CRITICAL)
	@Description("Make a Credit Card payment.")
	@Story("Credit Cards payment.")
//	@Parameters({"testParam"})
	@RetryOnFailCount(2)
	public void Script11_CreditCards_OneTimePaymentTest(/*@Optional String testParam*/) {

		// navigate to regular ROB login page and login
		bobRegTMXLogin.completeLogin();

		// confirm login
		common.confirmLogin(runtimeData.welcomeName);

		// navigate to credit card
		common.navigateToMainTab(Common.Locator_Header_Button_CreditCardsTab.toString(), Common.Locator_Header_Button_CreditCardsTab_Active.toString());

		// confirm overview and form content
		creditCard.confirmOverview();

		// navigate to credit card payment
		common.navigateToMainTab(CreditCard.Locator_LeftNav_Button_CreditCardPayment.toString(), CreditCard.Locator_LeftNav_Button_CreditCardPayment_Active.toString());

		// confirm Payment Screen
		creditCardPayment.confirmPaymentPage();

		// submit payment
		creditCardPayment.submitOneTimePayment();

		// verify details on confirm details page
		creditCardPayment.confirmPaymentDetails();

		// summary page
		creditCardPayment.confirmPaymentSummary();

		// pending status
		creditCardPayment.confirmPaymentPending();

		// pending list status
		creditCardPayment.confirmPaymentPendingList();

		// delete payment
		creditCardPayment.deleteOneTimePayment();

		// confirm delete details
		creditCardPayment.confirmDeleteOneTimeDetails();

		// click delete button
		creditCardPayment.delete();

		// confirm delete summary
		creditCardPayment.confirmDeleteOneTimeSummary();

	}

}
