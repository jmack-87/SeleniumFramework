package ROB.BuildAcceptance;

import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import app_resources.rob.robBusinessComponent;
import app_resources.rob.pageObjects.Common;
import app_resources.rob.pageObjects.CreditCard;
import app_resources.rob.pageObjects.CreditCardPayment;
import common_resources.utility;
import common_resources.custom_annotations.RetryOnFailCount;

/**
 *
 * @author x923749
 *
 */
public class Script11_CreditCards_OneTimePayment extends robBusinessComponent {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Credit Cards One Time Payment", description="Make a payment on credit card")
	@Parameters({"isSuiteRun", "postToALM", "closeBrowserAfterTest"})
	@RetryOnFailCount(0)
	public void Script11_CreditCards_OneTimePaymentTest(
			@Optional Boolean isSuiteRun,
			@Optional Boolean postToALM,
			@Optional Boolean closeBrowserAfterTest) {

		utility.isSuiteRun = isSuiteRun == null ?  utility.isSuiteRun : isSuiteRun;
		utility.postToALM = postToALM == null ?  utility.postToALM : postToALM;
		utility.closeBrowserAfterTest = closeBrowserAfterTest == null ? utility.closeBrowserAfterTest : closeBrowserAfterTest;

		System.out.format("\tEmail?: %b%n\tALM?: %b%n\tCloseBrowser?: %b%n",
				isSuiteRun,
				postToALM,
				closeBrowserAfterTest);

		try {

            initialize_TestDataSheet("ROB.xls");

            // Fetch environment data
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            HashMap<String, String> sEnvTestData = getTestData();

            System.out.println("Environment Data:");
            sEnvTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));

            // Start browser
            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            // Fetch test data
            fnDefineQuery("Select * from ROB where TestCaseNo='TC_ROB_BUILDACCEPTANCE_011'");
            HashMap<String, String> sROBTestData = getTestData();

            System.out.println("Test Data:");

            sROBTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));


            // navigate to regular ROB login page
            System.out.println("Completing login");
			/*robRegTMXLogin.*/completeLogin(sROBTestData.get("userId"), sROBTestData.get("password"));

			// confirm login
			System.out.println("Confirming login");
			/*common.*/confirmLogin(sROBTestData.get("welcomeName"), sROBTestData.get("userId"));

			// navigate to credit card
			/*common.*/navigateToMainTab(Common.Locator_Header_Button_CreditCardsTab, CreditCard.Locator_CreditCard_Link_MakePayment_First);

			// confirm overview and form content
			/*creditCard.*/confirmOverview();

			// navigate to credit card payment
			/*common.*/navigateToMainTab(CreditCard.Locator_LeftNav_Button_CreditCardPayment, CreditCardPayment.Locator_Button_Calendar);

			// confirm Payment Screen
			/*creditCardPayment.*/confirmPaymentPage(Boolean.parseBoolean(sROBTestData.get("ccFaqCheck")));

			// submit payment
			/*creditCardPayment.*/submitOneTimePayment(sROBTestData.get("toAccount"), sROBTestData.get("fromAccount"), sROBTestData.get("paymentAmount"));

			// verify details on confirm details page
			/*creditCardPayment.*/confirmPaymentDetails();

			// summary page
			/*creditCardPayment.*/confirmPaymentSummary();

			// pending status
			/*creditCardPayment.*/confirmPaymentPending();

			// pending list status
			/*creditCardPayment.*/confirmPaymentPendingList();

			// delete payment
			/*creditCardPayment.*/deleteOneTimePayment();

			// confirm delete details
			/*creditCardPayment.*/confirmDeleteOneTimeDetails();

			// click delete button
			/*creditCardPayment.*/delete();

			// confirm delete summary
			/*creditCardPayment.*/confirmDeleteOneTimeSummary();

		} catch (Exception e) {
			fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
		}

	}

}
