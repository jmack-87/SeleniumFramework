package ROB.BuildAcceptance;

import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import app_resources.rob.robBusinessComponent;
import app_resources.rob.pageObjects.Common;
import app_resources.rob.pageObjects.Transfer;
import common_resources.utility;
import common_resources.custom_annotations.RetryOnFailCount;

/**
 *
 * @author x923749
 *
 */
public class Script10_Transfers_OneTimeTransfer_S2S extends robBusinessComponent {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Transfer Santander to Santander accounts", description="Transfer money between Santander accounts")
	@Parameters({"isSuiteRun", "postToALM", "closeBrowserAfterTest"})
	@RetryOnFailCount(0)
	public void Script10_Transfers_OneTimeTransfer_S2STest(
			@Optional Boolean isSuiteRun,
			@Optional Boolean postToALM,
			@Optional Boolean closeBrowserAfterTest) {

		utility.isSuiteRun = isSuiteRun == null ?  utility.isSuiteRun : isSuiteRun;
		utility.postToALM = postToALM == null ?  utility.postToALM : postToALM;
		utility.closeBrowserAfterTest = closeBrowserAfterTest == null ? utility.closeBrowserAfterTest : closeBrowserAfterTest;

		System.out.format("\tEmail?: %b%n\tALM?: %b%n\tCloseBrowser?: %b%n",
				isSuiteRun,
				postToALM,
				closeBrowserAfterTest);

		try {

            initialize_TestDataSheet("ROB.xls");

            // Fetch environment data
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            HashMap<String, String> sEnvTestData = getTestData();

            System.out.println("Environment Data:");
            sEnvTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));

            // Start browser
            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            // Fetch test data
            fnDefineQuery("Select * from ROB where TestCaseNo='TC_ROB_BUILDACCEPTANCE_010'");
            HashMap<String, String> sROBTestData = getTestData();

            System.out.println("Test Data:");

            sROBTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));


            // navigate to regular ROB login page
            System.out.println("Completing login");
			/*robRegTMXLogin.*/completeLogin(sROBTestData.get("userId"), sROBTestData.get("password"));

			// confirm login
			System.out.println("Confirming login");
			/*common.*/confirmLogin(sROBTestData.get("welcomeName"), sROBTestData.get("userId"));


			// navigate to transfer funds page
			System.out.println("Navigate to Transfer");
			/*common.*/navigateToMainTab(Common.Locator_Header_Button_TransferTab, Common.Locator_Header_Button_TransferTab_Active);

			// confirm Transfer Funds page of Transfers tab
			System.out.println("Confirming Transfer Funds screen");
			/*transferFunds.*/confirmTransferPage();

				System.out.println("Set from account");
				/*transferFunds.*/setFromAccount_Transfer(Transfer.Text_Checking);
				// [NEGATIVE] check error condition: No To Account
				System.out.println("Check error condition: No To account");
				/*transferFunds.*/checkErrorCondition(Transfer.Text_NoToAccountError);

				System.out.println("Set to account");
				// [NEGATIVE] check error condition: No Amount
				/*transferFunds.*/setToAccount_Transfer(Transfer.Text_Saving);
				System.out.println("Check error condition: no Amount");
				/*transferFunds.*/checkErrorCondition(Transfer.Text_EnterTransferAmountError);

				System.out.println("Set amount");
				// [NEGATIVE] check error condition: Greater than available
				/*transferFunds.*/enterTransferAmount(sROBTestData.get("paymentAmount"));
				System.out.println("Check error condition: Amount > available");
				/*transferFunds.*/checkErrorCondition(Transfer.Text_TransferAmountGreaterThanAvailableBalanceError);

			// select transfer account to transfer from
			System.out.println("Set from Account");
			/*transferFunds.*/setFromAccount_Transfer(Transfer.Text_Checking);

			// select transfer account to transfer to
			System.out.println("Set To Account");
			/*transferFunds.*/setToAccount_Transfer(Transfer.Text_Saving);

			// enter transfer amount
			System.out.println("Set amount");
			/*transferFunds.*/enterTransferAmount(sROBTestData.get("paymentAmount"));

			// select frequency
			System.out.println("Set frequency: One time");
			/*transferFunds.*/setTransferFrequency(Transfer.Text_Frequency_OneTime);

			// click continue and confirm details
			System.out.println("Submit data");
			/*transferFunds.*/submitTransfer();

			// click and verify confirm details
			System.out.println("Confirm details screen, continue");
			/*transferFunds.*/confirmTransfer();

			// view details on summary page
			System.out.println("Confirm summary screen");
			/*transferFunds.*/confirmSummaryPage();

		} catch (Exception e) {
			fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
		}


	}


}
