package C2S.Regression;

import org.testng.annotations.Test;

import java.util.HashMap;

import app_resources.c2s.c2sBusinessComponent;
import app_resources.c2s.pageObjects.*;

public class Script17_ExistingConsumer_E2E_BasicCheckingAndSavings extends c2sBusinessComponent {

    @Test
    public void Script17_ExistingConsumer_E2E_BasicCheckingAndSavingsTest() {
        try {
        	 initialize_TestDataSheet("C2S.xls");
             fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
             //Fetch test data
             HashMap<String, String> sEnvTestData = getTestData();

             fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

             fnDefineQuery("Select * from ROB where TestCaseNo='TC_C2S_017'");
             //Fetch test data
             HashMap<String, String> sC2STestData = getTestData();
             
             // Randomize some Customer Data to ensure Uniqueness
             randomizeInputDataConsumer(sC2STestData);

             // Log into ONE Application
             fnC2SLogin(sC2STestData.get("userId"),sC2STestData.get("password"));
             
             // Search for customer by name
             searchRetailCustomer();
     				
     		 // Create the new prospect
     		 addProspect();
     				
     		 // Fill in the form to create a prospect for a consumer
     		 enterProspectInformationConsumer();
     				
     		 // Get the F-Number for the new prospect
     		 getFNumberFromLandingPage();
     				
     		 // Begin the process to add the checking account
     		 goToOpenAccounts();
     				
     		 // Search by SSN for customer
     		 searchExistingCustomer();
     				
     		 // Complete the personal data form
     		 completePersonalDataForm();
     						
     		 // Complete the Qualification Form
     		 passQualificationForm();
     			
     		 // Choose Savings to save time 
     		 chooseSantanderMoneyMarketSavings();
     				
     		 // Complete Know Your Customer Form
     		 completeKYCForCheckingAndSavingsExistingCustomer();
     		
     		 // Now that consumer is created and set up, it can be considered existing
     		 // Log into ONE Application
     		 fnC2SLogin(sC2STestData.get("userId"),sC2STestData.get("password"));
     		
     		 // Search for customer by name
     		 searchExistingRetailCustomer();
     		
     		 // check that Savings is on the account before moving forward
     		 validateAccountsCreatedSantanderMoneyMarketSavings();
     				
     		 // Begin the process to add the checking account
     		 returnToOpenAccounts();
     		
     		 // Complete the ID captures to move to re-qualification
     		 completeIDCaptures();
     		
     		 // Choose Basic checking products
     		 chooseBasicCheckingAndSavings();
     			
     		 // Fake printing out the required documents
     		 printAllRequiredDocs();
     		
     		 // Return to ONE to Validate Creation
     		 returnToONE();
     		
     		 // Validate that the proper accounts were created on the one portal
     		 validateAccountsCreatedBasicCheckingAndSavings();



        }

        catch(Exception e){
            fnReportLog("Failed","Exception occurred at ", e.getMessage() , true, e.getLocalizedMessage());
        }

    }

}
