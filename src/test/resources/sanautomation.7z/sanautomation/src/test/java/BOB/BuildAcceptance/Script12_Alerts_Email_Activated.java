package BOB.BuildAcceptance;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.santander.Base.TestBase;
import com.santander.Base.CustomAnnotations.RetryOnFailCount;
import com.santander.Enumerations.BOB.Accounts;
import com.santander.Enumerations.BOB.Common;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

/**
 *
 * @author x923749
 *
 */
@Epic("BOB")
@Feature("Alerts Activation")
public class Script12_Alerts_Email_Activated extends TestBase {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Alerts Activation", description="Activate sms alerts in BOB")
	@Severity(SeverityLevel.CRITICAL)
	@Description("Test Description: Activate sms alerts in BOB.")
	@Story("Activate sms alerts.")
//	@Parameters({"testParam"})
	@RetryOnFailCount(2)
	public void Script12_Alerts_Email_ActivatedTest(/*@Optional String testParam*/) {

		// navigate to regular ROB login page and login
		bobRegTMXLogin.completeLogin();

		// confirm login
		common.confirmLogin(runtimeData.welcomeName);

		// navigate to Accounts
		common.navigateToMainTab(Common.Locator_Header_Button_AccountsTab.toString(), Common.Locator_Header_Button_AccountsTab_Active.toString());

		// navigate to alerts page
		common.navigateToMainTab(Accounts.Locator_LeftNav_Button_AlertsTab.toString(), Accounts.Locator_LeftNav_Button_AlertsTab_Active.toString());

		// confirm elements on alerts page
		alerts.confirmAlertsPage();

		// enable alerts for international iransaction
		alerts.enableInternationalTransactionAlert();

		// check if selected alert is correctly marked with check mark
		alerts.confirmDetails();

		// alert changes on summary page
		alerts.confirmSummaryPageUpdated();

		// tear down
		alerts.revertChanges();


	}

}
