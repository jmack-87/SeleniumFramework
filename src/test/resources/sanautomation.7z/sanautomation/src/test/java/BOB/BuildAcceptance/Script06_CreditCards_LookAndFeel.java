package BOB.BuildAcceptance;

import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import app_resources.bob.robBusinessComponent;
import app_resources.bob.pageObjects.BillPay;
import app_resources.bob.pageObjects.Common;
import common_resources.utility;
import common_resources.custom_annotations.RetryOnFailCount;


/**
 *
 * @author x923749
 *
 */
public class Script06_CreditCards_LookAndFeel extends bobBusinessComponent {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Credit Cards Look & Feel", description="View the credit card page after logging into BOB")
	@Parameters({"isSuiteRun", "postToALM", "closeBrowserAfterTest"})
	@RetryOnFailCount(1)
	public void Script06_CreditCards_LookAndFeelTest(
			@Optional boolean isSuiteRun,
			@Optional boolean postToALM,
			@Optional boolean closeBrowserAfterTest) {

		System.out.format("\tEmail?: %b%n\tALM?: %b%n\tCloseBrowser?: %b%n",
				isSuiteRun,
				postToALM,
				closeBrowserAfterTest);

		utility.isSuiteRun = isSuiteRun;
		utility.postToALM = postToALM;
		utility.closeBrowserAfterTest = closeBrowserAfterTest;

		try {

            initialize_TestDataSheet("BOB.xls");

            // Fetch environment data
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            HashMap<String, String> sEnvTestData = getTestData();

            System.out.println("Environment Data:");
            sEnvTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));

            // Start browser
            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            // Fetch test data
            fnDefineQuery("Select * from BOB where TestCaseNo='TC_BOB_BUILDACCEPTANCE_006'");
            HashMap<String, String> sROBTestData = getTestData();

            System.out.println("Test Data:");

            sROBTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));


            // navigate to regular ROB login page
 			/*bobRegTMXLogin.*/completeLogin(sBOBTestData.get("userId"), sBOBTestData.get("password"));

 			// confirm login
 			/*common.*/confirmLogin(sBOBTestData.get("welcomeName"), sBOBTestData.get("userId"));

 			//TODO: -->
			// navigate to Credit Cards tab
			/*common.*/navigateToMainTab(Common.Locator_Header_Button_CreditCardsTab, Common.Locator_Header_Button_CreditCardsTab_Active);

			// confirm top navigation
			//common.confirmTopNavigation();
			/*common.*/confirmActiveNavigationButton(Common.Locator_Header_Button_CreditCardsTab_Active);

			// confirm active left navigation
			/*creditCard.*/confirmLeftNavigation();
			/*common.*/confirmActiveNavigationButton(CreditCard.Locator_LeftNav_Button_Overview_Active);

			// confirm help and print links
			/*creditCard.*/confirmHelpWithThisPageLink();
			/*creditCard.*/confirmPrintLink();

			// confirm header HelpCenter, LogOut link, button (generic)
			/*common.*/confirmHelpCenterLink();
			/*common.*/confirmLogoutButton();

			// confirm content title
			/*creditCard.*/confirmFormTitle();

			// confirm first member of body content
			/*creditCard.*/confirmContentBody();

		} catch (Exception e) {
			fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
		}

	}

}
