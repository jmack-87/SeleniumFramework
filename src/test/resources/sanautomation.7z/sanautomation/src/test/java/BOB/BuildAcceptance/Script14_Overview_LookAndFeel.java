package BOB.BuildAcceptance;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.santander.Base.TestBase;
import com.santander.Base.CustomAnnotations.RetryOnFailCount;
import com.santander.Enumerations.BOB.Accounts;
import com.santander.Enumerations.BOB.Common;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

/**
 *
 * @author x923749
 *
 */
@Epic("BOB")
@Feature("Accounts")
public class Script14_Overview_LookAndFeel extends TestBase {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Overview, Look and Feel", description="Overview, Look and Feel")
	@Severity(SeverityLevel.CRITICAL)
	@Description("Overview, Look and Feel.")
	@Story("Overview, Look and Feel")
//	@Parameters({"testParam"})
	@RetryOnFailCount(2)
	public void Script14_Overview_LookAndFeelTest(/*@Optional String testParam*/) {

		// navigate to regular BOB login page and login
		bobRegTMXLogin.completeLogin();

		// confirm login
		common.confirmLogin(runtimeData.welcomeName);

		// navigate to Accounts
		common.navigateToMainTab(Common.Locator_Header_Button_AccountsTab.toString(), Common.Locator_Header_Button_AccountsTab_Active.toString());

		// confirm left tabs
		common.confirmActiveNavigationButton(Accounts.Locator_LeftNav_Button_OverviewTab_Active.toString());
		accounts.confirmLeftNavigation();

		// confirm ApplyOnlineNow links (PO, common to at least Customer Service)
		common.confirmApplyOnlineWidgetAndComponents();

		// confirm QuickTransfer presence (PO, common to at least Customer Service)
		quickTransfers.confirmQuickTransferWidgetAndComponents();

		// confirm print, help links (Overview)
		accounts.confirmPrintLink();
		accounts.confirmHelpWithThisPageLink();

		// confirm header HelpCenter, LogOut link, button (generic)
		common.confirmHelpCenterLink();
		common.confirmLogoutButton();

		// confirm content header
		accounts.confirmContentHeader();

		// confirm center content
		accounts.confirmContentBody();

		// confirm content footer
		accounts.confirmContentFooter();

	}

}
