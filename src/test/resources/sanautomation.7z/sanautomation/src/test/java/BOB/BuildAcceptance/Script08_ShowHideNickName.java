package BOB.BuildAcceptance;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.santander.Base.TestBase;
import com.santander.Base.CustomAnnotations.RetryOnFailCount;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

/**
 *
 * @author x923749
 *
 */
@Epic("BOB")
@Feature("Show,Hide,Nickname Accounts")
public class Script08_ShowHideNickName extends TestBase {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Show, Hide, Nickname Accounts", description="Change visibility and order of accounts, rename nickname")
	@Severity(SeverityLevel.CRITICAL)
	@Description("Verify show hide nickname account changes.")
	@Story("Show, Hide, Nickname Accounts.")
//	@Parameters({"testParam"})
	@RetryOnFailCount(2)
	public void Script08_ShowHideNickNameTest(/*@Optional String testParam*/) {

		// navigate to regular ROB login page and login
		bobRegTMXLogin.completeLogin();

		// confirm login
		common.confirmLogin(runtimeData.welcomeName);

		// navigate to show hide page
		showHideNickname.navigateToShowHideAndNicknameAccountsPage();

		// hide first checking and first credit card
		showHideNickname.hideFirstCheckingAndFirstCreditCard();

		// verify if account is not shown in accounts page
		showHideNickname.confirmAbsenceOfDisabledAccounts();

		// change order and nickname
		showHideNickname.changeOrderAndNickname();

		// verify name changes
		showHideNickname.confirmOrderAndNickname();

		// revert name changes (order is not significant)
		showHideNickname.revertChanges();

	}

}
