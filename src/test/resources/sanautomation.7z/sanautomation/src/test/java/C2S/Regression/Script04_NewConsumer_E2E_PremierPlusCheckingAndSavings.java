package C2S.Regression;

import org.testng.annotations.Test;

import java.util.HashMap;

import app_resources.c2s.c2sBusinessComponent;

public class Script04_NewConsumer_E2E_PremierPlusCheckingAndSavings extends c2sBusinessComponent {

    @Test
    public void Script04_NewConsumer_E2E_PremierPlusCheckingAndSavingsTest() {
        try {
            initialize_TestDataSheet("C2S.xls");
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            //Fetch test data
            HashMap<String, String> sEnvTestData = getTestData();

            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            fnDefineQuery("Select * from C2S where TestCaseNo='TC_C2S_004'");
           //Fetch test data
            HashMap<String, String> sC2STestData = getTestData();
            
            // Randomize some Customer Data to ensure Uniqueness
            randomizeInputDataConsumer(sC2STestData);

         // Log into ONE Application
            fnC2SLogin(sEnvTestData.get("userId"), 
            		sEnvTestData.get("password"));
    		
    		// Search for customer by name
            searchRetailCustomer(sC2STestData.get("searchFirstName"), 
            		sC2STestData.get("searchLastName"));
    		
    		// Create the new prospect
            addProspect();
    		
    		// Fill in the form to create a prospect for a consumer
            enterProspectInformationConsumer(sC2STestData);
    		
    		// Get the F-Number for the new prospect
            getFNumberFromLandingPage();
    		
    		// Begin the process to add the checking account
            goToOpenAccounts();
    		
    		// Search by SSN for customer
            searchExistingCustomer(sC2STestData.get("documentNumber"));
    		
    		// Complete the personal data form
            completePersonalDataForm(sC2STestData.get("emailID"), 
            		sC2STestData.get("employer"), 
            		sC2STestData.get("state"), 
            		sC2STestData.get("documentNumber"));
    		
    		// Complete the Qualification Form
            passQualificationForm(sC2STestData.get("fNumber"), 
            		sC2STestData.get("documentNumber"), 
            		sC2STestData.get("contactNumber"), 
            		sC2STestData.get("employer"), 
            		sC2STestData.get("occupation"));
    		
    		// Choose Basic checking products
            choosePremierPlusCheckingAndSavings();
    		
    		// Complete Know Your Customer Form
            completeKYCForCheckingAndSavings();
    		
    		// Fake printing out the required documents
            printAllRequiredDocs(sC2STestData.get("searchFirstName"), 
            		sC2STestData.get("searchLastName"), 
            		sC2STestData.get("downloadPDFPath"));
    		
    		// Return to ONE portal to validate accounts created
            returnToONE();
    		
    		// Validate that the proper accounts were created on the one portal
            validateAccountsCreatedPremierPlusCheckingAndSavings();

            
        }

        catch(Exception e){
        	
        	fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
			
        }

    }

}
