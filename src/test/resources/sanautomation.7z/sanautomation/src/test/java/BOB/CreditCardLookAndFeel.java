package BOB;

import org.testng.annotations.Test;

import java.util.HashMap;

import app_resources.bob.bobBusinessComponent;
import app_resources.bob.pageObjects.LoginPage;

public class CreditCardLookAndFeel extends bobBusinessComponent {

    @Test
    public void creditCardLookAndFeel() {
        try {
            initialize_TestDataSheet("BOB.xls");
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            //Fetch test data
            HashMap<String, String> sEnvTestData = getTestData();

            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            fnDefineQuery("Select * from BOB where TestCaseNo='TC_BOB_001'");
            //Fetch test data
            HashMap<String, String> sBOBTestData = getTestData();

            fnBOBLogin(sBOBTestData.get("userId"),sBOBTestData.get("password"));

            String Title = fnGetText(LoginPage.verificationText);

            if(Title.contains(sBOBTestData.get("welcomeName")))
                fnReportLog("Passed", "Login", "Successfully LoggedIn",false);
            else
                fnReportLog("Failed", "Login", "Not able to Successfully LoggedIn",true);



        }

        catch(Exception e){
            fnReportLog("Failed","Exception occurred at ", e.getMessage() , true, e.getLocalizedMessage());
        }

    }

}
