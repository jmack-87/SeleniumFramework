package ROB.BuildAcceptance;

import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import app_resources.rob.robBusinessComponent;
import common_resources.utility;
import common_resources.custom_annotations.RetryOnFailCount;

/**
 *
 * @author x923749
 *
 */
public class Script07_Transfers_LookAndFeel extends robBusinessComponent {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Transfers Look & Feel", description="View the transfers page after logging into ROB")
	@Parameters({"isSuiteRun", "postToALM", "closeBrowserAfterTest"})
	@RetryOnFailCount(2)
	public void Script07_Transfers_LookAndFeelTest(
			@Optional Boolean isSuiteRun,
			@Optional Boolean postToALM,
			@Optional Boolean closeBrowserAfterTest) {

		utility.isSuiteRun = isSuiteRun == null ?  utility.isSuiteRun : isSuiteRun;
		utility.postToALM = postToALM == null ?  utility.postToALM : postToALM;
		utility.closeBrowserAfterTest = closeBrowserAfterTest == null ? utility.closeBrowserAfterTest : closeBrowserAfterTest;

		System.out.format("\tEmail?: %b%n\tALM?: %b%n\tCloseBrowser?: %b%n",
				isSuiteRun,
				postToALM,
				closeBrowserAfterTest);

		try {

            initialize_TestDataSheet("ROB.xls");

            // Fetch environment data
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            HashMap<String, String> sEnvTestData = getTestData();

            System.out.println("Environment Data:");
            sEnvTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));

            // Start browser
            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            // Fetch test data
            fnDefineQuery("Select * from ROB where TestCaseNo='TC_ROB_BUILDACCEPTANCE_007'");
            HashMap<String, String> sROBTestData = getTestData();

            System.out.println("Test Data:");

            sROBTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));


            // navigate to regular ROB login page
            System.out.println("Completing login");
			/*robRegTMXLogin.*/completeLogin(sROBTestData.get("userId"), sROBTestData.get("password"));

			// confirm login
			System.out.println("Confirming login");
			/*common.*/confirmLogin(sROBTestData.get("welcomeName"), sROBTestData.get("userId"));


			// confirm Quick Transfer widget
			System.out.println("Confirm Quick Transfer widget");
			/*quickTransfers.*/confirmQuickTransferWidgetAndComponents();

			// pre-load accounts for dropdowns
			System.out.println("Pre-load dorpdowns");
			/*quickTransfers.*/loadAccounts();

			// set From account
			System.out.println("set from account");
			/*quickTransfers.*/setFromAccount_QuickTransfer(sROBTestData.get("fromAccount"));

			// set To account
			System.out.println("Set to account");
			/*quickTransfers.*/setToAccount_QuickTransfer(sROBTestData.get("toAccount"));

			// set tomorrow's date
			System.out.println("Set tomorrow");
			/*quickTransfers.*/setDate();

			// set amount
			System.out.println("Set amount");
			/*quickTransfers.*/setAmount(sROBTestData.get("paymentAmount"));

			// click Go button
			System.out.println("Submit");
			/*quickTransfers.*/submit();

			// confirm submission
			System.out.println("Confirm submission");
			/*quickTransfers.*/confirmQuickTransferSubmission();

		} catch (Exception e) {
			fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
		}

	}

}
