package BOB.BuildAcceptance;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.santander.Base.TestBase;
import com.santander.Base.CustomAnnotations.RetryOnFailCount;
import com.santander.Enumerations.BOB.Common;
import com.santander.Enumerations.BOB.CustomerService;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

/**
 *
 * @author x923749
 *
 */
@Epic("BOB")
@Feature("Contact and Help Look and Feel")
public class Script09_CustomerService_ContactUsAndHelp extends TestBase  {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Customer Service Contact Us & Help", description="Customer service contact us and help page")
	@Severity(SeverityLevel.CRITICAL)
	@Description("Test Description: Customer has access to Contact us and Help page.")
	@Story("Customer Service Contact Us & Help.")
//	@Parameters({"testParam"})
	@RetryOnFailCount(2)
	public void Script09_CustomerService_ContactUsAndHelpTest(/*@Optional String testParam*/) {

		// navigate to regular ROB login page and login
		bobRegTMXLogin.completeLogin();

		// confirm login
		common.confirmLogin(runtimeData.welcomeName);

		// navigate to Customer Service
		common.navigateToMainTab(Common.Locator_Header_Button_CustomerServiceTab.toString(), Common.Locator_Header_Button_CustomerServiceTab_Active.toString());

		// confirm Account Services page
		customerService.confirmAccountServicesPage();

		// navigate to Contact Us & Help
		common.navigateToMainTab(CustomerService.Locator_LeftNav_Button_ContactUsAndHelp.toString(), CustomerService.Locator_LeftNav_Button_ContactUsAndHelp_Active.toString());

		//confirm page is at the contact us and help page
		customerService.confirmContactUsAndHelpPage();

	}

}
