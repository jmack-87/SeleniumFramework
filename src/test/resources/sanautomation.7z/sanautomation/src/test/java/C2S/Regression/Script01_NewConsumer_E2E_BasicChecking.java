package C2S.Regression;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;

import app_resources.c2s.c2sBusinessComponent;
import common_resources.utility;
import common_resources.custom_annotations.RetryOnFailCount;

public class Script01_NewConsumer_E2E_BasicChecking extends c2sBusinessComponent {

	/**
	 * @author x171065
	 *
	 * @param isSuiteRun (boolean) basically: send an email after execution as TestNG suite
	 * @param postToALM (boolean) flag to post to ALM
	 * @param closeBrowserAfterTest (boolean) flag to close browser
	 */
	@Test(testName="Script01_NewConsumer_E2E_BasicChecking", description="E2E from New consumer to created basic checking")
	@Parameters({"isSuiteRun", "postToALM", "closeBrowserAfterTest"})
	@RetryOnFailCount(0)
    public void Script01_NewConsumer_E2E_BasicCheckingTest(
    		@Optional boolean isSuiteRun,
			@Optional boolean postToALM,
			@Optional boolean closeBrowserAfterTest) {
    	
    	System.out.format("\tEmail?: %b%n\tALM?: %b%n\tCloseBrowser?: %b%n",
				isSuiteRun,
				postToALM,
				closeBrowserAfterTest);

		utility.isSuiteRun = isSuiteRun;
		utility.postToALM = postToALM;
		utility.closeBrowserAfterTest = closeBrowserAfterTest;
    	
        try {
            initialize_TestDataSheet("C2S.xls");
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            //Fetch test data
            HashMap<String, String> sEnvTestData = getTestData();

            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            fnDefineQuery("Select * from C2S where TestCaseNo='TC_C2S_001'");
            //Fetch test data
            HashMap<String, String> sC2STestData = getTestData();
            
            // Randomize some Customer Data to ensure Uniqueness
            randomizeInputDataConsumer(sC2STestData);
            
            System.out.println("Test Data:");

            sC2STestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));
            
            // Open ONE Application
            System.out.println(sEnvTestData.get("URL"));
            launchPage(sEnvTestData.get("URL"));

            // Log into ONE Application
            fnC2SLogin(sEnvTestData.get("Username"), 
            		sEnvTestData.get("Password"));
    		
    		// Search for customer by name
            searchRetailCustomer(sC2STestData.get("searchFirstName"), 
            		sC2STestData.get("searchLastName"));
    		
    		// Create the new prospect
            addProspect();
    		
    		// Fill in the form to create a prospect for a consumer
            enterProspectInformationConsumer(sC2STestData);
    		
    		// Get the F-Number for the new prospect
            getFNumberFromLandingPage();
    		
    		// Begin the process to add the checking account
            goToOpenAccounts();
    		
    		// Search by SSN for customer
            searchExistingCustomer(sC2STestData.get("documentNumber"));
    		
    		// Complete the personal data form
            completePersonalDataForm(sC2STestData.get("emailID"), 
            		sC2STestData.get("employer"), 
            		sC2STestData.get("State"), 
            		sC2STestData.get("documentNumber"));
    		
    		// Complete the Qualification Form
            passQualificationForm(sC2STestData.get("fNumber"), 
            		sC2STestData.get("documentNumber"), 
            		sC2STestData.get("contactNumber"), 
            		sC2STestData.get("employer"), 
            		sC2STestData.get("occupation"));
    		
    		// Choose Basic checking products
            chooseBasicChecking();
    		
    		// Complete Know Your Customer Form
            completeKYCForChecking();
    		
    		// Fake printing out the required documents
            printAllRequiredDocs(sC2STestData.get("searchFirstName"), 
            		sC2STestData.get("searchLastName"), 
            		sC2STestData.get("downloadPDFPath"));
    		
    		// Return to ONE portal to validate accounts created
            returnToONE();
    		
    		// Validate that the proper accounts were created on the one portal
            validateAccountsCreatedBasicChecking();

            
        }

        catch(Exception e){
        	
        	fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
			
        }

    }

}
