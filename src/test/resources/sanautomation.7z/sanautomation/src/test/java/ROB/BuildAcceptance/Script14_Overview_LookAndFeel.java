package ROB.BuildAcceptance;

import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import app_resources.rob.robBusinessComponent;
import app_resources.rob.pageObjects.Accounts;
import app_resources.rob.pageObjects.Common;
import common_resources.utility;
import common_resources.custom_annotations.RetryOnFailCount;

/**
 *
 * @author x923749
 *
 */
public class Script14_Overview_LookAndFeel extends robBusinessComponent {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Overview, Look and Feel", description="Overview, Look and Feel")
	@Parameters({"isSuiteRun", "postToALM", "closeBrowserAfterTest"})
	@RetryOnFailCount(0)
	public void Script14_Overview_LookAndFeelTest(
			@Optional Boolean isSuiteRun,
			@Optional Boolean postToALM,
			@Optional Boolean closeBrowserAfterTest) {

		utility.isSuiteRun = isSuiteRun == null ?  utility.isSuiteRun : isSuiteRun;
		utility.postToALM = postToALM == null ?  utility.postToALM : postToALM;
		utility.closeBrowserAfterTest = closeBrowserAfterTest == null ? utility.closeBrowserAfterTest : closeBrowserAfterTest;

		System.out.format("\tEmail?: %b%n\tALM?: %b%n\tCloseBrowser?: %b%n",
				isSuiteRun,
				postToALM,
				closeBrowserAfterTest);

		try {

            initialize_TestDataSheet("ROB.xls");

            // Fetch environment data
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            HashMap<String, String> sEnvTestData = getTestData();

            System.out.println("Environment Data:");
            sEnvTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));

            // Start browser
            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            // Fetch test data
            fnDefineQuery("Select * from ROB where TestCaseNo='TC_ROB_BUILDACCEPTANCE_014'");
            HashMap<String, String> sROBTestData = getTestData();

            System.out.println("Test Data:");

            sROBTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));


            // navigate to regular ROB login page
            System.out.println("Completing login");
			/*robRegTMXLogin.*/completeLogin(sROBTestData.get("userId"), sROBTestData.get("password"));

			// confirm login
			System.out.println("Confirming login");
			/*common.*/confirmLogin(sROBTestData.get("welcomeName"), sROBTestData.get("userId"));

			// navigate to Accounts
			System.out.println("Navigating to Accounts");
			/*common.*/navigateToMainTab(Common.Locator_Header_Button_AccountsTab, Common.Locator_Header_Button_AccountsTab_Active);

			// confirm left tabs
			System.out.println("Confirming active left navigation button");
			/*common.*/confirmActiveNavigationButton(Accounts.Locator_LeftNav_Button_OverviewTab_Active);
			System.out.println("Confirming left navigation");
			/*accounts.*/confirmLeftNavigation();

			// confirm ApplyOnlineNow links (PO, common to at least Customer Service)
			System.out.println("Confirming Apply Online widget");
			/*common.*/confirmApplyOnlineWidgetAndComponents();

			// confirm QuickTransfer presence (PO, common to at least Customer Service)
			System.out.println("Confirming Quick Transfer widget");
			/*quickTransfers.*/confirmQuickTransferWidgetAndComponents();

			// confirm print, help links (Overview)
			System.out.println("confirming help link");
			/*accounts.*/confirmPrintLink_Accounts();
			System.out.println("Confirming print link");
			/*accounts.*/confirmHelpWithThisPageLink();

			// confirm header HelpCenter, LogOut link, button (generic)
			System.out.println("Confirming help center link");
			/*common.*/confirmHelpCenterLink();
			System.out.println("Confirming logout button");
			/*common.*/confirmLogoutButton();

			// confirm content header
			System.out.println("Confirming header content");
			/*accounts.*/confirmContentHeader_Accounts();

			// confirm center content
			System.out.println("Confirming body content");
			/*accounts.*/confirmContentBody();

			// confirm content footer
			System.out.println("Confiring footer content");
			/*accounts.*/confirmContentFooter();

		} catch (Exception e) {
			fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
		}

	}

}
