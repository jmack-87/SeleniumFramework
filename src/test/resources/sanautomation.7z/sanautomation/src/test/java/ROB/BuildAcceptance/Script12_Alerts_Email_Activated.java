package ROB.BuildAcceptance;

import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import app_resources.rob.robBusinessComponent;
import app_resources.rob.pageObjects.Accounts;
import app_resources.rob.pageObjects.Common;
import common_resources.utility;
import common_resources.custom_annotations.RetryOnFailCount;

/**
 *
 * @author x923749
 *
 */
public class Script12_Alerts_Email_Activated extends robBusinessComponent {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Alerts Activation", description="Activate sms alerts in ROB")
	@Parameters({"isSuiteRun", "postToALM", "closeBrowserAfterTest"})
	@RetryOnFailCount(0)
	public void Script12_Alerts_Email_ActivatedTest(
			@Optional Boolean isSuiteRun,
			@Optional Boolean postToALM,
			@Optional Boolean closeBrowserAfterTest) {

		utility.isSuiteRun = isSuiteRun == null ?  utility.isSuiteRun : isSuiteRun;
		utility.postToALM = postToALM == null ?  utility.postToALM : postToALM;
		utility.closeBrowserAfterTest = closeBrowserAfterTest == null ? utility.closeBrowserAfterTest : closeBrowserAfterTest;

		System.out.format("\tEmail?: %b%n\tALM?: %b%n\tCloseBrowser?: %b%n",
				isSuiteRun,
				postToALM,
				closeBrowserAfterTest);

		try {

            initialize_TestDataSheet("ROB.xls");

            // Fetch environment data
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            HashMap<String, String> sEnvTestData = getTestData();

            System.out.println("Environment Data:");
            sEnvTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));

            // Start browser
            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            // Fetch test data
            fnDefineQuery("Select * from ROB where TestCaseNo='TC_ROB_BUILDACCEPTANCE_012'");
            HashMap<String, String> sROBTestData = getTestData();

            System.out.println("Test Data:");

            sROBTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));


            // navigate to regular ROB login page
            System.out.println("Completing login");
			/*robRegTMXLogin.*/completeLogin(sROBTestData.get("userId"), sROBTestData.get("password"));

			// confirm login
			System.out.println("Confirming login");
			/*common.*/confirmLogin(sROBTestData.get("welcomeName"), sROBTestData.get("userId"));

			// navigate to Accounts
            System.out.println("Navigating to Accounts");
			/*common.*/navigateToMainTab(Common.Locator_Header_Button_AccountsTab, Common.Locator_Header_Button_AccountsTab_Active);

			System.out.println("Navigating to Alerts");
			// navigate to alerts page
			/*common.*/navigateToMainTab(Accounts.Locator_LeftNav_Button_AlertsTab, Accounts.Locator_LeftNav_Button_AlertsTab_Active);

			// confirm elements on alerts page
			System.out.println("Confirming Alerts screen");
			/*alerts.*/confirmAlertsPage();

			// enable alerts for international transaction
			System.out.println("Turning on International transaction");
			/*alerts.*/enableInternationalTransactionAlert();

			// check if selected alert is correctly marked with check mark
			System.out.println("Confirming details screen");
			/*alerts.*/confirmDetails_Alerts();

			// alert changes on summary page
			System.out.println("Confirming summary screen");
			/*alerts.*/confirmSummaryPageUpdated();

			// tear down
			System.out.println("Reverting changes");
			/*alerts.*/revertChanges_Alerts();

		} catch (Exception e) {
			fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
		}

	}

}
