package BOB.BuildAcceptance;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.santander.Base.TestBase;
import com.santander.Base.CustomAnnotations.RetryOnFailCount;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

/**
 *
 * @author x923749
 *
 */
@Epic("BOB")
@Feature("Transfers Look and Feel")
public class Script07_Transfers_LookAndFeel extends TestBase {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Transfers Look & Feel", description="View the transfers page after logging into BOB")
	@Severity(SeverityLevel.CRITICAL)
	@Description("Verify elements on Transfers page.")
	@Story("Transfers page Look & Feel.")
//	@Parameters({"testParam"})
	@RetryOnFailCount(2)
	public void Script07_Transfers_LookAndFeelTest(/*@Optional String testParam*/) {

		// navigate to regular ROB login page and login
		bobRegTMXLogin.completeLogin();

		// confirm login
		common.confirmLogin(runtimeData.welcomeName);

		// confirm Quick Transfer widget
		quickTransfers.confirmQuickTransferWidgetAndComponents();

		// pre-load accounts for dropdowns
		quickTransfers.loadAccounts();

		// set From account
		quickTransfers.setFromAccount();

		// set To account
		quickTransfers.setToAccount();

		// set tomorrow's date
		quickTransfers.setDate();

		// set amount
		quickTransfers.setAmount();

		// click Go button
		quickTransfers.submit();

		// confirm submission
		quickTransfers.confirmQuickTransferSubmission();

	}

}
