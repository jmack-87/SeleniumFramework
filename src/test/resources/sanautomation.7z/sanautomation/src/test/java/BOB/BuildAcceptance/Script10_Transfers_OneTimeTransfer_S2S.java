package BOB.BuildAcceptance;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.santander.Base.TestBase;
import com.santander.Base.CustomAnnotations.RetryOnFailCount;
import com.santander.Enumerations.BOB.Common;
import com.santander.Enumerations.BOB.TransferFunds;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

/**
 *
 * @author x923749
 *
 */
@Epic("BOB")
@Feature("Transfers")
public class Script10_Transfers_OneTimeTransfer_S2S extends TestBase {

	/**
	 *
	 * @param testParam optional TestNG value from suite
	 */
	@Test(testName="Transfer Santander to Santander accounts", description="Transfer money between Santander accounts")
	@Severity(SeverityLevel.CRITICAL)
	@Description("Test Description: Transfer money between Santander accounts.")
	@Story("Transfer funds between Santander accounts.")
//	@Parameters({"testParam"})
	@RetryOnFailCount(2)
	public void Script10_Transfers_OneTimeTransfer_S2STest(/*@Optional String testParam*/) {

		// navigate to regular ROB login page and login
		bobRegTMXLogin.completeLogin();

		// confirm login
		common.confirmLogin(runtimeData.welcomeName);

		// navigate to transfer funds page
		common.navigateToMainTab(Common.Locator_Header_Button_TransferTab.toString(), Common.Locator_Header_Button_TransferTab_Active.toString());

		// confirm Transfer Funds page of Transfers tab
		transferFunds.confirmTransferFundsPage();

			transferFunds.setFromAccount(TransferFunds.Text_Checking.toString());
			// [NEGATIVE] check error condition: No To Account
			transferFunds.checkErrorCondition(TransferFunds.Text_NoToAccountError.toString());

			// [NEGATIVE] check error condition: No Amount
			transferFunds.setToAccount(TransferFunds.Text_Saving.toString());
			transferFunds.checkErrorCondition(TransferFunds.Text_EnterTransferAmountError.toString());

			// [NEGATIVE] check error condition: No Amount
			transferFunds.enterTransferAmount();
			transferFunds.checkErrorCondition(TransferFunds.Text_TransferAmountGreaterThanAvailableBalanceError.toString());

		// select transfer account to transfer from
		transferFunds.setFromAccount(TransferFunds.Text_Checking.toString());

		// select transfer account to transfer to
		transferFunds.setToAccount(TransferFunds.Text_Saving.toString());

		// enter transfer amount
		transferFunds.enterTransferAmount();

		// select frequency
		transferFunds.setTransferFrequency(TransferFunds.Text_Frequency_OneTime.toString());

		// click continue and confirm details
		transferFunds.submitTransfer();

		// click and verify confirm details
		transferFunds.confirmTransfer();

		// view details on summary page
		transferFunds.confirmSummaryPage();

	}


}
