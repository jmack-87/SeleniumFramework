package ROB.BuildAcceptance;

import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import app_resources.rob.robBusinessComponent;
import common_resources.utility;
import common_resources.custom_annotations.RetryOnFailCount;


/**
 *
 * @author x923749
 *
 */
public class Script02_Login_RegularLogin extends robBusinessComponent {


	/**
	 * @author x923749
	 *
	 * @param isSuiteRun (boolean) basically: send an email after execution as TestNG suite
	 * @param postToALM (boolean) flag to post to ALM
	 * @param closeBrowserAfterTest (boolean) flag to close browser
	 */
	@Test(testName="ROB ThreatMetrix Login", description="Login to ROB.")
	@Parameters({"isSuiteRun", "postToALM", "closeBrowserAfterTest"})
	@RetryOnFailCount(1)
	public void Script02_Login_RegularLoginTest(
			@Optional Boolean isSuiteRun,
			@Optional Boolean postToALM,
			@Optional Boolean closeBrowserAfterTest) {

		utility.isSuiteRun = isSuiteRun == null ?  utility.isSuiteRun : isSuiteRun;
		utility.postToALM = postToALM == null ?  utility.postToALM : postToALM;
		utility.closeBrowserAfterTest = closeBrowserAfterTest == null ? utility.closeBrowserAfterTest : closeBrowserAfterTest;

		System.out.format("\tEmail?: %b%n\tALM?: %b%n\tCloseBrowser?: %b%n",
				isSuiteRun,
				postToALM,
				closeBrowserAfterTest);

		try {

            initialize_TestDataSheet("ROB.xls");

            // Fetch environment data
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            HashMap<String, String> sEnvTestData = getTestData();

            System.out.println("Environment Data:");
            sEnvTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));

            // Start browser
            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            // Fetch test data
            fnDefineQuery("Select * from ROB where TestCaseNo='TC_ROB_BUILDACCEPTANCE_002'");
            HashMap<String, String> sROBTestData = getTestData();

            System.out.println("Test Data:");

            sROBTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));


			// launch custom ThreatMetrix login page
            System.out.println("Launching app");
			/*robRegTMXLogin.*/launchPage(sEnvTestData.get("URL"));

			// set user name
			System.out.println("Setting user id");
			/*robRegTMXLogin.*/setUserName(sROBTestData.get("userId"));

			// set password
			System.out.println("Setting password");
			/*robRegTMXLogin.*/setPassword(sROBTestData.get("password"));

			// submit form
			System.out.println("Submitting login");
			/*robRegTMXLogin.*/submitLogin();

			// confirm santander logo image
			System.out.println("Checking logo image");
			/*common.*/confirmLogoPresence();

			// confirm user name match
			System.out.println("Checking Welcome message name");
			/*common.*/confirmUserName(sROBTestData.get("welcomeName"));

			//confirm last login date
			System.out.println("Checking last login date pattern");
			/*common.*/confirmLastLoginDatePattern();

			// confirm last login date-time (DB query required)
			System.out.println("Checking last login date-time");
			/*common.*/confirmLastLoginDateTime(sROBTestData.get("userId"));

			// confirm logon destination
			System.out.println("Checking active nav buttons");
			/*robRegTMXLogin.*/confirmDefaultPage();

		} catch (Exception e) {
			fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
		}

	}


}
