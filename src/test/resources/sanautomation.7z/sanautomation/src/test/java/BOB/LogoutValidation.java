package BOB;

import app_resources.rob.pageObjects.*;
import app_resources.rob.robBusinessComponent;
import org.testng.annotations.Test;

import java.util.HashMap;

public class LogoutValidation extends robBusinessComponent {

    @Test
    public void logoutvalidation_1_0() {
        try {
            initialize_TestDataSheet("ROB.xls");
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            //Fetch test data
            HashMap<String, String> sEnvTestData = getTestData();

            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            fnDefineQuery("Select * from ROB where TestCaseNo='TC_ROB_001'");
            //Fetch test data
            HashMap<String, String> sROBTestData = getTestData();

            fnROBLogin(sROBTestData.get("userId"),sROBTestData.get("password"));

            String Title = fnGetText(LoginPage.verificationText).toLowerCase();

            if(Title.contains(sROBTestData.get("welcomeName").toLowerCase()))
                fnReportLog("Passed", "Login", "Successfully LoggedIn",false);
            else
                fnReportLog("Failed", "Login", "Not able to Successfully LoggedIn",true);

            Boolean lg = fnROBLogout();

            if (lg = true)
                fnReportLog("Passed", "Logout", "Successfully LoggedOut",false);
            else
                fnReportLog("Failed", "Logout", "Not able to Successfully LoggedOut",true);

        }

        catch(Exception e){
            fnReportLog("Failed","Exception occurred at ", e.getMessage() , true, e.getLocalizedMessage());
        }

    }

}
