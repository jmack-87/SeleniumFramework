package BOB.BuildAcceptance;

import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import app_resources.bob.robBusinessComponent;
import app_resources.bob.pageObjects.BillPay;
import app_resources.bob.pageObjects.Common;
import common_resources.utility;
import common_resources.custom_annotations.RetryOnFailCount;


/**
 *
 * @author x923749
 *
 */
public class Script05_BillPay_MakeAPayment extends bobBusinessComponent {

	/**
	 * @author x923749
	 *
	 * @param isSuiteRun (boolean) basically: send an email after execution as TestNG suite
	 * @param postToALM (boolean) flag to post to ALM
	 * @param closeBrowserAfterTest (boolean) flag to close browser
	 */
	@Test(testName="Make A Payment.", description="Make A Payment.")
	@Parameters({"isSuiteRun", "postToALM", "closeBrowserAfterTest"})
	@RetryOnFailCount(1)
	public void Script05_BillPay_MakeAPaymentTest(
			@Optional boolean isSuiteRun,
			@Optional boolean postToALM,
			@Optional boolean closeBrowserAfterTest) {

		System.out.format("\tEmail?: %b%n\tALM?: %b%n\tCloseBrowser?: %b%n",
				isSuiteRun,
				postToALM,
				closeBrowserAfterTest);

		utility.isSuiteRun = isSuiteRun;
		utility.postToALM = postToALM;
		utility.closeBrowserAfterTest = closeBrowserAfterTest;

		try {

            initialize_TestDataSheet("BOB.xls");

            // Fetch environment data
            fnDefineQuery("Select * from ENV_Details where Is_Required='Y'");
            HashMap<String, String> sEnvTestData = getTestData();

            System.out.println("Environment Data:");
            sEnvTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));

            // Start browser
            fnInvokeBrowser(sEnvTestData.get("Browser"), sEnvTestData.get("URL"));

            // Fetch test data
            fnDefineQuery("Select * from BOB where TestCaseNo='TC_BOB_BUILDACCEPTANCE_005'");
            HashMap<String, String> sBOBTestData = getTestData();

            System.out.println("Test Data:");

            sBOBTestData.forEach((k,v)-> System.out.format("\t%s:%s%n", k, v));


			// navigate to regular ROB login page
			/*bobRegTMXLogin.*/completeLogin(sBOBTestData.get("userId"), sBOBTestData.get("password"));

			// confirm login
			/*common.*/confirmLogin(sBOBTestData.get("welcomeName"), sBOBTestData.get("userId"));

			// navigate to BillPay
			/*common.*/navigateToMainTab(Common.Locator_Header_Button_BillPayTab, BillPay.Locator_Header_Button_BillPayTab_Active);

			// confirm BillPay test region screen, proceed
			/*billPay.*/confirmAndEnterTestRegion();

			// confirm left nav (including title)
			/*billPay.*/confirmLeftNavigation();
			/*common.*/confirmActiveNavigationButton(BillPay.Locator_LeftNav_Button_PaymentCenter_Active);

			// confirm Payment Center right accordions
			/*billPay.*/confirmRightAccordions(); // empty method

			// confirm Payment Center body
			/*billPay.*/confirmContentBody();

			// enter data
			/*billPay.*/submitPaymentToFirstPayee(sBOBTestData.get("paymentAmount"));

			//TODO: cancel? (probably not necessary)

		} catch (Exception e) {
			fnReportLog("FAILED", "Exception occurred at: ", e.getLocalizedMessage(), true);
			ss.fail("FAILED by generic exception.");
		}


	}

}
